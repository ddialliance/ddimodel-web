using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the delimiter used to separate variables in a delimited record. Valid values include, space, tab, comma, semicolon, colon, pipe, and other. If "other" is used the characters used for separating (delimiting) objects should be entered in the attribute otherValue. Spaces and binary characters are not allowed. The attribute treatConsecutiveDelimiterAsOne indicates how consecutive delimiters should be handed by the software. The default value of "false" indicates that each delimiter should be treated as a valid delimiter.
    /// <summary>
    public partial class DelimiterType : SpecifiedDelimiterType
    {
        /// <summary>
        /// When the value of Delimiter is "other" provide the character used for delimiting values here. Spaces and binary values are not allowed.
        /// <summary>
        public string OtherValue { get; set; }
        /// <summary>
        /// Defines the default value for the delimiter used to separate variables in a delimited record. The attribute treatConsecutiveDelimiterAsOne indicates how consecutive delimiters should be handed by the software.
        /// <summary>
        public bool TreatConsecutiveDelimiterAsOne { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("SpecifiedDelimiterType").Descendants())
            {
                xEl.Add(el);
            }
            if (OtherValue != null)
            {
                xEl.Add(new XElement(ns + "OtherValue", OtherValue));
            }
            xEl.Add(new XElement(ns + "TreatConsecutiveDelimiterAsOne", TreatConsecutiveDelimiterAsOne));
            return xEl;
        }
    }
}

