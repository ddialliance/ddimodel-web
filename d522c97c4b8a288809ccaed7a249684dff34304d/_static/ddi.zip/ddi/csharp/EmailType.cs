using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Email address type (Currently restricted to Internet format user@server.ext.).
    /// <summary>
    public partial class EmailType
    {
        /// <summary>
        /// The email address express as a string (restricted to the Internet format).
        /// <summary>
        [StringValidation(null, @"([\.a-zA-Z0-9_\-])+@([a-zA-Z0-9_\-])+(([a-zA-Z0-9_\-])*\.([a-zA-Z0-9_\-])+)+")]
        public string InternetEmail { get; set; }
        /// <summary>
        /// Code indicating the type of e-mail address. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType EmailTypeCode { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (InternetEmail != null)
            {
                xEl.Add(new XElement(ns + "InternetEmail", InternetEmail));
            }
            if (EmailTypeCode != null) { xEl.Add(EmailTypeCode.ToXml("EmailTypeCode")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            return xEl;
        }
    }
}

