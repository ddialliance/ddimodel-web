using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes both minimum and preferred language abilities sought for the translation work as a set of source and target language requirements.
    /// <summary>
    public partial class TranslationMethodType
    {
        /// <summary>
        /// Specifies the type of translation method used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfTranslationMethod { get; set; }
        /// <summary>
        /// Description of the translation method. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfTranslationMethod != null) { xEl.Add(TypeOfTranslationMethod.ToXml("TypeOfTranslationMethod")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

