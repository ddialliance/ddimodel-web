using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the version information for the data file related to this physical instance. Note that while Physical Instance allows for multiple copies of the same data file (such as backup copies) the assumption is that they are identical in terms of content, layout, format and version. The minimum information required is the versionNumber. Additional information on the versionDate, the type of version number when multiple types are supported by an agency, as well as information on VersionResponsibility (inline or by reference) and VersionRationale are available to provide additional information for process tracking and/or informing users of the differences between this and the previous version of the file.
    /// <summary>
    public partial class DataFileVersionType
    {
        /// <summary>
        /// This is the name of the versioning scheme as defined by the user's system, in cases where the user's system employs more than one versioning scheme.
        /// <summary>
        public string TypeOfVersionNumber { get; set; }
        /// <summary>
        /// Person or organization within the MaintenanceAgency responsible for the version change. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, it may be included in this notation. This is primarily intended for internal use.
        /// <summary>
        public string VersionResponsibility { get; set; }
        /// <summary>
        /// Reference person or organization within the MaintenanceAgency responsible for the version change, as described in an OrganizationScheme. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, a Relation should be created between the individual referenced here and his/her organization. This is primarily intended for internal use.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent VersionResponsibilityReference { get; set; }
        /// <summary>
        /// Textual description of the rationale/purpose for a version change.
        /// <summary>
        public VersionRationaleType VersionRationale { get; set; }
        /// <summary>
        /// The version number of the data file identified by this physical instance.
        /// <summary>
        public string VersionNumber { get; set; }
        /// <summary>
        /// Date of version using the union set BaseDateType. Duration should not be used in this field, even though allowed by the ISO format enforced by the parser.
        /// <summary>
        public CogsDate VersionDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfVersionNumber != null)
            {
                xEl.Add(new XElement(ns + "TypeOfVersionNumber", TypeOfVersionNumber));
            }
            if (VersionResponsibility != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibility", VersionResponsibility));
            }
            if (VersionResponsibilityReference != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibilityReference", 
                    new XElement(ns + "URN", VersionResponsibilityReference.URN), 
                    new XElement(ns + "Agency", VersionResponsibilityReference.Agency), 
                    new XElement(ns + "ID", VersionResponsibilityReference.ID), 
                    new XElement(ns + "Version", VersionResponsibilityReference.Version), 
                    new XElement(ns + "TypeOfObject", VersionResponsibilityReference.GetType().Name)));
            }
            if (VersionRationale != null) { xEl.Add(VersionRationale.ToXml("VersionRationale")); }
            if (VersionNumber != null)
            {
                xEl.Add(new XElement(ns + "VersionNumber", VersionNumber));
            }
            if (VersionDate != null && VersionDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "VersionDate", VersionDate.ToString()));
            }
            return xEl;
        }
    }
}

