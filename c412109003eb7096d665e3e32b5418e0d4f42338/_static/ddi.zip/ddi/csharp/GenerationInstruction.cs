using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Processing instructions for recodes, derivations from multiple question or variable sources, and derivations based on external sources. Instructions should be listed separately so they can be referenced individually.
    /// <summary>
    public partial class GenerationInstruction : ProcessingInstruction
    {
        /// <summary>
        /// Reference to a question used in the instruction. Allows the designation of an Alias used by the instruction. TypeOfObject should be set to QuestionItem or QuestionGrid.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Question> InputQuestionReference { get; set; } = new List<Question>();
        public bool ShouldSerializeInputQuestionReference() { return InputQuestionReference.Count > 0; }
        /// <summary>
        /// Reference to a Measurement used in the instruction. Allows the designation of an Alias used by the instruction. TypeOfObject should be set to MeasurementItem.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementItem> InputMeasurementReference { get; set; } = new List<MeasurementItem>();
        public bool ShouldSerializeInputMeasurementReference() { return InputMeasurementReference.Count > 0; }
        /// <summary>
        /// Reference to a variable used in the coding process. Allows the designation of an Alias used by the instruction. TypeOfObject should be set to Variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> InputVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeInputVariableReference() { return InputVariableReference.Count > 0; }
        /// <summary>
        /// Reference to an external source of information used in the coding process, for example a value from a chart, etc.
        /// <summary>
        public List<ExternalInformationType> ExternalInformation { get; set; } = new List<ExternalInformationType>();
        public bool ShouldSerializeExternalInformation() { return ExternalInformation.Count > 0; }
        /// <summary>
        /// A description of the generation instruction. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Structured information used by a system to process the instruction.
        /// <summary>
        public List<CommandCodeType> CommandCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeCommandCode() { return CommandCode.Count > 0; }
        /// <summary>
        /// A control construct which is used to describe or process the instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }
        /// <summary>
        /// Describes the aggregation process, identifying both the independent and dependent variables within the process.
        /// <summary>
        public AggregationType Aggregation { get; set; }
        /// <summary>
        /// Default setting is "true", the instruction describes a derivation. If the instruction is a simple recode, set to "false".
        /// <summary>
        public bool IsDerived { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "GenerationInstruction");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (InputQuestionReference != null && InputQuestionReference.Count > 0)
            {
                foreach (var item in InputQuestionReference)
                {
                    xEl.Add(new XElement(ns + "InputQuestionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InputMeasurementReference != null && InputMeasurementReference.Count > 0)
            {
                foreach (var item in InputMeasurementReference)
                {
                    xEl.Add(new XElement(ns + "InputMeasurementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InputVariableReference != null && InputVariableReference.Count > 0)
            {
                foreach (var item in InputVariableReference)
                {
                    xEl.Add(new XElement(ns + "InputVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalInformation != null && ExternalInformation.Count > 0)
            {
                foreach (var item in ExternalInformation)
                {
                    xEl.Add(item.ToXml("ExternalInformation"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CommandCode != null && CommandCode.Count > 0)
            {
                foreach (var item in CommandCode)
                {
                    xEl.Add(item.ToXml("CommandCode"));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Aggregation != null) { xEl.Add(Aggregation.ToXml("Aggregation")); }
            xEl.Add(new XElement(ns + "IsDerived", IsDerived));
            return xEl;
        }
    }
}

