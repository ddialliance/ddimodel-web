using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A ControlConstruct that provides a sequence order within Sampling Stages expressed as control constructs.
    /// <summary>
    public partial class SamplingStage : ControlConstruct
    {
        /// <summary>
        /// Provides the ability to "type" a sequence for classification or processing purposes. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfSequence { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfSequence() { return TypeOfSequence.Count > 0; }
        /// <summary>
        /// References control constructs in the order that they should appear within the instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }
        /// <summary>
        /// Describes alternate ordering for different cases using the SpecificSequence structure. If you set the sequence to anything other than order of appearance the only allowable children are QuestionConstruct or Sequence. Contents must be randomizable.
        /// <summary>
        public SpecificSequenceType ConstructSequence { get; set; }
        /// <summary>
        /// Describes the minimum requirements of the frame needed to use this sample stage. For example, if a stratification by age is specified in the stage the sample frame would need to support this stratification.
        /// <summary>
        public StructuredStringType FrameRequirements { get; set; }
        /// <summary>
        /// Identifies a specific sample frame or frames appropriate for this plan.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> RecommendedSampleFrameReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeRecommendedSampleFrameReference() { return RecommendedSampleFrameReference.Count > 0; }
        /// <summary>
        /// A distinct "strata" within a population used to define a group to be sampled within that population, for example an Income Level or Postal Code.
        /// <summary>
        public List<StratificationType> Stratification { get; set; } = new List<StratificationType>();
        public bool ShouldSerializeStratification() { return Stratification.Count > 0; }
        /// <summary>
        /// Sampling unit for this stage
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public UnitType SamplingUnitReference { get; set; }
        /// <summary>
        /// If known and available, provide the selection probability for each sampling unit.  This is one number for equal probability sampling, such as SRS.  For PPS, a description of the size criterion is needed.  For other unequal designs, a description of of how the probabilities are assigned is needed.
        /// <summary>
        public StructuredStringType SelectionProbability { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingStage");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSequence != null && TypeOfSequence.Count > 0)
            {
                foreach (var item in TypeOfSequence)
                {
                    xEl.Add(item.ToXml("TypeOfSequence"));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConstructSequence != null) { xEl.Add(ConstructSequence.ToXml("ConstructSequence")); }
            if (FrameRequirements != null) { xEl.Add(FrameRequirements.ToXml("FrameRequirements")); }
            if (RecommendedSampleFrameReference != null && RecommendedSampleFrameReference.Count > 0)
            {
                foreach (var item in RecommendedSampleFrameReference)
                {
                    xEl.Add(new XElement(ns + "RecommendedSampleFrameReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Stratification != null && Stratification.Count > 0)
            {
                foreach (var item in Stratification)
                {
                    xEl.Add(item.ToXml("Stratification"));
                }
            }
            if (SamplingUnitReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingUnitReference", 
                    new XElement(ns + "URN", SamplingUnitReference.URN), 
                    new XElement(ns + "Agency", SamplingUnitReference.Agency), 
                    new XElement(ns + "ID", SamplingUnitReference.ID), 
                    new XElement(ns + "Version", SamplingUnitReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingUnitReference.GetType().Name)));
            }
            if (SelectionProbability != null) { xEl.Add(SelectionProbability.ToXml("SelectionProbability")); }
            return xEl;
        }
    }
}

