using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the BaseRecordLayout substitution group intended for use when the data items of an NCube Instances are captured in-line within the metadata instance. In addition to the link to the PhysicalStructure provided by BaseRecordLayout, the record layout is this namespace (m2) identifies the array base for the in-line data, a full description of each data item contained within an NCube Instance including a link to its description (matrix address) and contained values.
    /// <summary>
    public partial class InLineNCubeRecordLayout : BaseRecordLayout
    {
        /// <summary>
        /// Sets the array base for any arrays used in the definition (that is, whether the first value is in position 0 or 1, etc.). This may be the data array in a delimited data file or the measure array for measures that are bundled and stored in a single location. Array base is generally set to either 0 or 1. There is no override provided as systems processing a record would use a consistent array base.
        /// <summary>
        public int ArrayBase { get; set; }
        /// <summary>
        /// A container for defining an instance of an NCube, indicating the matrix address of each cell and capturing the data for each measure within a cell of the NCube is stored. Allows specifying the values of the attributes attached to a NCube.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeInstanceI> NCubeInstanceIReference { get; set; } = new List<NCubeInstanceI>();
        public bool ShouldSerializeNCubeInstanceIReference() { return NCubeInstanceIReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "InLineNCubeRecordLayout");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "ArrayBase", ArrayBase));
            if (NCubeInstanceIReference != null && NCubeInstanceIReference.Count > 0)
            {
                foreach (var item in NCubeInstanceIReference)
                {
                    xEl.Add(new XElement(ns + "NCubeInstanceIReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

