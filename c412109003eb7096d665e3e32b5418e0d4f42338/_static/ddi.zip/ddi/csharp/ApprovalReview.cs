using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides information about the Approval Review undertaken in relation to the activity. Identifies the organization processing the review, the role of the approval review organization, case number, description, and related dates. Allows the inclusion of a reference to an external source detailing the approval review.
    /// <summary>
    public partial class ApprovalReview : Versionable
    {
        /// <summary>
        /// A brief identification of the type of approval review such as IRB, ethical, compliance, etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfApprovalReview { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfApprovalReview() { return TypeOfApprovalReview.Count > 0; }
        /// <summary>
        /// Reference to an existing identifiable object using the Reference structure.  TypeOfObject should be set to any Versionable or Maintainable object.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Versionable> ReviewObjectReference { get; set; } = new List<Versionable>();
        public bool ShouldSerializeReviewObjectReference() { return ReviewObjectReference.Count > 0; }
        /// <summary>
        /// Reference to an organization or individual, that provided the approval review. TypeOfObject should be set to Organization.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> AgencyOrganizationReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeAgencyOrganizationReference() { return AgencyOrganizationReference.Count > 0; }
        /// <summary>
        /// Role of the reviewing organization or individual. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType ReviewerRole { get; set; }
        /// <summary>
        /// The reference or case identification of the review. Used to specify or track the case by the review organization
        /// <summary>
        public List<string> ReferenceIdentifier { get; set; } = new List<string>();
        public bool ShouldSerializeReferenceIdentifier() { return ReferenceIdentifier.Count > 0; }
        /// <summary>
        /// Description of the approval review which can include requirements for the review, contents, or results.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Link to a document related to the ethical review using the OtherMaterial structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public OtherMaterial ApprovalReviewDocumentReference { get; set; }
        /// <summary>
        /// Date materials submitted for approval review.
        /// <summary>
        public DateType ApplicationDate { get; set; }
        /// <summary>
        /// Date approval received from approval review organization.
        /// <summary>
        public DateType ApprovalDate { get; set; }
        /// <summary>
        /// Period for which the approval is valid. This may be a start date, and end date, or range specified as a start and end date.
        /// <summary>
        public DateType ApprovedPeriod { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ApprovalReview");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfApprovalReview != null && TypeOfApprovalReview.Count > 0)
            {
                foreach (var item in TypeOfApprovalReview)
                {
                    xEl.Add(item.ToXml("TypeOfApprovalReview"));
                }
            }
            if (ReviewObjectReference != null && ReviewObjectReference.Count > 0)
            {
                foreach (var item in ReviewObjectReference)
                {
                    xEl.Add(new XElement(ns + "ReviewObjectReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (AgencyOrganizationReference != null && AgencyOrganizationReference.Count > 0)
            {
                foreach (var item in AgencyOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "AgencyOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ReviewerRole != null) { xEl.Add(ReviewerRole.ToXml("ReviewerRole")); }
            if (ReferenceIdentifier != null && ReferenceIdentifier.Count > 0)
            {
                xEl.Add(
                    from item in ReferenceIdentifier
                    select new XElement(ns + "ReferenceIdentifier", item.ToString()));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ApprovalReviewDocumentReference != null)
            {
                xEl.Add(new XElement(ns + "ApprovalReviewDocumentReference", 
                    new XElement(ns + "URN", ApprovalReviewDocumentReference.URN), 
                    new XElement(ns + "Agency", ApprovalReviewDocumentReference.Agency), 
                    new XElement(ns + "ID", ApprovalReviewDocumentReference.ID), 
                    new XElement(ns + "Version", ApprovalReviewDocumentReference.Version), 
                    new XElement(ns + "TypeOfObject", ApprovalReviewDocumentReference.GetType().Name)));
            }
            if (ApplicationDate != null) { xEl.Add(ApplicationDate.ToXml("ApplicationDate")); }
            if (ApprovalDate != null) { xEl.Add(ApprovalDate.ToXml("ApprovalDate")); }
            if (ApprovedPeriod != null) { xEl.Add(ApprovedPeriod.ToXml("ApprovedPeriod")); }
            return xEl;
        }
    }
}

