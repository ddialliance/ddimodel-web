using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a stack of links from the LocalAddedContent to the Depository content and provides instructions regarding the relationship between the local added content and the deposited content.
    /// <summary>
    public partial class ContentLinkingMapType
    {
        /// <summary>
        /// Provides a link from a local object to a deposited object via reference and designates if the added material should Override, act as AddedContent, or DeleteContent in the original deposited material.
        /// <summary>
        public List<LinkingMapType> LinkingMap { get; set; } = new List<LinkingMapType>();
        public bool ShouldSerializeLinkingMap() { return LinkingMap.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (LinkingMap != null && LinkingMap.Count > 0)
            {
                foreach (var item in LinkingMap)
                {
                    xEl.Add(item.ToXml("LinkingMap"));
                }
            }
            return xEl;
        }
    }
}

