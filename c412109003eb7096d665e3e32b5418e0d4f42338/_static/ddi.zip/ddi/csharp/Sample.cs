using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a sample created by the implementation of a sample plan.
    /// <summary>
    public partial class Sample : Versionable
    {
        /// <summary>
        /// A generic means of classifying a SamplingProcedure. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfSample { get; set; }
        /// <summary>
        /// A name for the sample. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SampleName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSampleName() { return SampleName.Count > 0; }
        /// <summary>
        /// A display label for the sample. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Full description of the sample. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describe the population being sampled through a combination of textual description and reference to a structured Universe.
        /// <summary>
        public List<PopulationType> PopulationOfConcern { get; set; } = new List<PopulationType>();
        public bool ShouldSerializePopulationOfConcern() { return PopulationOfConcern.Count > 0; }
        /// <summary>
        /// The target value of the sample size for the primary and any secondary or sub-population.
        /// <summary>
        public List<PopulationSizeType> OverallTargetSampleSize { get; set; } = new List<PopulationSizeType>();
        public bool ShouldSerializeOverallTargetSampleSize() { return OverallTargetSampleSize.Count > 0; }
        /// <summary>
        /// The size of the overall sample actually used.
        /// <summary>
        public SizeType OverallSampleSize { get; set; }
        /// <summary>
        /// Provides sample stage level details where needed. Repeat for individual stages or sub-stages.
        /// <summary>
        public List<ApplicationDetailsType> ApplicationDetails { get; set; } = new List<ApplicationDetailsType>();
        public bool ShouldSerializeApplicationDetails() { return ApplicationDetails.Count > 0; }
        /// <summary>
        /// Date the sample was taken. May be expressed as a single date or range. If the sample was created using multiple extractions at different dates, repeat for each date.
        /// <summary>
        public List<DateType> DateOfSample { get; set; } = new List<DateType>();
        public bool ShouldSerializeDateOfSample() { return DateOfSample.Count > 0; }
        /// <summary>
        /// Description of general limitations of the frame, including  over/under-coverage and update schedules and procedures.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterial> SampleLocationReference { get; set; } = new List<OtherMaterial>();
        public bool ShouldSerializeSampleLocationReference() { return SampleLocationReference.Count > 0; }
        /// <summary>
        /// A reference to the SamplingPlan implemented to creating the sample. Target object should be SamplingPlan
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingPlan> SamplingPlanImplementedReference { get; set; } = new List<SamplingPlan>();
        public bool ShouldSerializeSamplingPlanImplementedReference() { return SamplingPlanImplementedReference.Count > 0; }
        /// <summary>
        /// A reference to the SampleFrame used for creating the sample. Target object should be SampleFrame
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> SampleFrameUsedReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeSampleFrameUsedReference() { return SampleFrameUsedReference.Count > 0; }
        /// <summary>
        /// A reference to a previously created sample that was used as a component of the current sample. Target object should be Sample.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Sample> ComponentSampleReference { get; set; } = new List<Sample>();
        public bool ShouldSerializeComponentSampleReference() { return ComponentSampleReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Sample");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSample != null) { xEl.Add(TypeOfSample.ToXml("TypeOfSample")); }
            if (SampleName != null && SampleName.Count > 0)
            {
                foreach (var item in SampleName)
                {
                    xEl.Add(item.ToXml("SampleName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (PopulationOfConcern != null && PopulationOfConcern.Count > 0)
            {
                foreach (var item in PopulationOfConcern)
                {
                    xEl.Add(item.ToXml("PopulationOfConcern"));
                }
            }
            if (OverallTargetSampleSize != null && OverallTargetSampleSize.Count > 0)
            {
                foreach (var item in OverallTargetSampleSize)
                {
                    xEl.Add(item.ToXml("OverallTargetSampleSize"));
                }
            }
            if (OverallSampleSize != null) { xEl.Add(OverallSampleSize.ToXml("OverallSampleSize")); }
            if (ApplicationDetails != null && ApplicationDetails.Count > 0)
            {
                foreach (var item in ApplicationDetails)
                {
                    xEl.Add(item.ToXml("ApplicationDetails"));
                }
            }
            if (DateOfSample != null && DateOfSample.Count > 0)
            {
                foreach (var item in DateOfSample)
                {
                    xEl.Add(item.ToXml("DateOfSample"));
                }
            }
            if (SampleLocationReference != null && SampleLocationReference.Count > 0)
            {
                foreach (var item in SampleLocationReference)
                {
                    xEl.Add(new XElement(ns + "SampleLocationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingPlanImplementedReference != null && SamplingPlanImplementedReference.Count > 0)
            {
                foreach (var item in SamplingPlanImplementedReference)
                {
                    xEl.Add(new XElement(ns + "SamplingPlanImplementedReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleFrameUsedReference != null && SampleFrameUsedReference.Count > 0)
            {
                foreach (var item in SampleFrameUsedReference)
                {
                    xEl.Add(new XElement(ns + "SampleFrameUsedReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ComponentSampleReference != null && ComponentSampleReference.Count > 0)
            {
                foreach (var item in ComponentSampleReference)
                {
                    xEl.Add(new XElement(ns + "ComponentSampleReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

