using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Information on a specific data collection event including details on who was involved in data collection, the source of the data, the date and frequency of collection, mode of collection, identification of the instrument used for collection, information on the actual situation under which data was collected, actions taken to minimize loss of data, and reference to a quality standard or statement regarding the handling of the data collection process during this event.
    /// <summary>
    public partial class CollectionEventType : IdentifiableType
    {
        /// <summary>
        /// A name for the Collection Event. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> CollectionEventName { get; set; } = new List<NameType>();
        public bool ShouldSerializeCollectionEventName() { return CollectionEventName.Count > 0; }
        /// <summary>
        /// A display label for the Collection Event. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the Collection Event. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for the data collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> DataCollectorOrganizationReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeDataCollectorOrganizationReference() { return DataCollectorOrganizationReference.Count > 0; }
        /// <summary>
        /// Describes a source of the data.
        /// <summary>
        public List<DataSourceType> DataSource { get; set; } = new List<DataSourceType>();
        public bool ShouldSerializeDataSource() { return DataSource.Count > 0; }
        /// <summary>
        /// Provides a date or range of dates for the described data collection event as well as  a cycle number when the collection is part of a series of data collection events.
        /// <summary>
        public DateType DataCollectionDate { get; set; }
        /// <summary>
        /// Documents the intended frequency of data collection, for example monthly, yearly, weekly, etc., preferably using an optional controlled vocabulary in the IntendedFrequency element. Date of first collection should be provided in StartDate as a basis for defining periodicity. EndDate should be entered for data collection cycles with a known or anticipated end date. EndDate is omitted in data collection series that are intended to be on-going.
        /// <summary>
        public List<DataCollectionFrequencyType> DataCollectionFrequency { get; set; } = new List<DataCollectionFrequencyType>();
        public bool ShouldSerializeDataCollectionFrequency() { return DataCollectionFrequency.Count > 0; }
        /// <summary>
        /// Describes the mode of data collection.
        /// <summary>
        public List<ModeOfCollectionType> ModeOfCollection { get; set; } = new List<ModeOfCollectionType>();
        public bool ShouldSerializeModeOfCollection() { return ModeOfCollection.Count > 0; }
        /// <summary>
        /// References the instrument or instruments used during the process of collecting data for this collection event period.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Instrument> InstrumentReference { get; set; } = new List<Instrument>();
        public bool ShouldSerializeInstrumentReference() { return InstrumentReference.Count > 0; }
        /// <summary>
        /// Describes the situation in which the data collection event takes place. If a number of collection situation types occurred repeat this element.
        /// <summary>
        public List<CollectionSituationType> CollectionSituation { get; set; } = new List<CollectionSituationType>();
        public bool ShouldSerializeCollectionSituation() { return CollectionSituation.Count > 0; }
        /// <summary>
        /// Describes action taken to minimize loss of data from the collection event.
        /// <summary>
        public List<ActionToMinimizeLossesType> ActionToMinimizeLosses { get; set; } = new List<ActionToMinimizeLossesType>();
        public bool ShouldSerializeActionToMinimizeLosses() { return ActionToMinimizeLosses.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the study methodology, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// References the Sample used by this CollectionEvent. TypeOfObject should be Sample.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Sample> SampleReference { get; set; } = new List<Sample>();
        public bool ShouldSerializeSampleReference() { return SampleReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (CollectionEventName != null && CollectionEventName.Count > 0)
            {
                foreach (var item in CollectionEventName)
                {
                    xEl.Add(item.ToXml("CollectionEventName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DataCollectorOrganizationReference != null && DataCollectorOrganizationReference.Count > 0)
            {
                foreach (var item in DataCollectorOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "DataCollectorOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataSource != null && DataSource.Count > 0)
            {
                foreach (var item in DataSource)
                {
                    xEl.Add(item.ToXml("DataSource"));
                }
            }
            if (DataCollectionDate != null) { xEl.Add(DataCollectionDate.ToXml("DataCollectionDate")); }
            if (DataCollectionFrequency != null && DataCollectionFrequency.Count > 0)
            {
                foreach (var item in DataCollectionFrequency)
                {
                    xEl.Add(item.ToXml("DataCollectionFrequency"));
                }
            }
            if (ModeOfCollection != null && ModeOfCollection.Count > 0)
            {
                foreach (var item in ModeOfCollection)
                {
                    xEl.Add(item.ToXml("ModeOfCollection"));
                }
            }
            if (InstrumentReference != null && InstrumentReference.Count > 0)
            {
                foreach (var item in InstrumentReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CollectionSituation != null && CollectionSituation.Count > 0)
            {
                foreach (var item in CollectionSituation)
                {
                    xEl.Add(item.ToXml("CollectionSituation"));
                }
            }
            if (ActionToMinimizeLosses != null && ActionToMinimizeLosses.Count > 0)
            {
                foreach (var item in ActionToMinimizeLosses)
                {
                    xEl.Add(item.ToXml("ActionToMinimizeLosses"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleReference != null && SampleReference.Count > 0)
            {
                foreach (var item in SampleReference)
                {
                    xEl.Add(new XElement(ns + "SampleReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

