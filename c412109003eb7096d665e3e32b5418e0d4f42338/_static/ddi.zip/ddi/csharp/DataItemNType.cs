using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a single data item or cell within an NCube Instance. It defines its location within the NCube by its coordinate (matrix) address which is its intersect point on each dimension. Allows for the specification of data item specific attributes, and identifies the physical location of each measure for the data item. May optionally indicate the language of the data contents.
    /// <summary>
    public partial class DataItemNType
    {
        /// <summary>
        /// A dimension describes the rank or order of the dimension within the NCube structure and provides the specific coordinate value of the dimension for the data item.
        /// <summary>
        public List<DimensionRankValueType> DimensionRankValue { get; set; } = new List<DimensionRankValueType>();
        public bool ShouldSerializeDimensionRankValue() { return DimensionRankValue.Count > 0; }
        /// <summary>
        /// This is an attribute attached to the specified Data Item. The content of the attribute can be provided as a single value or reference a location in the data store where the attribute value will be found. This may be in addition to attribute information described in the logical structure.
        /// <summary>
        public List<AttachedAttributeType> AttachedAttribute { get; set; } = new List<AttachedAttributeType>();
        public bool ShouldSerializeAttachedAttribute() { return AttachedAttribute.Count > 0; }
        /// <summary>
        /// Identifies the specific measure of the cell by noting the order value of the measure within the MeasureDimension and provides information on the storage location of the cell value for the measure.
        /// <summary>
        public List<MeasureType> Measure { get; set; } = new List<MeasureType>();
        public bool ShouldSerializeMeasure() { return Measure.Count > 0; }
        /// <summary>
        /// Use to indicate the language of the data item in the file.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (DimensionRankValue != null && DimensionRankValue.Count > 0)
            {
                foreach (var item in DimensionRankValue)
                {
                    xEl.Add(item.ToXml("DimensionRankValue"));
                }
            }
            if (AttachedAttribute != null && AttachedAttribute.Count > 0)
            {
                foreach (var item in AttachedAttribute)
                {
                    xEl.Add(item.ToXml("AttachedAttribute"));
                }
            }
            if (Measure != null && Measure.Count > 0)
            {
                foreach (var item in Measure)
                {
                    xEl.Add(item.ToXml("Measure"));
                }
            }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

