using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A form of control construct providing a code and assigning a variable to hold value of the code as used for computation in control construct flow. Member of the ControlConstruct substitution group.
    /// <summary>
    public partial class ComputationItem : ControlConstruct
    {
        /// <summary>
        /// A brief textual identification of the ComputationItem. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfComputationItem { get; set; }
        /// <summary>
        /// The Code which contains the value of the variable in programming terms.
        /// <summary>
        public CommandCodeType CommandCode { get; set; }
        /// <summary>
        /// A reference to a variable to which the associated value in the Code element is assigned.
        /// <summary>
        public ParameterType AssignedVariableReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ComputationItem");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfComputationItem != null) { xEl.Add(TypeOfComputationItem.ToXml("TypeOfComputationItem")); }
            if (CommandCode != null) { xEl.Add(CommandCode.ToXml("CommandCode")); }
            if (AssignedVariableReference != null) { xEl.Add(AssignedVariableReference.ToXml("AssignedVariableReference")); }
            return xEl;
        }
    }
}

