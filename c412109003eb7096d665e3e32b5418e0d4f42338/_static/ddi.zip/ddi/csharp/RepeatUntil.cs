using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. Specifies a ControlConstruct to be repeated until a specified condition is met. Before each iteration the condition is tested. When the condition is met, control passes back to the containing control construct.
    /// <summary>
    public partial class RepeatUntil : ControlConstruct
    {
        /// <summary>
        /// Information on the command used to determine whether the "Until" condition is met.
        /// <summary>
        public CommandCodeType UntilCondition { get; set; }
        /// <summary>
        /// A reference to the ControlConstruct to implement until the UntilCondition is met. This could be a single ControlConstruct or a set of ControlConstructs within a Sequence.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Sequence UntilConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "RepeatUntil");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UntilCondition != null) { xEl.Add(UntilCondition.ToXml("UntilCondition")); }
            if (UntilConstructReference != null)
            {
                xEl.Add(new XElement(ns + "UntilConstructReference", 
                    new XElement(ns + "URN", UntilConstructReference.URN), 
                    new XElement(ns + "Agency", UntilConstructReference.Agency), 
                    new XElement(ns + "ID", UntilConstructReference.ID), 
                    new XElement(ns + "Version", UntilConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", UntilConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

