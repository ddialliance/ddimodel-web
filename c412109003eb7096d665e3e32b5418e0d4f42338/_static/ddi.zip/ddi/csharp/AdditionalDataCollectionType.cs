using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of the method and mode of data collection in administering the pretest. Notes any additional data collected in the administration of the pretest.
    /// <summary>
    public partial class AdditionalDataCollectionType
    {
        /// <summary>
        /// Specifies type of additional data collected. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfAdditionalData { get; set; }
        /// <summary>
        /// Description of the additional data collected. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfAdditionalData != null) { xEl.Add(TypeOfAdditionalData.ToXml("TypeOfAdditionalData")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

