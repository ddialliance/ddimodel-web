using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A note related to one or more identifiable objects. Note is designed to be an inherent part of the DDI. (Unlike XML comments or other types of system-level annotations, which may be removed during processing.) DDI recommends placing the note within the maintainable object containing the objects this note relates to in order to assist tracking of note items within a study. Each note may indicate who is responsible for the note, its type using a controlled vocabulary, the subject of the note, a head and note content, a set of key/value pairs and language specification for the overall note. In addition each note must be related to one or more identifiable objects.
    /// <summary>
    public partial class NoteType
    {
        /// <summary>
        /// Specifies the type of note. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfNote { get; set; }
        /// <summary>
        /// The subject of the note.
        /// <summary>
        public CodeValueType NoteSubject { get; set; }
        /// <summary>
        /// Reference to one or more identifiable objects which the note is related to.
        /// <summary>
        public List<RelationshipType> Relationship { get; set; } = new List<RelationshipType>();
        public bool ShouldSerializeRelationship() { return Relationship.Count > 0; }
        /// <summary>
        /// The person or agency responsible for adding the note.
        /// <summary>
        public string Responsibility { get; set; }
        /// <summary>
        /// A brief label or heading for the note contents.
        /// <summary>
        public InternationalStringType Header { get; set; }
        /// <summary>
        /// The content of the note. Note should contain content except when it is a production flag that is fully explained by its "type". If the note provides system specific information in a structured way using XHTML formating, DDI strongly recommends the use of local extensions or the Key/Value pair structure in ProprietaryInfo whenever possible.
        /// <summary>
        public StructuredStringType NoteContent { get; set; }
        /// <summary>
        /// A set of actions related to the object as described by a set of name-value pairs. This would commonly be used in a case where additional information needs to be recorded regarding the content of a new element or attribute that has not yet been added to the schema, for example when a bug for a missing object has been filed and the user wishes to record the content prior to correction in the schema. Ideally this should be handled by local extensions of the schema as described in Part 2 of the formal documentation. However, the structure in Note allows for an unanticipated need for an extension at run time by providing a means of capturing system specific information in a structured way.
        /// <summary>
        public ProprietaryInfoType ProprietaryInfo { get; set; }
        /// <summary>
        /// Indicates the language of content. Note that xml:lang allows for a simple 2 or 3 character language code or a language code extended by a country code , for example en-au for English as used in Australia.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfNote != null) { xEl.Add(TypeOfNote.ToXml("TypeOfNote")); }
            if (NoteSubject != null) { xEl.Add(NoteSubject.ToXml("NoteSubject")); }
            if (Relationship != null && Relationship.Count > 0)
            {
                foreach (var item in Relationship)
                {
                    xEl.Add(item.ToXml("Relationship"));
                }
            }
            if (Responsibility != null)
            {
                xEl.Add(new XElement(ns + "Responsibility", Responsibility));
            }
            if (Header != null) { xEl.Add(Header.ToXml("Header")); }
            if (NoteContent != null) { xEl.Add(NoteContent.ToXml("NoteContent")); }
            if (ProprietaryInfo != null) { xEl.Add(ProprietaryInfo.ToXml("ProprietaryInfo")); }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

