using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the relationship between records of different types or of the same type within a longitudinal study. Identifies the key and linking value relationships. All relationships are pairwise. Multiple pairwise relationships maybe needed to clarify all record relationships within a logical product or data set. In addition to the standard name, label, and description, the structure identifies the pair of logical records for which the relationship is defined as SourceLogicalRecord and TargetLogicalRecord, describes the link between these two records and indicates the relationship of the of the source record to the target record.
    /// <summary>
    public partial class RecordRelationshipType : IdentifiableType
    {
        /// <summary>
        /// A name for the RecordRelationship. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RecordRelationshipName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRecordRelationshipName() { return RecordRelationshipName.Count > 0; }
        /// <summary>
        /// A display label for the RecordRelationship. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the RecordRelationship. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to the Logical Record acting as the Source Record. All relationship information is from the source to the target. If the relationship is not unidirectional (i.e., sibling) simply assign one record as the source and the other as the target.
        /// <summary>
        public LogicalRecordType SourceLogicalRecordReference { get; set; }
        /// <summary>
        /// A reference to the Logical Record acting as the Target Record.
        /// <summary>
        public LogicalRecordType TargetLogicalRecordReference { get; set; }
        /// <summary>
        /// Each SourceTargetLink provides a pair of variables which act as all or part of a link between the source and the target records. Repeat if more than one set of variables is required to make the link.
        /// <summary>
        public List<SourceTargetLinkType> SourceTargetLink { get; set; } = new List<SourceTargetLinkType>();
        public bool ShouldSerializeSourceTargetLink() { return SourceTargetLink.Count > 0; }
        /// <summary>
        /// Indicates the relationship of the source to the target. The value describes the role of the source in the relationship. This is a restricted list of Parent, Child, Sibling, Unknown.
        /// <summary>
        [StringValidation(new string[] {
            "Parent"
,             "Child"
,             "Sibling"
,             "Unknown"
        })]
        public string RelationToTarget { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (RecordRelationshipName != null && RecordRelationshipName.Count > 0)
            {
                foreach (var item in RecordRelationshipName)
                {
                    xEl.Add(item.ToXml("RecordRelationshipName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SourceLogicalRecordReference != null) { xEl.Add(SourceLogicalRecordReference.ToXml("SourceLogicalRecordReference")); }
            if (TargetLogicalRecordReference != null) { xEl.Add(TargetLogicalRecordReference.ToXml("TargetLogicalRecordReference")); }
            if (SourceTargetLink != null && SourceTargetLink.Count > 0)
            {
                foreach (var item in SourceTargetLink)
                {
                    xEl.Add(item.ToXml("SourceTargetLink"));
                }
            }
            if (RelationToTarget != null)
            {
                xEl.Add(new XElement(ns + "RelationToTarget", RelationToTarget));
            }
            return xEl;
        }
    }
}

