using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. A construct which ties question content to the programmatic logic of the control constructs. Contains a reference to a QuestionItem, QuestionGrid or QuestionBlock, can set response or dimension sequence for use in a specific application, identifies the response unit, analysis unit, and universe. May provide an estimate of the number of minutes needed to respond.
    /// <summary>
    public partial class QuestionConstruct : ControlConstruct
    {
        /// <summary>
        /// Reference to a QuestionItem, QuestionGrid, or QuestionBlock.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public QuestionItem QuestionReference { get; set; }
        /// <summary>
        /// Describes the sequencing of the response options to the question for this application.
        /// <summary>
        public SpecificSequenceType ResponseSequence { get; set; }
        /// <summary>
        /// Describes the sequencing of the dimension within a QuestionGrid for this application.
        /// <summary>
        public SpecificSequenceType DimensionSequence { get; set; }
        /// <summary>
        /// Identifies the intended Response unit (respondent). Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType ResponseUnit { get; set; }
        /// <summary>
        /// The analysis unit, expressed as a term which may come from a controlled vocabulary.
        /// <summary>
        public List<CodeValueType> AnalysisUnit { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeAnalysisUnit() { return AnalysisUnit.Count > 0; }
        /// <summary>
        /// Reference to the universe statement containing a description of the persons or other elements that this variable refers to, and to which any analytic results refer. If more than one universe is referenced the universe of the variable is the intersect of the referenced universes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// The estimated amount of time required to answer a question expressed in seconds. Decimal values should be used to define fractions of seconds. At the question construct level it refers to the estimated time within the context of is use in a questionnaire.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QuestionConstruct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QuestionReference != null)
            {
                xEl.Add(new XElement(ns + "QuestionReference", 
                    new XElement(ns + "URN", QuestionReference.URN), 
                    new XElement(ns + "Agency", QuestionReference.Agency), 
                    new XElement(ns + "ID", QuestionReference.ID), 
                    new XElement(ns + "Version", QuestionReference.Version), 
                    new XElement(ns + "TypeOfObject", QuestionReference.GetType().Name)));
            }
            if (ResponseSequence != null) { xEl.Add(ResponseSequence.ToXml("ResponseSequence")); }
            if (DimensionSequence != null) { xEl.Add(DimensionSequence.ToXml("DimensionSequence")); }
            if (ResponseUnit != null) { xEl.Add(ResponseUnit.ToXml("ResponseUnit")); }
            if (AnalysisUnit != null && AnalysisUnit.Count > 0)
            {
                foreach (var item in AnalysisUnit)
                {
                    xEl.Add(item.ToXml("AnalysisUnit"));
                }
            }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

