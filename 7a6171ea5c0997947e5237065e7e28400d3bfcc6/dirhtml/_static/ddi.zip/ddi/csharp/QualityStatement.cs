using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A statement of quality which may be related to an external standard or contain a simple statement of internal quality goals or expectations. When relating to an external standard information on compliance may be added providing a reference to a ComplianceConcept, an ExternalComplianceCode, as well as a description. Optionally, a general statement of quality may be provided using OtherQualityStatement.
    /// <summary>
    public partial class QualityStatement : Versionable
    {
        /// <summary>
        /// Name of the QualityStatement using the DDI Name structure.
        /// <summary>
        public List<NameType> QualityStatementName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQualityStatementName() { return QualityStatementName.Count > 0; }
        /// <summary>
        /// A display label for the QualityStatement. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the QualityStatement. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Identifies the external standard used and describes the level of compliance with the standard in terms specific aspects of the standard's content.
        /// <summary>
        public StandardType Standard { get; set; }
        /// <summary>
        /// Describes the steps taken to ensure quality that are not related to a specific standard. Language variants should be captured within a single OtherQualityStatement. Repeat the OtherQualityStatement for differing content if needed.
        /// <summary>
        public StructuredStringType OtherQualityStatement { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QualityStatement");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QualityStatementName != null && QualityStatementName.Count > 0)
            {
                foreach (var item in QualityStatementName)
                {
                    xEl.Add(item.ToXml("QualityStatementName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Standard != null) { xEl.Add(Standard.ToXml("Standard")); }
            if (OtherQualityStatement != null) { xEl.Add(OtherQualityStatement.ToXml("OtherQualityStatement")); }
            return xEl;
        }
    }
}

