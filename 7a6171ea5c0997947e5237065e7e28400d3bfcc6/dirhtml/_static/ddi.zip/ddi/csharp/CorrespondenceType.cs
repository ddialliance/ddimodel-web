using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the commonalities and differences between two items using a textual description of both commonalities and differences plus an optional coding of the type of commonality, a commonality expresses as a 0 to 1 weighting factor (expressing degree of comparability) and a user defined correspondence property which is specific to an organization or community of use.
    /// <summary>
    public partial class CorrespondenceType
    {
        /// <summary>
        /// A description of the common features of the two items using a StructuredString to support multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Commonality { get; set; }
        /// <summary>
        /// A description of the differences between the two items using a StructuredString to support multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Difference { get; set; }
        /// <summary>
        /// A brief description describing the commonality of the two schemes/items, i.e., "Identical", "High", "Medium", "Low", "None". Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType CommonalityTypeCoded { get; set; }
        /// <summary>
        /// A value between 0 and 1 expressing the degree of commonality (0 indicates none, 1 indicates that they are identical).
        /// <summary>
        [Range(0, )]
        public float CommonalityWeight { get; set; }
        /// <summary>
        /// An alternate means of expressing commonality within a specific system. A system specific user defined correspondence expressed as a key/value pair. As this is specific to an individual system the use of controlled vocabularies for the key is strongly recommended.
        /// <summary>
        public List<StandardKeyValuePairType> UserDefinedCorrespondenceProperty { get; set; } = new List<StandardKeyValuePairType>();
        public bool ShouldSerializeUserDefinedCorrespondenceProperty() { return UserDefinedCorrespondenceProperty.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Commonality != null) { xEl.Add(Commonality.ToXml("Commonality")); }
            if (Difference != null) { xEl.Add(Difference.ToXml("Difference")); }
            if (CommonalityTypeCoded != null) { xEl.Add(CommonalityTypeCoded.ToXml("CommonalityTypeCoded")); }
            if (CommonalityWeight != null)
            {
                xEl.Add(new XElement(ns + "CommonalityWeight", CommonalityWeight));
            }
            if (UserDefinedCorrespondenceProperty != null && UserDefinedCorrespondenceProperty.Count > 0)
            {
                foreach (var item in UserDefinedCorrespondenceProperty)
                {
                    xEl.Add(item.ToXml("UserDefinedCorrespondenceProperty"));
                }
            }
            return xEl;
        }
    }
}

