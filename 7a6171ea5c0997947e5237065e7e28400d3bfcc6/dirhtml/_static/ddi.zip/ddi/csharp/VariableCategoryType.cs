using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A category value for which one or more statistics are recorded. Each VariableCategory has one category value and any number of associated statistics.
    /// <summary>
    public partial class VariableCategoryType
    {
        /// <summary>
        /// The value of the category.
        /// <summary>
        public CategoryValueType CategoryValue { get; set; }
        /// <summary>
        /// The value of a statistic associated with the category value indicated in the sibling CategoryValue element.
        /// <summary>
        public List<CategoryStatisticType> CategoryStatistic { get; set; } = new List<CategoryStatisticType>();
        public bool ShouldSerializeCategoryStatistic() { return CategoryStatistic.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (CategoryValue != null) { xEl.Add(CategoryValue.ToXml("CategoryValue")); }
            if (CategoryStatistic != null && CategoryStatistic.Count > 0)
            {
                foreach (var item in CategoryStatistic)
                {
                    xEl.Add(item.ToXml("CategoryStatistic"));
                }
            }
            return xEl;
        }
    }
}

