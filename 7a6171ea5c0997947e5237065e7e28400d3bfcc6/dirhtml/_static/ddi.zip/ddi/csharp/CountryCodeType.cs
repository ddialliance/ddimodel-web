using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Serves as head of a substitution group for specifying ISO 3166 Country Codes or use of unspecified text.
    /// <summary>
    public partial class CountryCodeType : string
    {
        /// <summary>
        /// If it is important to specify the date that this code is effective in order to accurately capture a name or similar change, specify that here.
        /// <summary>
        [JsonConverter(typeof(DateTimeConverter))]
        public DateTimeOffset EffectiveDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("string").Descendants())
            {
                xEl.Add(el);
            }
            if (EffectiveDate != default(DateTimeOffset))
            {
                xEl.Add(new XElement(ns + "EffectiveDate", EffectiveDate.ToString("yyyy-MM-dd\\THH:mm:ss.FFFFFFFK")));
            }
            return xEl;
        }
    }
}

