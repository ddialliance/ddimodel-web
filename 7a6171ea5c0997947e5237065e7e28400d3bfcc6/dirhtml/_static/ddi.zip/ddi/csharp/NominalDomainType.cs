using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A response domain capturing a nominal (check off) response for a question grid response. Includes standard response domain elements; OutParameter, designation of response cardinality, and a declaration of an offset date for the data content.
    /// <summary>
    public partial class NominalDomainType : NominalRepresentationBaseType
    {
        /// <summary>
        /// A display label for the domain. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the domain. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the response to be bound to one of the QuestionItem's OutParameters, so the collected information can be used elsewhere, for example as inputs to subsequent questions in an Instrument or to a GenerationInstruction. If multiple responses are possible, this would represent and ordered array of the responses.
        /// <summary>
        public ParameterType OutParameter { get; set; }
        /// <summary>
        /// Allows the designation of the minimum and maximum number of responses allowed for this response domain.
        /// <summary>
        public ResponseCardinalityType ResponseCardinality { get; set; }
        /// <summary>
        /// Identifies the difference between the date applied to the data as a whole and this specific item such as previous year's income or residence 5 years ago.
        /// <summary>
        public ContentDateOffsetType ContentDateOffset { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("NominalRepresentationBaseType").Descendants())
            {
                xEl.Add(el);
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (OutParameter != null) { xEl.Add(OutParameter.ToXml("OutParameter")); }
            if (ResponseCardinality != null) { xEl.Add(ResponseCardinality.ToXml("ResponseCardinality")); }
            if (ContentDateOffset != null) { xEl.Add(ContentDateOffset.ToXml("ContentDateOffset")); }
            return xEl;
        }
    }
}

