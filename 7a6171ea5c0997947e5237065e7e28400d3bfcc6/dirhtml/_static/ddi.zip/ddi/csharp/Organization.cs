using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Details of an organization including name, contact information, a description, keywords to support searching, their regional affiliation, and any additional information. In addition the organization may capture how they manage version distinction. All agencies should be defined as an Organization and referenced by the Archive module. The organization and specific pieces of information regarding the individual may be tagged for information privacy.
    /// <summary>
    public partial class Organization : Versionable
    {
        /// <summary>
        /// Identification information on the Organization. The structure contains a OrganizationName which can be repeated to provide any number of OrganizationNames that have a) a specific contextual usage, or b) are of specific types (e.g. PreviousFormalName). The DDI Maintenance Agency ID and and organization images, such as a building picture or logo are found in OrganizationIdentification. Images and names can be individually date stamped.
        /// <summary>
        public OrganizationIdentificationType OrganizationIdentification { get; set; }
        /// <summary>
        /// A description of the organization. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Keyword used to classify the organization or its activities. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// The geographic region within which this organization operates.
        /// <summary>
        public List<CodeValueType> RegionalCoverage { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeRegionalCoverage() { return RegionalCoverage.Count > 0; }
        /// <summary>
        /// Any additional information you which to note about the organization. This is a structured string so it can be formatted and a privacy tag can be applied.
        /// <summary>
        public List<AdditionalInformationType> AdditionalInformation { get; set; } = new List<AdditionalInformationType>();
        public bool ShouldSerializeAdditionalInformation() { return AdditionalInformation.Count > 0; }
        /// <summary>
        /// Describes the data versioning scheme(s) used by an organization. If more than one, Name should differentiate between a standard versioning structure used by the organization and special structures used by specific projects or studies. Information on what drives and major and minor change and how they are structured.
        /// <summary>
        public List<VersionDistinctionType> VersionDistinction { get; set; } = new List<VersionDistinctionType>();
        public bool ShouldSerializeVersionDistinction() { return VersionDistinction.Count > 0; }
        /// <summary>
        /// Contact information for the organization including location specification, address, URL, phone numbers, and other means of communication access. Address, location, telephone, and other means of communication can be repeated to express multiple means of a single type or change over time. Each major piece of contact information (with exception of URL contains the element EffectiveDates in order to date stamp the period for which the information is valid.
        /// <summary>
        public List<ContactInformationType> ContactInformation { get; set; } = new List<ContactInformationType>();
        public bool ShouldSerializeContactInformation() { return ContactInformation.Count > 0; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Organization");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (OrganizationIdentification != null) { xEl.Add(OrganizationIdentification.ToXml("OrganizationIdentification")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (RegionalCoverage != null && RegionalCoverage.Count > 0)
            {
                foreach (var item in RegionalCoverage)
                {
                    xEl.Add(item.ToXml("RegionalCoverage"));
                }
            }
            if (AdditionalInformation != null && AdditionalInformation.Count > 0)
            {
                foreach (var item in AdditionalInformation)
                {
                    xEl.Add(item.ToXml("AdditionalInformation"));
                }
            }
            if (VersionDistinction != null && VersionDistinction.Count > 0)
            {
                foreach (var item in VersionDistinction)
                {
                    xEl.Add(item.ToXml("VersionDistinction"));
                }
            }
            if (ContactInformation != null && ContactInformation.Count > 0)
            {
                foreach (var item in ContactInformation)
                {
                    xEl.Add(item.ToXml("ContactInformation"));
                }
            }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            return xEl;
        }
    }
}

