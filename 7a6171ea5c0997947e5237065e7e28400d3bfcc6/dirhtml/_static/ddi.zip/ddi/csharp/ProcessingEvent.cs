using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// ProcessingEvent can contain a number of operations of different types to express a range of events that occur together. For example a ProcessingEvent of a CleaningOperation may also include a reference to a ProcessingInstruction used in the cleaning process. Event activities include ControlOperation, CleaningOperation, Weighting, and DataAppraisalInformation. References to related processing instructions and quality statement may be included.
    /// <summary>
    public partial class ProcessingEvent : Versionable
    {
        /// <summary>
        /// Description of a Control Operation used to facilitate data control.
        /// <summary>
        public List<OperationType> ControlOperation { get; set; } = new List<OperationType>();
        public bool ShouldSerializeControlOperation() { return ControlOperation.Count > 0; }
        /// <summary>
        /// Description of a Cleaning Operation such as consistency checking, invalid or out of range values, etc.
        /// <summary>
        public List<OperationType> CleaningOperation { get; set; } = new List<OperationType>();
        public bool ShouldSerializeCleaningOperation() { return CleaningOperation.Count > 0; }
        /// <summary>
        /// Description of the weighting process and any resultant standard weights.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Weighting> WeightingReference { get; set; } = new List<Weighting>();
        public bool ShouldSerializeWeightingReference() { return WeightingReference.Count > 0; }
        /// <summary>
        /// Description of the data appraisal processing including the resultant sampling error and response rate.
        /// <summary>
        public List<DataAppraisalInformationType> DataAppraisalInformation { get; set; } = new List<DataAppraisalInformationType>();
        public bool ShouldSerializeDataAppraisalInformation() { return DataAppraisalInformation.Count > 0; }
        /// <summary>
        /// Reference to a processing instruction (GeneralInstruction or GenerationInstruction) used during the processing event. The basic Reference structure is extended to allow for the use of ParameterLinkage to link specific source parameters to the InParameter of the instruction to reflect its use within this specific Processing Event.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeneralInstruction> ProcessingInstructionReference_GeneralInstruction { get; set; } = new List<GeneralInstruction>();
        public bool ShouldSerializeProcessingInstructionReference_GeneralInstruction() { return ProcessingInstructionReference_GeneralInstruction.Count > 0; }
        /// <summary>
        /// Reference to a processing instruction (GeneralInstruction or GenerationInstruction) used during the processing event. The basic Reference structure is extended to allow for the use of ParameterLinkage to link specific source parameters to the InParameter of the instruction to reflect its use within this specific Processing Event.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenerationInstruction> ProcessingInstructionReference_GenerationInstruction { get; set; } = new List<GenerationInstruction>();
        public bool ShouldSerializeProcessingInstructionReference_GenerationInstruction() { return ProcessingInstructionReference_GenerationInstruction.Count > 0; }
        /// <summary>
        /// Reference to a quality statement relating to the processing event.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ProcessingEvent");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ControlOperation != null && ControlOperation.Count > 0)
            {
                foreach (var item in ControlOperation)
                {
                    xEl.Add(item.ToXml("ControlOperation"));
                }
            }
            if (CleaningOperation != null && CleaningOperation.Count > 0)
            {
                foreach (var item in CleaningOperation)
                {
                    xEl.Add(item.ToXml("CleaningOperation"));
                }
            }
            if (WeightingReference != null && WeightingReference.Count > 0)
            {
                foreach (var item in WeightingReference)
                {
                    xEl.Add(new XElement(ns + "WeightingReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataAppraisalInformation != null && DataAppraisalInformation.Count > 0)
            {
                foreach (var item in DataAppraisalInformation)
                {
                    xEl.Add(item.ToXml("DataAppraisalInformation"));
                }
            }
            if (ProcessingInstructionReference_GeneralInstruction != null && ProcessingInstructionReference_GeneralInstruction.Count > 0)
            {
                foreach (var item in ProcessingInstructionReference_GeneralInstruction)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionReference_GeneralInstruction", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingInstructionReference_GenerationInstruction != null && ProcessingInstructionReference_GenerationInstruction.Count > 0)
            {
                foreach (var item in ProcessingInstructionReference_GenerationInstruction)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionReference_GenerationInstruction", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

