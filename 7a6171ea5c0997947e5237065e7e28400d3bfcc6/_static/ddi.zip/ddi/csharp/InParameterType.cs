using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A parameter that may accept content from outside its parent element. In addition to standard parameter content may provide the instructions for limiting the allowable array index.
    /// <summary>
    public partial class InParameterType : ParameterType
    {
        /// <summary>
        /// When the InParameter represents an array of items, this attribute specifies the index identification of the items within the zero-based array which should be treated as input parameters. If not specified, the full array is treated as the input parameter.
        /// <summary>
        [StringValidation(null, @"\c+")]
        public string LimitArrayIndex { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ParameterType").Descendants())
            {
                xEl.Add(el);
            }
            if (LimitArrayIndex != null)
            {
                xEl.Add(new XElement(ns + "LimitArrayIndex", LimitArrayIndex));
            }
            return xEl;
        }
    }
}

