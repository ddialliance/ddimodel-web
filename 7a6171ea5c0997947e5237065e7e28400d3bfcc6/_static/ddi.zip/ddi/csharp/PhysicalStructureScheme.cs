using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A scheme containing a set of PhysicalStructures containing descriptions of overall structure of a physical data storage format. These descriptions provide the primary link to the LogicalRecord found in the data file, general structural information such as use of proprietary storage structures, division of logical records into physical segment, and default values for decimal separators, etc. Each description can apply to one or more data files containing the same logical records in the same overall structure. In addition to the standard name, label, and description, it allows for inclusion of an existing PhysicalStructureScheme by reference, and PhysicalStructure or PhysicalStructureGroup descriptions in-line or by reference.
    /// <summary>
    public partial class PhysicalStructureScheme : Maintainable
    {
        /// <summary>
        /// A name for the PhysicalStructureScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> PhysicalStructureSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializePhysicalStructureSchemeName() { return PhysicalStructureSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the PhysicalStructureScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the PhysicalStructureScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing PhysicalStructureScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalStructureScheme> PhysicalStructureSchemeReference { get; set; } = new List<PhysicalStructureScheme>();
        public bool ShouldSerializePhysicalStructureSchemeReference() { return PhysicalStructureSchemeReference.Count > 0; }
        /// <summary>
        /// A PhysicalStructure description providing the primary link to the LogicalRecord and general structural information. Each description can apply to one or more data files containing the same logical records in the same overall structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalStructure> PhysicalStructureReference { get; set; } = new List<PhysicalStructure>();
        public bool ShouldSerializePhysicalStructureReference() { return PhysicalStructureReference.Count > 0; }
        /// <summary>
        /// A group of PhysicalStructure descriptions for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalStructureGroup> PhysicalStructureGroupReference { get; set; } = new List<PhysicalStructureGroup>();
        public bool ShouldSerializePhysicalStructureGroupReference() { return PhysicalStructureGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "PhysicalStructureScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (PhysicalStructureSchemeName != null && PhysicalStructureSchemeName.Count > 0)
            {
                foreach (var item in PhysicalStructureSchemeName)
                {
                    xEl.Add(item.ToXml("PhysicalStructureSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (PhysicalStructureSchemeReference != null && PhysicalStructureSchemeReference.Count > 0)
            {
                foreach (var item in PhysicalStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalStructureReference != null && PhysicalStructureReference.Count > 0)
            {
                foreach (var item in PhysicalStructureReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalStructureReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalStructureGroupReference != null && PhysicalStructureGroupReference.Count > 0)
            {
                foreach (var item in PhysicalStructureGroupReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalStructureGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

