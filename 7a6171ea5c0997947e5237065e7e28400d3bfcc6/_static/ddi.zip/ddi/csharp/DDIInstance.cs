using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// DDIInstance is the top-level publication wrapper for any DDI document. All DDI content published as XML (with the exception of a Fragment intended for transmission) has DDIInstance as its top level structure. In addition to a citation and coverage statement for the instance, the DDIInstance can contain a Group, ResourcePackage, LocalHoldingPackage or StudyUnit. Additional OtherMaterial content may be added but in general OtherMaterial should be listed in the maintainable object containing the objects the OtherMaterial is related to. The instance can provide an applicable DDIProfile either in-line or by reference and can contain overall translation information.
    /// <summary>
    public partial class DDIInstance : Maintainable
    {
        /// <summary>
        /// Citation for the Instance. Note that the citation is optional, because the DDI Instance may contain only reusable component pieces of metadata sets, which are not directly concerned with a single study or studies.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// This element contains descriptions of temporal, geographic and topical coverage. At the instance level these descriptions should be inclusive of the coverage of all modules in the instance. The element is available within individual modules and can be used to refine the coverage to that of the individual module.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// A publication of a Group of StudyUnits in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Group> GroupReference { get; set; } = new List<Group>();
        public bool ShouldSerializeGroupReference() { return GroupReference.Count > 0; }
        /// <summary>
        /// A publication of a set of maintainables (modules or schemes) intended for reuse between studies in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ResourcePackage> ResourcePackageReference { get; set; } = new List<ResourcePackage>();
        public bool ShouldSerializeResourcePackageReference() { return ResourcePackageReference.Count > 0; }
        /// <summary>
        /// A publication package containing a deposited publication as well as local value added or processing information in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<LocalHoldingPackage> LocalHoldingPackageReference { get; set; } = new List<LocalHoldingPackage>();
        public bool ShouldSerializeLocalHoldingPackageReference() { return LocalHoldingPackageReference.Count > 0; }
        /// <summary>
        /// A publication of a study unit representing the purpose, background, development, data capture, and data products related to a study in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StudyUnit> StudyUnitReference { get; set; } = new List<StudyUnit>();
        public bool ShouldSerializeStudyUnitReference() { return StudyUnitReference.Count > 0; }
        /// <summary>
        /// External materials related to the DDI Instance that have not been included in any maintainables contained within the instance.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }
        /// <summary>
        /// A DDIProfile applicable to the instance.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DDIProfile> DDIProfileReference { get; set; } = new List<DDIProfile>();
        public bool ShouldSerializeDDIProfileReference() { return DDIProfileReference.Count > 0; }
        /// <summary>
        /// TranslationInformation contains information about the translation of the content of the DDI Instance. This includes human-readable information about which language(s) are involved in the translation.
        /// <summary>
        public TranslationType TranslationInformation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DDIInstance");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (GroupReference != null && GroupReference.Count > 0)
            {
                foreach (var item in GroupReference)
                {
                    xEl.Add(new XElement(ns + "GroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResourcePackageReference != null && ResourcePackageReference.Count > 0)
            {
                foreach (var item in ResourcePackageReference)
                {
                    xEl.Add(new XElement(ns + "ResourcePackageReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LocalHoldingPackageReference != null && LocalHoldingPackageReference.Count > 0)
            {
                foreach (var item in LocalHoldingPackageReference)
                {
                    xEl.Add(new XElement(ns + "LocalHoldingPackageReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (StudyUnitReference != null && StudyUnitReference.Count > 0)
            {
                foreach (var item in StudyUnitReference)
                {
                    xEl.Add(new XElement(ns + "StudyUnitReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            if (DDIProfileReference != null && DDIProfileReference.Count > 0)
            {
                foreach (var item in DDIProfileReference)
                {
                    xEl.Add(new XElement(ns + "DDIProfileReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (TranslationInformation != null) { xEl.Add(TranslationInformation.ToXml("TranslationInformation")); }
            return xEl;
        }
    }
}

