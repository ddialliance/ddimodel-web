using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the structure, starting point and increment step of an interval.
    /// <summary>
    public partial class IntervalType
    {
        /// <summary>
        /// Identifies the start value for this interval.
        /// <summary>
        public string Anchor_string { get; set; }
        /// <summary>
        /// Value specifying the increment between categories.
        /// <summary>
        public string Increment { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Anchor_string != null)
            {
                xEl.Add(new XElement(ns + "Anchor_string", Anchor_string));
            }
            if (Increment != null)
            {
                xEl.Add(new XElement(ns + "Increment", Increment));
            }
            return xEl;
        }
    }
}

