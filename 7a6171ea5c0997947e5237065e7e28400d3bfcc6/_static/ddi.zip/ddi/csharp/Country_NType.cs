using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for string content which may be taken from an externally maintained controlled vocabulary (code value). If the content is from a controlled vocabulary provide the code value, as well as a reference to the code list from which the value is taken. Provide as many of the identifying attributes as needed to adequately identify the controlled vocabulary. Note that DDI has published a number of controlled vocabularies applicable to several locations using the CodeValue structure. Use of shared controlled vocabularies helps support interoperability and machine actionability.
    /// <summary>
    public partial class Country_NType : CountryCodeType
    {
        /// <summary>
        /// The ID of the code list (controlled vocabulary) that the content was taken from.
        /// <summary>
        public string CodeListID { get; set; }
        /// <summary>
        /// The name of the code list. Fixed as ISO3166 numeric
        /// <summary>
        public string CodeListName_string { get; set; }
        /// <summary>
        /// The name of the agency maintaining the code list.
        /// <summary>
        public string CodeListAgencyName { get; set; }
        /// <summary>
        /// If the value of the string is "Other" or the equivalent from the codelist, this attribute can provide a more specific value not found in the codelist.
        /// <summary>
        public string OtherValue { get; set; }
        /// <summary>
        /// The URN of the codelist. Fixed value. Note this is fixed as late bound. Codes will not be removed from this list when the country code is no longer in active use.
        /// <summary>
        public string CodeListURN { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("CountryCodeType").Descendants())
            {
                xEl.Add(el);
            }
            if (CodeListID != null)
            {
                xEl.Add(new XElement(ns + "CodeListID", CodeListID));
            }
            if (CodeListName_string != null)
            {
                xEl.Add(new XElement(ns + "CodeListName_string", CodeListName_string));
            }
            if (CodeListAgencyName != null)
            {
                xEl.Add(new XElement(ns + "CodeListAgencyName", CodeListAgencyName));
            }
            if (OtherValue != null)
            {
                xEl.Add(new XElement(ns + "OtherValue", OtherValue));
            }
            if (CodeListURN != null)
            {
                xEl.Add(new XElement(ns + "CodeListURN", CodeListURN));
            }
            return xEl;
        }
    }
}

