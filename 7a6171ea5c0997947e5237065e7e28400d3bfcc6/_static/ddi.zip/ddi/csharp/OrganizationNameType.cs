using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Names by which the organization is known. Use the attribute isFormal="true" to designate the legal or formal name of the Organization. The preferred name should be noted with the isPreferred attribute. Names may be typed with TypeOfOrganizationName to indicate their appropriate usage.
    /// <summary>
    public partial class OrganizationNameType : NameType
    {
        /// <summary>
        /// An abbreviation or acronym for the name. This may be expressed in multiple languages. It is assumed that if only a single language is provided that it may be used in any of the other languages within which the name itself is expressed.
        /// <summary>
        public InternationalStringType Abbreviation { get; set; }
        /// <summary>
        /// The type of organization name provided. the use of a controlled vocabulary is strongly recommended. At minimum this should include, e.g. PreviousFormalName, Nickname (or CommonName), Other.
        /// <summary>
        public CodeValueType TypeOfOrganizationName { get; set; }
        /// <summary>
        /// The time period for which this name is accurate and in use.
        /// <summary>
        public DateType EffectivePeriod { get; set; }
        /// <summary>
        /// The legal or formal name of the organization should have the isFormal attribute set to true. To avoid confusion only one organization name should have the isFormal attribute set to true. Use the TypeOfOrganizationName to further differentiate the type and applied usage when multiple names are provided.
        /// <summary>
        public bool IsFormal { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("NameType").Descendants())
            {
                xEl.Add(el);
            }
            if (Abbreviation != null) { xEl.Add(Abbreviation.ToXml("Abbreviation")); }
            if (TypeOfOrganizationName != null) { xEl.Add(TypeOfOrganizationName.ToXml("TypeOfOrganizationName")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            xEl.Add(new XElement(ns + "IsFormal", IsFormal));
            return xEl;
        }
    }
}

