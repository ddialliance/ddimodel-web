using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides information on the Maintainable Parent of the object. If the scope of the Identifiable or Versionable Object is the Maintinable, this information must be provided in order to provide all the information contained in the Canonical DDI URN. This is done to support interoperability.
    /// <summary>
    public partial class MaintainableObjectType
    {
        /// <summary>
        /// The object type of the parent maintainable taken from a restricted list.
        /// <summary>
        [StringValidation(new string[] {
            "Access"
,             "ActionToMinimizeLosses"
,             "AggregationVariables"
,             "Attribute"
,             "AuthorizedSource"
,             "BudgetDocument"
,             "Code"
,             "CollectionEvent"
,             "CollectionSituation"
,             "CoordinateRegion"
,             "DataCollectionMethodology"
,             "DefaultAccess"
,             "DeviationFromSampleDesign"
,             "Embargo"
,             "ExternalAid"
,             "ExternalInformation"
,             "ExternalInterviewerInstruction"
,             "GeographicLevel"
,             "GrossFileStructure"
,             "GrossRecordStructure"
,             "InParameter"
,             "ItemMap"
,             "LifecycleEvent"
,             "LocationValue"
,             "LogicalRecord"
,             "MeasureDefinition"
,             "ModeOfCollection"
,             "OtherMaterial"
,             "OutParameter"
,             "PhysicalRecordSegment"
,             "RecordRelationship"
,             "SamplingProcedure"
,             "SpatialCoverage"
,             "StandardUsed"
,             "StandardWeight"
,             "StimulusMaterial"
,             "TemporalCoverage"
,             "TimeMethod"
,             "TopicalCoverage"
,             "Category"
,             "CategoryGroup"
,             "CategoryMap"
,             "CodeListGroup"
,             "ComputationItem"
,             "Concept"
,             "ConceptGroup"
,             "ConceptMap"
,             "ConceptualVariable"
,             "ConceptualVariableGroup"
,             "ControlConstructGroup"
,             "DataRelationship"
,             "DataSet"
,             "GeneralInstruction"
,             "GenerationInstruction"
,             "GeographicLocation"
,             "GeographicLocationGroup"
,             "GeographicStructure"
,             "GeographicStructureGroup"
,             "IfThenElse"
,             "Individual"
,             "Instruction"
,             "InstructionGroup"
,             "Instrument"
,             "InstrumentGroup"
,             "Loop"
,             "ManagedDateTimeRepresentation"
,             "ManagedMissingValuesRepresentation"
,             "ManagedNumericRepresentation"
,             "ManagedRepresentationGroup"
,             "ManagedScaleRepresentation"
,             "ManagedTextRepresentation"
,             "Methodology"
,             "NCube"
,             "NCubeGroup"
,             "NCubeInstance"
,             "Organization"
,             "OrganizationGroup"
,             "PhysicalStructure"
,             "PhysicalStructureGroup"
,             "ProcessingEvent"
,             "ProcessingEventGroup"
,             "ProcessingInstructionGroup"
,             "QualityStatement"
,             "QualityStatementGroup"
,             "QuestionBlock"
,             "QuestionConstruct"
,             "QuestionGrid"
,             "QuestionGroup"
,             "QuestionItem"
,             "QuestionMap"
,             "RecordLayout"
,             "RecordLayoutGroup"
,             "Relation"
,             "RepeatUntil"
,             "RepeatWhile"
,             "RepresentationMap"
,             "RepresentedVariable"
,             "RepresentedVariableGroup"
,             "Sequence"
,             "StatementItem"
,             "SubGroup"
,             "SubUniverseClass"
,             "Universe"
,             "UniverseGroup"
,             "UniverseMap"
,             "Variable"
,             "VariableGroup"
,             "VariableMap"
,             "VariableStatistics"
,             "Weighting"
,             "Archive"
,             "CategoryScheme"
,             "CodeList"
,             "CodeListScheme"
,             "Comparison"
,             "ConceptScheme"
,             "ConceptualComponent"
,             "ConceptualVariableScheme"
,             "ControlConstructScheme"
,             "DataCollection"
,             "DDIInstance"
,             "DDIProfile"
,             "GeographicLocationScheme"
,             "GeographicStructureScheme"
,             "Group"
,             "InstrumentScheme"
,             "InterviewerInstructionScheme"
,             "LocalGroupContent"
,             "LocalHoldingPackage"
,             "LocalResourcePackageContent"
,             "LocalStudyUnitContent"
,             "LogicalProduct"
,             "ManagedRepresentationScheme"
,             "NCubeScheme"
,             "OrganizationScheme"
,             "PhysicalDataProduct"
,             "PhysicalInstance"
,             "PhysicalStructureScheme"
,             "ProcessingEventScheme"
,             "ProcessingInstructionScheme"
,             "QualityStatementScheme"
,             "QuestionScheme"
,             "RecordLayoutScheme"
,             "RepresentedVariableScheme"
,             "ResourcePackage"
,             "StudyUnit"
,             "UniverseScheme"
,             "VariableScheme"
        })]
        public string TypeOfObject { get; set; }
        /// <summary>
        /// The value of the ID of the maintainable parent object.
        /// <summary>
        public IDType MaintainableID { get; set; }
        /// <summary>
        /// The version number of the maintainable parent object at the time the identifiable or versionable object was created or altered. Note that creating or altering the non-administrative content of an object within a maintainable will increment the version number of the maintainable and the content of this element should contain the new version number. In short, this represents the version number of the maintainable when the content of the current object first appeared in its present form.
        /// <summary>
        [StringValidation(null, @"[0-9]+(\.[0-9]+)*")]
        public string MaintainableVersion { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfObject != null)
            {
                xEl.Add(new XElement(ns + "TypeOfObject", TypeOfObject));
            }
            if (MaintainableID != null) { xEl.Add(MaintainableID.ToXml("MaintainableID")); }
            if (MaintainableVersion != null)
            {
                xEl.Add(new XElement(ns + "MaintainableVersion", MaintainableVersion));
            }
            return xEl;
        }
    }
}

