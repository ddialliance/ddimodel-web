using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A module describing the physical storage structures of data files and the relationship of their internal objects to the logical (intellectual) description of the objects found in LogicalProduct. This describes the physical aspects of data files which may be common between one or more data files as described by physical structure of the file and the structure of data items within a record. The PhysicalDataProduct contains the critical links between the physical data store identified by a PhysicalInstance and the logical (intellectual) description of the data as found in the LogicalProduct. In addition to the standard name, label, and description, the module allows for OtherMaterial, and descriptions of PhysicalStructureSchemes and RecordLayoutSchemes in-line or by reference.
    /// <summary>
    public partial class PhysicalDataProduct : Maintainable
    {
        /// <summary>
        /// A name for the PhysicalDataProduct module. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> PhysicalDataProductName { get; set; } = new List<NameType>();
        public bool ShouldSerializePhysicalDataProductName() { return PhysicalDataProductName.Count > 0; }
        /// <summary>
        /// A display label for the PhysicalDataProduct module. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the PhysicalDataProduct module. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// References other resources related to the described physical data product.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }
        /// <summary>
        /// A scheme containing a set of PhysicalStructures containing descriptions of overall structure of a physical data storage format. These descriptions provide the primary link to the LogicalRecord found in the data file, general structural information such as use of proprietary storage structures, division of logical records into physical segment, and default values for decimal separators, etc. Each description can apply to one or more data files containing the same logical records in the same overall structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalStructureScheme> PhysicalStructureSchemeReference { get; set; } = new List<PhysicalStructureScheme>();
        public bool ShouldSerializePhysicalStructureSchemeReference() { return PhysicalStructureSchemeReference.Count > 0; }
        /// <summary>
        /// A scheme containing a set of RecordLayouts describing the location of individual data items within the physical record and how to address them (locate and retrieve). RecordLayouts provide a link to the PhysicalStructure description and to individual variables or NCubes describing the data items.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutScheme> RecordLayoutSchemeReference { get; set; } = new List<RecordLayoutScheme>();
        public bool ShouldSerializeRecordLayoutSchemeReference() { return RecordLayoutSchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "PhysicalDataProduct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (PhysicalDataProductName != null && PhysicalDataProductName.Count > 0)
            {
                foreach (var item in PhysicalDataProductName)
                {
                    xEl.Add(item.ToXml("PhysicalDataProductName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            if (PhysicalStructureSchemeReference != null && PhysicalStructureSchemeReference.Count > 0)
            {
                foreach (var item in PhysicalStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutSchemeReference != null && RecordLayoutSchemeReference.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

