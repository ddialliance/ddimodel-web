using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains metadata specific to a particular archive's holding. This includes information on the items or collection of items held by the archive, the default terms of access, funding information and budget specific to the archive and its maintenance of this collection, reference to a quality statement related to archive activities, and coverage of the archive or sub-set of the archive.
    /// <summary>
    public partial class ArchiveSpecificType
    {
        /// <summary>
        /// A reference to the organization or an individual acting as the archive.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization ArchiveOrganizationReference_Organization { get; set; }
        /// <summary>
        /// A reference to the organization or an individual acting as the archive.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual ArchiveOrganizationReference_Individual { get; set; }
        /// <summary>
        /// Describes individual items held or distributed by the archive in connection with a study, group of studies, or resource packages. What constitutes an item is determined by the archive.
        /// <summary>
        public List<ItemType> Item { get; set; } = new List<ItemType>();
        public bool ShouldSerializeItem() { return Item.Count > 0; }
        /// <summary>
        /// Describes a collection of items held or distributed by the archive in connection with a study, group of studies, or resource packages. What constitutes an collection is determined by the archive.
        /// <summary>
        public List<CollectionType> Collection { get; set; } = new List<CollectionType>();
        public bool ShouldSerializeCollection() { return Collection.Count > 0; }
        /// <summary>
        /// Describes access to the archive in general. The restrictions noted at this level apply to all holdings of the archive unless overridden for specified collections or items.
        /// <summary>
        public List<AccessType> DefaultAccess { get; set; } = new List<AccessType>();
        public bool ShouldSerializeDefaultAccess() { return DefaultAccess.Count > 0; }
        /// <summary>
        /// Describes funding information in relationship to the archive and its activities. This may be archive wide or related to specific collections or projects within the archive.
        /// <summary>
        public List<FundingInformationType> FundingInformation { get; set; } = new List<FundingInformationType>();
        public bool ShouldSerializeFundingInformation() { return FundingInformation.Count > 0; }
        /// <summary>
        /// This describes the archive budget. It can be repeated for distinct budget activities such as budget periods, specific projects or types of activity.
        /// <summary>
        public List<BudgetType> Budget { get; set; } = new List<BudgetType>();
        public bool ShouldSerializeBudget() { return Budget.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement regarding the activities and operation of the archive. These may include access or preservation appraisal assessments or certification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// Documents the spatial, temporal, and/or topical coverage of the archive or division of an archive.
        /// <summary>
        public CoverageType Coverage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ArchiveOrganizationReference_Organization != null)
            {
                xEl.Add(new XElement(ns + "ArchiveOrganizationReference_Organization", 
                    new XElement(ns + "URN", ArchiveOrganizationReference_Organization.URN), 
                    new XElement(ns + "Agency", ArchiveOrganizationReference_Organization.Agency), 
                    new XElement(ns + "ID", ArchiveOrganizationReference_Organization.ID), 
                    new XElement(ns + "Version", ArchiveOrganizationReference_Organization.Version), 
                    new XElement(ns + "TypeOfObject", ArchiveOrganizationReference_Organization.GetType().Name)));
            }
            if (ArchiveOrganizationReference_Individual != null)
            {
                xEl.Add(new XElement(ns + "ArchiveOrganizationReference_Individual", 
                    new XElement(ns + "URN", ArchiveOrganizationReference_Individual.URN), 
                    new XElement(ns + "Agency", ArchiveOrganizationReference_Individual.Agency), 
                    new XElement(ns + "ID", ArchiveOrganizationReference_Individual.ID), 
                    new XElement(ns + "Version", ArchiveOrganizationReference_Individual.Version), 
                    new XElement(ns + "TypeOfObject", ArchiveOrganizationReference_Individual.GetType().Name)));
            }
            if (Item != null && Item.Count > 0)
            {
                foreach (var item in Item)
                {
                    xEl.Add(item.ToXml("Item"));
                }
            }
            if (Collection != null && Collection.Count > 0)
            {
                foreach (var item in Collection)
                {
                    xEl.Add(item.ToXml("Collection"));
                }
            }
            if (DefaultAccess != null && DefaultAccess.Count > 0)
            {
                foreach (var item in DefaultAccess)
                {
                    xEl.Add(item.ToXml("DefaultAccess"));
                }
            }
            if (FundingInformation != null && FundingInformation.Count > 0)
            {
                foreach (var item in FundingInformation)
                {
                    xEl.Add(item.ToXml("FundingInformation"));
                }
            }
            if (Budget != null && Budget.Count > 0)
            {
                foreach (var item in Budget)
                {
                    xEl.Add(item.ToXml("Budget"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            return xEl;
        }
    }
}

