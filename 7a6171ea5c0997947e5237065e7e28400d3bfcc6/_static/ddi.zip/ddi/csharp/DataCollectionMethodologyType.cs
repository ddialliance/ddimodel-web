using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A basic structure for describing the methodology used for collecting data. In addition to a descriptive narrative, the methodology may be classified by a short term or external controlled vocabulary.
    /// <summary>
    public partial class DataCollectionMethodologyType : IdentifiableType
    {
        /// <summary>
        /// Allows for brief identification of the type of data collection methodology using an optional controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfDataCollectionMethodology { get; set; }
        /// <summary>
        /// Full description of the data collection methodology. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfDataCollectionMethodology != null) { xEl.Add(TypeOfDataCollectionMethodology.ToXml("TypeOfDataCollectionMethodology")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

