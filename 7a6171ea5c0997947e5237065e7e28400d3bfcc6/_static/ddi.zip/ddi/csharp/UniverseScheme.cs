using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a set of Universe descriptions that may be organized into sub-universe structures. A Universe may also be known as a population. A Universe describes the "object" of a Data Element Concept or Data Element as defined by ISO/IEC 11179.
    /// <summary>
    public partial class UniverseScheme : Maintainable
    {
        /// <summary>
        /// A name for the UniverseScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> UniverseSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeUniverseSchemeName() { return UniverseSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the UniverseScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the UniverseScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows the inclusion of a UniverseScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UniverseScheme> UniverseSchemeReference { get; set; } = new List<UniverseScheme>();
        public bool ShouldSerializeUniverseSchemeReference() { return UniverseSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a universe (population, object). A universe may be organized into hierarchical sub-universe classes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Describes a group of universes (populations, objects) for administrative purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UniverseGroup> UniverseGroupReference { get; set; } = new List<UniverseGroup>();
        public bool ShouldSerializeUniverseGroupReference() { return UniverseGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "UniverseScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UniverseSchemeName != null && UniverseSchemeName.Count > 0)
            {
                foreach (var item in UniverseSchemeName)
                {
                    xEl.Add(item.ToXml("UniverseSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseSchemeReference != null && UniverseSchemeReference.Count > 0)
            {
                foreach (var item in UniverseSchemeReference)
                {
                    xEl.Add(new XElement(ns + "UniverseSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UniverseGroupReference != null && UniverseGroupReference.Count > 0)
            {
                foreach (var item in UniverseGroupReference)
                {
                    xEl.Add(new XElement(ns + "UniverseGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

