using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Maps two items of the same type within the Source and Target Schemes identified.
    /// <summary>
    public partial class ItemMapType : IdentifiableType
    {
        /// <summary>
        /// The ID of the source object in the source scheme already identified. Note that the version of the object is whichever version of it that exists in the version of the parent scheme as identified.
        /// <summary>
        public IDType SourceItem { get; set; }
        /// <summary>
        /// The ID of the target object in the target scheme already identified. Note that the version of the object is whichever version of it that exists in the version of the parent scheme as identified.
        /// <summary>
        public IDType TargetItem { get; set; }
        /// <summary>
        /// Describe the level of similarity and difference between the Source and the Target objects.
        /// <summary>
        public CorrespondenceType Correspondence { get; set; }
        /// <summary>
        /// Identifies related maps for example an ItemMap of two questions may point to the CodeMap defining the comparison of the two response domains.
        /// <summary>
        public List<ReferenceType> RelatedMapReference { get; set; } = new List<ReferenceType>();
        public bool ShouldSerializeRelatedMapReference() { return RelatedMapReference.Count > 0; }
        /// <summary>
        /// Allows for an alias to be assigned to the correspondence between two items, so that it can be referred to with a single name, that would include both related items.
        /// <summary>
        public string Alias { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (SourceItem != null) { xEl.Add(SourceItem.ToXml("SourceItem")); }
            if (TargetItem != null) { xEl.Add(TargetItem.ToXml("TargetItem")); }
            if (Correspondence != null) { xEl.Add(Correspondence.ToXml("Correspondence")); }
            if (RelatedMapReference != null && RelatedMapReference.Count > 0)
            {
                foreach (var item in RelatedMapReference)
                {
                    xEl.Add(item.ToXml("RelatedMapReference"));
                }
            }
            if (Alias != null)
            {
                xEl.Add(new XElement(ns + "Alias", Alias));
            }
            return xEl;
        }
    }
}

