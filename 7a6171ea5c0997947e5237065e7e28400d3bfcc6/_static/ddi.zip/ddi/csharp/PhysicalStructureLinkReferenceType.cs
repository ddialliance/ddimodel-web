using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// References a PhysicalStructure description and the ID of the physical record segment from that is described by this record layout. TypeOfObject should be set to PhysicalStructure.
    /// <summary>
    public partial class PhysicalStructureLinkReferenceType : ReferenceType
    {
        /// <summary>
        /// References the ID of PhysicalRecordSegment that describes the coverage of the record contents. The ID of the PhysicalRecordSegment must be contained within the referenced PhysicalStructure.
        /// <summary>
        public IDType PhysicalRecordSegmentUsed { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (PhysicalRecordSegmentUsed != null) { xEl.Add(PhysicalRecordSegmentUsed.ToXml("PhysicalRecordSegmentUsed")); }
            return xEl;
        }
    }
}

