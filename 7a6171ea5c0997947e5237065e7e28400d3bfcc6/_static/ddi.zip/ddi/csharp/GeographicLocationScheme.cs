using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Scheme containing a set of geographic locations, each for a single Geography type, e.g., States, OR Counties, OR Countries, etc. The geographic location element has to be repeated for each geography. In addition to the standard name, label, and description, allows for the inclusion of an existing GeographicLocationScheme by reference and GeographicLocation descriptions either in-line or by reference.
    /// <summary>
    public partial class GeographicLocationScheme : Maintainable
    {
        /// <summary>
        /// A name for the GeographicLocationScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> GeographicLocationSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeGeographicLocationSchemeName() { return GeographicLocationSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the GeographicLocationScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the GeographicLocationScheme. May be expressed in multiple languages and supports the use of Location content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing GeographicLocationScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicLocationScheme> GeographicLocationSchemeReference { get; set; } = new List<GeographicLocationScheme>();
        public bool ShouldSerializeGeographicLocationSchemeReference() { return GeographicLocationSchemeReference.Count > 0; }
        /// <summary>
        /// Description of a GeographicLocation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicLocation> GeographicLocationReference { get; set; } = new List<GeographicLocation>();
        public bool ShouldSerializeGeographicLocationReference() { return GeographicLocationReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of GeographicLocation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicLocationGroup> GeographicLocationGroupReference { get; set; } = new List<GeographicLocationGroup>();
        public bool ShouldSerializeGeographicLocationGroupReference() { return GeographicLocationGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "GeographicLocationScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (GeographicLocationSchemeName != null && GeographicLocationSchemeName.Count > 0)
            {
                foreach (var item in GeographicLocationSchemeName)
                {
                    xEl.Add(item.ToXml("GeographicLocationSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GeographicLocationSchemeReference != null && GeographicLocationSchemeReference.Count > 0)
            {
                foreach (var item in GeographicLocationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicLocationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicLocationReference != null && GeographicLocationReference.Count > 0)
            {
                foreach (var item in GeographicLocationReference)
                {
                    xEl.Add(new XElement(ns + "GeographicLocationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicLocationGroupReference != null && GeographicLocationGroupReference.Count > 0)
            {
                foreach (var item in GeographicLocationGroupReference)
                {
                    xEl.Add(new XElement(ns + "GeographicLocationGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

