using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A scheme containing sets of CodeLists that are used by reference to define code representations used by value representations and response domains. In addition to the standard name, label, description, the CodeListScheme may contain another CodeListScheme by reference, CodeLists either in-line or by reference, and CodeListGroups either in-line or by reference.
    /// <summary>
    public partial class CodeListScheme : Maintainable
    {
        /// <summary>
        /// A name for the CodeListScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> CodeListSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeCodeListSchemeName() { return CodeListSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the CodeListScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the CodeListScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the inclusion of another CodeListScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CodeListScheme> CodeListSchemeReference { get; set; } = new List<CodeListScheme>();
        public bool ShouldSerializeCodeListSchemeReference() { return CodeListSchemeReference.Count > 0; }
        /// <summary>
        /// A structure used to associate a list of code values to specified categories. May be flat or hierarchical. A maintainable CodeList listed in the CodeListScheme in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CodeList> CodeListReference { get; set; } = new List<CodeList>();
        public bool ShouldSerializeCodeListReference() { return CodeListReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of CodeLists for conceptual, administrative or other purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CodeListGroup> CodeListGroupReference { get; set; } = new List<CodeListGroup>();
        public bool ShouldSerializeCodeListGroupReference() { return CodeListGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "CodeListScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CodeListSchemeName != null && CodeListSchemeName.Count > 0)
            {
                foreach (var item in CodeListSchemeName)
                {
                    xEl.Add(item.ToXml("CodeListSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CodeListSchemeReference != null && CodeListSchemeReference.Count > 0)
            {
                foreach (var item in CodeListSchemeReference)
                {
                    xEl.Add(new XElement(ns + "CodeListSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CodeListReference != null && CodeListReference.Count > 0)
            {
                foreach (var item in CodeListReference)
                {
                    xEl.Add(new XElement(ns + "CodeListReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CodeListGroupReference != null && CodeListGroupReference.Count > 0)
            {
                foreach (var item in CodeListGroupReference)
                {
                    xEl.Add(new XElement(ns + "CodeListGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

