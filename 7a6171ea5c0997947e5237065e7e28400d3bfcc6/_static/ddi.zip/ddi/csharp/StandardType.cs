using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the external standard used and describes the level of compliance with the standard in terms specific aspects of the standard's content.
    /// <summary>
    public partial class StandardType
    {
        /// <summary>
        /// Provide the citation and location of the published standard using the OtherMaterialType.
        /// <summary>
        public OtherMaterialType StandardUsed { get; set; }
        /// <summary>
        /// Allows for a quality statement based on frameworks to be described using itemized properties. A reference to a concept, a coded value, or both can be used to specify the property from the standard framework identified in StandardUsed. ComplianceDescription can provide further details or a general description of compliance with a standard.
        /// <summary>
        public List<ComplianceType> Compliance { get; set; } = new List<ComplianceType>();
        public bool ShouldSerializeCompliance() { return Compliance.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (StandardUsed != null) { xEl.Add(StandardUsed.ToXml("StandardUsed")); }
            if (Compliance != null && Compliance.Count > 0)
            {
                foreach (var item in Compliance)
                {
                    xEl.Add(item.ToXml("Compliance"));
                }
            }
            return xEl;
        }
    }
}

