using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the type of evaluation, completion date, evaluation process and outcomes of the ExPost Evaluation. Allows identification of the Evaluator via reference to and organization or individual and provides for the optional use of a controlled vocabulary to define the specific role of the evaluator.
    /// <summary>
    public partial class EvaluatorType
    {
        /// <summary>
        /// Reference to an Organization or Individual involved in performing the evaluation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization EvaluatorReference_Organization { get; set; }
        /// <summary>
        /// Reference to an Organization or Individual involved in performing the evaluation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual EvaluatorReference_Individual { get; set; }
        /// <summary>
        /// Describes the role of the evaluator with optional use of a controlled vocabulary.
        /// <summary>
        public List<CodeValueType> EvaluatorRole { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeEvaluatorRole() { return EvaluatorRole.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (EvaluatorReference_Organization != null)
            {
                xEl.Add(new XElement(ns + "EvaluatorReference_Organization", 
                    new XElement(ns + "URN", EvaluatorReference_Organization.URN), 
                    new XElement(ns + "Agency", EvaluatorReference_Organization.Agency), 
                    new XElement(ns + "ID", EvaluatorReference_Organization.ID), 
                    new XElement(ns + "Version", EvaluatorReference_Organization.Version), 
                    new XElement(ns + "TypeOfObject", EvaluatorReference_Organization.GetType().Name)));
            }
            if (EvaluatorReference_Individual != null)
            {
                xEl.Add(new XElement(ns + "EvaluatorReference_Individual", 
                    new XElement(ns + "URN", EvaluatorReference_Individual.URN), 
                    new XElement(ns + "Agency", EvaluatorReference_Individual.Agency), 
                    new XElement(ns + "ID", EvaluatorReference_Individual.ID), 
                    new XElement(ns + "Version", EvaluatorReference_Individual.Version), 
                    new XElement(ns + "TypeOfObject", EvaluatorReference_Individual.GetType().Name)));
            }
            if (EvaluatorRole != null && EvaluatorRole.Count > 0)
            {
                foreach (var item in EvaluatorRole)
                {
                    xEl.Add(item.ToXml("EvaluatorRole"));
                }
            }
            return xEl;
        }
    }
}

