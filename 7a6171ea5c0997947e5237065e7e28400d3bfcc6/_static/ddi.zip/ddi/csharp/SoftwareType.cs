using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a specific software package, which may be commercially available or custom-made.
    /// <summary>
    public partial class SoftwareType
    {
        /// <summary>
        /// The name of the software package, including its producer.
        /// <summary>
        public List<NameType> SoftwareName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSoftwareName() { return SoftwareName.Count > 0; }
        /// <summary>
        /// A coded value from a controlled vocabulary, describing the software package.
        /// <summary>
        public CodeValueType SoftwarePackage { get; set; }
        /// <summary>
        /// The version of the software package. Defaults to '1.0'.
        /// <summary>
        public string SoftwareVersion { get; set; }
        /// <summary>
        /// A description of the content and purpose of the software. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Supported date of the software package with, at minimum, a release date if known.
        /// <summary>
        public DateType Date { get; set; }
        /// <summary>
        /// Identifies the functions handled by this software. Repeat for multiple functions. It may be advisable to note only those functions used in the specific usage of the software.
        /// <summary>
        public List<CodeValueType> Function { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeFunction() { return Function.Count > 0; }
        /// <summary>
        /// Language (human language) of the software package.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (SoftwareName != null && SoftwareName.Count > 0)
            {
                foreach (var item in SoftwareName)
                {
                    xEl.Add(item.ToXml("SoftwareName"));
                }
            }
            if (SoftwarePackage != null) { xEl.Add(SoftwarePackage.ToXml("SoftwarePackage")); }
            if (SoftwareVersion != null)
            {
                xEl.Add(new XElement(ns + "SoftwareVersion", SoftwareVersion));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Date != null) { xEl.Add(Date.ToXml("Date")); }
            if (Function != null && Function.Count > 0)
            {
                foreach (var item in Function)
                {
                    xEl.Add(item.ToXml("Function"));
                }
            }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

