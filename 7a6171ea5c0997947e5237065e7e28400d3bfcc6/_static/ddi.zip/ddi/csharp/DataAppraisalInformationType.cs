using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the result of data appraisal activities as a response rate and sampling error. May also list additional appraisal processes taken as a result of the initial appraisal process.
    /// <summary>
    public partial class DataAppraisalInformationType
    {
        /// <summary>
        /// A specific rate of response and/or a description of the rate of response for this event. If data contains multiple response rates for different portions of the data due to delivery method, identification of sub-populations or other reasons, repeat this element providing the specific response rate and a description of the sub-population, delivery method or other feature that was used in developing the specific rate.
        /// <summary>
        public List<ResponseRateType> ResponseRate { get; set; } = new List<ResponseRateType>();
        public bool ShouldSerializeResponseRate() { return ResponseRate.Count > 0; }
        /// <summary>
        /// Sampling Error provided using a StructuredString to support multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> SamplingError { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeSamplingError() { return SamplingError.Count > 0; }
        /// <summary>
        /// Other Appraisal Process provided using a StructuredString to support multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> OtherAppraisalProcess { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeOtherAppraisalProcess() { return OtherAppraisalProcess.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ResponseRate != null && ResponseRate.Count > 0)
            {
                foreach (var item in ResponseRate)
                {
                    xEl.Add(item.ToXml("ResponseRate"));
                }
            }
            if (SamplingError != null && SamplingError.Count > 0)
            {
                foreach (var item in SamplingError)
                {
                    xEl.Add(item.ToXml("SamplingError"));
                }
            }
            if (OtherAppraisalProcess != null && OtherAppraisalProcess.Count > 0)
            {
                foreach (var item in OtherAppraisalProcess)
                {
                    xEl.Add(item.ToXml("OtherAppraisalProcess"));
                }
            }
            return xEl;
        }
    }
}

