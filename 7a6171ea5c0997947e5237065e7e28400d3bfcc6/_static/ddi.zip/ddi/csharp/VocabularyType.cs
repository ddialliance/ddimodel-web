using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides information about the vocabulary used to create a concept scheme.
    /// <summary>
    public partial class VocabularyType
    {
        /// <summary>
        /// Full title of vocabulary.
        /// <summary>
        public InternationalStringType VocabularyTitle { get; set; }
        /// <summary>
        /// Abbreviation of vocabulary title.
        /// <summary>
        public List<InternationalStringType> Abbreviation { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeAbbreviation() { return Abbreviation.Count > 0; }
        /// <summary>
        /// Keywords that describe the vocabulary.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Vocabulary. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// URI to external resource providing information about the vocabulary (general description, main web page).
        /// <summary>
        public Uri URI { get; set; }
        /// <summary>
        /// URI to the vocabulary represented as an XML document.
        /// <summary>
        public Uri XML-URI { get; set; }
        /// <summary>
        /// Textual description of the XML scheme in which the classification is written.
        /// <summary>
        public string Scheme { get; set; }
        /// <summary>
        /// URI to the XML scheme used in the vocabulary (DTD or XML Schema for the XML document above; schemes like DDI, Claset, Neuchatel, and DocBook). Typically, this will be an XML namespace.
        /// <summary>
        public Uri SchemeURI { get; set; }
        /// <summary>
        /// Information for the user regarding the reasons for use of the vocabulary and appropriate usage constraints.
        /// <summary>
        public List<StructuredStringType> Comments { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeComments() { return Comments.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VocabularyTitle != null) { xEl.Add(VocabularyTitle.ToXml("VocabularyTitle")); }
            if (Abbreviation != null && Abbreviation.Count > 0)
            {
                foreach (var item in Abbreviation)
                {
                    xEl.Add(item.ToXml("Abbreviation"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (URI != null)
            {
                xEl.Add(new XElement(ns + "URI", URI));
            }
            if (XML-URI != null)
            {
                xEl.Add(new XElement(ns + "XML-URI", XML-URI));
            }
            if (Scheme != null)
            {
                xEl.Add(new XElement(ns + "Scheme", Scheme));
            }
            if (SchemeURI != null)
            {
                xEl.Add(new XElement(ns + "SchemeURI", SchemeURI));
            }
            if (Comments != null && Comments.Count > 0)
            {
                foreach (var item in Comments)
                {
                    xEl.Add(item.ToXml("Comments"));
                }
            }
            return xEl;
        }
    }
}

