using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the representation of the variable in the data set. Describes the function of the variable, variables or standard weights that may be used to weight this variable during analysis, imputation and processing information, other variables used to create the value of this variable through concatenation, valid value representations (valid for analysis of respondents), missing value representations, aggregation methods used to generate the content of the variable, and additivity information.
    /// <summary>
    public partial class VariableRepresentationType
    {
        /// <summary>
        /// Describes a specific function of the variable, such as identity, weight, geographic variable, time, date, currency, etc. This is a more extensive means of identifying the function of the variable than the Boolean indicators on the variable. Allows for agency specific designations. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType VariableRole { get; set; }
        /// <summary>
        /// Reference to one or more weight variables that may be used in analyzing this variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> WeightVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeWeightVariableReference() { return WeightVariableReference.Count > 0; }
        /// <summary>
        /// Reference to the StandardWeight found in the Weighting description, which is relevant for analyzing this variable. A standard weight is a single weight used for all variables of a specific type or for a specified sub-universe.
        /// <summary>
        public StandardWeightType StandardWeightReference { get; set; }
        /// <summary>
        /// Reference to the imputation process described as a General Instruction in a ProcessingInstructionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeneralInstruction ImputationReference_GeneralInstruction { get; set; }
        /// <summary>
        /// Reference to the imputation process described as a General Instruction in a ProcessingInstructionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction ImputationReference_GenerationInstruction { get; set; }
        /// <summary>
        /// Provides a reference to other variables and describes the method for deriving the value of this variable by concatenating a collection of other variables. This is useful in creating concatenated keys.
        /// <summary>
        public ConcatenatedValueType ConcatenatedValue { get; set; }
        /// <summary>
        /// A reference to either a general or generation instruction that was provided to those who converted information from one form to another to create a particular variable. This might include the reordering of numeric information into another form or the conversion of textual information into numeric information.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction ProcessingInstructionReference { get; set; }
        /// <summary>
        /// Describes the actual representation of the variables' values. Allows for the listing of values to be treated as missing in order to support 3.1 structures. The preferred method is the use of a reference to ManagedMissingValues description using MissingValuesReference. If both are used and there is a conflict in the content, MissingValuesReference will override the content provided in the ValueRepresentationReference.
        /// <summary>
        public RepresentationType ValueRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ValueRepresentationReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ValueRepresentationReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ValueRepresentationReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ValueRepresentationReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ValueRepresentationReference_ManagedTextRepresentation { get; set; }
        /// <summary>
        /// Reference to an existing MissingValuesRepresentation using the Reference structure. If this content conflicts with content provided in the ValueRepresentation regarding Missing Values. The content of the MissingValuesRepresentation overrides. TypeOfObject will be MissingValuesRepresentation
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation MissingValuesReference { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// Identifies the difference between the date applied to the data as a whole and this specific item such as previous year's income or residence 5 years ago.
        /// <summary>
        public ContentDateOffsetType ContentDateOffset { get; set; }
        /// <summary>
        /// Indicates the type of aggregation method used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType AggregationMethod { get; set; }
        /// <summary>
        /// Records type of additivity, such as 'stock', 'flow', 'non-additive'.
        /// <summary>
        [StringValidation(new string[] {
            "Stock"
,             "Flow"
,             "NonAdditive"
        })]
        public string Additivity { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableRole != null) { xEl.Add(VariableRole.ToXml("VariableRole")); }
            if (WeightVariableReference != null && WeightVariableReference.Count > 0)
            {
                foreach (var item in WeightVariableReference)
                {
                    xEl.Add(new XElement(ns + "WeightVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (StandardWeightReference != null) { xEl.Add(StandardWeightReference.ToXml("StandardWeightReference")); }
            if (ImputationReference_GeneralInstruction != null)
            {
                xEl.Add(new XElement(ns + "ImputationReference_GeneralInstruction", 
                    new XElement(ns + "URN", ImputationReference_GeneralInstruction.URN), 
                    new XElement(ns + "Agency", ImputationReference_GeneralInstruction.Agency), 
                    new XElement(ns + "ID", ImputationReference_GeneralInstruction.ID), 
                    new XElement(ns + "Version", ImputationReference_GeneralInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ImputationReference_GeneralInstruction.GetType().Name)));
            }
            if (ImputationReference_GenerationInstruction != null)
            {
                xEl.Add(new XElement(ns + "ImputationReference_GenerationInstruction", 
                    new XElement(ns + "URN", ImputationReference_GenerationInstruction.URN), 
                    new XElement(ns + "Agency", ImputationReference_GenerationInstruction.Agency), 
                    new XElement(ns + "ID", ImputationReference_GenerationInstruction.ID), 
                    new XElement(ns + "Version", ImputationReference_GenerationInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ImputationReference_GenerationInstruction.GetType().Name)));
            }
            if (ConcatenatedValue != null) { xEl.Add(ConcatenatedValue.ToXml("ConcatenatedValue")); }
            if (ProcessingInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference", 
                    new XElement(ns + "URN", ProcessingInstructionReference.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference.GetType().Name)));
            }
            if (ValueRepresentation != null) { xEl.Add(ValueRepresentation.ToXml("ValueRepresentation")); }
            if (ValueRepresentationReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedTextRepresentation.GetType().Name)));
            }
            if (MissingValuesReference != null)
            {
                xEl.Add(new XElement(ns + "MissingValuesReference", 
                    new XElement(ns + "URN", MissingValuesReference.URN), 
                    new XElement(ns + "Agency", MissingValuesReference.Agency), 
                    new XElement(ns + "ID", MissingValuesReference.ID), 
                    new XElement(ns + "Version", MissingValuesReference.Version), 
                    new XElement(ns + "TypeOfObject", MissingValuesReference.GetType().Name)));
            }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (ContentDateOffset != null) { xEl.Add(ContentDateOffset.ToXml("ContentDateOffset")); }
            if (AggregationMethod != null) { xEl.Add(AggregationMethod.ToXml("AggregationMethod")); }
            if (Additivity != null)
            {
                xEl.Add(new XElement(ns + "Additivity", Additivity));
            }
            return xEl;
        }
    }
}

