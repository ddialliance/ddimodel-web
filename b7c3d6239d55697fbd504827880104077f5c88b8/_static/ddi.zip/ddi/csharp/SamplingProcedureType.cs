using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a sampling procedure. If multiple sampling procedures were used repeat this element for each.
    /// <summary>
    public partial class SamplingProcedureType : IdentifiableType
    {
        /// <summary>
        /// A generic means of classifying a SamplingProcedure. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfSamplingProcedure { get; set; }
        /// <summary>
        /// Full description of the sampling procedure. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describe the population being sampled through a combination of textual description and reference to a structured Universe.
        /// <summary>
        public List<PopulationType> PopulationOfConcern { get; set; } = new List<PopulationType>();
        public bool ShouldSerializePopulationOfConcern() { return PopulationOfConcern.Count > 0; }
        /// <summary>
        /// Reference to sample plan which describes a process for achieving the sample.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlan SamplingPlanReference { get; set; }
        /// <summary>
        /// The target value of the sample size for the primary and any secondary or sub-population.
        /// <summary>
        public List<PopulationSizeType> OverallTargetSampleSize { get; set; } = new List<PopulationSizeType>();
        public bool ShouldSerializeOverallTargetSampleSize() { return OverallTargetSampleSize.Count > 0; }
        /// <summary>
        /// The size of the overall sample actually used.
        /// <summary>
        public SizeType OverallSampleSize { get; set; }
        /// <summary>
        /// Provides sample stage level details where needed. Repeat for individual stages or sub-stages.
        /// <summary>
        public List<ApplicationDetailsType> ApplicationDetails { get; set; } = new List<ApplicationDetailsType>();
        public bool ShouldSerializeApplicationDetails() { return ApplicationDetails.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingProcedure != null) { xEl.Add(TypeOfSamplingProcedure.ToXml("TypeOfSamplingProcedure")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (PopulationOfConcern != null && PopulationOfConcern.Count > 0)
            {
                foreach (var item in PopulationOfConcern)
                {
                    xEl.Add(item.ToXml("PopulationOfConcern"));
                }
            }
            if (SamplingPlanReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanReference", 
                    new XElement(ns + "URN", SamplingPlanReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanReference.ID), 
                    new XElement(ns + "Version", SamplingPlanReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanReference.GetType().Name)));
            }
            if (OverallTargetSampleSize != null && OverallTargetSampleSize.Count > 0)
            {
                foreach (var item in OverallTargetSampleSize)
                {
                    xEl.Add(item.ToXml("OverallTargetSampleSize"));
                }
            }
            if (OverallSampleSize != null) { xEl.Add(OverallSampleSize.ToXml("OverallSampleSize")); }
            if (ApplicationDetails != null && ApplicationDetails.Count > 0)
            {
                foreach (var item in ApplicationDetails)
                {
                    xEl.Add(item.ToXml("ApplicationDetails"));
                }
            }
            return xEl;
        }
    }
}

