using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A substage assumes that its sample frame is the result of its parent stage.
    /// <summary>
    public partial class SubStageType : IdentifiableType
    {
        /// <summary>
        /// Condition for using this stage. Use only when multiple top level stages are used.
        /// <summary>
        public List<StratificationType> Stratification { get; set; } = new List<StratificationType>();
        public bool ShouldSerializeStratification() { return Stratification.Count > 0; }
        /// <summary>
        /// A split results in multiple strata using different sampling plans. For example a study of those who fish which samples those engaged in fishing at particular locations (strata 1) and those who have fishing licenses (strata 2).
        /// <summary>
        public CodeValueType SamplingUnit { get; set; }
        /// <summary>
        /// Identifies a specific sample frame or frames appropriate for this plan.
        /// <summary>
        public CodeValueType TypeOfPlan { get; set; }
        /// <summary>
        /// Allows for recursive nesting.
        /// <summary>
        public List<SubStageType> SubStage { get; set; } = new List<SubStageType>();
        public bool ShouldSerializeSubStage() { return SubStage.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (Stratification != null && Stratification.Count > 0)
            {
                foreach (var item in Stratification)
                {
                    xEl.Add(item.ToXml("Stratification"));
                }
            }
            if (SamplingUnit != null) { xEl.Add(SamplingUnit.ToXml("SamplingUnit")); }
            if (TypeOfPlan != null) { xEl.Add(TypeOfPlan.ToXml("TypeOfPlan")); }
            if (SubStage != null && SubStage.Count > 0)
            {
                foreach (var item in SubStage)
                {
                    xEl.Add(item.ToXml("SubStage"));
                }
            }
            return xEl;
        }
    }
}

