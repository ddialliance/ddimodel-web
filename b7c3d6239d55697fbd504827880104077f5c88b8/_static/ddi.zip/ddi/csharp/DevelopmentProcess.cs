using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a name, label and description for the Development Process and lists the individual development activities which should take place.
    /// <summary>
    public partial class DevelopmentProcess : Versionable
    {
        /// <summary>
        /// A name for the DevelopmentProcess. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentProcessName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentProcessName() { return DevelopmentProcessName.Count > 0; }
        /// <summary>
        /// A display label for the Development Process. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the overall Development Process. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// References the Development Plan which the results refer to.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentPlan> DevelopmentPlanReference { get; set; } = new List<DevelopmentPlan>();
        public bool ShouldSerializeDevelopmentPlanReference() { return DevelopmentPlanReference.Count > 0; }
        /// <summary>
        /// Steps within the development process.
        /// <summary>
        public List<DevelopmentProcessStepType> DevelopmentProcessStep { get; set; } = new List<DevelopmentProcessStepType>();
        public bool ShouldSerializeDevelopmentProcessStep() { return DevelopmentProcessStep.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentProcess");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentProcessName != null && DevelopmentProcessName.Count > 0)
            {
                foreach (var item in DevelopmentProcessName)
                {
                    xEl.Add(item.ToXml("DevelopmentProcessName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentPlanReference != null && DevelopmentPlanReference.Count > 0)
            {
                foreach (var item in DevelopmentPlanReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentPlanReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentProcessStep != null && DevelopmentProcessStep.Count > 0)
            {
                foreach (var item in DevelopmentProcessStep)
                {
                    xEl.Add(item.ToXml("DevelopmentProcessStep"));
                }
            }
            return xEl;
        }
    }
}

