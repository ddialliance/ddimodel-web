using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Processing instructions that pertain to data collection or data processing overall such as handling of non-response to questions, imputation practices, suppression rules, etc. General instructions should be listed separately to allow for referencing of specific processes.
    /// <summary>
    public partial class GeneralInstruction : ProcessingInstruction
    {
        /// <summary>
        /// A description of the general instruction. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Structured information used by a system to process the instruction.
        /// <summary>
        public List<CommandCodeType> CommandCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeCommandCode() { return CommandCode.Count > 0; }
        /// <summary>
        /// Used when attribute of the containing GeneralInstruction isOverride equals true. This element provides the reference to the GeneralInstruction being overridden by the use of this instruction. For example a special confidentiality process used for a select set of variables rather than the normal process.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstruction OverriddenCodeReference { get; set; }
        /// <summary>
        /// If set to "true", indicates that this coding instruction overrides a more generally used process.
        /// <summary>
        public bool IsOverride { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "GeneralInstruction");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CommandCode != null && CommandCode.Count > 0)
            {
                foreach (var item in CommandCode)
                {
                    xEl.Add(item.ToXml("CommandCode"));
                }
            }
            if (OverriddenCodeReference != null)
            {
                xEl.Add(new XElement(ns + "OverriddenCodeReference", 
                    new XElement(ns + "URN", OverriddenCodeReference.URN), 
                    new XElement(ns + "Agency", OverriddenCodeReference.Agency), 
                    new XElement(ns + "ID", OverriddenCodeReference.ID), 
                    new XElement(ns + "Version", OverriddenCodeReference.Version), 
                    new XElement(ns + "TypeOfObject", OverriddenCodeReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOverride", IsOverride));
            return xEl;
        }
    }
}

