using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Correspondence Table expresses the relationship between two Statistical Classifications. These are typically: two versions from the same Classification Series; Statistical Classifications from different Classification Series; a variant and the version on which it is based; different versions of a variant. In the first and last examples, the Correspondence Table facilitates comparability over time. Correspondence relationships are shown in both directions
    /// <summary>
    public partial class ClassificationCorrespondenceTable : Describable
    {
        /// <summary>
        /// The statistical office, other authority or section that created and maintains the Correspondence Table. A Correspondence Table may have several owners.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> Owner { get; set; } = new List<Agent>();
        public bool ShouldSerializeOwner() { return Owner.Count > 0; }
        /// <summary>
        /// The unit or group of persons who are responsible for the Correspondence Table, i.e. for maintaining and updating it. 
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> MaintenanceUnit { get; set; } = new List<Agent>();
        public bool ShouldSerializeMaintenanceUnit() { return MaintenanceUnit.Count > 0; }
        /// <summary>
        /// The person(s) who may be contacted for additional information about the Correspondence Table.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ContactPerson { get; set; } = new List<Agent>();
        public bool ShouldSerializeContactPerson() { return ContactPerson.Count > 0; }
        /// <summary>
        /// A list of the publications in which the Correspondence Table has been published. 
        /// <summary>
        public List<PublicationType> Publication { get; set; } = new List<PublicationType>();
        public bool ShouldSerializePublication() { return Publication.Count > 0; }
        /// <summary>
        /// The Statistical Classification from which the correspondence is made. 
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public StatisticalClassification SourceClassification { get; set; }
        /// <summary>
        /// The Statistical Classification(s) to which the correspondence is directed. There may be multiple target Statistical Classifications associated with the Correspondence Table.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StatisticalClassification> TargetClassification { get; set; } = new List<StatisticalClassification>();
        public bool ShouldSerializeTargetClassification() { return TargetClassification.Count > 0; }
        /// <summary>
        /// The correspondence is normally restricted to a certain Level in the source Statistical Classification. In this case, target Classification Items are assigned only to source Classification Items on the given level. If no level is indicated, target Classification Items can be assigned to any Level of the source Statistical Classification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel SourceLevel { get; set; }
        /// <summary>
        /// The correspondence is normally restricted to a certain Level in the target Statistical Classification. In this case, source Classification Items are assigned only to target Classification Items on the given Level. If no Level is indicated, source Classification Items can be assigned to any Level of the target Statistical Classification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel TargetLevel { get; set; }
        /// <summary>
        /// A Correspondence Table can define a 1:1, 1:N, N:1 or M:N relationship between source and target Classification Items.
        /// <summary>
        public CodeValueType RelationshipMappingType { get; set; }
        /// <summary>
        /// The relationship between two Statistical Classifications
        /// <summary>
        public List<ClassificationMapType> Maps { get; set; } = new List<ClassificationMapType>();
        public bool ShouldSerializeMaps() { return Maps.Count > 0; }
        /// <summary>
        /// If the source and/or target Statistical Classifications of a Correspondence Table are floating Statistical Classifications, the date of the Correspondence Table must be noted. The Correspondence Table expresses the relationships between the two Statistical Classifications as they existed on the date specified in the Correspondence Table.
        /// <summary>
        public CogsDate FloatingMapDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationCorrespondenceTable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Owner != null && Owner.Count > 0)
            {
                foreach (var item in Owner)
                {
                    xEl.Add(new XElement(ns + "Owner", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MaintenanceUnit != null && MaintenanceUnit.Count > 0)
            {
                foreach (var item in MaintenanceUnit)
                {
                    xEl.Add(new XElement(ns + "MaintenanceUnit", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ContactPerson != null && ContactPerson.Count > 0)
            {
                foreach (var item in ContactPerson)
                {
                    xEl.Add(new XElement(ns + "ContactPerson", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Publication != null && Publication.Count > 0)
            {
                foreach (var item in Publication)
                {
                    xEl.Add(item.ToXml("Publication"));
                }
            }
            if (SourceClassification != null)
            {
                xEl.Add(new XElement(ns + "SourceClassification", 
                    new XElement(ns + "URN", SourceClassification.URN), 
                    new XElement(ns + "Agency", SourceClassification.Agency), 
                    new XElement(ns + "ID", SourceClassification.ID), 
                    new XElement(ns + "Version", SourceClassification.Version), 
                    new XElement(ns + "TypeOfObject", SourceClassification.GetType().Name)));
            }
            if (TargetClassification != null && TargetClassification.Count > 0)
            {
                foreach (var item in TargetClassification)
                {
                    xEl.Add(new XElement(ns + "TargetClassification", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SourceLevel != null)
            {
                xEl.Add(new XElement(ns + "SourceLevel", 
                    new XElement(ns + "URN", SourceLevel.URN), 
                    new XElement(ns + "Agency", SourceLevel.Agency), 
                    new XElement(ns + "ID", SourceLevel.ID), 
                    new XElement(ns + "Version", SourceLevel.Version), 
                    new XElement(ns + "TypeOfObject", SourceLevel.GetType().Name)));
            }
            if (TargetLevel != null)
            {
                xEl.Add(new XElement(ns + "TargetLevel", 
                    new XElement(ns + "URN", TargetLevel.URN), 
                    new XElement(ns + "Agency", TargetLevel.Agency), 
                    new XElement(ns + "ID", TargetLevel.ID), 
                    new XElement(ns + "Version", TargetLevel.Version), 
                    new XElement(ns + "TypeOfObject", TargetLevel.GetType().Name)));
            }
            if (RelationshipMappingType != null) { xEl.Add(RelationshipMappingType.ToXml("RelationshipMappingType")); }
            if (Maps != null && Maps.Count > 0)
            {
                foreach (var item in Maps)
                {
                    xEl.Add(item.ToXml("Maps"));
                }
            }
            if (FloatingMapDate != null && FloatingMapDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "FloatingMapDate", FloatingMapDate.ToString()));
            }
            return xEl;
        }
    }
}

