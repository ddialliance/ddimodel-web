using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Documents an event in the life cycle of a study or group of studies. A life cycle event can be any event which is judged to be significant enough to document by the agency maintaining the documentation for a particular set of data. The element EventType indicates the type of event, using a typology meaningful to the documenter.
    /// <summary>
    public partial class LifecycleEventType : IdentifiableType
    {
        /// <summary>
        /// A label for the LifecycleEvent. May be repeated to provide different labels needed due to system or application constraints.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Indicates the type of LifecycleEvent, using a typology meaningful to the documenter. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType EventType { get; set; }
        /// <summary>
        /// The date or date range of the LifecycleEvent.
        /// <summary>
        public DateType Date { get; set; }
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for the life cycle event.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> AgencyOrganizationReference { get; set; } = new List<Organization>();
        public bool ShouldSerializeAgencyOrganizationReference() { return AgencyOrganizationReference.Count > 0; }
        /// <summary>
        /// A description of the event such as what the event included, its importance, or other significant information. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows linking a lifecycle event to one or more sections of metadata. If no relationship is noted the lifecycle event relates to its full parent StudyUnit, Group, or Resource Package.
        /// <summary>
        public List<RelationshipType> Relationship { get; set; } = new List<RelationshipType>();
        public bool ShouldSerializeRelationship() { return Relationship.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (EventType != null) { xEl.Add(EventType.ToXml("EventType")); }
            if (Date != null) { xEl.Add(Date.ToXml("Date")); }
            if (AgencyOrganizationReference != null && AgencyOrganizationReference.Count > 0)
            {
                foreach (var item in AgencyOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "AgencyOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Relationship != null && Relationship.Count > 0)
            {
                foreach (var item in Relationship)
                {
                    xEl.Add(item.ToXml("Relationship"));
                }
            }
            return xEl;
        }
    }
}

