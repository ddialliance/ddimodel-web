using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines a dimension of a scale providing it with a label, a numeric or character based range, the attachment of a category label at one or more of the scale values, the frequency of increment markers, and the frequency of value labels on marked or unmarked increments.
    /// <summary>
    public partial class ScaleDimensionType
    {
        /// <summary>
        /// A display label for the scale. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Indicates the high and low values (endpoints) of a numeric scale.
        /// <summary>
        public NumberRangeType NumberRange { get; set; }
        /// <summary>
        /// Indicates the high and low values (endpoints) of a non-numeric scale.
        /// <summary>
        public RangeType Range { get; set; }
        /// <summary>
        /// Allows for the attachment of a category label at any anchor point.
        /// <summary>
        public List<AnchorType> Anchor { get; set; } = new List<AnchorType>();
        public bool ShouldSerializeAnchor() { return Anchor.Count > 0; }
        /// <summary>
        /// Identifies the frequency for increment markers (with or without value attachments).
        /// <summary>
        public BasicIncrementType MarkedIncrement { get; set; }
        /// <summary>
        /// Identifies the frequency for value labels on marked or unmarked increments.
        /// <summary>
        public BasicIncrementType ValueIncrement { get; set; }
        /// <summary>
        /// A number used to identify this dimension when describing its intersect point with one or more dimensions in the same scale representation. The dimension is denoted with a 1-based indexing. Dimension in the scale are numbered (1,2,n).
        /// <summary>
        public int DimensionNumber { get; set; }
        /// <summary>
        /// A horizontal line is described as a 0 (zero) slope. Expressed as the number of degrees positive (right end angle above the horizontal line) or degrees positive (right end descending below the horizontal line).
        /// <summary>
        public int DegreeSlopeFromHorizontal { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (NumberRange != null) { xEl.Add(NumberRange.ToXml("NumberRange")); }
            if (Range != null) { xEl.Add(Range.ToXml("Range")); }
            if (Anchor != null && Anchor.Count > 0)
            {
                foreach (var item in Anchor)
                {
                    xEl.Add(item.ToXml("Anchor"));
                }
            }
            if (MarkedIncrement != null) { xEl.Add(MarkedIncrement.ToXml("MarkedIncrement")); }
            if (ValueIncrement != null) { xEl.Add(ValueIncrement.ToXml("ValueIncrement")); }
            xEl.Add(new XElement(ns + "DimensionNumber", DimensionNumber));
            xEl.Add(new XElement(ns + "DegreeSlopeFromHorizontal", DegreeSlopeFromHorizontal));
            return xEl;
        }
    }
}

