using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Classification Series is an ensemble of one or several consecutive Statistical Classifications under a particular heading (for example ISIC or ISCO).
    /// <summary>
    public partial class ClassificationSeries : Describable
    {
        /// <summary>
        /// A Classification Series can be designed in a specific context. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType SeriesContext { get; set; }
        /// <summary>
        /// A Classification Series is designed to classify a specific type of object/unit according to a specific attribute. TypeOfObject should be set to UnitType.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public UnitType UnitTypeClassifiedReference { get; set; }
        /// <summary>
        /// Areas of statistics in which the Classification Series is implemented. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> SubjectArea { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeSubjectArea() { return SubjectArea.Count > 0; }
        /// <summary>
        /// The statistical office or other authority, which created and maintains the Statistical Classification(s) related to the Classification Series. A Classification Series may have several owners. TypeOfObject should be set to Organization or Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> OwnerReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeOwnerReference() { return OwnerReference.Count > 0; }
        /// <summary>
        /// A Classification Series can be associated with one or a number of keywords. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// A Classification Series has at least one Statistical Classification. TypeOfObject should be set to StatisticalClassification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StatisticalClassification> StatisticalClassificationReference { get; set; } = new List<StatisticalClassification>();
        public bool ShouldSerializeStatisticalClassificationReference() { return StatisticalClassificationReference.Count > 0; }
        /// <summary>
        /// If there are several Statistical Classifications related to a Classification Series, one Statistical Classification may be assigned as the currently valid Statistical Classification. TypeOfObject should be set to StatisticalClassification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public StatisticalClassification CurrentStatisticalClassificationReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationSeries");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SeriesContext != null) { xEl.Add(SeriesContext.ToXml("SeriesContext")); }
            if (UnitTypeClassifiedReference != null)
            {
                xEl.Add(new XElement(ns + "UnitTypeClassifiedReference", 
                    new XElement(ns + "URN", UnitTypeClassifiedReference.URN), 
                    new XElement(ns + "Agency", UnitTypeClassifiedReference.Agency), 
                    new XElement(ns + "ID", UnitTypeClassifiedReference.ID), 
                    new XElement(ns + "Version", UnitTypeClassifiedReference.Version), 
                    new XElement(ns + "TypeOfObject", UnitTypeClassifiedReference.GetType().Name)));
            }
            if (SubjectArea != null && SubjectArea.Count > 0)
            {
                foreach (var item in SubjectArea)
                {
                    xEl.Add(item.ToXml("SubjectArea"));
                }
            }
            if (OwnerReference != null && OwnerReference.Count > 0)
            {
                foreach (var item in OwnerReference)
                {
                    xEl.Add(new XElement(ns + "OwnerReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (StatisticalClassificationReference != null && StatisticalClassificationReference.Count > 0)
            {
                foreach (var item in StatisticalClassificationReference)
                {
                    xEl.Add(new XElement(ns + "StatisticalClassificationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CurrentStatisticalClassificationReference != null)
            {
                xEl.Add(new XElement(ns + "CurrentStatisticalClassificationReference", 
                    new XElement(ns + "URN", CurrentStatisticalClassificationReference.URN), 
                    new XElement(ns + "Agency", CurrentStatisticalClassificationReference.Agency), 
                    new XElement(ns + "ID", CurrentStatisticalClassificationReference.ID), 
                    new XElement(ns + "Version", CurrentStatisticalClassificationReference.Version), 
                    new XElement(ns + "TypeOfObject", CurrentStatisticalClassificationReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

