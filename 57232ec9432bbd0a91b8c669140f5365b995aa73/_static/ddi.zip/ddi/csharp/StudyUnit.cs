using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A primary packaging and publication module within DDI representing the purpose, background, development, data capture, and data products related to a study. In DDI a study is defined as a single coordinated set of data collection/capture activities, such as a one-time survey or a single iteration of a multi-year repeated study (such as one year of a longitudinal survey). The StudyUnit brings together all of the components of the study including the description of its purpose, funding, quality statements, data collection and capture methods and activities, processing activities, and a description of the resulting data (description of its intellectual or logical content plus a description of its physical store). A study unit may have only a single data collection or capture process resulting in one or more data products (i.e., Census). A complex study unit may contain multiple means of data capture that are integrated into one or more data products (i.e., a medical study collecting bio-markers, patient background, health care service information, etc.). A longitudinal study with multiple waves or iterations of data collection is considered to be a group of studies, each wave or iteration captured as a single study unit. As a primary packaging module, the Study Unit contains a full citation, abstract, authorization information, a universe reference, series statement, quality statement, information on post study evaluation, funding information, budget, purpose, coverage, type of analysis units covered, kind of data, other materials, a list of required resource packages, embargoes,  the conceptual components (universe, concept, data element, geographic structure and locations), data collection, logical products, physical data products, physical instance, archive, and DDI profile. The maintainable elements within a Study Unit may be included in-line or by reference.
    /// <summary>
    public partial class StudyUnit : Maintainable
    {
        /// <summary>
        /// A brief textual identification of the StudyUnit. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfStudyUnit { get; set; }
        /// <summary>
        /// The citation for the study. DDI strongly recommends that at minimum a Title be provided.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// An abstract of the study unit describing the nature and scope of the data collection, special characteristics of its content. Note that detailed information on the purpose of the study and structured coverage information are to be entered in Purpose and Coverage. Abstract supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Abstract { get; set; }
        /// <summary>
        /// Identifies the authorizing agency for the study and allows for the full text of the authorization (law, regulation, or other form of authorization). May be used to list authorizations from oversight committees and other regulatory agencies.
        /// <summary>
        public List<AuthorizationSourceType> AuthorizationSource { get; set; } = new List<AuthorizationSourceType>();
        public bool ShouldSerializeAuthorizationSource() { return AuthorizationSource.Count > 0; }
        /// <summary>
        /// Provides information about the Approval Review undertaken in relation to the activity. Identifies the organization processing the review, the role of the approval review organization, case number, description, and related dates. Allows the inclusion of a reference to an external source detailing the approval review.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ApprovalReview ApprovalReviewReference { get; set; }
        /// <summary>
        /// A concept that defines or aids in understanding the content of the study unit.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept DefiningConceptReference { get; set; }
        /// <summary>
        /// Reference to the universe statement from the universe scheme, describing the group of persons or other elements that are the object of research and to which any analytic results refer. Age, nationality, and residence commonly help to delineate a given universe, but any of a number of factors may be involved, such as sex, race, income, veteran status, criminal convictions, etc. The universe may consist of elements other than persons, such as housing units, court cases, deaths, countries, etc. In general, it should be possible to tell from the description of the universe whether a given individual or element (hypothetical or real) is a member of the population under study. A universe may be described as "inclusive" or "exclusive". This StudyUnit level reference is normally to the top level of the UniverseScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// A study, particularly one in a series, may be the result of two series merging into a single study. The new study belongs to both series. For example, Niger now fields the UNICEF Multiple Indicators Cluster Survey (MICS) and the Demographic and Health Survey as a single merged instrument.
        /// <summary>
        public List<SeriesStatementType> SeriesStatement { get; set; } = new List<SeriesStatementType>();
        public bool ShouldSerializeSeriesStatement() { return SeriesStatement.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the study overall, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// A scheme containing statements of quality related to the quality of methodologies, metadata, or data. Quality statements and standards may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityScheme> QualitySchemeReference { get; set; } = new List<QualityScheme>();
        public bool ShouldSerializeQualitySchemeReference() { return QualitySchemeReference.Count > 0; }
        /// <summary>
        /// An evaluation of the study process, often taking place after the completion of the study. These may include issues such as timing of the study, sequencing issues, cost/budget issues, relevance, institutional or legal arrangements etc. of the study. If the study is part of a series or group (i.e., a single wave in a longitudinal study) this may include evaluation of earlier waves which resulted in changes to the current wave.
        /// <summary>
        public List<ExPostEvaluationType> ExPostEvaluation { get; set; } = new List<ExPostEvaluationType>();
        public bool ShouldSerializeExPostEvaluation() { return ExPostEvaluation.Count > 0; }
        /// <summary>
        /// Contains details of the study unit's funding, including information about grants, agencies, etc.
        /// <summary>
        public List<FundingInformationType> FundingInformation { get; set; } = new List<FundingInformationType>();
        public bool ShouldSerializeFundingInformation() { return FundingInformation.Count > 0; }
        /// <summary>
        /// This describes the overall budget of the study. It can be repeated for distinct budget activities. It contains a structured description and one or more budget documents described by an OtherMaterial type.
        /// <summary>
        public List<BudgetType> StudyBudget { get; set; } = new List<BudgetType>();
        public bool ShouldSerializeStudyBudget() { return StudyBudget.Count > 0; }
        /// <summary>
        /// The purpose of the study, why the study took place. This should include detailed information on the investigator's primary study questions or hypotheses as well as information on any legal basis for the data collection, such as laws requiring the collection of census data for apportionment purposes. Legal or other authorization should be provided in detail within AuthorizationSource. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Purpose { get; set; }
        /// <summary>
        /// Describes the coverage of the study unit. Detailed information on Topical, Temporal, and Spatial Coverage is contained here. Note that Coverage at this level should be inclusive all lower level modules or section. Lower level descriptions serve to constrain coverage within the scope described here.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Allows the use of a controlled vocabulary to list all of the units of analysis used in the study. Should be repeated to describe multiple units of analysis. The DDI Alliance has provided a controlled vocabulary (AnalysisUnit) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public List<CodeValueType> AnalysisUnit { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeAnalysisUnit() { return AnalysisUnit.Count > 0; }
        /// <summary>
        /// A narrative of the units of analysis in the study unit. Uses an InternationalString to support multiple languages.
        /// <summary>
        public InternationalStringType AnalysisUnitsCovered { get; set; }
        /// <summary>
        /// Briefly describes the kind of data documented in a study unit. Examples include survey data, census/enumeration data, administrative data, measurement data, assessment data, demographic data, voting data, etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<KindOfDataType> KindOfData { get; set; } = new List<KindOfDataType>();
        public bool ShouldSerializeKindOfData() { return KindOfData.Count > 0; }
        /// <summary>
        /// Briefly describes the data formats documented in the logical product(s) of a study unit. Examples include Numeric, Text, Audio, Visual, Geospatial, StillImage, Software, 3D, etc. Supports the use of an external controlled vocabulary. The DDI Alliance has provided a controlled vocabulary (KindOfDataFormat) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public List<CodeValueType> GeneralDataFormat { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeGeneralDataFormat() { return GeneralDataFormat.Count > 0; }
        /// <summary>
        /// Specifies by reference the ResourcePackages required to resolve the Study. This list is informational and assists in creating full transmissions of metadata or creating archival packages. Primarily used after the instance is relatively stable and published.
        /// <summary>
        public RequiredResourcePackagesType RequiredResourcePackages { get; set; }
        /// <summary>
        /// Embargo information about the study unit. References to embargo information in this section can be made from individual variables.
        /// <summary>
        public List<EmbargoType> Embargo { get; set; } = new List<EmbargoType>();
        public bool ShouldSerializeEmbargo() { return Embargo.Count > 0; }
        /// <summary>
        /// This scheme contains a set of other materials referenced by the metadata.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterialScheme> OtherMaterialSchemeReference { get; set; } = new List<OtherMaterialScheme>();
        public bool ShouldSerializeOtherMaterialSchemeReference() { return OtherMaterialSchemeReference.Count > 0; }
        /// <summary>
        /// Documents the content and relational structure of the concepts, universes, data elements, geographic structures and geographic locations used by the study unit.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualComponent> ConceptualComponentReference { get; set; } = new List<ConceptualComponent>();
        public bool ShouldSerializeConceptualComponentReference() { return ConceptualComponentReference.Count > 0; }
        /// <summary>
        /// Documents the content of the Data Collection activities used in this study; development of data collection processes, questions, question flows (control constructs), data collection instrument, instructions, processing events and instructions, methodology, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DataCollection> DataCollectionReference { get; set; } = new List<DataCollection>();
        public bool ShouldSerializeDataCollectionReference() { return DataCollectionReference.Count > 0; }
        /// <summary>
        /// Documents the logical (intellectual) content of the data produced by the study unit. Note that l:BaseLogicalProduct is the head of a substitution group and is replaced by the appropriate member of that substitution group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<BaseLogicalProduct> LogicalProductReference { get; set; } = new List<BaseLogicalProduct>();
        public bool ShouldSerializeLogicalProductReference() { return LogicalProductReference.Count > 0; }
        /// <summary>
        /// Documents the physical structure of the data produced by the study unit.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalDataProduct> PhysicalDataProductReference { get; set; } = new List<PhysicalDataProduct>();
        public bool ShouldSerializePhysicalDataProductReference() { return PhysicalDataProductReference.Count > 0; }
        /// <summary>
        /// Documents the link to a specific external data file produced by the study unit. May contain summary and category level statistics on the variables contained in the data file.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalInstance> PhysicalInstanceReference { get; set; } = new List<PhysicalInstance>();
        public bool ShouldSerializePhysicalInstanceReference() { return PhysicalInstanceReference.Count > 0; }
        /// <summary>
        /// Allows physical instance modules to be grouped with or without hierarchical structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalInstanceGroup> PhysicalInstanceGroupReference { get; set; } = new List<PhysicalInstanceGroup>();
        public bool ShouldSerializePhysicalInstanceGroupReference() { return PhysicalInstanceGroupReference.Count > 0; }
        /// <summary>
        /// Archive serves as a packet containing both persistent and transient information. Describes archive-specific material including item record information as well as lifecycle information. The metadata in the package is divided into elements that are persistent (should remain with the Study Unit through its life-cycle), and transient (pertinent only to the Study Unit as held by that archive).
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Archive> ArchiveReference { get; set; } = new List<Archive>();
        public bool ShouldSerializeArchiveReference() { return ArchiveReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of a Classification Family.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationFamily> ClassificationFamilyReference { get; set; } = new List<ClassificationFamily>();
        public bool ShouldSerializeClassificationFamilyReference() { return ClassificationFamilyReference.Count > 0; }
        /// <summary>
        /// Contains a DDI Profile which is used by the study unit.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DDIProfile> DDIProfileReference { get; set; } = new List<DDIProfile>();
        public bool ShouldSerializeDDIProfileReference() { return DDIProfileReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "StudyUnit");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfStudyUnit != null) { xEl.Add(TypeOfStudyUnit.ToXml("TypeOfStudyUnit")); }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (Abstract != null) { xEl.Add(Abstract.ToXml("Abstract")); }
            if (AuthorizationSource != null && AuthorizationSource.Count > 0)
            {
                foreach (var item in AuthorizationSource)
                {
                    xEl.Add(item.ToXml("AuthorizationSource"));
                }
            }
            if (ApprovalReviewReference != null)
            {
                xEl.Add(new XElement(ns + "ApprovalReviewReference", 
                    new XElement(ns + "URN", ApprovalReviewReference.URN), 
                    new XElement(ns + "Agency", ApprovalReviewReference.Agency), 
                    new XElement(ns + "ID", ApprovalReviewReference.ID), 
                    new XElement(ns + "Version", ApprovalReviewReference.Version), 
                    new XElement(ns + "TypeOfObject", ApprovalReviewReference.GetType().Name)));
            }
            if (DefiningConceptReference != null)
            {
                xEl.Add(new XElement(ns + "DefiningConceptReference", 
                    new XElement(ns + "URN", DefiningConceptReference.URN), 
                    new XElement(ns + "Agency", DefiningConceptReference.Agency), 
                    new XElement(ns + "ID", DefiningConceptReference.ID), 
                    new XElement(ns + "Version", DefiningConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", DefiningConceptReference.GetType().Name)));
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (SeriesStatement != null && SeriesStatement.Count > 0)
            {
                foreach (var item in SeriesStatement)
                {
                    xEl.Add(item.ToXml("SeriesStatement"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualitySchemeReference != null && QualitySchemeReference.Count > 0)
            {
                foreach (var item in QualitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "QualitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExPostEvaluation != null && ExPostEvaluation.Count > 0)
            {
                foreach (var item in ExPostEvaluation)
                {
                    xEl.Add(item.ToXml("ExPostEvaluation"));
                }
            }
            if (FundingInformation != null && FundingInformation.Count > 0)
            {
                foreach (var item in FundingInformation)
                {
                    xEl.Add(item.ToXml("FundingInformation"));
                }
            }
            if (StudyBudget != null && StudyBudget.Count > 0)
            {
                foreach (var item in StudyBudget)
                {
                    xEl.Add(item.ToXml("StudyBudget"));
                }
            }
            if (Purpose != null) { xEl.Add(Purpose.ToXml("Purpose")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (AnalysisUnit != null && AnalysisUnit.Count > 0)
            {
                foreach (var item in AnalysisUnit)
                {
                    xEl.Add(item.ToXml("AnalysisUnit"));
                }
            }
            if (AnalysisUnitsCovered != null) { xEl.Add(AnalysisUnitsCovered.ToXml("AnalysisUnitsCovered")); }
            if (KindOfData != null && KindOfData.Count > 0)
            {
                foreach (var item in KindOfData)
                {
                    xEl.Add(item.ToXml("KindOfData"));
                }
            }
            if (GeneralDataFormat != null && GeneralDataFormat.Count > 0)
            {
                foreach (var item in GeneralDataFormat)
                {
                    xEl.Add(item.ToXml("GeneralDataFormat"));
                }
            }
            if (RequiredResourcePackages != null) { xEl.Add(RequiredResourcePackages.ToXml("RequiredResourcePackages")); }
            if (Embargo != null && Embargo.Count > 0)
            {
                foreach (var item in Embargo)
                {
                    xEl.Add(item.ToXml("Embargo"));
                }
            }
            if (OtherMaterialSchemeReference != null && OtherMaterialSchemeReference.Count > 0)
            {
                foreach (var item in OtherMaterialSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptualComponentReference != null && ConceptualComponentReference.Count > 0)
            {
                foreach (var item in ConceptualComponentReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualComponentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataCollectionReference != null && DataCollectionReference.Count > 0)
            {
                foreach (var item in DataCollectionReference)
                {
                    xEl.Add(new XElement(ns + "DataCollectionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LogicalProductReference != null && LogicalProductReference.Count > 0)
            {
                foreach (var item in LogicalProductReference)
                {
                    xEl.Add(new XElement(ns + "LogicalProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalDataProductReference != null && PhysicalDataProductReference.Count > 0)
            {
                foreach (var item in PhysicalDataProductReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalDataProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalInstanceReference != null && PhysicalInstanceReference.Count > 0)
            {
                foreach (var item in PhysicalInstanceReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalInstanceReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalInstanceGroupReference != null && PhysicalInstanceGroupReference.Count > 0)
            {
                foreach (var item in PhysicalInstanceGroupReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalInstanceGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ArchiveReference != null && ArchiveReference.Count > 0)
            {
                foreach (var item in ArchiveReference)
                {
                    xEl.Add(new XElement(ns + "ArchiveReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ClassificationFamilyReference != null && ClassificationFamilyReference.Count > 0)
            {
                foreach (var item in ClassificationFamilyReference)
                {
                    xEl.Add(new XElement(ns + "ClassificationFamilyReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DDIProfileReference != null && DDIProfileReference.Count > 0)
            {
                foreach (var item in DDIProfileReference)
                {
                    xEl.Add(new XElement(ns + "DDIProfileReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

