using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Classification Item represents a Category at a certain Level within a Statistical Classification. It defines the content and the borders of the category. An object/unit can be classified to one and only one Classification Item at each Level of a Statistical Classification.
    /// <summary>
    public partial class ClassificationItem : Describable
    {
        /// <summary>
        /// A Classification Item is identified by an alphabetical, numerical or alphanumerical code, which is in line with the code structure of the Level. The code is unique within the Statistical Classification to which the Classification Item belongs.
        /// <summary>
        public string ItemCode { get; set; }
        /// <summary>
        /// A concept which describes the Classification Item. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> DefiningConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeDefiningConceptReference() { return DefiningConceptReference.Count > 0; }
        /// <summary>
        /// Specifies the contents of the category. Supports multiple languages and use of structured content.
        /// <summary>
        public StructuredStringType Includes { get; set; }
        /// <summary>
        /// A list of borderline cases, which belong to the described category. Supports multiple languages and use of structured content.
        /// <summary>
        public StructuredStringType IncludesAlso { get; set; }
        /// <summary>
        /// A list of borderline cases, which do not belong to the described category. Excluded cases may contain a reference to the Classification Items to which the excluded cases belong. Supports multiple languages and use of structured content.
        /// <summary>
        public StructuredStringType Excludes { get; set; }
        /// <summary>
        /// A reference to the Classification Items to which the excluded cases belong. TypeOfObject should be set to ClassificationItem.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationItem> ExcludedClassificationItemReference { get; set; } = new List<ClassificationItem>();
        public bool ShouldSerializeExcludedClassificationItemReference() { return ExcludedClassificationItemReference.Count > 0; }
        /// <summary>
        /// The Classification Level to which the Classification Item belongs. TypeOfObject should be set to ClassificationLevel.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel ClassificationLevelReference { get; set; }
        /// <summary>
        /// Indicates whether or not the Classification Item has been generated to make the Level to which it belongs complete.
        /// <summary>
        public bool IsGenerated { get; set; }
        /// <summary>
        /// If updates are allowed in the Statistical Classification, a Classification Item may be restricted in its validity, i.e. it may become valid or invalid after the Statistical Classification has been released. Indicates whether or not the Classification Item is currently valid.
        /// <summary>
        public bool IsValid { get; set; }
        /// <summary>
        /// Date from which the Classification Item became valid. The date must be defined if the Classification Item belongs to a floating Statistical Classification.
        /// <summary>
        public CogsDate ValidFrom { get; set; }
        /// <summary>
        /// Date at which the Classification Item became invalid. The date must be defined if the Classification Item belongs to a floating Statistical Classification and is no longer valid.
        /// <summary>
        public CogsDate ValidTo { get; set; }
        /// <summary>
        /// The future events describe a change (or a number of changes) related to an invalid Classification Item. These changes may e.g. have turned the now invalid Classification Item into one or several successor Classification Items. In describing these changes, terminology from the Typology of item changes, found in Appendix 3 should be used. This allows the possibility to follow successors of the Classification Item in the future. Supports the use of multiple languages and structured content.
        /// <summary>
        public StructuredStringType FutureEvents { get; set; }
        /// <summary>
        /// Future events may e.g. have turned the now invalid Classification Item into one or several successor Classification Items, listed here. TypeOfObject should be set to ClassificationItem.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationItem> SuccessorClassificationItemReference { get; set; } = new List<ClassificationItem>();
        public bool ShouldSerializeSuccessorClassificationItemReference() { return SuccessorClassificationItemReference.Count > 0; }
        /// <summary>
        /// Describes the changes, which the Classification Item has been subject to from the previous version to the actual Statistical Classification. In describing these changes, terminology from the Typology of item changes, found in Appendix 3 of GSIM should be used. Supports the use of multiple languages and structured content.
        /// <summary>
        public StructuredStringType ChangesFromPriorVersion { get; set; }
        /// <summary>
        /// Describes the changes, which the Classification Item has been subject to during the life time of the actual Statistical Classification. Supports the use of multiple languages and structured content.
        /// <summary>
        public StructuredStringType Updates { get; set; }
        /// <summary>
        /// The Classification Item at the next higher Level of the Statistical Classification of which the actual Classification Item is a sub item. TypeOfObject should be set to ClassificationItem.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationItem ParentClassificationItemReference { get; set; }
        /// <summary>
        /// Refers to one or more case law rulings related to the Classification Item.
        /// <summary>
        public List<CaseLawType> CaseLaws { get; set; } = new List<CaseLawType>();
        public bool ShouldSerializeCaseLaws() { return CaseLaws.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationItem");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ItemCode != null)
            {
                xEl.Add(new XElement(ns + "ItemCode", ItemCode));
            }
            if (DefiningConceptReference != null && DefiningConceptReference.Count > 0)
            {
                foreach (var item in DefiningConceptReference)
                {
                    xEl.Add(new XElement(ns + "DefiningConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Includes != null) { xEl.Add(Includes.ToXml("Includes")); }
            if (IncludesAlso != null) { xEl.Add(IncludesAlso.ToXml("IncludesAlso")); }
            if (Excludes != null) { xEl.Add(Excludes.ToXml("Excludes")); }
            if (ExcludedClassificationItemReference != null && ExcludedClassificationItemReference.Count > 0)
            {
                foreach (var item in ExcludedClassificationItemReference)
                {
                    xEl.Add(new XElement(ns + "ExcludedClassificationItemReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ClassificationLevelReference != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevelReference", 
                    new XElement(ns + "URN", ClassificationLevelReference.URN), 
                    new XElement(ns + "Agency", ClassificationLevelReference.Agency), 
                    new XElement(ns + "ID", ClassificationLevelReference.ID), 
                    new XElement(ns + "Version", ClassificationLevelReference.Version), 
                    new XElement(ns + "TypeOfObject", ClassificationLevelReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsGenerated", IsGenerated));
            xEl.Add(new XElement(ns + "IsValid", IsValid));
            if (ValidFrom != null && ValidFrom.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidFrom", ValidFrom.ToString()));
            }
            if (ValidTo != null && ValidTo.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidTo", ValidTo.ToString()));
            }
            if (FutureEvents != null) { xEl.Add(FutureEvents.ToXml("FutureEvents")); }
            if (SuccessorClassificationItemReference != null && SuccessorClassificationItemReference.Count > 0)
            {
                foreach (var item in SuccessorClassificationItemReference)
                {
                    xEl.Add(new XElement(ns + "SuccessorClassificationItemReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ChangesFromPriorVersion != null) { xEl.Add(ChangesFromPriorVersion.ToXml("ChangesFromPriorVersion")); }
            if (Updates != null) { xEl.Add(Updates.ToXml("Updates")); }
            if (ParentClassificationItemReference != null)
            {
                xEl.Add(new XElement(ns + "ParentClassificationItemReference", 
                    new XElement(ns + "URN", ParentClassificationItemReference.URN), 
                    new XElement(ns + "Agency", ParentClassificationItemReference.Agency), 
                    new XElement(ns + "ID", ParentClassificationItemReference.ID), 
                    new XElement(ns + "Version", ParentClassificationItemReference.Version), 
                    new XElement(ns + "TypeOfObject", ParentClassificationItemReference.GetType().Name)));
            }
            if (CaseLaws != null && CaseLaws.Count > 0)
            {
                foreach (var item in CaseLaws)
                {
                    xEl.Add(item.ToXml("CaseLaws"));
                }
            }
            return xEl;
        }
    }
}

