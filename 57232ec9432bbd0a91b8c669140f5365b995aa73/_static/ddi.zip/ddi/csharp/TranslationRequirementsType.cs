using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a detailed description of the requirements for an acceptable translation and indicate if the translation should be oral and/or written. Supports multiple language versions of the same content as well as optional formatting of the content.
    /// <summary>
    public partial class TranslationRequirementsType
    {
        /// <summary>
        /// A description of the Translation Requirements. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Indicates if the translation is an oral translation.
        /// <summary>
        public bool IsOral { get; set; }
        /// <summary>
        /// Indicates if the translation is a written translation.
        /// <summary>
        public bool IsWritten { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            xEl.Add(new XElement(ns + "IsOral", IsOral));
            xEl.Add(new XElement(ns + "IsWritten", IsWritten));
            return xEl;
        }
    }
}

