using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. The components of a SplitJoin consists of a number of process steps to be executed concurrently with partial synchronization. SplitJoin consists of process steps that are executed concurrently (execution with barrier synchronization). That is, SplitJoin completes when all of its components processes have completed. Supports parallel processing that requires completion of all included process steps to exit.
    /// <summary>
    public partial class SplitJoin : ControlConstruct
    {
        /// <summary>
        /// Provides the ability to "type" a split for classification or processing purposes. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfSequence { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfSequence() { return TypeOfSequence.Count > 0; }
        /// <summary>
        /// References control constructs that can be executed concurrently.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SplitJoin");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSequence != null && TypeOfSequence.Count > 0)
            {
                foreach (var item in TypeOfSequence)
                {
                    xEl.Add(item.ToXml("TypeOfSequence"));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

