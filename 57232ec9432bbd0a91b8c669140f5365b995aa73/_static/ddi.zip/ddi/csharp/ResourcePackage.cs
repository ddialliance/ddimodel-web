using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The Resource Package is a specialized structure which is intended to hold reusable metadata outside of the structures of a single StudyUnit or Group. For example this may be common methodological approaches bound in a DataCollection module, DataRelationship information bound in a LogicalProduct, or any maintainable scheme. The ResourcePackage is often used to manage and publish metadata that is used by StudyUnits or Groups by reference. Any maintainable object with the exception of a Group, StudyUnit or LocalHoldingPackage may be published in a Resource Package. Each maintainable object may be entered as either an in-line representation or by reference. Within each maintainable type the ordering of in-line or referenced content may be mixed. In addition the ResourcePackage contains self identifying information including: a citation, abstract, authorization source, a universe reference, series statement, references to applicable quality statements, funding and budget information, purpose, coverage, other material, embargo, and the resource package archive (as opposed to an Archive module intended as the part of the published reusable content).
    /// <summary>
    public partial class ResourcePackage : Maintainable
    {
        /// <summary>
        /// The citation for the ResourcePackage. DDI strongly recommends that at minimum a Title be provided.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// A brief description of the resource package type. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfResourcePackage { get; set; }
        /// <summary>
        /// An abstract of the ResourcePackage unit describing the nature and scope of the data collection, special characteristics of its content. Note that detailed information on the purpose of the ResourcePackage and structured coverage information are to be entered in Purpose and Coverage. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Abstract { get; set; }
        /// <summary>
        /// Identifies the authorizing agency for the ResourcePackage and allows for the full text of the authorization (law, regulation, or other form of authorization). May be used to list authorizations from oversight committees and other regulatory agencies.
        /// <summary>
        public List<AuthorizationSourceType> AuthorizationSource { get; set; } = new List<AuthorizationSourceType>();
        public bool ShouldSerializeAuthorizationSource() { return AuthorizationSource.Count > 0; }
        /// <summary>
        /// Provides information about the Approval Review undertaken in relation to the activity. Identifies the organization processing the review, the role of the approval review organization, case number, description, and related dates. Allows the inclusion of a reference to an external source detailing the approval review.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ApprovalReview ApprovalReviewReference { get; set; }
        /// <summary>
        /// A concept that defines or aids in understanding the content of the resource package.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept DefiningConceptReference { get; set; }
        /// <summary>
        /// Reference to the universe statement from the universe scheme, describing the ResourcePackage of persons or other elements that are the object of research and to which any analytic results refer. Age, nationality, and residence commonly help to delineate a given universe, but any of a number of factors may be involved, such as sex, race, income, veteran status, criminal convictions, etc. The universe may consist of elements other than persons, such as housing units, court cases, deaths, countries, etc. In general, it should be possible to tell from the description of the universe whether a given individual or element (hypothetical or real) is a member of the population under ResourcePackage. A universe may be described as "inclusive" or "exclusive". This ResourcePackage level reference is normally to the top level of the UniverseScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// A ResourcePackage, particularly one in a series, may be the result of two series merging into a single ResourcePackage. The new ResourcePackage belongs to both series. For example, Niger now fields the UNICEF Multiple Indicators Cluster Survey (MICS) and the Demographic and Health Survey as a single merged instrument.
        /// <summary>
        public List<SeriesStatementType> SeriesStatement { get; set; } = new List<SeriesStatementType>();
        public bool ShouldSerializeSeriesStatement() { return SeriesStatement.Count > 0; }
        /// <summary>
        /// A reference to a QualityScheme containing statements of quality related to the quality of the ResourcePackage methodology, metadata, or data. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// Contains details of the ResourcePackage unit's funding, including information about grants, agencies, etc.
        /// <summary>
        public List<FundingInformationType> FundingInformation { get; set; } = new List<FundingInformationType>();
        public bool ShouldSerializeFundingInformation() { return FundingInformation.Count > 0; }
        /// <summary>
        /// This describes the overall budget of the ResourcePackage. It can be repeated for distinct budget activities. It contains a structured description and one or more budget documents described by an OtherMaterial type.
        /// <summary>
        public List<BudgetType> ProjectBudget { get; set; } = new List<BudgetType>();
        public bool ShouldSerializeProjectBudget() { return ProjectBudget.Count > 0; }
        /// <summary>
        /// The purpose of the ResourcePackage, why the ResourcePackage took place. This should include detailed information on the investigator's primary ResourcePackage questions or hypotheses as well as information on any legal basis for the data collection, such as laws requiring the collection of census data for apportionment purposes. Legal or other authorization should be provided in detail within AuthorizationSource. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Purpose { get; set; }
        /// <summary>
        /// Describes the coverage of the ResourcePackage unit. Detailed information on Topical, Temporal, and Spatial Coverage is contained here. Note that Coverage at this level should be inclusive all lower level modules or section. Lower level descriptions serve to constrain coverage within the scope described here.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Embargo information about the ResourcePackage unit. References to embargo information in this section can be made from individual variables.
        /// <summary>
        public List<EmbargoType> Embargo { get; set; } = new List<EmbargoType>();
        public bool ShouldSerializeEmbargo() { return Embargo.Count > 0; }
        /// <summary>
        /// This scheme contains a set of other materials referenced by the metadata.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterialScheme> OtherMaterialSchemeReference { get; set; } = new List<OtherMaterialScheme>();
        public bool ShouldSerializeOtherMaterialSchemeReference() { return OtherMaterialSchemeReference.Count > 0; }
        /// <summary>
        /// This is archive information specific to the creation, maintenance, and archiving of the ResourcePackage provided either in-line or by reference. This packaging element differentiates this "Archive" from one being published as a product within a ResourcePackage.
        /// <summary>
        public List<ResourcePackageArchiveType> ResourcePackageArchive { get; set; } = new List<ResourcePackageArchiveType>();
        public bool ShouldSerializeResourcePackageArchive() { return ResourcePackageArchive.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an ConceptualComponent.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualComponent> ConceptualComponentReference { get; set; } = new List<ConceptualComponent>();
        public bool ShouldSerializeConceptualComponentReference() { return ConceptualComponentReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an DataCollection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DataCollection> DataCollectionReference { get; set; } = new List<DataCollection>();
        public bool ShouldSerializeDataCollectionReference() { return DataCollectionReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of any LogicalProduct. l:BaseLogicalProduct is a substitution group base.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<BaseLogicalProduct> LogicalProductReference { get; set; } = new List<BaseLogicalProduct>();
        public bool ShouldSerializeLogicalProductReference() { return LogicalProductReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an PhysicalDataProduct.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalDataProduct> PhysicalDataProductReference { get; set; } = new List<PhysicalDataProduct>();
        public bool ShouldSerializePhysicalDataProductReference() { return PhysicalDataProductReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an PhysicalInstance.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalInstance> PhysicalInstanceReference { get; set; } = new List<PhysicalInstance>();
        public bool ShouldSerializePhysicalInstanceReference() { return PhysicalInstanceReference.Count > 0; }
        /// <summary>
        /// Allows physical instance modules to be grouped with or without hierarchical structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalInstanceGroup> PhysicalInstanceGroupReference { get; set; } = new List<PhysicalInstanceGroup>();
        public bool ShouldSerializePhysicalInstanceGroupReference() { return PhysicalInstanceGroupReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an Archive.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Archive> ArchiveReference { get; set; } = new List<Archive>();
        public bool ShouldSerializeArchiveReference() { return ArchiveReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an DDIProfile.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DDIProfile> DDIProfileReference { get; set; } = new List<DDIProfile>();
        public bool ShouldSerializeDDIProfileReference() { return DDIProfileReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of an Comparison.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Comparison> ComparisonReference { get; set; } = new List<Comparison>();
        public bool ShouldSerializeComparisonReference() { return ComparisonReference.Count > 0; }
        /// <summary>
        /// Allows for in-line entry of a Classification Family.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationFamily> ClassificationFamilyReference { get; set; } = new List<ClassificationFamily>();
        public bool ShouldSerializeClassificationFamilyReference() { return ClassificationFamilyReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a OrganizationScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OrganizationScheme> OrganizationSchemeReference { get; set; } = new List<OrganizationScheme>();
        public bool ShouldSerializeOrganizationSchemeReference() { return OrganizationSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ConceptScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptScheme> ConceptSchemeReference { get; set; } = new List<ConceptScheme>();
        public bool ShouldSerializeConceptSchemeReference() { return ConceptSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a UniverseScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UniverseScheme> UniverseSchemeReference { get; set; } = new List<UniverseScheme>();
        public bool ShouldSerializeUniverseSchemeReference() { return UniverseSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ConceptualVariableScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualVariableScheme> ConceptualVariableSchemeReference { get; set; } = new List<ConceptualVariableScheme>();
        public bool ShouldSerializeConceptualVariableSchemeReference() { return ConceptualVariableSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a RepresentedVariableScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariableScheme> RepresentedVariableSchemeReference { get; set; } = new List<RepresentedVariableScheme>();
        public bool ShouldSerializeRepresentedVariableSchemeReference() { return RepresentedVariableSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a GeographicStructureScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicStructureScheme> GeographicStructureSchemeReference { get; set; } = new List<GeographicStructureScheme>();
        public bool ShouldSerializeGeographicStructureSchemeReference() { return GeographicStructureSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a GeographicLocationScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicLocationScheme> GeographicLocationSchemeReference { get; set; } = new List<GeographicLocationScheme>();
        public bool ShouldSerializeGeographicLocationSchemeReference() { return GeographicLocationSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a InterviewerInstructionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InterviewerInstructionScheme> InterviewerInstructionSchemeReference { get; set; } = new List<InterviewerInstructionScheme>();
        public bool ShouldSerializeInterviewerInstructionSchemeReference() { return InterviewerInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ControlConstructScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstructScheme> ControlConstructSchemeReference { get; set; } = new List<ControlConstructScheme>();
        public bool ShouldSerializeControlConstructSchemeReference() { return ControlConstructSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a QuestionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionScheme> QuestionSchemeReference { get; set; } = new List<QuestionScheme>();
        public bool ShouldSerializeQuestionSchemeReference() { return QuestionSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a MeasurementScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementScheme> MeasurementSchemeReference { get; set; } = new List<MeasurementScheme>();
        public bool ShouldSerializeMeasurementSchemeReference() { return MeasurementSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a CategoryScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CategoryScheme> CategorySchemeReference { get; set; } = new List<CategoryScheme>();
        public bool ShouldSerializeCategorySchemeReference() { return CategorySchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a CodeListScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CodeListScheme> CodeListSchemeReference { get; set; } = new List<CodeListScheme>();
        public bool ShouldSerializeCodeListSchemeReference() { return CodeListSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a NCubeScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeScheme> NCubeSchemeReference { get; set; } = new List<NCubeScheme>();
        public bool ShouldSerializeNCubeSchemeReference() { return NCubeSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a VariableScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableScheme> VariableSchemeReference { get; set; } = new List<VariableScheme>();
        public bool ShouldSerializeVariableSchemeReference() { return VariableSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a PhysicalStructureScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalStructureScheme> PhysicalStructureSchemeReference { get; set; } = new List<PhysicalStructureScheme>();
        public bool ShouldSerializePhysicalStructureSchemeReference() { return PhysicalStructureSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a RecordLayoutScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutScheme> RecordLayoutSchemeReference { get; set; } = new List<RecordLayoutScheme>();
        public bool ShouldSerializeRecordLayoutSchemeReference() { return RecordLayoutSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a QualityScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityScheme> QualitySchemeReference { get; set; } = new List<QualityScheme>();
        public bool ShouldSerializeQualitySchemeReference() { return QualitySchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a InstrumentScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InstrumentScheme> InstrumentSchemeReference { get; set; } = new List<InstrumentScheme>();
        public bool ShouldSerializeInstrumentSchemeReference() { return InstrumentSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ProcessingEventScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingEventScheme> ProcessingEventSchemeReference { get; set; } = new List<ProcessingEventScheme>();
        public bool ShouldSerializeProcessingEventSchemeReference() { return ProcessingEventSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ProcessingInstructionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingInstructionScheme> ProcessingInstructionSchemeReference { get; set; } = new List<ProcessingInstructionScheme>();
        public bool ShouldSerializeProcessingInstructionSchemeReference() { return ProcessingInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a ManagedRepresentationScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ManagedRepresentationScheme> ManagedRepresentationSchemeReference { get; set; } = new List<ManagedRepresentationScheme>();
        public bool ShouldSerializeManagedRepresentationSchemeReference() { return ManagedRepresentationSchemeReference.Count > 0; }
        /// <summary>
        /// In-line inclusion of a UnitTypeScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UnitTypeScheme> UnitTypeSchemeReference { get; set; } = new List<UnitTypeScheme>();
        public bool ShouldSerializeUnitTypeSchemeReference() { return UnitTypeSchemeReference.Count > 0; }
        /// <summary>
        /// A set of sample frames maintained by an agency, and used in the instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingInformationScheme> SamplingInformationSchemeReference { get; set; } = new List<SamplingInformationScheme>();
        public bool ShouldSerializeSamplingInformationSchemeReference() { return SamplingInformationSchemeReference.Count > 0; }
        /// <summary>
        /// A set of development activities maintained by an agency, and used in the development, review, or creation of a question, measurement, data capture flow (control construct), or instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivityScheme> DevelopmentActivitySchemeReference { get; set; } = new List<DevelopmentActivityScheme>();
        public bool ShouldSerializeDevelopmentActivitySchemeReference() { return DevelopmentActivitySchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ResourcePackage");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (TypeOfResourcePackage != null) { xEl.Add(TypeOfResourcePackage.ToXml("TypeOfResourcePackage")); }
            if (Abstract != null) { xEl.Add(Abstract.ToXml("Abstract")); }
            if (AuthorizationSource != null && AuthorizationSource.Count > 0)
            {
                foreach (var item in AuthorizationSource)
                {
                    xEl.Add(item.ToXml("AuthorizationSource"));
                }
            }
            if (ApprovalReviewReference != null)
            {
                xEl.Add(new XElement(ns + "ApprovalReviewReference", 
                    new XElement(ns + "URN", ApprovalReviewReference.URN), 
                    new XElement(ns + "Agency", ApprovalReviewReference.Agency), 
                    new XElement(ns + "ID", ApprovalReviewReference.ID), 
                    new XElement(ns + "Version", ApprovalReviewReference.Version), 
                    new XElement(ns + "TypeOfObject", ApprovalReviewReference.GetType().Name)));
            }
            if (DefiningConceptReference != null)
            {
                xEl.Add(new XElement(ns + "DefiningConceptReference", 
                    new XElement(ns + "URN", DefiningConceptReference.URN), 
                    new XElement(ns + "Agency", DefiningConceptReference.Agency), 
                    new XElement(ns + "ID", DefiningConceptReference.ID), 
                    new XElement(ns + "Version", DefiningConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", DefiningConceptReference.GetType().Name)));
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (SeriesStatement != null && SeriesStatement.Count > 0)
            {
                foreach (var item in SeriesStatement)
                {
                    xEl.Add(item.ToXml("SeriesStatement"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (FundingInformation != null && FundingInformation.Count > 0)
            {
                foreach (var item in FundingInformation)
                {
                    xEl.Add(item.ToXml("FundingInformation"));
                }
            }
            if (ProjectBudget != null && ProjectBudget.Count > 0)
            {
                foreach (var item in ProjectBudget)
                {
                    xEl.Add(item.ToXml("ProjectBudget"));
                }
            }
            if (Purpose != null) { xEl.Add(Purpose.ToXml("Purpose")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (Embargo != null && Embargo.Count > 0)
            {
                foreach (var item in Embargo)
                {
                    xEl.Add(item.ToXml("Embargo"));
                }
            }
            if (OtherMaterialSchemeReference != null && OtherMaterialSchemeReference.Count > 0)
            {
                foreach (var item in OtherMaterialSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResourcePackageArchive != null && ResourcePackageArchive.Count > 0)
            {
                foreach (var item in ResourcePackageArchive)
                {
                    xEl.Add(item.ToXml("ResourcePackageArchive"));
                }
            }
            if (ConceptualComponentReference != null && ConceptualComponentReference.Count > 0)
            {
                foreach (var item in ConceptualComponentReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualComponentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataCollectionReference != null && DataCollectionReference.Count > 0)
            {
                foreach (var item in DataCollectionReference)
                {
                    xEl.Add(new XElement(ns + "DataCollectionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LogicalProductReference != null && LogicalProductReference.Count > 0)
            {
                foreach (var item in LogicalProductReference)
                {
                    xEl.Add(new XElement(ns + "LogicalProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalDataProductReference != null && PhysicalDataProductReference.Count > 0)
            {
                foreach (var item in PhysicalDataProductReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalDataProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalInstanceReference != null && PhysicalInstanceReference.Count > 0)
            {
                foreach (var item in PhysicalInstanceReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalInstanceReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalInstanceGroupReference != null && PhysicalInstanceGroupReference.Count > 0)
            {
                foreach (var item in PhysicalInstanceGroupReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalInstanceGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ArchiveReference != null && ArchiveReference.Count > 0)
            {
                foreach (var item in ArchiveReference)
                {
                    xEl.Add(new XElement(ns + "ArchiveReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DDIProfileReference != null && DDIProfileReference.Count > 0)
            {
                foreach (var item in DDIProfileReference)
                {
                    xEl.Add(new XElement(ns + "DDIProfileReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ComparisonReference != null && ComparisonReference.Count > 0)
            {
                foreach (var item in ComparisonReference)
                {
                    xEl.Add(new XElement(ns + "ComparisonReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ClassificationFamilyReference != null && ClassificationFamilyReference.Count > 0)
            {
                foreach (var item in ClassificationFamilyReference)
                {
                    xEl.Add(new XElement(ns + "ClassificationFamilyReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OrganizationSchemeReference != null && OrganizationSchemeReference.Count > 0)
            {
                foreach (var item in OrganizationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OrganizationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptSchemeReference != null && ConceptSchemeReference.Count > 0)
            {
                foreach (var item in ConceptSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UniverseSchemeReference != null && UniverseSchemeReference.Count > 0)
            {
                foreach (var item in UniverseSchemeReference)
                {
                    xEl.Add(new XElement(ns + "UniverseSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptualVariableSchemeReference != null && ConceptualVariableSchemeReference.Count > 0)
            {
                foreach (var item in ConceptualVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentedVariableSchemeReference != null && RepresentedVariableSchemeReference.Count > 0)
            {
                foreach (var item in RepresentedVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicStructureSchemeReference != null && GeographicStructureSchemeReference.Count > 0)
            {
                foreach (var item in GeographicStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicLocationSchemeReference != null && GeographicLocationSchemeReference.Count > 0)
            {
                foreach (var item in GeographicLocationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicLocationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InterviewerInstructionSchemeReference != null && InterviewerInstructionSchemeReference.Count > 0)
            {
                foreach (var item in InterviewerInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InterviewerInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ControlConstructSchemeReference != null && ControlConstructSchemeReference.Count > 0)
            {
                foreach (var item in ControlConstructSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionSchemeReference != null && QuestionSchemeReference.Count > 0)
            {
                foreach (var item in QuestionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "QuestionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MeasurementSchemeReference != null && MeasurementSchemeReference.Count > 0)
            {
                foreach (var item in MeasurementSchemeReference)
                {
                    xEl.Add(new XElement(ns + "MeasurementSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CategorySchemeReference != null && CategorySchemeReference.Count > 0)
            {
                foreach (var item in CategorySchemeReference)
                {
                    xEl.Add(new XElement(ns + "CategorySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CodeListSchemeReference != null && CodeListSchemeReference.Count > 0)
            {
                foreach (var item in CodeListSchemeReference)
                {
                    xEl.Add(new XElement(ns + "CodeListSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (NCubeSchemeReference != null && NCubeSchemeReference.Count > 0)
            {
                foreach (var item in NCubeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableSchemeReference != null && VariableSchemeReference.Count > 0)
            {
                foreach (var item in VariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "VariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalStructureSchemeReference != null && PhysicalStructureSchemeReference.Count > 0)
            {
                foreach (var item in PhysicalStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutSchemeReference != null && RecordLayoutSchemeReference.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualitySchemeReference != null && QualitySchemeReference.Count > 0)
            {
                foreach (var item in QualitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "QualitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstrumentSchemeReference != null && InstrumentSchemeReference.Count > 0)
            {
                foreach (var item in InstrumentSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingEventSchemeReference != null && ProcessingEventSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingEventSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingEventSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingInstructionSchemeReference != null && ProcessingInstructionSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ManagedRepresentationSchemeReference != null && ManagedRepresentationSchemeReference.Count > 0)
            {
                foreach (var item in ManagedRepresentationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ManagedRepresentationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UnitTypeSchemeReference != null && UnitTypeSchemeReference.Count > 0)
            {
                foreach (var item in UnitTypeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "UnitTypeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingInformationSchemeReference != null && SamplingInformationSchemeReference.Count > 0)
            {
                foreach (var item in SamplingInformationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "SamplingInformationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentActivitySchemeReference != null && DevelopmentActivitySchemeReference.Count > 0)
            {
                foreach (var item in DevelopmentActivitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

