using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Correspondence Table expresses the relationship between two Statistical Classifications. These are typically: two versions from the same Classification Series; Statistical Classifications from different Classification Series; a variant and the version on which it is based; different versions of a variant. In the first and last examples, the Correspondence Table facilitates comparability over time. Correspondence relationships are shown in both directions
    /// <summary>
    public partial class ClassificationCorrespondenceTable : Describable
    {
        /// <summary>
        /// The statistical office, other authority or section that created and maintains the Correspondence Table. A Correspondence Table may have several owners. TypeOfObject should be Organization or Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> OwnerReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeOwnerReference() { return OwnerReference.Count > 0; }
        /// <summary>
        /// The unit or group of persons who are responsible for the Correspondence Table, i.e. for maintaining and updating it. TypeOfObject should be Organization or Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> MaintenanceUnitReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeMaintenanceUnitReference() { return MaintenanceUnitReference.Count > 0; }
        /// <summary>
        /// The person(s) who may be contacted for additional information about the Correspondence Table. TypeOfObject should be Organization or Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ContactPersonReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeContactPersonReference() { return ContactPersonReference.Count > 0; }
        /// <summary>
        /// A list of the publications in which the Correspondence Table has been published.
        /// <summary>
        public List<PublicationType> Publication { get; set; } = new List<PublicationType>();
        public bool ShouldSerializePublication() { return Publication.Count > 0; }
        /// <summary>
        /// The Statistical Classification from which the correspondence is made. TypeOfObject should be StatisticalClassification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public StatisticalClassification SourceClassificationReference { get; set; }
        /// <summary>
        /// The Statistical Classification(s) to which the correspondence is directed. There may be multiple target Statistical Classifications associated with the Correspondence Table. TypeOfObject should be StatisticalClassification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StatisticalClassification> TargetClassificationReference { get; set; } = new List<StatisticalClassification>();
        public bool ShouldSerializeTargetClassificationReference() { return TargetClassificationReference.Count > 0; }
        /// <summary>
        /// The correspondence is normally restricted to a certain Level in the source Statistical Classification. In this case, target Classification Items are assigned only to source Classification Items on the given level. If no level is indicated, target Classification Items can be assigned to any Level of the source Statistical Classification. TypeOfObject should be set to ClassificationLevel.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel SourceLevelReference { get; set; }
        /// <summary>
        /// The correspondence is normally restricted to a certain Level in the target Statistical Classification. In this case, source Classification Items are assigned only to target Classification Items on the given Level. If no Level is indicated, source Classification Items can be assigned to any Level of the target Statistical Classification. TypeOfObject should be set to ClassificationLevel.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel TargetLevelReference { get; set; }
        /// <summary>
        /// A Correspondence Table can define a 1:1, 1:N, N:1 or M:N relationship between source and target Classification Items. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType RelationshipMappingType { get; set; }
        /// <summary>
        /// The relationship between two Statistical Classifications. A Map is an expression of the relation between a Classification Item in a source Statistical Classification and a corresponding Classification Item in the target Statistical Classification. The Map should specify whether the relationship between the two Classification Items is partial or complete. Depending on the relationship type of the Correspondence Table, there may be several Maps for a single source or target Classification Item.
        /// <summary>
        public List<ClassificationMapType> Maps { get; set; } = new List<ClassificationMapType>();
        public bool ShouldSerializeMaps() { return Maps.Count > 0; }
        /// <summary>
        /// If the source and/or target Statistical Classifications of a Correspondence Table are floating Statistical Classifications, the date of the Correspondence Table must be noted. The Correspondence Table expresses the relationships between the two Statistical Classifications as they existed on the date specified in the Correspondence Table.
        /// <summary>
        public CogsDate FloatingMapDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationCorrespondenceTable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (OwnerReference != null && OwnerReference.Count > 0)
            {
                foreach (var item in OwnerReference)
                {
                    xEl.Add(new XElement(ns + "OwnerReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MaintenanceUnitReference != null && MaintenanceUnitReference.Count > 0)
            {
                foreach (var item in MaintenanceUnitReference)
                {
                    xEl.Add(new XElement(ns + "MaintenanceUnitReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ContactPersonReference != null && ContactPersonReference.Count > 0)
            {
                foreach (var item in ContactPersonReference)
                {
                    xEl.Add(new XElement(ns + "ContactPersonReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Publication != null && Publication.Count > 0)
            {
                foreach (var item in Publication)
                {
                    xEl.Add(item.ToXml("Publication"));
                }
            }
            if (SourceClassificationReference != null)
            {
                xEl.Add(new XElement(ns + "SourceClassificationReference", 
                    new XElement(ns + "URN", SourceClassificationReference.URN), 
                    new XElement(ns + "Agency", SourceClassificationReference.Agency), 
                    new XElement(ns + "ID", SourceClassificationReference.ID), 
                    new XElement(ns + "Version", SourceClassificationReference.Version), 
                    new XElement(ns + "TypeOfObject", SourceClassificationReference.GetType().Name)));
            }
            if (TargetClassificationReference != null && TargetClassificationReference.Count > 0)
            {
                foreach (var item in TargetClassificationReference)
                {
                    xEl.Add(new XElement(ns + "TargetClassificationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SourceLevelReference != null)
            {
                xEl.Add(new XElement(ns + "SourceLevelReference", 
                    new XElement(ns + "URN", SourceLevelReference.URN), 
                    new XElement(ns + "Agency", SourceLevelReference.Agency), 
                    new XElement(ns + "ID", SourceLevelReference.ID), 
                    new XElement(ns + "Version", SourceLevelReference.Version), 
                    new XElement(ns + "TypeOfObject", SourceLevelReference.GetType().Name)));
            }
            if (TargetLevelReference != null)
            {
                xEl.Add(new XElement(ns + "TargetLevelReference", 
                    new XElement(ns + "URN", TargetLevelReference.URN), 
                    new XElement(ns + "Agency", TargetLevelReference.Agency), 
                    new XElement(ns + "ID", TargetLevelReference.ID), 
                    new XElement(ns + "Version", TargetLevelReference.Version), 
                    new XElement(ns + "TypeOfObject", TargetLevelReference.GetType().Name)));
            }
            if (RelationshipMappingType != null) { xEl.Add(RelationshipMappingType.ToXml("RelationshipMappingType")); }
            if (Maps != null && Maps.Count > 0)
            {
                foreach (var item in Maps)
                {
                    xEl.Add(item.ToXml("Maps"));
                }
            }
            if (FloatingMapDate != null && FloatingMapDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "FloatingMapDate", FloatingMapDate.ToString()));
            }
            return xEl;
        }
    }
}

