using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// References a PhysicalInstance module that describes a data file containing the summary and/or category statistics OR contains the statistics in-line.  For example, when the same data are stored as an ASCII file and as an ORACLE file, the summary and category statistics would only be listed in one of the physical instance files, and referenced in the other(s).
    /// <summary>
    public partial class StatisticalDataLocationType
    {
        /// <summary>
        /// References a physical instance containing the statistics inline or that identifies the data file which contains the statistics.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public PhysicalInstance PhysicalInstanceReference { get; set; }
        /// <summary>
        /// Set to "true" if the summary/category statistics are found inline in the referenced physical instance. Set to "false" if they are in the data file associated with the physical instance.
        /// <summary>
        public bool IsInline { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (PhysicalInstanceReference != null)
            {
                xEl.Add(new XElement(ns + "PhysicalInstanceReference", 
                    new XElement(ns + "URN", PhysicalInstanceReference.URN), 
                    new XElement(ns + "Agency", PhysicalInstanceReference.Agency), 
                    new XElement(ns + "ID", PhysicalInstanceReference.ID), 
                    new XElement(ns + "Version", PhysicalInstanceReference.Version), 
                    new XElement(ns + "TypeOfObject", PhysicalInstanceReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsInline", IsInline));
            return xEl;
        }
    }
}

