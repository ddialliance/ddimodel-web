using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Storage format arranged record by record. A RecordSet requires a list of variables to appear in a specified order. Provides a consistent order for the variables and a set of values for each record displayed in variable order.
    /// <summary>
    public partial class RecordSetType
    {
        /// <summary>
        /// Provides the sequence of variables representing the order of storage within each record.
        /// <summary>
        public VariableOrderType VariableOrder { get; set; }
        /// <summary>
        /// For each record, contains the values for the items in order by the specified variable sequence.
        /// <summary>
        public List<RecordType> Record { get; set; } = new List<RecordType>();
        public bool ShouldSerializeRecord() { return Record.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (VariableOrder != null) { xEl.Add(VariableOrder.ToXml("VariableOrder")); }
            if (Record != null && Record.Count > 0)
            {
                foreach (var item in Record)
                {
                    xEl.Add(item.ToXml("Record"));
                }
            }
            return xEl;
        }
    }
}

