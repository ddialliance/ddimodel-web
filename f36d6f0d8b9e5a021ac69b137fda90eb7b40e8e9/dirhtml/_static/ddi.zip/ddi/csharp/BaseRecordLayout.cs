using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This type structures an abstract element which is used only as the head of a substitution group. It contains a reference to the Physical Structure that is available for use in all of the substitute RecordLayout structures.
    /// <summary>
    public partial class BaseRecordLayout : Versionable
    {
        /// <summary>
        /// Reference to the PhysicalStructure and the PhysicalSegment used by this Record Layout.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public PhysicalStructure PhysicalStructureLinkReference { get; set; }
        /// <summary>
        /// Specifies the end-of-line (EOL) marker used in the file as produced. If no value is provided assume the use of a CRLF (carriage return and line feed). This is the common EOL for PC's. The common EOL in a Unix environment is LF. Some systems will automatically translate EOLs when a file is moved across systems. Common EOLs include: CR (carriage return), LF (line feed), CRLF, NEL (next line), VT (vertical tab), FF (form feed), LS (line separator) and PS (paragraph separator). See Part I documentation for more detailed information. This object supports the use of a controlled vocabulary. Use of a common controlled vocabulary is strongly recommended.
        /// <summary>
        public CodeValueType EndOfLineMarker { get; set; }
        /// <summary>
        /// Use for delimited files to designate the which text qualifier, if any, was used. Valid values include: singleQuote, doubleQuote, and none.
        /// <summary>
        [StringValidation(new string[] {
            "singleQuote"
,             "doubleQuote"
,             "none"
        })]
        public string TextQualifier { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "BaseRecordLayout");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (PhysicalStructureLinkReference != null)
            {
                xEl.Add(new XElement(ns + "PhysicalStructureLinkReference", 
                    new XElement(ns + "URN", PhysicalStructureLinkReference.URN), 
                    new XElement(ns + "Agency", PhysicalStructureLinkReference.Agency), 
                    new XElement(ns + "ID", PhysicalStructureLinkReference.ID), 
                    new XElement(ns + "Version", PhysicalStructureLinkReference.Version), 
                    new XElement(ns + "TypeOfObject", PhysicalStructureLinkReference.GetType().Name)));
            }
            if (EndOfLineMarker != null) { xEl.Add(EndOfLineMarker.ToXml("EndOfLineMarker")); }
            if (TextQualifier != null)
            {
                xEl.Add(new XElement(ns + "TextQualifier", TextQualifier));
            }
            return xEl;
        }
    }
}

