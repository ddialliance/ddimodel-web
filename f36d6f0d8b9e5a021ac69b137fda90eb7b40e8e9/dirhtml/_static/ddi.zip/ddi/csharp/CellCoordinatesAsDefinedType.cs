using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines one or more cells by defining the applicable values of each dimension as "all values", a "specific value" or a range. For example in a simple 2 dimensional grid where dimension rank-1 is displayed as rows and dimension rank-2 as columns and the first column contains a NumericDomain; SelectDimension rank="1" allValues="true" and SelectDimension rank="2" specificValue="1" would result in the NumericDomain being attached to the first column of the grid only.
    /// <summary>
    public partial class CellCoordinatesAsDefinedType
    {
        /// <summary>
        /// For each dimension in the grid define the applicable values as "all values", a "specific value" or a range. If a rangeMinimum or rangeMaximum is provided without the other, the assumption is unbounded for the object not included.
        /// <summary>
        public List<SelectDimensionType> SelectDimension { get; set; } = new List<SelectDimensionType>();
        public bool ShouldSerializeSelectDimension() { return SelectDimension.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (SelectDimension != null && SelectDimension.Count > 0)
            {
                foreach (var item in SelectDimension)
                {
                    xEl.Add(item.ToXml("SelectDimension"));
                }
            }
            return xEl;
        }
    }
}

