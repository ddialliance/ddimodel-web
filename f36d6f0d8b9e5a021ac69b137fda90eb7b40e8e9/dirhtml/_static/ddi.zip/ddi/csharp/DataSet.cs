using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// DataSet is a substitution for a BaseRecordLayout and allows for in-line inclusion of micro or unit level data in the metadata file. This is valuable for small datasets or cases where there is a need to combine the metadata and data within a single file. In addition to the PhysicalStructureReference the DataSet indicates the ArrayBase if applicable, a name for the DataSet, a reference to the default Variable Scheme used by the data set, a reference to an Identifying Variable (e.g. case number), and a choice of organization order for the data: Record Set, Item Set, or Variable Set. RecordSet describes records of data which contain the same variables in the same order, ItemSet describes individual items of a dataset in any order. VariableSet describes the values for a given variable in record order.
    /// <summary>
    public partial class DataSet : BaseRecordLayout
    {
        /// <summary>
        /// Sets the array base for any arrays used in the definition (that is, whether the first value is in position 0 or 1, etc.).
        /// <summary>
        public int ArrayBase { get; set; }
        /// <summary>
        /// A name for the data set. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DataSetName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDataSetName() { return DataSetName.Count > 0; }
        /// <summary>
        /// Reference to the variable used to identify a specific record within the data set (unique identifier or key).
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable IdentifyingVariableReference { get; set; }
        /// <summary>
        /// A reference to the Variable Scheme containing all or a majority of the variables in the data set. May be overridden by an individual VariableReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public VariableScheme DefaultVariableSchemeReference { get; set; }
        /// <summary>
        /// Storage format arranged record by record. A RecordSet requires a list of variables to appear in a specified order.
        /// <summary>
        public RecordSetType RecordSet { get; set; }
        /// <summary>
        /// Storage format for random order item variables. Each ItemValue references it's defining variable, it's record identifier, and the it's value.
        /// <summary>
        public ItemSetType ItemSet { get; set; }
        /// <summary>
        /// Storage format arranged variable by variable. Item values are listed in record order with the assumption that each record will occupy the position in each array.
        /// <summary>
        public VariableSetType VariableSet { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "DataSet");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "ArrayBase", ArrayBase));
            if (DataSetName != null && DataSetName.Count > 0)
            {
                foreach (var item in DataSetName)
                {
                    xEl.Add(item.ToXml("DataSetName"));
                }
            }
            if (IdentifyingVariableReference != null)
            {
                xEl.Add(new XElement(ns + "IdentifyingVariableReference", 
                    new XElement(ns + "URN", IdentifyingVariableReference.URN), 
                    new XElement(ns + "Agency", IdentifyingVariableReference.Agency), 
                    new XElement(ns + "ID", IdentifyingVariableReference.ID), 
                    new XElement(ns + "Version", IdentifyingVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", IdentifyingVariableReference.GetType().Name)));
            }
            if (DefaultVariableSchemeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultVariableSchemeReference", 
                    new XElement(ns + "URN", DefaultVariableSchemeReference.URN), 
                    new XElement(ns + "Agency", DefaultVariableSchemeReference.Agency), 
                    new XElement(ns + "ID", DefaultVariableSchemeReference.ID), 
                    new XElement(ns + "Version", DefaultVariableSchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultVariableSchemeReference.GetType().Name)));
            }
            if (RecordSet != null) { xEl.Add(RecordSet.ToXml("RecordSet")); }
            if (ItemSet != null) { xEl.Add(ItemSet.ToXml("ItemSet")); }
            if (VariableSet != null) { xEl.Add(VariableSet.ToXml("VariableSet")); }
            return xEl;
        }
    }
}

