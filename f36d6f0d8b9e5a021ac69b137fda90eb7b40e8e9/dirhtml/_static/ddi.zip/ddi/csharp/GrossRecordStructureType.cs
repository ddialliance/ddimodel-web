using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The gross or macro level structures of the record structure including the link to the LogicalRecord and information on the number and ordering of each Physical Segment of the LogicalRecord as stored in the data file. Provides an attribute stating the number of physical segments with a default value of "1".
    /// <summary>
    public partial class GrossRecordStructureType : IdentifiableType
    {
        /// <summary>
        /// Reference to the LogicalRecord that describes the record type and intellectual content of the record within the physical data file.
        /// <summary>
        public LogicalRecordType LogicalRecordReference { get; set; }
        /// <summary>
        /// A description of each physical storage segment required to completely cover the logical record. A logical record may be stored in one or more segments housed hierarchically in a single file or in separate data files. All logical records have at least one segment.
        /// <summary>
        public List<PhysicalRecordSegmentType> PhysicalRecordSegment { get; set; } = new List<PhysicalRecordSegmentType>();
        public bool ShouldSerializePhysicalRecordSegment() { return PhysicalRecordSegment.Count > 0; }
        /// <summary>
        /// Number of physical records segments each logical record (case) is divided into. Express as an integer. Caution in using checksums is recommended. Conflict between checksums and the items being counted can cause problems with warning flags during processing. If using checksum to capture information for internal processing purposes, the use of automatically generated check sums is strongly urged.
        /// <summary>
        public int NumberOfPhysicalSegments { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (LogicalRecordReference != null) { xEl.Add(LogicalRecordReference.ToXml("LogicalRecordReference")); }
            if (PhysicalRecordSegment != null && PhysicalRecordSegment.Count > 0)
            {
                foreach (var item in PhysicalRecordSegment)
                {
                    xEl.Add(item.ToXml("PhysicalRecordSegment"));
                }
            }
            xEl.Add(new XElement(ns + "NumberOfPhysicalSegments", NumberOfPhysicalSegments));
            return xEl;
        }
    }
}

