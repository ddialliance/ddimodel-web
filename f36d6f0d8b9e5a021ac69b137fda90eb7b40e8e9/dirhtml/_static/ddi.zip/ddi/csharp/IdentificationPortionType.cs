using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides structural information for parsing the identification code structure of the Authorized Source into its separate parts.
    /// <summary>
    public partial class IdentificationPortionType
    {
        /// <summary>
        /// Reference to the Geographic Level to which this identification segment refers.
        /// <summary>
        public List<GeographicLevelType> GeographicLevelReference { get; set; } = new List<GeographicLevelType>();
        public bool ShouldSerializeGeographicLevelReference() { return GeographicLevelReference.Count > 0; }
        /// <summary>
        /// The start position of the first character expressed as an integer.
        /// <summary>
        public int StartPosition { get; set; }
        /// <summary>
        /// The length of the segment expressed as an integer.
        /// <summary>
        public int Length { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (GeographicLevelReference != null && GeographicLevelReference.Count > 0)
            {
                foreach (var item in GeographicLevelReference)
                {
                    xEl.Add(item.ToXml("GeographicLevelReference"));
                }
            }
            xEl.Add(new XElement(ns + "StartPosition", StartPosition));
            xEl.Add(new XElement(ns + "Length", Length));
            return xEl;
        }
    }
}

