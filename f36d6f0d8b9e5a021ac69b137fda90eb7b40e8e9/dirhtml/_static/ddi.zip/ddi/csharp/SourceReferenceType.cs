using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to a variable or question used in the derivation or coding instruction.  TypeOfObject should be set to Variable, QuestionItem, or QuestionGrid.
    /// <summary>
    public partial class SourceReferenceType : ReferenceType
    {
        /// <summary>
        /// Allows for assigning an alias used to reference this item in a command. For example if the SourceReference was a question capturing a persons age the command might read "If AGE LT 5...". AGE would be the alias.
        /// <summary>
        public string Alias { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (Alias != null)
            {
                xEl.Add(new XElement(ns + "Alias", Alias));
            }
            return xEl;
        }
    }
}

