using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the cell or cells in a grid to which the item is attached by a reference to a specific cell coordinate in a grid or by identifying a range of values along a dimension.
    /// <summary>
    public partial class GridAttachmentType
    {
        /// <summary>
        /// Defines a single cell by its matrix coordinate address. For example "1,3,2" for a 3 dimensional matrix where dimension rank-1 has a value of 1, dimension rank-2 has a value of 3, and dimension rank-3 has a value of 2.
        /// <summary>
        public string SpecificCellCoordinate { get; set; }
        /// <summary>
        /// Defines one or more cells by defining the applicable values of each dimension as "all values", a "specific value" or a range. For example in a simple 2 dimensional grid where dimension rank-1 is displayed as rows and dimension rank-2 as columns and the first column contains a NumericDomain; SelectDimension rank="1" allValues="true" and SelectDimension rank="2" specificValue="1" would result in the NumericDomain being attached to the first column of the grid only.
        /// <summary>
        public CellCoordinatesAsDefinedType CellCoordinatesAsDefined { get; set; }
        /// <summary>
        /// If the item should be attached to all the cells in the grid set this attribute to "true".
        /// <summary>
        public bool AllCells { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (SpecificCellCoordinate != null)
            {
                xEl.Add(new XElement(ns + "SpecificCellCoordinate", SpecificCellCoordinate));
            }
            if (CellCoordinatesAsDefined != null) { xEl.Add(CellCoordinatesAsDefined.ToXml("CellCoordinatesAsDefined")); }
            xEl.Add(new XElement(ns + "AllCells", AllCells));
            return xEl;
        }
    }
}

