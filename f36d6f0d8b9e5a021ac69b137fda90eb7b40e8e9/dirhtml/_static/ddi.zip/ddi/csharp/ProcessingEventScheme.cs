using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of processing events maintained by an agency, and used in the processing data during development, cleaning, converting to variables, aggregating, and comparing. In addition to the standard name, label, and description allows for the inclusion of an existing ProcessingEventScheme by reference and descriptions of ProcessingEvent and ProcessingEventGroup either in-line or by reference.
    /// <summary>
    public partial class ProcessingEventScheme : Maintainable
    {
        /// <summary>
        /// A name for the ProcessingEventScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ProcessingEventSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeProcessingEventSchemeName() { return ProcessingEventSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the ProcessingEventScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ProcessingEventScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing ProcessingEventScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingEventScheme> ProcessingEventSchemeReference { get; set; } = new List<ProcessingEventScheme>();
        public bool ShouldSerializeProcessingEventSchemeReference() { return ProcessingEventSchemeReference.Count > 0; }
        /// <summary>
        /// A ProcessingEvent described in the ProcessingEventScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingEvent> ProcessingEventReference { get; set; } = new List<ProcessingEvent>();
        public bool ShouldSerializeProcessingEventReference() { return ProcessingEventReference.Count > 0; }
        /// <summary>
        /// A description of a group of ProcessingEvent for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingEventGroup> ProcessingEventGroupReference { get; set; } = new List<ProcessingEventGroup>();
        public bool ShouldSerializeProcessingEventGroupReference() { return ProcessingEventGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "ProcessingEventScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ProcessingEventSchemeName != null && ProcessingEventSchemeName.Count > 0)
            {
                foreach (var item in ProcessingEventSchemeName)
                {
                    xEl.Add(item.ToXml("ProcessingEventSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ProcessingEventSchemeReference != null && ProcessingEventSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingEventSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingEventSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingEventReference != null && ProcessingEventReference.Count > 0)
            {
                foreach (var item in ProcessingEventReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingEventReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingEventGroupReference != null && ProcessingEventGroupReference.Count > 0)
            {
                foreach (var item in ProcessingEventGroupReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingEventGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

