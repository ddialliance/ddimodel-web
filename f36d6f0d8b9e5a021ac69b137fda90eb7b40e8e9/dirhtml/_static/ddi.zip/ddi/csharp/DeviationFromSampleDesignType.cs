using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes any deviations from the planned sample design. These may be for reasons of practicality, implementation issues, or other reasons. In addition to a narrative description allows for use of a brief term or controlled vocabulary term to classify the type of deviation.
    /// <summary>
    public partial class DeviationFromSampleDesignType : IdentifiableType
    {
        /// <summary>
        /// Allows brief identification of the deviation from the sample design with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfDeviationFromSampleDesign { get; set; }
        /// <summary>
        /// Full description of deviation from the sample design. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfDeviationFromSampleDesign != null) { xEl.Add(TypeOfDeviationFromSampleDesign.ToXml("TypeOfDeviationFromSampleDesign")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

