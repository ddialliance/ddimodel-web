using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the language of translation as well as a description of translation for the contents of the DDI Instance.
    /// <summary>
    public partial class TranslationType
    {
        /// <summary>
        /// Uses the more generic Language element found in a Citation. Allows for use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> Language { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeLanguage() { return Language.Count > 0; }
        /// <summary>
        /// Value of the language identifier used.
        /// <summary>
        public string I18n-text { get; set; }
        /// <summary>
        /// Identifies the l18n catalog used.
        /// <summary>
        public string I18n-catalog { get; set; }
        /// <summary>
        /// Description of the translation process of the data and metadata
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Language of the tag content.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (Language != null && Language.Count > 0)
            {
                foreach (var item in Language)
                {
                    xEl.Add(item.ToXml("Language"));
                }
            }
            if (I18n-text != null)
            {
                xEl.Add(new XElement(ns + "I18n-text", I18n-text));
            }
            if (I18n-catalog != null)
            {
                xEl.Add(new XElement(ns + "I18n-catalog", I18n-catalog));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

