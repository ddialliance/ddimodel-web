using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A maintainable module for the conceptual components of the study or group of studies. Conceptual components include the objects used to describe the concepts the study is examining, the universe (population) and sub-universes those concepts to which they are related, and the geographic structures and locations wherein those populations reside. Concepts, and ConceptualVariables (containing a concept linked to a universe) provide an abstract view of what is being measured by questions or other forms of data capture, and the variables which are used to describe the data that will be collected. Universe describes the populations (objects) about whom information is sought. GeographicStructure and GeographicLocation specify the geographical locations of those objects and the structural relationships between locations of different types, e.g. the relationship of a city to the state that contains it. In addition to the standard name, label, and description, ConceptualComponent contains ConceptSchemes, ConceptualVariableSchemes, UniverseSchemes, GeographicStructureSchemes, and GeographicLocationSchemes both in-line and by reference.
    /// <summary>
    public partial class ConceptualComponent : Maintainable
    {
        /// <summary>
        /// A name for the ConceptualComponentModule. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptualComponentModuleName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptualComponentModuleName() { return ConceptualComponentModuleName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptualComponentModule. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ConceptualComponentModule. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides information about the topical, spatial, and temporal coverage of the conceptual components included in this module.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Provides information about external resources related to the conceptual components described in this module.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }
        /// <summary>
        /// Contains a set of the concepts measured by the data that are being documented.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptScheme> ConceptSchemeReference { get; set; } = new List<ConceptScheme>();
        public bool ShouldSerializeConceptSchemeReference() { return ConceptSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a set of the Universes and sub-universes of the data that are being documented.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UniverseScheme> UniverseSchemeReference { get; set; } = new List<UniverseScheme>();
        public bool ShouldSerializeUniverseSchemeReference() { return UniverseSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a set of ConceptualVariables.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualVariableScheme> ConceptualVariableSchemeReference { get; set; } = new List<ConceptualVariableScheme>();
        public bool ShouldSerializeConceptualVariableSchemeReference() { return ConceptualVariableSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a collection of geographic structures.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicStructureScheme> GeographicStructureSchemeReference { get; set; } = new List<GeographicStructureScheme>();
        public bool ShouldSerializeGeographicStructureSchemeReference() { return GeographicStructureSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a collection of geographic locations.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicLocationScheme> GeographicLocationSchemeReference { get; set; } = new List<GeographicLocationScheme>();
        public bool ShouldSerializeGeographicLocationSchemeReference() { return GeographicLocationSchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "ConceptualComponent");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptualComponentModuleName != null && ConceptualComponentModuleName.Count > 0)
            {
                foreach (var item in ConceptualComponentModuleName)
                {
                    xEl.Add(item.ToXml("ConceptualComponentModuleName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            if (ConceptSchemeReference != null && ConceptSchemeReference.Count > 0)
            {
                foreach (var item in ConceptSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UniverseSchemeReference != null && UniverseSchemeReference.Count > 0)
            {
                foreach (var item in UniverseSchemeReference)
                {
                    xEl.Add(new XElement(ns + "UniverseSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptualVariableSchemeReference != null && ConceptualVariableSchemeReference.Count > 0)
            {
                foreach (var item in ConceptualVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicStructureSchemeReference != null && GeographicStructureSchemeReference.Count > 0)
            {
                foreach (var item in GeographicStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicLocationSchemeReference != null && GeographicLocationSchemeReference.Count > 0)
            {
                foreach (var item in GeographicLocationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicLocationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

