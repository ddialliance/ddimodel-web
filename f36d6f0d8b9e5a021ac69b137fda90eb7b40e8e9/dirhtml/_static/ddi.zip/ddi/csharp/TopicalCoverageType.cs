using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the topical coverage of the module using Subject and Keyword. Note that upper level modules should include all the members of lower level modules. Subjects are members of structured classification systems such as formal subject headings in libraries or topical thesauri. Keywords are generally unstructured and reflect the terminology found in the document and other related (broader or similar) terms.
    /// <summary>
    public partial class TopicalCoverageType : IdentifiableType
    {
        /// <summary>
        /// A subject or list of subjects that indicate the topical coverage of the data described in a particular module/section. Uses and InternationalCodeValue and may indicate the language of the code used.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// A keyword that indicates the topical coverage of the data described in a particular module/section. Uses and InternationalCodeValue and may indicate the language of the code used.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            return xEl;
        }
    }
}

