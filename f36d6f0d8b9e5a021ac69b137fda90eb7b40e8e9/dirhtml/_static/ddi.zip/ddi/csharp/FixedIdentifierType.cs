using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to the variable containing the unique identifier. This may be a concatenated variable which indicates the combination of variable required to create a unique identification. If more than one variable reference is included the combination of the variable field contents must be unique and all variables are required for case identification.
    /// <summary>
    public partial class FixedIdentifierType
    {
        /// <summary>
        /// Reference to a variable used as a fixed identifier either singly or in combination with additional reference variables.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> VariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeVariableReference() { return VariableReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null && VariableReference.Count > 0)
            {
                foreach (var item in VariableReference)
                {
                    xEl.Add(new XElement(ns + "VariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

