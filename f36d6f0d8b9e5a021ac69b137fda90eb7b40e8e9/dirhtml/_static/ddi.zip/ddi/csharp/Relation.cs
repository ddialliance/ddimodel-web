using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the relationship between any two organizations or individual, or an individual and an organization. This is a pairwise relationship and relationships may be unidirectional. Identifies the Source organization or individual and the Target organization or individual, describes the relationship, provides a keyword to classify the relationship, provides and effective period for the relationship, allows for addition information to be provided, and can contain a privacy specification.
    /// <summary>
    public partial class Relation : Versionable
    {
        /// <summary>
        /// Identifies the Source organization or individual in the relationship. Source to Target provides a directional perception when defining the relationship.
        /// <summary>
        public SourceObjectType SourceObject { get; set; }
        /// <summary>
        /// Identifies the Target organization or individual in the relationship. The Target object describes its role in relationship to the Source object.
        /// <summary>
        public TargetObjectType TargetObject { get; set; }
        /// <summary>
        /// A description of the relationship. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A brief textual identification of the relation type. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Time period during which this relationship is valid.
        /// <summary>
        public List<DateType> EffectivePeriod { get; set; } = new List<DateType>();
        public bool ShouldSerializeEffectivePeriod() { return EffectivePeriod.Count > 0; }
        /// <summary>
        /// Any additional information you which to note about the relation. This is a structured string so it can be formatted and a privacy tag can be applied.
        /// <summary>
        public List<AdditionalInformationType> AdditionalInformation { get; set; } = new List<AdditionalInformationType>();
        public bool ShouldSerializeAdditionalInformation() { return AdditionalInformation.Count > 0; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "Relation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SourceObject != null) { xEl.Add(SourceObject.ToXml("SourceObject")); }
            if (TargetObject != null) { xEl.Add(TargetObject.ToXml("TargetObject")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (EffectivePeriod != null && EffectivePeriod.Count > 0)
            {
                foreach (var item in EffectivePeriod)
                {
                    xEl.Add(item.ToXml("EffectivePeriod"));
                }
            }
            if (AdditionalInformation != null && AdditionalInformation.Count > 0)
            {
                foreach (var item in AdditionalInformation)
                {
                    xEl.Add(item.ToXml("AdditionalInformation"));
                }
            }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            return xEl;
        }
    }
}

