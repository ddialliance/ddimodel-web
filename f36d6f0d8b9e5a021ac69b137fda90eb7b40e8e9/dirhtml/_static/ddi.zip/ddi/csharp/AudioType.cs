using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the type and length of the audio segment.
    /// <summary>
    public partial class AudioType
    {
        /// <summary>
        /// The type of audio clip provided. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfAudioClip { get; set; }
        /// <summary>
        /// The point to begin the audio clip. If no point is provided the assumption is that the start point is the beginning of the clip provided.
        /// <summary>
        public string AudioClipBegin { get; set; }
        /// <summary>
        /// The point to end the audio clip. If no point is provided the assumption is that the end point is the end of the clip provided.
        /// <summary>
        public string AudioClipEnd { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (TypeOfAudioClip != null) { xEl.Add(TypeOfAudioClip.ToXml("TypeOfAudioClip")); }
            if (AudioClipBegin != null)
            {
                xEl.Add(new XElement(ns + "AudioClipBegin", AudioClipBegin));
            }
            if (AudioClipEnd != null)
            {
                xEl.Add(new XElement(ns + "AudioClipEnd", AudioClipEnd));
            }
            return xEl;
        }
    }
}

