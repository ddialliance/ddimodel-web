using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specifies the Geographic Location Codes included in the representation by providing a reference to the authorized source of the code, the GeographicLocation used, and any excluded values.
    /// <summary>
    public partial class IncludedGeographicLocationCodesType
    {
        /// <summary>
        /// A reference to the Authorized Source of the value used by this representation. A GeographicLocation may have more than one Authorized Source included in the listing.
        /// <summary>
        public AuthorizedSourceType AuthorizedSourceReference { get; set; }
        /// <summary>
        /// A reference to the GeographicLocation used by this representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicLocation GeographicLocationReference { get; set; }
        /// <summary>
        /// A reference to a location value that is excluded, not used by, this representation. May be repeated to exclude multiple location values.
        /// <summary>
        public List<LocationValueType> ExcludedLocationValueReference { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializeExcludedLocationValueReference() { return ExcludedLocationValueReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (AuthorizedSourceReference != null) { xEl.Add(AuthorizedSourceReference.ToXml("AuthorizedSourceReference")); }
            if (GeographicLocationReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicLocationReference", 
                    new XElement(ns + "URN", GeographicLocationReference.URN), 
                    new XElement(ns + "Agency", GeographicLocationReference.Agency), 
                    new XElement(ns + "ID", GeographicLocationReference.ID), 
                    new XElement(ns + "Version", GeographicLocationReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicLocationReference.GetType().Name)));
            }
            if (ExcludedLocationValueReference != null && ExcludedLocationValueReference.Count > 0)
            {
                foreach (var item in ExcludedLocationValueReference)
                {
                    xEl.Add(item.ToXml("ExcludedLocationValueReference"));
                }
            }
            return xEl;
        }
    }
}

