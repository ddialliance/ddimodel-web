using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a RepresentedVariable contained in the RepresentedVariableScheme. In addition to the standard name, label, and description a RepresentedVariable contains a reference to the Concept and Universe (or ConceptualVariable) as well as the representation of the RepresentedVariable. Representation may be provided in-line or by reference to a managed representation. RepresentedVariables are the core reusable parts of a Variable. RepresentedVariable maps to the GSIM Represented Variable. In addition to the standard name, label, and description
    /// <summary>
    public partial class RepresentedVariable : Versionable
    {
        /// <summary>
        /// A name for the RepresentedVariable. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RepresentedVariableName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRepresentedVariableName() { return RepresentedVariableName.Count > 0; }
        /// <summary>
        /// A display label for the RepresentedVariable. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the RepresentedVariable. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to a ConceptualVariable which provides the linkage to the Universe and Concept used by this RepresentedVariable. TypeOfObject should be set to ConceptualVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ConceptualVariable ConceptualVariableReference { get; set; }
        /// <summary>
        /// Reference to the universe statement containing a description of the widest possible group of persons or other elements that this RepresentedVariable refers to, and to which any analytic results refer. TypeOfObject should be set to Universe.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// Reference to the concept measured by this RepresentedVariable. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to a category scheme that contains the representation domain of the RepresentedVariable. Use this element when only the category specifications are provided. If both a code and the related category must be specified use CodeRepresentation (member of the substitution group ValueRepresentation). TypeOfObject should be set to CategoryScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }
        /// <summary>
        /// Describes the actual representation of the RepresentedVariables' values. ValueRepresentation is the head of a substitution group which supports a number of representation types, i.e. CodeRepresentation, NumericRepresentation, TextRepresentation, DateTimeRepresentation, ScaleRepresentation, GeographicStructureCodeRepresentation, and GeographicLocationCodeRepresentation. Although the structure allows for specification of missing values these features should be used with caution. Like the definition of the universe and concept, the specification of the representation can be constrained by the Variable (the GSIM ImplementedVariable), for example a NumericRepresentation could be constrained with a lower top coding specification. Missing Values can be assigned separately by the Variable without impact on the ValueRepresentation of the specified valid values provided here.
        /// <summary>
        public RepresentationType ValueRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of managed value representations by reference. ValueRepresentationReference is the head of a substitution group which supports a number of representation types not managed within existing schemes, i.e. ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, and ManagedScaleRepresentation. TypeOfObject should be set to ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, or ManagedScaleRepresentation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ValueRepresentationReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of managed value representations by reference. ValueRepresentationReference is the head of a substitution group which supports a number of representation types not managed within existing schemes, i.e. ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, and ManagedScaleRepresentation. TypeOfObject should be set to ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, or ManagedScaleRepresentation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ValueRepresentationReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of managed value representations by reference. ValueRepresentationReference is the head of a substitution group which supports a number of representation types not managed within existing schemes, i.e. ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, and ManagedScaleRepresentation. TypeOfObject should be set to ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, or ManagedScaleRepresentation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ValueRepresentationReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of managed value representations by reference. ValueRepresentationReference is the head of a substitution group which supports a number of representation types not managed within existing schemes, i.e. ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, and ManagedScaleRepresentation. TypeOfObject should be set to ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, or ManagedScaleRepresentation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ValueRepresentationReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of managed value representations by reference. ValueRepresentationReference is the head of a substitution group which supports a number of representation types not managed within existing schemes, i.e. ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, and ManagedScaleRepresentation. TypeOfObject should be set to ManagedNumericRepresentation, ManagedTextRepresentation, ManagedDateTimeRepresentation, or ManagedScaleRepresentation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ValueRepresentationReference_ManagedTextRepresentation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "RepresentedVariable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RepresentedVariableName != null && RepresentedVariableName.Count > 0)
            {
                foreach (var item in RepresentedVariableName)
                {
                    xEl.Add(item.ToXml("RepresentedVariableName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptualVariableReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptualVariableReference", 
                    new XElement(ns + "URN", ConceptualVariableReference.URN), 
                    new XElement(ns + "Agency", ConceptualVariableReference.Agency), 
                    new XElement(ns + "ID", ConceptualVariableReference.ID), 
                    new XElement(ns + "Version", ConceptualVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptualVariableReference.GetType().Name)));
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            if (ValueRepresentation != null) { xEl.Add(ValueRepresentation.ToXml("ValueRepresentation")); }
            if (ValueRepresentationReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ValueRepresentationReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ValueRepresentationReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference_ManagedTextRepresentation.GetType().Name)));
            }
            return xEl;
        }
    }
}

