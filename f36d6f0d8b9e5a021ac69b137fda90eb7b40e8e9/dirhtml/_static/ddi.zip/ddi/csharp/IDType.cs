using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// ID type. A fixed attribute is added to the string to ensure that only one ID can be provided.
    /// <summary>
    public partial class IDType : BaseIDType
    {
        /// <summary>
        /// This is a fixed value attribute declaring that the element is Identifiable and follows the rules of an identifiable object within DDI.
        /// <summary>
        public string Type { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("BaseIDType").Descendants())
            {
                xEl.Add(el);
            }
            if (Type != null)
            {
                xEl.Add(new XElement(ns + "Type", Type));
            }
            return xEl;
        }
    }
}

