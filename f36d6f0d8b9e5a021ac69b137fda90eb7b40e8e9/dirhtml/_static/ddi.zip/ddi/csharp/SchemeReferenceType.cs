using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Used for referencing an scheme expressed in DDI XML using the standard reference structure plus the ability to exclude the inclusion of any specified items belonging to the scheme.  TypeOfObject should be set to CategoryScheme, CodeListScheme, ConceptScheme, ConceptualVariableScheme, ControlConstructScheme, GeographicLocationScheme, GeographicStructureScheme, InstrumentScheme, InterviewerInstructionScheme, ManagedRepresentationScheme, NCubeScheme, OrganizationScheme, PhysicalStructureScheme, ProcessingEventScheme, ProcessingInstructionScheme, QualityStatementScheme, QuestionScheme, RecordLayoutScheme, RepresentedVariableScheme, UniverseScheme, or VariableScheme.
    /// <summary>
    public partial class SchemeReferenceType : ReferenceType
    {
        /// <summary>
        /// Identification of an item from the referenced scheme which should be excluded from use for the purposes of the reference.
        /// <summary>
        public List<ReferenceType> Exclude { get; set; } = new List<ReferenceType>();
        public bool ShouldSerializeExclude() { return Exclude.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (Exclude != null && Exclude.Count > 0)
            {
                foreach (var item in Exclude)
                {
                    xEl.Add(item.ToXml("Exclude"));
                }
            }
            return xEl;
        }
    }
}

