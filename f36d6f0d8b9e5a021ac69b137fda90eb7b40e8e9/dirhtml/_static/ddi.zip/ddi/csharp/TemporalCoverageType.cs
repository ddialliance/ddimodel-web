using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the temporal coverage of the data described in a particular DDI module. A date may have a subject attached to it if the referent date has limited application.
    /// <summary>
    public partial class TemporalCoverageType : IdentifiableType
    {
        /// <summary>
        /// The time period to which the data refer. This item reflects the time period covered by the data, not dates in the life cycle of a study or collection.
        /// <summary>
        public List<ReferenceDateType> ReferenceDate { get; set; } = new List<ReferenceDateType>();
        public bool ShouldSerializeReferenceDate() { return ReferenceDate.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (ReferenceDate != null && ReferenceDate.Count > 0)
            {
                foreach (var item in ReferenceDate)
                {
                    xEl.Add(item.ToXml("ReferenceDate"));
                }
            }
            return xEl;
        }
    }
}

