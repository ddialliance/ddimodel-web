using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a set of Variables and VariableGroups. In addition to the standard name, label, and description of the Variable Scheme, may contain another VariableScheme by reference, a listing of Variables (in-line or by reference), and a listing of VariableGroups (in-line or by reference).
    /// <summary>
    public partial class VariableScheme : Maintainable
    {
        /// <summary>
        /// A name for the VariableScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> VariableSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeVariableSchemeName() { return VariableSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the VariableScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the inclusion of another VariableScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableScheme> VariableSchemeReference { get; set; } = new List<VariableScheme>();
        public bool ShouldSerializeVariableSchemeReference() { return VariableSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a Variable in-line. This is the applied expression of a data item within a data set.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> VariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeVariableReference() { return VariableReference.Count > 0; }
        /// <summary>
        /// Contains a group of Variables, which may be ordered or hierarchical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableGroup> VariableGroupReference { get; set; } = new List<VariableGroup>();
        public bool ShouldSerializeVariableGroupReference() { return VariableGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "VariableScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (VariableSchemeName != null && VariableSchemeName.Count > 0)
            {
                foreach (var item in VariableSchemeName)
                {
                    xEl.Add(item.ToXml("VariableSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (VariableSchemeReference != null && VariableSchemeReference.Count > 0)
            {
                foreach (var item in VariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "VariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableReference != null && VariableReference.Count > 0)
            {
                foreach (var item in VariableReference)
                {
                    xEl.Add(new XElement(ns + "VariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableGroupReference != null && VariableGroupReference.Count > 0)
            {
                foreach (var item in VariableGroupReference)
                {
                    xEl.Add(new XElement(ns + "VariableGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

