using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A parameter is a structure that specifically identifies a source of input or output information so that it can be use pragmatically.
    /// <summary>
    public partial class ParameterType : IdentifiableType
    {
        /// <summary>
        /// A name for the Parameter. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ParameterName { get; set; } = new List<NameType>();
        public bool ShouldSerializeParameterName() { return ParameterName.Count > 0; }
        /// <summary>
        /// If the content of the parameter is being used in a generic set of code as an alias for the value of an object in a formula (for example source code for a statistical program) enter that name here. This provides a link from the identified parameter to the alias in the code.
        /// <summary>
        public string Alias { get; set; }
        /// <summary>
        /// A description of the Parameter. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// If the content of the parameter contains representational content, such as codes, provide the representation here. ValueRepresentation is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentation. Inclusion of the ValueRepresentation is recommended if you will be sharing data with others as it provides information on the structure of what they can expect to receive when the parameter is processed.
        /// <summary>
        public RepresentationType ValueRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        public RepresentationReferenceType ValueRepresentationReference { get; set; }
        /// <summary>
        /// Provides a default value for the parameter if there is no value provided by the object it is bound to or the process that was intended to produce a value.
        /// <summary>
        public ValueType DefaultValue { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the parameter is a delimited array rather than a single object and should be processed as such.
        /// <summary>
        public bool IsArray { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (ParameterName != null && ParameterName.Count > 0)
            {
                foreach (var item in ParameterName)
                {
                    xEl.Add(item.ToXml("ParameterName"));
                }
            }
            if (Alias != null)
            {
                xEl.Add(new XElement(ns + "Alias", Alias));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ValueRepresentation != null) { xEl.Add(ValueRepresentation.ToXml("ValueRepresentation")); }
            if (ValueRepresentationReference != null) { xEl.Add(ValueRepresentationReference.ToXml("ValueRepresentationReference")); }
            if (DefaultValue != null) { xEl.Add(DefaultValue.ToXml("DefaultValue")); }
            xEl.Add(new XElement(ns + "IsArray", IsArray));
            return xEl;
        }
    }
}

