using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the default missing value parameter for the this physical instance by referencing a ManagedMissingValuesRepresentation. Note that this MissingValues declaration overrides the value found in the LogicalRecord if it conflicts. The assumption is that this is a System Missing Value declaration, specific to the storage format of the file. If not, change the value of isSystemMissingValue to "false". TypeOfObject should be set to ManagedMissingValuesRepresentation.
    /// <summary>
    public partial class DefaultMissingValuesReferenceType : ReferenceType
    {
        /// <summary>
        /// The assumption is that this is a System Missing Value declaration, specific to the storage format of the file (default value of "true"). If not, change the value to "false".
        /// <summary>
        public bool IsSystemMissingValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsSystemMissingValue", IsSystemMissingValue));
            return xEl;
        }
    }
}

