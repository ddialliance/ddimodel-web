using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. Specifies a ControlConstruct to be repeated while a specified condition is met. Before each iteration the condition is tested. When the condition is not met, control passes back to the containing control construct.
    /// <summary>
    public partial class RepeatWhile : ControlConstruct
    {
        /// <summary>
        /// Information on the command used to determine whether the "While" condition is met.
        /// <summary>
        public CommandCodeType WhileCondition { get; set; }
        /// <summary>
        /// A reference to the ControlConstruct to implement until the WhileCondition is met. This could be a single ControlConstruct or a set of ControlConstructs within a Sequence.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Sequence WhileConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "RepeatWhile");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (WhileCondition != null) { xEl.Add(WhileCondition.ToXml("WhileCondition")); }
            if (WhileConstructReference != null)
            {
                xEl.Add(new XElement(ns + "WhileConstructReference", 
                    new XElement(ns + "URN", WhileConstructReference.URN), 
                    new XElement(ns + "Agency", WhileConstructReference.Agency), 
                    new XElement(ns + "ID", WhileConstructReference.ID), 
                    new XElement(ns + "Version", WhileConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", WhileConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

