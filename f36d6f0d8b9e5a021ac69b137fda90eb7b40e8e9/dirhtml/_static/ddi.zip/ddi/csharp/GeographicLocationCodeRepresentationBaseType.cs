using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for the use of all or part of a GeographicLocation description to be used as a response domain or value representation by a question or variable. In addition to the basic objects of a representation it describes the Geographic Location values available for use by the question or variable.
    /// <summary>
    public partial class GeographicLocationCodeRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// Identifies the Geographic Location codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicLocationCodesType IncludedGeographicLocationCodes { get; set; }
        /// <summary>
        /// When the code is a concatenation this structure allows you to limit the portion of the concatenated code that this object captures.
        /// <summary>
        public LimitedCodeSegmentCapturedType LimitedCodeSegmentCaptured { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (IncludedGeographicLocationCodes != null) { xEl.Add(IncludedGeographicLocationCodes.ToXml("IncludedGeographicLocationCodes")); }
            if (LimitedCodeSegmentCaptured != null) { xEl.Add(LimitedCodeSegmentCaptured.ToXml("LimitedCodeSegmentCaptured")); }
            return xEl;
        }
    }
}

