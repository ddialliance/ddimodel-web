using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Text which has a changeable value depending on a stated condition, response to earlier questions, or as input from a set of metrics (pre-supplied data).
    /// <summary>
    public partial class ConditionalTextType : TextContentType
    {
        /// <summary>
        /// The condition on which the associated text varies expressed by a command code. For example, a command that inserts an age by calculating the difference between today’s date and a previously defined date of birth.
        /// <summary>
        public CommandCodeType Expression { get; set; }
        /// <summary>
        /// This allows for the simple insert of a piece of information from another specified parameter. For example, if the text of the item using conditional text included the respondent’s name use SourceParameterReference to reference the InParameter of the question that is bound to the OutParameter of the question: “What is your name?”
        /// <summary>
        public ParameterType SourceParameterReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("TextContentType").Descendants())
            {
                xEl.Add(el);
            }
            if (Expression != null) { xEl.Add(Expression.ToXml("Expression")); }
            if (SourceParameterReference != null) { xEl.Add(SourceParameterReference.ToXml("SourceParameterReference")); }
            return xEl;
        }
    }
}

