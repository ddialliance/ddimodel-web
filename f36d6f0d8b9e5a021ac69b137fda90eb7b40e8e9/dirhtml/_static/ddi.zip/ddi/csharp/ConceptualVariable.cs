using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a ConceptualVariable which provides the link between a concept to a specific universe (object) that defines this as a ConceptualVariable. In addition to the standard name, label, and description, it provides the two primary components of a ConceptualVariable by referencing a concept and its related universe. Note that the concept referenced may itself contain sub-concepts and/or references to similar concepts. This maps to the GSIM ConceptualVariable and has a basis in the ISO/IEC 11179 RepresentedVariableConcept.
    /// <summary>
    public partial class ConceptualVariable : Versionable
    {
        /// <summary>
        /// A name for the ConceptualVariable. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptualVariableName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptualVariableName() { return ConceptualVariableName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptualVariable. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ConceptualVariable. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to a Concept that is being linked to a Universe identified by the UniverseReference. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to a universe being associated with this concept. TypeOfObject should be set to Universe.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "ConceptualVariable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptualVariableName != null && ConceptualVariableName.Count > 0)
            {
                foreach (var item in ConceptualVariableName)
                {
                    xEl.Add(item.ToXml("ConceptualVariableName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

