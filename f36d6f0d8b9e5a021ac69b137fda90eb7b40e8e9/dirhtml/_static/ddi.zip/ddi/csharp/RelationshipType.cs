using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Relationship specification between this item and the item to which it is related. Provides a reference to any identifiable object and a description of the relationship.
    /// <summary>
    public partial class RelationshipType
    {
        /// <summary>
        /// Reference to the item within the DDI Instance to which this item is related.
        /// <summary>
        public IdentifiableType RelatedToReference_IdentifiableType { get; set; }
        /// <summary>
        /// Reference to the item within the DDI Instance to which this item is related.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Versionable RelatedToReference_Versionable { get; set; }
        /// <summary>
        /// Reference to the item within the DDI Instance to which this item is related.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable RelatedToReference_Maintainable { get; set; }
        /// <summary>
        /// A description of the nature of the relationship between the parent element of the relationship item and the DDI object to which it is related.
        /// <summary>
        public StructuredStringType RelationshipDescription { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (RelatedToReference_IdentifiableType != null) { xEl.Add(RelatedToReference_IdentifiableType.ToXml("RelatedToReference_IdentifiableType")); }
            if (RelatedToReference_Versionable != null)
            {
                xEl.Add(new XElement(ns + "RelatedToReference_Versionable", 
                    new XElement(ns + "URN", RelatedToReference_Versionable.URN), 
                    new XElement(ns + "Agency", RelatedToReference_Versionable.Agency), 
                    new XElement(ns + "ID", RelatedToReference_Versionable.ID), 
                    new XElement(ns + "Version", RelatedToReference_Versionable.Version), 
                    new XElement(ns + "TypeOfObject", RelatedToReference_Versionable.GetType().Name)));
            }
            if (RelatedToReference_Maintainable != null)
            {
                xEl.Add(new XElement(ns + "RelatedToReference_Maintainable", 
                    new XElement(ns + "URN", RelatedToReference_Maintainable.URN), 
                    new XElement(ns + "Agency", RelatedToReference_Maintainable.Agency), 
                    new XElement(ns + "ID", RelatedToReference_Maintainable.ID), 
                    new XElement(ns + "Version", RelatedToReference_Maintainable.Version), 
                    new XElement(ns + "TypeOfObject", RelatedToReference_Maintainable.GetType().Name)));
            }
            if (RelationshipDescription != null) { xEl.Add(RelationshipDescription.ToXml("RelationshipDescription")); }
            return xEl;
        }
    }
}

