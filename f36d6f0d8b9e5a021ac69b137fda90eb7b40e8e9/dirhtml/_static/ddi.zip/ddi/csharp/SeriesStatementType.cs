using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Series statement contains information about the series to which a study unit or group of study units belongs. You may point to the URL of a series repository and then use the SeriesName field to indicate the series itself as identified in that repository. Fields also exist for describing the series and providing abbreviations.
    /// <summary>
    public partial class SeriesStatementType
    {
        /// <summary>
        /// Location of the repository containing the series. This may be repeated for multiple repository locations.
        /// <summary>
        public List<Uri> SeriesRepositoryLocation { get; set; } = new List<Uri>();
        public bool ShouldSerializeSeriesRepositoryLocation() { return SeriesRepositoryLocation.Count > 0; }
        /// <summary>
        /// The full name of the series. The structure supports the use of multiple language versions of the content. If the name varies depending upon the context or is known by multiple names, this element may be repeated.
        /// <summary>
        public List<NameType> SeriesName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSeriesName() { return SeriesName.Count > 0; }
        /// <summary>
        /// Abbreviation of the series name. Repeat for multiple abbreviations for the SAME series Name.
        /// <summary>
        public List<CodeValueType> SeriesAbbreviation { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeSeriesAbbreviation() { return SeriesAbbreviation.Count > 0; }
        /// <summary>
        /// Describe the purpose of coverage of the series. The structure supports the use of multiple language versions of the content.
        /// <summary>
        public StructuredStringType SeriesDescription { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (SeriesRepositoryLocation != null && SeriesRepositoryLocation.Count > 0)
            {
                foreach (var item in SeriesRepositoryLocation)
                {
                    xEl.Add(new XElement(ns + "SeriesRepositoryLocation", item));
                }
            }
            if (SeriesName != null && SeriesName.Count > 0)
            {
                foreach (var item in SeriesName)
                {
                    xEl.Add(item.ToXml("SeriesName"));
                }
            }
            if (SeriesAbbreviation != null && SeriesAbbreviation.Count > 0)
            {
                foreach (var item in SeriesAbbreviation)
                {
                    xEl.Add(item.ToXml("SeriesAbbreviation"));
                }
            }
            if (SeriesDescription != null) { xEl.Add(SeriesDescription.ToXml("SeriesDescription")); }
            return xEl;
        }
    }
}

