using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Packaging structure for multiple language versions of the same string content. Where an element of this type is repeatable, the expectation is that each repetition contains different content, each of which can be expressed in multiple languages. The language designation goes on the individual String.
    /// <summary>
    public partial class InternationalStringType
    {
        /// <summary>
        /// A non-formatted string of text with an attribute that designates the language of the text. Repeat this object to express the same content in another language.
        /// <summary>
        public List<StringType> String { get; set; } = new List<StringType>();
        public bool ShouldSerializeString() { return String.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (String != null && String.Count > 0)
            {
                foreach (var item in String)
                {
                    xEl.Add(item.ToXml("String"));
                }
            }
            return xEl;
        }
    }
}

