using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specification of the character offset for the beginning and end of the segment.
    /// <summary>
    public partial class CharacterParameterType
    {
        /// <summary>
        /// Number of characters from beginning of the document, indicating the inclusive start of the text range.
        /// <summary>
        public int StartCharOffset { get; set; }
        /// <summary>
        /// Number of characters from the beginning of the document, indicating the inclusive end of the text segment.
        /// <summary>
        public int EndCharOffset { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "StartCharOffset", StartCharOffset));
            xEl.Add(new XElement(ns + "EndCharOffset", EndCharOffset));
            return xEl;
        }
    }
}

