using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A location of the specified geographic level providing information on its name, identification codes, temporal and spatial coverage as expressed by bounding and excluding polygon descriptions or references.
    /// <summary>
    public partial class LocationValueType : IdentifiableType
    {
        /// <summary>
        /// A name for the Location. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> LocationValueName { get; set; } = new List<NameType>();
        public bool ShouldSerializeLocationValueName() { return LocationValueName.Count > 0; }
        /// <summary>
        /// A unique identifier for the geographic location. Repeat for multiple identifiers from other authorized sources.
        /// <summary>
        public List<GeographicLocationIdentifierType> GeographicLocationIdentifier { get; set; } = new List<GeographicLocationIdentifierType>();
        public bool ShouldSerializeGeographicLocationIdentifier() { return GeographicLocationIdentifier.Count > 0; }
        /// <summary>
        /// Use to attach one or more characteristics which define the area. These are often useful in terms of selection. For example a U.S. Block may be classified as Urban, Rural, or Mixed. The defining characteristic supports the use of a controlled vocabulary and may provide a time period for which the characteristic is valid.
        /// <summary>
        public List<DefiningCharacteristicType> DefiningCharacteristic { get; set; } = new List<DefiningCharacteristicType>();
        public bool ShouldSerializeDefiningCharacteristic() { return DefiningCharacteristic.Count > 0; }
        /// <summary>
        /// The time period for which the description (names and codes) are valid. Use a date range when start and end periods are known (or the location description is still valid). If the range is unknown indicate a single date for which you know the description is valid. This will allow others to relate it to a fuller date range if external information become available.
        /// <summary>
        public DateType GeographicTime { get; set; }
        /// <summary>
        /// A choice of a BoundingBox and/or a set of BoundingPolygons and ExcludingPolygons that describe an area for a specific time period. Repeat the GeographicBoundary for changes in the geographic footprint of the LocationValue or when providing references to BoundingPolygons from different sources.
        /// <summary>
        public List<GeographicBoundaryType> GeographicBoundary { get; set; } = new List<GeographicBoundaryType>();
        public bool ShouldSerializeGeographicBoundary() { return GeographicBoundary.Count > 0; }
        /// <summary>
        /// Provides a reference to the LocationValue or Values that the current LocationValue supersedes partially or fully. For example, if the LocationValue was the State of North Dakota as defined in 1890 it would supersede the LocationValue for Dakota Territory (1861-1889) as a description of "part" of that Territory.
        /// <summary>
        public List<LocationValueType> SupersedesLocationValue { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializeSupersedesLocationValue() { return SupersedesLocationValue.Count > 0; }
        /// <summary>
        /// Provides a reference to the LocationValue or Values that the current LocationValue immediately precedes partially or fully. For example, if the LocationValue was the Dakota Territory (1861-1889) preceded the State of North Dakota and the State of South Dakota as defined in 1890. The Dakota Territory provided "part" of its area in the creation of each new LocationValue.
        /// <summary>
        public List<LocationValueType> PrecedesLocationValue { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializePrecedesLocationValue() { return PrecedesLocationValue.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (LocationValueName != null && LocationValueName.Count > 0)
            {
                foreach (var item in LocationValueName)
                {
                    xEl.Add(item.ToXml("LocationValueName"));
                }
            }
            if (GeographicLocationIdentifier != null && GeographicLocationIdentifier.Count > 0)
            {
                foreach (var item in GeographicLocationIdentifier)
                {
                    xEl.Add(item.ToXml("GeographicLocationIdentifier"));
                }
            }
            if (DefiningCharacteristic != null && DefiningCharacteristic.Count > 0)
            {
                foreach (var item in DefiningCharacteristic)
                {
                    xEl.Add(item.ToXml("DefiningCharacteristic"));
                }
            }
            if (GeographicTime != null) { xEl.Add(GeographicTime.ToXml("GeographicTime")); }
            if (GeographicBoundary != null && GeographicBoundary.Count > 0)
            {
                foreach (var item in GeographicBoundary)
                {
                    xEl.Add(item.ToXml("GeographicBoundary"));
                }
            }
            if (SupersedesLocationValue != null && SupersedesLocationValue.Count > 0)
            {
                foreach (var item in SupersedesLocationValue)
                {
                    xEl.Add(item.ToXml("SupersedesLocationValue"));
                }
            }
            if (PrecedesLocationValue != null && PrecedesLocationValue.Count > 0)
            {
                foreach (var item in PrecedesLocationValue)
                {
                    xEl.Add(item.ToXml("PrecedesLocationValue"));
                }
            }
            return xEl;
        }
    }
}

