using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use for multiple branching from a single point in the flow logic represented by the flow logic If, Then, ElseIf, Then, etc. This is a packaging element for an IfCondition and ThenConstructReference and not a control construct.
    /// <summary>
    public partial class ElseIfType
    {
        /// <summary>
        /// The condition which must be met to trigger the Then clause, expressed as a Coding. The condition is an expression in the programming language used in the instrument.
        /// <summary>
        public CommandCodeType IfCondition { get; set; }
        /// <summary>
        /// Reference to the control construct which should be triggered if the associated condition is met.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Sequence ThenConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (IfCondition != null) { xEl.Add(IfCondition.ToXml("IfCondition")); }
            if (ThenConstructReference != null)
            {
                xEl.Add(new XElement(ns + "ThenConstructReference", 
                    new XElement(ns + "URN", ThenConstructReference.URN), 
                    new XElement(ns + "Agency", ThenConstructReference.Agency), 
                    new XElement(ns + "ID", ThenConstructReference.ID), 
                    new XElement(ns + "Version", ThenConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", ThenConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

