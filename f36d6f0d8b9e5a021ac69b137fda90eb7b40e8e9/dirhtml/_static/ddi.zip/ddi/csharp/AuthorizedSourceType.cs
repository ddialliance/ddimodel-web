using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A stack of LocationValueReferences to each of the locations of the specified PrimaryComponentLevel type that make up the Component Area. Includes a GeographicTime to allow for repetition for change over time.
    /// <summary>
    public partial class AuthorizedSourceType : OtherMaterialType
    {
        /// <summary>
        /// Provides structural information for parsing the identification code structure of the Authorized Source into its separate parts.
        /// <summary>
        public IdentifierParsingInformationType IdentifierParsingInformation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("OtherMaterialType").Descendants())
            {
                xEl.Add(el);
            }
            if (IdentifierParsingInformation != null) { xEl.Add(IdentifierParsingInformation.ToXml("IdentifierParsingInformation")); }
            return xEl;
        }
    }
}

