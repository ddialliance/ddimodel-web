using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains information proprietary to the software package which produced the data file. This is expressed as a set of key(name)-value pairs.
    /// <summary>
    public partial class ProprietaryInfoType
    {
        /// <summary>
        /// A structure that supports the use of a standard key value pair. Note that this information is often not interoperable and is provided to support the use of the metadata within specific systems.
        /// <summary>
        public List<StandardKeyValuePairType> ProprietaryProperty { get; set; } = new List<StandardKeyValuePairType>();
        public bool ShouldSerializeProprietaryProperty() { return ProprietaryProperty.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (ProprietaryProperty != null && ProprietaryProperty.Count > 0)
            {
                foreach (var item in ProprietaryProperty)
                {
                    xEl.Add(item.ToXml("ProprietaryProperty"));
                }
            }
            return xEl;
        }
    }
}

