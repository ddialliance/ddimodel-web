using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Adds the attribute identifying this as a versionable object as well as the MaintainableObject. All versionable objects should provide their contextual information, the identity of their maintainable parent. The deprecated form of the URN contains all the information to identify and object and its context. A Canonical URN scoped to the Maintainable contains the ID of the Maintainable as part of its structure. To provide full contextual information use the MaintainableObject structure. The use of the Canonical URN scoped to the agency or the identification sequence alone requires the content of the MaintainableObject to provide full contextual information. All content of Versionable is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. See DDI 3.2 Technical Documentation: Part I for further details.
    /// <summary>
    public partial class Versionable : IIdentifiable
    {
        [JsonIgnore]
        public string ReferenceId { get { return $"{URN}:{Agency}:{ID}:{Version}"; } }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[Uu][Rr][Nn]:[Dd][Dd][Ii]:[a-zA-Z0-9\-]{1,63}(\.[a-zA-Z0-9\-]{1,63})*:[A-Za-z0-9\*@$\-_]+(\.[A-Za-z0-9\*@$\-_]+)?:[0-9]+(\.[0-9]+)*")]
        public string URN { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringLength(253, MinimumLength = 1)]
        [StringValidation(null, @"[a-zA-Z0-9\-]{1,63}(\.[a-zA-Z0-9\-]{1,63})*")]
        public string Agency { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[A-Za-z0-9\*@$\-_]+(\.[A-Za-z0-9\*@$\-_]+)?")]
        public string ID { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[0-9]+(\.[0-9]+)*")]
        public string Version { get; set; }
        /// <summary>
        /// Allows for the specification of identifiers other than the specified DDI identification of the object. This may be a legacy ID from DDI-C, a system specific ID such as for a database or registry, or a non-DDI unique identifier. As the identifier is specific to a system the system must be identified with the UserID structure.
        /// <summary>
        public List<UserIDType> UserID { get; set; } = new List<UserIDType>();
        public bool ShouldSerializeUserID() { return UserID.Count > 0; }
        /// <summary>
        /// This section provides information on the Maintainable Parent of this object at its point of origination. This content will not change over time unless the version of the object changes. Note that if the ID, Agency, Version sequence is used, and the scope of uniqueness of the referenced object is the Maintainable, then the ID of the Maintainable is needed to create the structured ID portion of the canonical URN. If the system uses the deprecated URN, both the Maintainable ID and TypeOfMaintainableObject are required to create the deprecated URN structure.
        /// <summary>
        public MaintainableObjectType MaintainableObject { get; set; }
        /// <summary>
        /// This is a fixed flag informing the system or user that this element is versionable and may be versioned over time as well as referenced.
        /// <summary>
        public bool IsVersionable { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "Versionable");
            xEl.Add(new XElement(ns + "URN", URN));
            xEl.Add(new XElement(ns + "Agency", Agency));
            xEl.Add(new XElement(ns + "ID", ID));
            xEl.Add(new XElement(ns + "Version", Version));
            if (UserID != null && UserID.Count > 0)
            {
                foreach (var item in UserID)
                {
                    xEl.Add(item.ToXml("UserID"));
                }
            }
            if (MaintainableObject != null) { xEl.Add(MaintainableObject.ToXml("MaintainableObject")); }
            xEl.Add(new XElement(ns + "IsVersionable", IsVersionable));
            return xEl;
        }
    }
}

