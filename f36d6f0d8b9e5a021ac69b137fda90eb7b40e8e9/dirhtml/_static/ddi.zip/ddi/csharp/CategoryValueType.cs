using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A category value for which one or more statistics are recorded. Each VariableCategory has one category value and any number of associated statistics.
    /// <summary>
    public partial class CategoryValueType
    {
        /// <summary>
        /// A reference to the coded value of the category as used by a CodeRepresentation.
        /// <summary>
        public CodeType CodeReference { get; set; }
        /// <summary>
        /// The value of the category.
        /// <summary>
        public ValueType Value { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (CodeReference != null) { xEl.Add(CodeReference.ToXml("CodeReference")); }
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            return xEl;
        }
    }
}

