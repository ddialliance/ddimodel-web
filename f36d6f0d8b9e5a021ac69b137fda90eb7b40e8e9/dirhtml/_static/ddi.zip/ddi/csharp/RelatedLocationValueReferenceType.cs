using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a reference to the LocationValue or Values that is related to the current LocationValue partially or fully. TypeOfObject should be set to LocationValue.
    /// <summary>
    public partial class RelatedLocationValueReferenceType : ReferenceType
    {
        /// <summary>
        /// The attribute indicates whether or not the full area of the LocationValue within which the element is used maps to the referenced area. The default value is false, i.e. only part of the current LocationValue maps to the referenced LocationValue. Change to "true" if the full area of the current LocationValue maps to the referenced LocationValue.
        /// <summary>
        public bool IsFull { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsFull", IsFull));
            return xEl;
        }
    }
}

