using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A comprehensive list of the concepts measured by the data that are being documented that is maintained by an agency. In addition to the standard name, label, and description, allows for the inclusion of an existing ConceptScheme by reference, assignment of a controlled vocabulary for the scheme, inclusion of descriptions for Concepts and ConceptGroups in-line or by reference.
    /// <summary>
    public partial class ConceptScheme : Maintainable
    {
        /// <summary>
        /// A name for the ConceptScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptSchemeName() { return ConceptSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ConceptScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing ConceptScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptScheme> ConceptSchemeReference { get; set; } = new List<ConceptScheme>();
        public bool ShouldSerializeConceptSchemeReference() { return ConceptSchemeReference.Count > 0; }
        /// <summary>
        /// Identifies and describes the vocabulary used to create the concept scheme.
        /// <summary>
        public VocabularyType Vocabulary { get; set; }
        /// <summary>
        /// Describes an individual concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> ConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeConceptReference() { return ConceptReference.Count > 0; }
        /// <summary>
        /// Allows for grouping of concepts for administrative or conceptual purposes; groups may have a hierarchical structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptGroup> ConceptGroupReference { get; set; } = new List<ConceptGroup>();
        public bool ShouldSerializeConceptGroupReference() { return ConceptGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "ConceptScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptSchemeName != null && ConceptSchemeName.Count > 0)
            {
                foreach (var item in ConceptSchemeName)
                {
                    xEl.Add(item.ToXml("ConceptSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptSchemeReference != null && ConceptSchemeReference.Count > 0)
            {
                foreach (var item in ConceptSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Vocabulary != null) { xEl.Add(Vocabulary.ToXml("Vocabulary")); }
            if (ConceptReference != null && ConceptReference.Count > 0)
            {
                foreach (var item in ConceptReference)
                {
                    xEl.Add(new XElement(ns + "ConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptGroupReference != null && ConceptGroupReference.Count > 0)
            {
                foreach (var item in ConceptGroupReference)
                {
                    xEl.Add(new XElement(ns + "ConceptGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

