using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Field to capture coordinate pairs as individual pairs or as an array of pairs.
    /// <summary>
    public partial class CoordinatePairsType : TextDomainType
    {
        /// <summary>
        /// The maximum number of coordinate pairs listed in the array. The two values in a coordinate pair are separated by a comma. Pairs in an array are separated by the character indicated in the arraySeparator attribute. Default value is "1".
        /// <summary>
        public int MaxArray { get; set; }
        /// <summary>
        /// The character used to separate arrays, if present. If not given a value, and if the maxArray attribute has a value greater than one, the separator is assumed to be whitespace.
        /// <summary>
        public string ArraySeparator { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("TextDomainType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "MaxArray", MaxArray));
            if (ArraySeparator != null)
            {
                xEl.Add(new XElement(ns + "ArraySeparator", ArraySeparator));
            }
            return xEl;
        }
    }
}

