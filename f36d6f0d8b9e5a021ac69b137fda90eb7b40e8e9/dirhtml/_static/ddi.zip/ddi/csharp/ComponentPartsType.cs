using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A stack of LocationValueReferences to each of the locations of the specified PrimaryComponentLevel type that make up the Component Area. Includes a GeographicTime to allow for repetition for change over time.
    /// <summary>
    public partial class ComponentPartsType
    {
        /// <summary>
        /// Reference to the LocationValue of a basic building block of the composite area.
        /// <summary>
        public LocationValueType LocationValueReference { get; set; }
        /// <summary>
        /// The time period for which the LocationValues listed are a valid set.
        /// <summary>
        public DateType GeographicTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (LocationValueReference != null) { xEl.Add(LocationValueReference.ToXml("LocationValueReference")); }
            if (GeographicTime != null) { xEl.Add(GeographicTime.ToXml("GeographicTime")); }
            return xEl;
        }
    }
}

