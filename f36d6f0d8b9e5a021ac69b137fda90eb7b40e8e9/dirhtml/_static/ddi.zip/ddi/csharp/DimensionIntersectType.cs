using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the point at which the scales of a multidimensional scale intersect. May include all or a subset of dimensions intersecting at a given point. Repeat for multiple intersect points.
    /// <summary>
    public partial class DimensionIntersectType
    {
        /// <summary>
        /// List by repetition all dimensions intersecting at this value by Dimension Number.
        /// <summary>
        public List<int> IncludedDimension { get; set; } = new List<int>();
        public bool ShouldSerializeIncludedDimension() { return IncludedDimension.Count > 0; }
        /// <summary>
        /// If different dimensions intersect at different values list each set in a separate DimensionIntersect and list each dimension included by an IncludeDimension.
        /// <summary>
        public bool ForAllDimensions { get; set; }
        /// <summary>
        /// The value at which the dimensions intersect.
        /// <summary>
        public string IntersectValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            xEl.Add(
                from item in IncludedDimension
                select new XElement(ns + "IncludedDimension", item));
            xEl.Add(new XElement(ns + "ForAllDimensions", ForAllDimensions));
            if (IntersectValue != null)
            {
                xEl.Add(new XElement(ns + "IntersectValue", IntersectValue));
            }
            return xEl;
        }
    }
}

