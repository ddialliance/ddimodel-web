using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use when creating an object that is based on an existing object or objects that are managed by a different agency or when the new object is NOT simply a version change but you wish to maintain a reference to the object that served as a basis for the new object. BasedOnObject may contain references to any number of objects which serve as a basis for this object, a BasedOnRationalDescription of how the content of the referenced object was incorporated or altered, and a BasedOnRationalCode to allow for specific typing of the BasedOnReference according to an external controlled vocabulary.
    /// <summary>
    public partial class BasedOnObjectType
    {
        /// <summary>
        /// A reference to an object upon which the current object is based using a standard Reference structure. Repeat for multiple base objects. The TypeOfObject may be any Versionable or Maintainable object.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Versionable> BasedOnReference_Versionable { get; set; } = new List<Versionable>();
        public bool ShouldSerializeBasedOnReference_Versionable() { return BasedOnReference_Versionable.Count > 0; }
        /// <summary>
        /// A reference to an object upon which the current object is based using a standard Reference structure. Repeat for multiple base objects. The TypeOfObject may be any Versionable or Maintainable object.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Maintainable> BasedOnReference_Maintainable { get; set; } = new List<Maintainable>();
        public bool ShouldSerializeBasedOnReference_Maintainable() { return BasedOnReference_Maintainable.Count > 0; }
        /// <summary>
        /// Textual description of the rationale/purpose for the based on reference to inform users as to the extent and implication of the version change. May be expressed in multiple languages.
        /// <summary>
        public InternationalStringType BasedOnRationaleDescription { get; set; }
        /// <summary>
        /// RationaleCode is primarily for internal processing flags within an organization or system. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType BasedOnRationaleCode { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (BasedOnReference_Versionable != null && BasedOnReference_Versionable.Count > 0)
            {
                foreach (var item in BasedOnReference_Versionable)
                {
                    xEl.Add(new XElement(ns + "BasedOnReference_Versionable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (BasedOnReference_Maintainable != null && BasedOnReference_Maintainable.Count > 0)
            {
                foreach (var item in BasedOnReference_Maintainable)
                {
                    xEl.Add(new XElement(ns + "BasedOnReference_Maintainable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (BasedOnRationaleDescription != null) { xEl.Add(BasedOnRationaleDescription.ToXml("BasedOnRationaleDescription")); }
            if (BasedOnRationaleCode != null) { xEl.Add(BasedOnRationaleCode.ToXml("BasedOnRationaleCode")); }
            return xEl;
        }
    }
}

