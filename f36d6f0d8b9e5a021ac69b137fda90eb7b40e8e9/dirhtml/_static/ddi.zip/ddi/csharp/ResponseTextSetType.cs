using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a means of bundling multiple language versions of the same intended dynamic text together. This wrapper serves to differentiate between a case where multiple language content for a single ResponseText are provided and when two differing sets of ResponseText are in immediate sequence (with no intervening question). Each of the repetitions of ResponseText within this wrapper are assumed to be multi-language equivalents.
    /// <summary>
    public partial class ResponseTextSetType
    {
        /// <summary>
        /// Text closely related to the content of the ResponseDomain(s), in general, text required to make sense of the related response domain. Note that when using ResponseText, the full ResponseText must be repeated for multi-language versions of the content. Different languages may handle the dynamic portions in different locations and/or with different content. Therefore languages cannot be mixed within a dynamic text except when the full text itself has multiple language sections, for example, a foreign language term in a text. The DisplayText may also be repeated to provide a dynamic and plain text version of the display. This allows for accurate rendering of the ResponseText in a non-dynamic environment like print.
        /// <summary>
        public List<DynamicTextType> ResponseText { get; set; } = new List<DynamicTextType>();
        public bool ShouldSerializeResponseText() { return ResponseText.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (ResponseText != null && ResponseText.Count > 0)
            {
                foreach (var item in ResponseText)
                {
                    xEl.Add(item.ToXml("ResponseText"));
                }
            }
            return xEl;
        }
    }
}

