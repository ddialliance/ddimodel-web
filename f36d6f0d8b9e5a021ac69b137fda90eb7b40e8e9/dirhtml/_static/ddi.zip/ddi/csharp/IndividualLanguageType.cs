using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use to specify the languages known by the individual in terms of their ability to  speak, read, and write the language. May be repeated to cover multiple languages. This information is useful for foreign contacts in determining the language of communication to use with this individual.
    /// <summary>
    public partial class IndividualLanguageType
    {
        /// <summary>
        /// Specifies the language (and optionally the locale) of the individual. The language identifier is defined by IETF RFC 4646 or its successor. The base sub-tag is the ISO 639 2 or 3 digit language code.
        /// <summary>
        public CodeValueType Language { get; set; }
        /// <summary>
        /// Indicates reading knowledge of the language specified. Supports an optional controlled vocabulary.
        /// <summary>
        public CodeValueType Read { get; set; }
        /// <summary>
        /// Indicates writing knowledge of the language specified. Supports an optional controlled vocabulary.
        /// <summary>
        public CodeValueType Write { get; set; }
        /// <summary>
        /// Indicates speaking knowledge of the language specified. Supports an optional controlled vocabulary.
        /// <summary>
        public CodeValueType Speak { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (Language != null) { xEl.Add(Language.ToXml("Language")); }
            if (Read != null) { xEl.Add(Read.ToXml("Read")); }
            if (Write != null) { xEl.Add(Write.ToXml("Write")); }
            if (Speak != null) { xEl.Add(Speak.ToXml("Speak")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            return xEl;
        }
    }
}

