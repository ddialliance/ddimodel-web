using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use when only the lowest, most discrete codes in the CodeList will be expressed as valid values. Identifies those levels of a CodeList with a regular hierarchy or those indicates discrete codes within an irregular hierarchy. All other codes will be used as labels within the hierarchy to clearly express content, but will not be valid as a response or representation value.
    /// <summary>
    public partial class DataExistenceType
    {
        /// <summary>
        /// Use for a regular hierarchy. List the Level Number of the lowest or most discrete level of data available.
        /// <summary>
        public int LevelNumber { get; set; }
        /// <summary>
        /// Use for an irregular hierarchy where the most discrete codes have been identified by attribute isDiscrete. This element is to be used if only the most discrete data elements will have data. It has a fixed value, so it will indicate which categories have data based on their description.
        /// <summary>
        public bool DiscreteCategory { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "LevelNumber", LevelNumber));
            xEl.Add(new XElement(ns + "DiscreteCategory", DiscreteCategory));
            return xEl;
        }
    }
}

