using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains summary and category level statistics for the referenced variable. Includes information on the total number of responses, the weights in calculating the statistics, variable level summary statistics, and category statistics. The category statistics may be provided as unfiltered values or filtered through a single variable. For example the category statistics for Sex filtered by the variable Country for a multi-national data file. Note that if no weighting factor is identified, all of the statistics provided are unweighted. 
    /// <summary>
    public partial class VariableStatistics : Versionable
    {
        /// <summary>
        /// Reference to the variable to which the statistics apply.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// The total number of responses to this variable. This element is especially useful if the number of responses does not match added case counts. It may also be used to sum the frequencies for variable categories.
        /// <summary>
        public int TotalResponses { get; set; }
        /// <summary>
        /// Reference to the StandardWeight value provided in Weighting.
        /// <summary>
        public StandardWeightType StandardWeightReference { get; set; }
        /// <summary>
        /// Reference to a variable to use for weight in calculating the statistic.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable WeightVariableReference { get; set; }
        /// <summary>
        /// Indicates the missing values that were excluded from the statistic by referencing the ManagedMissingValuesRepresentation used by the Variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation MissingValuesReference { get; set; }
        /// <summary>
        /// A summary statistic for the referenced variable.
        /// <summary>
        public List<SummaryStatisticType> SummaryStatistic { get; set; } = new List<SummaryStatisticType>();
        public bool ShouldSerializeSummaryStatistic() { return SummaryStatistic.Count > 0; }
        /// <summary>
        /// The unfiltered values of any number of statistics by category value representing the full response distribution of the variable.
        /// <summary>
        public List<UnfilteredCategoryStatisticsType> UnfilteredCategoryStatistics { get; set; } = new List<UnfilteredCategoryStatisticsType>();
        public bool ShouldSerializeUnfilteredCategoryStatistics() { return UnfilteredCategoryStatistics.Count > 0; }
        /// <summary>
        /// Includes category-level statistic for the referenced variable using another variable to filter the categories through. For example, the Eurobarometer may filter its category statistics by country as represented in a variable "CountryCode".
        /// <summary>
        public List<FilteredCategoryStatisticsType> FilteredCategoryStatistics { get; set; } = new List<FilteredCategoryStatisticsType>();
        public bool ShouldSerializeFilteredCategoryStatistics() { return FilteredCategoryStatistics.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "VariableStatistics");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "TotalResponses", TotalResponses));
            if (StandardWeightReference != null) { xEl.Add(StandardWeightReference.ToXml("StandardWeightReference")); }
            if (WeightVariableReference != null)
            {
                xEl.Add(new XElement(ns + "WeightVariableReference", 
                    new XElement(ns + "URN", WeightVariableReference.URN), 
                    new XElement(ns + "Agency", WeightVariableReference.Agency), 
                    new XElement(ns + "ID", WeightVariableReference.ID), 
                    new XElement(ns + "Version", WeightVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", WeightVariableReference.GetType().Name)));
            }
            if (MissingValuesReference != null)
            {
                xEl.Add(new XElement(ns + "MissingValuesReference", 
                    new XElement(ns + "URN", MissingValuesReference.URN), 
                    new XElement(ns + "Agency", MissingValuesReference.Agency), 
                    new XElement(ns + "ID", MissingValuesReference.ID), 
                    new XElement(ns + "Version", MissingValuesReference.Version), 
                    new XElement(ns + "TypeOfObject", MissingValuesReference.GetType().Name)));
            }
            if (SummaryStatistic != null && SummaryStatistic.Count > 0)
            {
                foreach (var item in SummaryStatistic)
                {
                    xEl.Add(item.ToXml("SummaryStatistic"));
                }
            }
            if (UnfilteredCategoryStatistics != null && UnfilteredCategoryStatistics.Count > 0)
            {
                foreach (var item in UnfilteredCategoryStatistics)
                {
                    xEl.Add(item.ToXml("UnfilteredCategoryStatistics"));
                }
            }
            if (FilteredCategoryStatistics != null && FilteredCategoryStatistics.Count > 0)
            {
                foreach (var item in FilteredCategoryStatistics)
                {
                    xEl.Add(item.ToXml("FilteredCategoryStatistics"));
                }
            }
            return xEl;
        }
    }
}

