using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This is a reference to a MeasureDefinition as described in the parent NCube logical structure. The reference has an additional attribute orderValue which defines the position of the referenced MeasureDefinition along the MeasureDimension so that it can be used as part of the cell address. The default value is "1". Additional MeasureDefinitions should have incremental values (2,3,4,...).  TypeOfObject should be set to MeasureDefinition.
    /// <summary>
    public partial class NCubeMeasureDefinitionReferenceType : ReferenceType
    {
        /// <summary>
        /// The reference has an additional attribute orderValue which defines the position of the referenced MeasureDefinition along the MeasureDimension so that it can be used as part of the cell address. The default value is "1". Additional MeasureDefinitions should have incremental values (2,3,4,...)
        /// <summary>
        public int OrderValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "OrderValue", OrderValue));
            return xEl;
        }
    }
}

