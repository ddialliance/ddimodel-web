using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures the QuestionGrid as an NCube-like structure providing dimension information, labeling options, and response domains attached to one or more cells within the grid. Provides the intent of the QuestionGrid, input and output parameters for the grid, the question text for the grid, details on the dimensions, allowed responses, and additional cell contents of the grid, references to external aids and instructions, and an estimate of the time required to complete the grid. Note that the QuestionGrid is a reusable format for use in any number of applied uses. External aids, instructions, response sequencing etc. should contain information consistent with the general use of the QuestionGrid. Additional materials and information can be added within the QuestionConstruct which is the applied use of a question.
    /// <summary>
    public partial class QuestionGrid : Versionable
    {
        /// <summary>
        /// A name for the QuestionGrid. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QuestionGridName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQuestionGridName() { return QuestionGridName.Count > 0; }
        /// <summary>
        /// Provides an identity for input objects required for the QuestionGrid.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// Provides an identify for the output objects of the QuestionGrid.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// A structure used to bind the content of a parameter declared as the source to a parameter declared as the target. For example, binding the OutParameter of one Question to the InParameter of another Question in order to personalize a question text. Care should be taken to bind only reusable information at this level. Binding is also available at the QuestionConstruct to reflect bindings particular to the use of the question in a specific question flow or instrument.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// The text of a question. Supports the use of DynamicText. Note that when using QuestionText, the full QuestionText must be repeated for multi-language versions of the content. Different languages may handle the dynamic portions in different locations and/or with different content. Therefore languages cannot be mixed within a dynamic text except when the full text itself has multiple language sections, for example, a foreign language term in a text. The DisplayText may also be repeated to provide a dynamic and plain text version of the display. This allows for accurate rendering of the QuestionText in a non-dynamic environment like print.
        /// <summary>
        public List<DynamicTextType> QuestionText { get; set; } = new List<DynamicTextType>();
        public bool ShouldSerializeQuestionText() { return QuestionText.Count > 0; }
        /// <summary>
        /// The purpose of the QuestionGrid in terms of what it is designed to test. May contain information on specific aspects of the Grid and its construction.
        /// <summary>
        public StructuredStringType QuestionIntent { get; set; }
        /// <summary>
        /// Describes each dimension of the grid including dimension rank (for the purpose of identifying a cell address), a text for the dimension, and optional labels and codes used as column and row stubs. May also describe a roster (a set of unlabeled rows or columns depending upon display situation).
        /// <summary>
        public List<GridDimensionType> GridDimension { get; set; } = new List<GridDimensionType>();
        public bool ShouldSerializeGridDimension() { return GridDimension.Count > 0; }
        /// <summary>
        /// Contains a response domain for the question grid. All cells in the grid have the same response domain. Any cell may also contain an internal label.
        /// <summary>
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type DomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ResponseDomainReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type DomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ResponseDomainReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type DomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ResponseDomainReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type DomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ResponseDomainReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type DomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ResponseDomainReference_ManagedTextRepresentation { get; set; }
        /// <summary>
        /// Contains a mixture of response domains for the grid cells. Each response domain can be attached to a specific region of the grid, for example a single column or row.
        /// <summary>
        public StructuredMixedGridResponseDomainType StructuredMixedGridResponseDomain { get; set; }
        /// <summary>
        /// Provides for the addition of a label within a cell or cells of the grid.
        /// <summary>
        public List<CellLabelType> CellLabel { get; set; } = new List<CellLabelType>();
        public bool ShouldSerializeCellLabel() { return CellLabel.Count > 0; }
        /// <summary>
        /// A reference to the concept the QuestionGrid is intended to gather data on.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> ConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeConceptReference() { return ConceptReference.Count > 0; }
        /// <summary>
        /// A pointer to an external aid presented by the instrument such as a text card, image, audio, or audiovisual aid. Typically a URN. Use type attribute to describe the type of external aid provided. Example of terms to use would include: imageOnly audioOnly audioVisual multiMedia.
        /// <summary>
        public List<OtherMaterialType> ExternalAid { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeExternalAid() { return ExternalAid.Count > 0; }
        /// <summary>
        /// External reference to an interviewer instruction not expressed as DDI XML using OtherMaterial.
        /// <summary>
        public ExternalInterviewerInstructionType ExternalInterviewerInstruction { get; set; }
        /// <summary>
        /// Reference to an interviewer instruction expressed as DDI XML.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instruction InterviewerInstructionReference { get; set; }
        /// <summary>
        /// The estimated amount of time required to answer a question expressed in seconds. Decimal values should be used to define fractions of seconds.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "QuestionGrid");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QuestionGridName != null && QuestionGridName.Count > 0)
            {
                foreach (var item in QuestionGridName)
                {
                    xEl.Add(item.ToXml("QuestionGridName"));
                }
            }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (QuestionText != null && QuestionText.Count > 0)
            {
                foreach (var item in QuestionText)
                {
                    xEl.Add(item.ToXml("QuestionText"));
                }
            }
            if (QuestionIntent != null) { xEl.Add(QuestionIntent.ToXml("QuestionIntent")); }
            if (GridDimension != null && GridDimension.Count > 0)
            {
                foreach (var item in GridDimension)
                {
                    xEl.Add(item.ToXml("GridDimension"));
                }
            }
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedTextRepresentation.GetType().Name)));
            }
            if (StructuredMixedGridResponseDomain != null) { xEl.Add(StructuredMixedGridResponseDomain.ToXml("StructuredMixedGridResponseDomain")); }
            if (CellLabel != null && CellLabel.Count > 0)
            {
                foreach (var item in CellLabel)
                {
                    xEl.Add(item.ToXml("CellLabel"));
                }
            }
            if (ConceptReference != null && ConceptReference.Count > 0)
            {
                foreach (var item in ConceptReference)
                {
                    xEl.Add(new XElement(ns + "ConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalAid != null && ExternalAid.Count > 0)
            {
                foreach (var item in ExternalAid)
                {
                    xEl.Add(item.ToXml("ExternalAid"));
                }
            }
            if (ExternalInterviewerInstruction != null) { xEl.Add(ExternalInterviewerInstruction.ToXml("ExternalInterviewerInstruction")); }
            if (InterviewerInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "InterviewerInstructionReference", 
                    new XElement(ns + "URN", InterviewerInstructionReference.URN), 
                    new XElement(ns + "Agency", InterviewerInstructionReference.Agency), 
                    new XElement(ns + "ID", InterviewerInstructionReference.ID), 
                    new XElement(ns + "Version", InterviewerInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", InterviewerInstructionReference.GetType().Name)));
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

