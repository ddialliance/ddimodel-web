using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a group of RepresentedVariables, which may describe an ordered or hierarchical relationship structure. RepresentedVariables may be grouped for a wide range of reasons including conceptual or universe grouping, usage, subject or keyword relationships, or other grouping reason that will assist in the management of a group of RepresentedVariables. Specifies the purpose of the group, a name, label, and description of the group, its relationship to a specific universe or concept, and lists the members of the group.
    /// <summary>
    public partial class RepresentedVariableGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a RepresentedVariableGroup. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfRepresentedVariableGroup { get; set; }
        /// <summary>
        /// A name for the group. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RepresentedVariableGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRepresentedVariableGroupName() { return RepresentedVariableGroupName.Count > 0; }
        /// <summary>
        /// A display label for the RepresentedVariableGroup. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the RepresentedVariableGroup. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain. TypeOfObject should be set to Universe.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent RepresentedVariable (from the substitution group). TypeOfObject should be set to RepresentedVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RepresentedVariable RepresentedVariableReference { get; set; }
        /// <summary>
        /// Reference to constituent RepresentedVariableGroup. This allows for nesting of RepresentedVariableGroups. TypeOfObject should be set to RepresentedVariableGroup.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RepresentedVariableGroup RepresentedVariableGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + "RepresentedVariableGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfRepresentedVariableGroup != null) { xEl.Add(TypeOfRepresentedVariableGroup.ToXml("TypeOfRepresentedVariableGroup")); }
            if (RepresentedVariableGroupName != null && RepresentedVariableGroupName.Count > 0)
            {
                foreach (var item in RepresentedVariableGroupName)
                {
                    xEl.Add(item.ToXml("RepresentedVariableGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (RepresentedVariableReference != null)
            {
                xEl.Add(new XElement(ns + "RepresentedVariableReference", 
                    new XElement(ns + "URN", RepresentedVariableReference.URN), 
                    new XElement(ns + "Agency", RepresentedVariableReference.Agency), 
                    new XElement(ns + "ID", RepresentedVariableReference.ID), 
                    new XElement(ns + "Version", RepresentedVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", RepresentedVariableReference.GetType().Name)));
            }
            if (RepresentedVariableGroupReference != null)
            {
                xEl.Add(new XElement(ns + "RepresentedVariableGroupReference", 
                    new XElement(ns + "URN", RepresentedVariableGroupReference.URN), 
                    new XElement(ns + "Agency", RepresentedVariableGroupReference.Agency), 
                    new XElement(ns + "ID", RepresentedVariableGroupReference.ID), 
                    new XElement(ns + "Version", RepresentedVariableGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", RepresentedVariableGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

