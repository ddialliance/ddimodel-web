using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the mode of collection, i.e., paper questionnaire, observation, web delivered questionnaire, computer assisted interview, automated data harvesting, etc. In addition to the narrative description allows for the use of a brief term or item from a controlled vocabulary to classify the mode used. If multiple modes are used repeat the element.
    /// <summary>
    public partial class ModeOfCollectionType : IdentifiableType
    {
        /// <summary>
        /// Allows brief identification of the mode used with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfModeOfCollection { get; set; }
        /// <summary>
        /// Full description of the mode of collection. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfModeOfCollection != null) { xEl.Add(TypeOfModeOfCollection.ToXml("TypeOfModeOfCollection")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

