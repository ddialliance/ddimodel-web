using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the GeographicLocation as represented by a specific GeographicCode provided by an Authorized Source.
    /// <summary>
    public partial class GeographicLocationIdentifierType
    {
        /// <summary>
        /// Container for a standard geography code expressed as a string.
        /// <summary>
        public string GeographicCode { get; set; }
        /// <summary>
        /// Reference to the AuthorizedSource description in GeographicLocation that provided this code.
        /// <summary>
        public AuthorizedSourceType AuthorizedSourceReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (GeographicCode != null)
            {
                xEl.Add(new XElement(ns + "GeographicCode", GeographicCode));
            }
            if (AuthorizedSourceReference != null) { xEl.Add(AuthorizedSourceReference.ToXml("AuthorizedSourceReference")); }
            return xEl;
        }
    }
}

