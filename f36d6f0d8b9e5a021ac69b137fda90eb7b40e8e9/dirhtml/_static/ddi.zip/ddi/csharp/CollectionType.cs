using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a collection of items held or distributed by the archive in connection with a study, group of studies, or resource packages. What constitutes an collection is determined by the archive. These may be data file(s) in a variety of formats, statistical setups, codebooks, questionnaires, etc. A collection may also be a group of studies, groups, and/or resource packages.
    /// <summary>
    public partial class CollectionType
    {
        /// <summary>
        /// A citation for the collection. May additionally be rendered in native qualified Dublin Core (dc and dcterms).
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// Describes the location of the collection within the archive. Repeat for multiple locations such as separate stores for access and archival copies.
        /// <summary>
        public List<InternationalStringType> LocationInArchive { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeLocationInArchive() { return LocationInArchive.Count > 0; }
        /// <summary>
        /// The name, code, or number used by the archive to uniquely identify the collection within the archive.
        /// <summary>
        public string CallNumber { get; set; }
        /// <summary>
        /// The URL or URN for the collection.
        /// <summary>
        public Uri URI { get; set; }
        /// <summary>
        /// The number of items in the collection. This is a check sum and should be updated as the contents of the collection changes. The use of this element is best restricted to completed collections where change in the number of objects is not dynamic.
        /// <summary>
        public int ItemQuantity { get; set; }
        /// <summary>
        /// An archive specific classification for the collection. This may be a topical classification, a classification of intended processing levels, or information on the processing status.
        /// <summary>
        public StudyClassType StudyClass { get; set; }
        /// <summary>
        /// Default access restriction information applying to all of the items in the collection.
        /// <summary>
        public AccessType DefaultAccess { get; set; }
        /// <summary>
        /// The original archive for the described collection, expressed as a reference to an organization listed in the organization scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> OriginalArchiveOrganizationReference { get; set; } = new List<Organization>();
        public bool ShouldSerializeOriginalArchiveOrganizationReference() { return OriginalArchiveOrganizationReference.Count > 0; }
        /// <summary>
        /// A statement of availability for the collection. This is a positive statement (as opposed to access restrictions) which may be used for publication or other purposes. Allows for structured content.
        /// <summary>
        public StructuredStringType AvailabilityStatus { get; set; }
        /// <summary>
        /// The number of data files in the described collection, expressed as an integer. This is a check sum and should be updated as the contents of the collection changes. The use of this element is best restricted to completed collections where change in the number of objects is not dynamic.
        /// <summary>
        public int DataFileQuantity { get; set; }
        /// <summary>
        /// Describes the completeness of the collection. Note coverage gaps as well as collections strengths. This statement may be used for publication or other purposes. Allows for structured content.
        /// <summary>
        public StructuredStringType CollectionCompleteness { get; set; }
        /// <summary>
        /// Allows for the nesting of Item descriptions with a collection.
        /// <summary>
        public List<ItemType> Item { get; set; } = new List<ItemType>();
        public bool ShouldSerializeItem() { return Item.Count > 0; }
        /// <summary>
        /// Allows for the nesting of collection descriptions with a collection hierarchical groupings within a collection description.
        /// <summary>
        public List<CollectionType> Collection { get; set; } = new List<CollectionType>();
        public bool ShouldSerializeCollection() { return Collection.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "";
            XElement xEl = new XElement(ns + name);
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (LocationInArchive != null && LocationInArchive.Count > 0)
            {
                foreach (var item in LocationInArchive)
                {
                    xEl.Add(item.ToXml("LocationInArchive"));
                }
            }
            if (CallNumber != null)
            {
                xEl.Add(new XElement(ns + "CallNumber", CallNumber));
            }
            if (URI != null)
            {
                xEl.Add(new XElement(ns + "URI", URI));
            }
            xEl.Add(new XElement(ns + "ItemQuantity", ItemQuantity));
            if (StudyClass != null) { xEl.Add(StudyClass.ToXml("StudyClass")); }
            if (DefaultAccess != null) { xEl.Add(DefaultAccess.ToXml("DefaultAccess")); }
            if (OriginalArchiveOrganizationReference != null && OriginalArchiveOrganizationReference.Count > 0)
            {
                foreach (var item in OriginalArchiveOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "OriginalArchiveOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (AvailabilityStatus != null) { xEl.Add(AvailabilityStatus.ToXml("AvailabilityStatus")); }
            xEl.Add(new XElement(ns + "DataFileQuantity", DataFileQuantity));
            if (CollectionCompleteness != null) { xEl.Add(CollectionCompleteness.ToXml("CollectionCompleteness")); }
            if (Item != null && Item.Count > 0)
            {
                foreach (var item in Item)
                {
                    xEl.Add(item.ToXml("Item"));
                }
            }
            if (Collection != null && Collection.Count > 0)
            {
                foreach (var item in Collection)
                {
                    xEl.Add(item.ToXml("Collection"));
                }
            }
            return xEl;
        }
    }
}

