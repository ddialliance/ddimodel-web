using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A reference to an image, with a description of its properties and type.
    /// <summary>
    public partial class ImageType
    {
        /// <summary>
        /// A reference to the location of the image using a URI.
        /// <summary>
        public Uri ImageLocation { get; set; }
        /// <summary>
        /// Brief description of the image type. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfImage { get; set; }
        /// <summary>
        /// Provides the resolution of the image in dots per inch to assist in selecting the appropriate image for various uses.
        /// <summary>
        public int Dpi { get; set; }
        /// <summary>
        /// Language of image.
        /// <summary>
        public string LanguageOfImage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ImageLocation != null)
            {
                xEl.Add(new XElement(ns + "ImageLocation", ImageLocation));
            }
            if (TypeOfImage != null) { xEl.Add(TypeOfImage.ToXml("TypeOfImage")); }
            xEl.Add(new XElement(ns + "Dpi", Dpi));
            if (LanguageOfImage != null)
            {
                xEl.Add(new XElement(ns + "LanguageOfImage", LanguageOfImage));
            }
            return xEl;
        }
    }
}

