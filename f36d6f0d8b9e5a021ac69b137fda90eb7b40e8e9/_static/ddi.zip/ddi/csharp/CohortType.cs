using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the included values of a dimension by means of individual value references or by defining a range of values to include. Allows the included values to be identified by reference to the Code, the Category used by the Code, or the Value of the Code (which by definition should be unique). The dimension is identified by its rank value.
    /// <summary>
    public partial class CohortType
    {
        /// <summary>
        /// Reference to the Category represented by the Value of the Code assigned in a CodeList. Repeat for including multiple values.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Category> CategoryReference { get; set; } = new List<Category>();
        public bool ShouldSerializeCategoryReference() { return CategoryReference.Count > 0; }
        /// <summary>
        /// Reference to the Code within the CodeList used by the variable describing the dimension. Repeat for including multiple values.
        /// <summary>
        public List<CodeType> CodeReference { get; set; } = new List<CodeType>();
        public bool ShouldSerializeCodeReference() { return CodeReference.Count > 0; }
        /// <summary>
        /// Use when multiple values are included. This uses the unique Value provided for the Code as a means of identification. Provides the range of Values for this dimension that are within the area being defined. Repeat for non-contiguous values.
        /// <summary>
        public List<RangeType> Range { get; set; } = new List<RangeType>();
        public bool ShouldSerializeRange() { return Range.Count > 0; }
        /// <summary>
        /// Identify the dimension being described by its rank value within the NCube description.
        /// <summary>
        public int Rank { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CategoryReference != null && CategoryReference.Count > 0)
            {
                foreach (var item in CategoryReference)
                {
                    xEl.Add(new XElement(ns + "CategoryReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CodeReference != null && CodeReference.Count > 0)
            {
                foreach (var item in CodeReference)
                {
                    xEl.Add(item.ToXml("CodeReference"));
                }
            }
            if (Range != null && Range.Count > 0)
            {
                foreach (var item in Range)
                {
                    xEl.Add(item.ToXml("Range"));
                }
            }
            xEl.Add(new XElement(ns + "Rank", Rank));
            return xEl;
        }
    }
}

