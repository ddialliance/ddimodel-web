using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows a depository to provide locally created value added material and processing information in the appropriate packaging structure and to designate the relationship of added material to the original by means of a content map. The content maps indicates if the added material should Override, act as AddedContent, or DeleteContent in the original deposited material. The material is expressed in the structure of either a StudyUnit, Group, or ResourcePackage within a local content structure.
    /// <summary>
    public partial class LocalAddedContentType
    {
        /// <summary>
        /// Contains a stack of links from the LocalAddedContent to the Depository content and provides instructions regarding the relationship between the local added content and the deposited content.
        /// <summary>
        public ContentLinkingMapType ContentLinkingMap { get; set; }
        /// <summary>
        /// Local Content using the StudyUnit structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StudyUnit> LocalStudyUnitContentReference { get; set; } = new List<StudyUnit>();
        public bool ShouldSerializeLocalStudyUnitContentReference() { return LocalStudyUnitContentReference.Count > 0; }
        /// <summary>
        /// Local Content using the Group structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Group> LocalGroupContentReference { get; set; } = new List<Group>();
        public bool ShouldSerializeLocalGroupContentReference() { return LocalGroupContentReference.Count > 0; }
        /// <summary>
        /// Local Content using the ResourcePackage structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ResourcePackage> LocalResourcePackageContentReference { get; set; } = new List<ResourcePackage>();
        public bool ShouldSerializeLocalResourcePackageContentReference() { return LocalResourcePackageContentReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ContentLinkingMap != null) { xEl.Add(ContentLinkingMap.ToXml("ContentLinkingMap")); }
            if (LocalStudyUnitContentReference != null && LocalStudyUnitContentReference.Count > 0)
            {
                foreach (var item in LocalStudyUnitContentReference)
                {
                    xEl.Add(new XElement(ns + "LocalStudyUnitContentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LocalGroupContentReference != null && LocalGroupContentReference.Count > 0)
            {
                foreach (var item in LocalGroupContentReference)
                {
                    xEl.Add(new XElement(ns + "LocalGroupContentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LocalResourcePackageContentReference != null && LocalResourcePackageContentReference.Count > 0)
            {
                foreach (var item in LocalResourcePackageContentReference)
                {
                    xEl.Add(new XElement(ns + "LocalResourcePackageContentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

