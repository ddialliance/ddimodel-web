using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides information about data that are not currently available because of policies established by the principal investigators and/or data producers. This item may be attached to specific levels of a study such as a specific variable by reference. Embargo provides a name, label and description of the embargo, the dates covered by the embargo, the rationale or reason for the embargo, a reference to the agency establishing the embargo, and a reference to the agency enforcing the embargo.
    /// <summary>
    public partial class EmbargoType : IdentifiableType
    {
        /// <summary>
        /// The name or names by which the embargo is known. Repeat if different names are used for different purposes or different contexts. Language repetition is handled within the structure of the Embargo Name element.
        /// <summary>
        public List<NameType> EmbargoName { get; set; } = new List<NameType>();
        public bool ShouldSerializeEmbargoName() { return EmbargoName.Count > 0; }
        /// <summary>
        /// A label or labels for the embargo element. Repeat for differences in content due to software or application constraints. Language repetition is handled within the structure of the label.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Describe the content and coverage of the embargo. Structure supports multiple languages.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides the end date of the embargo, which may take the form of a date range (complete or open ended). Note SimpleDate should not be used for an Embargo Date as an embargo is for a period of time.
        /// <summary>
        public DateType Date { get; set; }
        /// <summary>
        /// Indicates the reason for the embargo.
        /// <summary>
        public StructuredStringType Rationale { get; set; }
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for the embargo.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization AgencyOrganizationReference { get; set; }
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for enforcing the embargo.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> EnforcementAgencyOrganizationReference { get; set; } = new List<Organization>();
        public bool ShouldSerializeEnforcementAgencyOrganizationReference() { return EnforcementAgencyOrganizationReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (EmbargoName != null && EmbargoName.Count > 0)
            {
                foreach (var item in EmbargoName)
                {
                    xEl.Add(item.ToXml("EmbargoName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Date != null) { xEl.Add(Date.ToXml("Date")); }
            if (Rationale != null) { xEl.Add(Rationale.ToXml("Rationale")); }
            if (AgencyOrganizationReference != null)
            {
                xEl.Add(new XElement(ns + "AgencyOrganizationReference", 
                    new XElement(ns + "URN", AgencyOrganizationReference.URN), 
                    new XElement(ns + "Agency", AgencyOrganizationReference.Agency), 
                    new XElement(ns + "ID", AgencyOrganizationReference.ID), 
                    new XElement(ns + "Version", AgencyOrganizationReference.Version), 
                    new XElement(ns + "TypeOfObject", AgencyOrganizationReference.GetType().Name)));
            }
            if (EnforcementAgencyOrganizationReference != null && EnforcementAgencyOrganizationReference.Count > 0)
            {
                foreach (var item in EnforcementAgencyOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "EnforcementAgencyOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

