using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Used to preserve an historical date, formatted in a non-ISO fashion.
    /// <summary>
    public partial class HistoricalDateType
    {
        /// <summary>
        /// This is the date expressed in a non-ISO compliant structure. Primarily used to retain legacy content or to express non-Gregorian calender dates.
        /// <summary>
        public string NonISODate { get; set; }
        /// <summary>
        /// Indicate the structure of the date provided in NonISODate. For example if the NonISODate contained 4/1/2000 the Historical Date Format would be mm/dd/yyyy. The use of a controlled vocabulary is strongly recommended to support interoperability.
        /// <summary>
        public CodeValueType HistoricalDateFormat { get; set; }
        /// <summary>
        /// Specifies the type of calendar used (e.g., Gregorian, Julian, Jewish).
        /// <summary>
        public CodeValueType Calendar { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (NonISODate != null)
            {
                xEl.Add(new XElement(ns + "NonISODate", NonISODate));
            }
            if (HistoricalDateFormat != null) { xEl.Add(HistoricalDateFormat.ToXml("HistoricalDateFormat")); }
            if (Calendar != null) { xEl.Add(Calendar.ToXml("Calendar")); }
            return xEl;
        }
    }
}

