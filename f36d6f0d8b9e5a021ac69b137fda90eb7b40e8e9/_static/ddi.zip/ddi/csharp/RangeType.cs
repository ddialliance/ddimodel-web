using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Indicates the range of items expressed as a string, such as an alphabetic range.
    /// <summary>
    public partial class RangeType
    {
        /// <summary>
        /// Specifies the units in the range.
        /// <summary>
        public string RangeUnit { get; set; }
        /// <summary>
        /// Minimum value in the range.
        /// <summary>
        public RangeValueType MinimumValue { get; set; }
        /// <summary>
        /// Maximum value in the range.
        /// <summary>
        public RangeValueType MaximumValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (RangeUnit != null)
            {
                xEl.Add(new XElement(ns + "RangeUnit", RangeUnit));
            }
            if (MinimumValue != null) { xEl.Add(MinimumValue.ToXml("MinimumValue")); }
            if (MaximumValue != null) { xEl.Add(MaximumValue.ToXml("MaximumValue")); }
            return xEl;
        }
    }
}

