using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Processing instructions for recodes, derivations from multiple question or variable sources, and derivations based on external sources. Instructions should be listed separately so they can be referenced individually.
    /// <summary>
    public partial class GenerationInstruction : Versionable
    {
        /// <summary>
        /// Reference to a question used in the instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionItem> SourceQuestion { get; set; } = new List<QuestionItem>();
        public bool ShouldSerializeSourceQuestion() { return SourceQuestion.Count > 0; }
        /// <summary>
        /// Reference to a variable used in the coding process
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> SourceVariable { get; set; } = new List<Variable>();
        public bool ShouldSerializeSourceVariable() { return SourceVariable.Count > 0; }
        /// <summary>
        /// Reference to an external source of information used in the coding process, for example a value from a chart, etc.
        /// <summary>
        public List<OtherMaterialType> ExternalInformation { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeExternalInformation() { return ExternalInformation.Count > 0; }
        /// <summary>
        /// A description of the generation instruction. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Structured information used by a system to process the instruction.
        /// <summary>
        public List<CommandCodeType> CommandCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeCommandCode() { return CommandCode.Count > 0; }
        /// <summary>
        /// A control construct which is used to describe or process the instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }
        /// <summary>
        /// Describes the aggregation process, identifying both the independent and dependent variables within the process.
        /// <summary>
        public AggregationType Aggregation { get; set; }
        /// <summary>
        /// Default setting is "true", the instruction describes a derivation. If the instruction is a simple recode, set to "false".
        /// <summary>
        public bool IsDerived { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "GenerationInstruction");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SourceQuestion != null && SourceQuestion.Count > 0)
            {
                foreach (var item in SourceQuestion)
                {
                    xEl.Add(new XElement(ns + "SourceQuestion", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SourceVariable != null && SourceVariable.Count > 0)
            {
                foreach (var item in SourceVariable)
                {
                    xEl.Add(new XElement(ns + "SourceVariable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalInformation != null && ExternalInformation.Count > 0)
            {
                foreach (var item in ExternalInformation)
                {
                    xEl.Add(item.ToXml("ExternalInformation"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CommandCode != null && CommandCode.Count > 0)
            {
                foreach (var item in CommandCode)
                {
                    xEl.Add(item.ToXml("CommandCode"));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Aggregation != null) { xEl.Add(Aggregation.ToXml("Aggregation")); }
            xEl.Add(new XElement(ns + "IsDerived", IsDerived));
            return xEl;
        }
    }
}

