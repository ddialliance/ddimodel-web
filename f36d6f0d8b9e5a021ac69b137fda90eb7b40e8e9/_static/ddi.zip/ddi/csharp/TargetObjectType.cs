using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the Target organization or individual in the relationship. References either an Organiztion or an Individual and specifies the role of the Target in relationship to the Source. Multiple roles for specified periods may be identified.
    /// <summary>
    public partial class TargetObjectType
    {
        /// <summary>
        /// A reference to an Organization described in DDI.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization OrganizationReference { get; set; }
        /// <summary>
        /// A reference to an Individual described in DDI.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual IndividualReference { get; set; }
        /// <summary>
        /// Describes the role of Target Individual or Organization in relation to the Source Object.
        /// <summary>
        public List<RoleType> Role { get; set; } = new List<RoleType>();
        public bool ShouldSerializeRole() { return Role.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (OrganizationReference != null)
            {
                xEl.Add(new XElement(ns + "OrganizationReference", 
                    new XElement(ns + "URN", OrganizationReference.URN), 
                    new XElement(ns + "Agency", OrganizationReference.Agency), 
                    new XElement(ns + "ID", OrganizationReference.ID), 
                    new XElement(ns + "Version", OrganizationReference.Version), 
                    new XElement(ns + "TypeOfObject", OrganizationReference.GetType().Name)));
            }
            if (IndividualReference != null)
            {
                xEl.Add(new XElement(ns + "IndividualReference", 
                    new XElement(ns + "URN", IndividualReference.URN), 
                    new XElement(ns + "Agency", IndividualReference.Agency), 
                    new XElement(ns + "ID", IndividualReference.ID), 
                    new XElement(ns + "Version", IndividualReference.Version), 
                    new XElement(ns + "TypeOfObject", IndividualReference.GetType().Name)));
            }
            if (Role != null && Role.Count > 0)
            {
                foreach (var item in Role)
                {
                    xEl.Add(item.ToXml("Role"));
                }
            }
            return xEl;
        }
    }
}

