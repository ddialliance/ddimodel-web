using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the range of values used in the ranking system using Range and sets the number of times a single value can be repeated.
    /// <summary>
    public partial class RankingRangeType : RangeType
    {
        /// <summary>
        /// Allows values to be expressed more than once, for example if respondent can specify a "tie" by repeating a single value.
        /// <summary>
        public int MaximumRepetitionOfSingleValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RangeType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "MaximumRepetitionOfSingleValue", MaximumRepetitionOfSingleValue));
            return xEl;
        }
    }
}

