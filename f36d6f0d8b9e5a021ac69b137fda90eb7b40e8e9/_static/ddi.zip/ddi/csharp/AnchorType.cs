using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for the attachment of a category label at any anchor point in a scale.
    /// <summary>
    public partial class AnchorType
    {
        /// <summary>
        /// A reference to the category containing the label for the anchor point.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Category CategoryReference { get; set; }
        /// <summary>
        /// The value of the anchor point.
        /// <summary>
        public string Value_string { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CategoryReference != null)
            {
                xEl.Add(new XElement(ns + "CategoryReference", 
                    new XElement(ns + "URN", CategoryReference.URN), 
                    new XElement(ns + "Agency", CategoryReference.Agency), 
                    new XElement(ns + "ID", CategoryReference.ID), 
                    new XElement(ns + "Version", CategoryReference.Version), 
                    new XElement(ns + "TypeOfObject", CategoryReference.GetType().Name)));
            }
            if (Value_string != null)
            {
                xEl.Add(new XElement(ns + "Value_string", Value_string));
            }
            return xEl;
        }
    }
}

