using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A structured display label for the element. Label provides display content of a fully human readable display for the identification of the element. DDI does not impose any length limitations on Label. If length of Label is constrained due to use of the element in a specific application, the maximum length supported should be noted in the attribute maxLength. TypeOfLabel should be used to indicate the application either directly or as an identified type, such as “systems with an 8 character label length limitation”. The label may also indicate its applicability to a specific locale using the attribute locationVariant. Label may be repeated to provide content for different uses or situations. Language variants should be made within the Label using the internal structure of the Structured String type. The assumption is that replication of Label is done to provide different intellectual content or content specific to differing systems or applications.
    /// <summary>
    public partial class LabelType : StructuredStringType
    {
        /// <summary>
        /// A brief description of the label type. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfLabel { get; set; }
        /// <summary>
        /// Indicate if the content is intended to be used in a specific location. For example if the Label is specific to use within a sub-region of a country that uses the same language but may have unique terminology. For example some regions of the United States use the term “water fountain” and others use “bubbler”.
        /// <summary>
        public string LocationVariant { get; set; }
        /// <summary>
        /// Allows for the specification of a starting date for the period that this label is valid. The date must be formatted according to ISO 8601.
        /// <summary>
        public CogsDate ValidForStartDate { get; set; }
        /// <summary>
        /// Allows for the specification of a ending date for the period that this label is valid. The date must be formatted according to ISO 8601.
        /// <summary>
        public CogsDate ValidForEndDate { get; set; }
        /// <summary>
        /// A positive integer indicating the maximum number of characters in the label.
        /// <summary>
        public int MaxLength { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("StructuredStringType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfLabel != null) { xEl.Add(TypeOfLabel.ToXml("TypeOfLabel")); }
            if (LocationVariant != null)
            {
                xEl.Add(new XElement(ns + "LocationVariant", LocationVariant));
            }
            if (ValidForStartDate != null && ValidForStartDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidForStartDate", ValidForStartDate.ToString()));
            }
            if (ValidForEndDate != null && ValidForEndDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidForEndDate", ValidForEndDate.ToString()));
            }
            xEl.Add(new XElement(ns + "MaxLength", MaxLength));
            return xEl;
        }
    }
}

