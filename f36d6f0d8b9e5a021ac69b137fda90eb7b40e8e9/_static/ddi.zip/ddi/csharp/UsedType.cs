using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specifies a DDI object and all its sub-objects supported by the DDIProfile. May specify an alternate local name and description of an object, instructions for its use, and set limits on its allowed usage.
    /// <summary>
    public partial class UsedType
    {
        /// <summary>
        /// Provides an alternate name for the element, for presentation purposes (not for use in the XML instance). It may be supplied in several language-versions.
        /// <summary>
        public InternationalStringType AlternateName { get; set; }
        /// <summary>
        /// A description of the content and purpose of the object. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Instructions for the use of the object within the context of the profile. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Instructions { get; set; }
        /// <summary>
        /// If true indicates that an element described as optional in DDI is required by the profile.
        /// <summary>
        public bool IsRequired { get; set; }
        /// <summary>
        /// Contains an XPath which points to an element or attribute in DDI instances which is used by the profile. All subelements of a used element are assumed to be supported unless explicitly addressed by the profile. The number of supported repetitions may be included in the XPath expression.
        /// <summary>
        public string Xpath { get; set; }
        /// <summary>
        /// This field provides a default value for the specified element or attribute if it holds simple content, and the value must be a valid one per the DDI schemas. This assumes that the value is not specified in the DDI instance itself, which would override the default. The value should also be provided as part of the XPath expression supplied for the field.
        /// <summary>
        public string DefaultValue_string { get; set; }
        /// <summary>
        /// This field allows for limiting the maximum occurrences of this field. If the number is greater than the maxOccurs value in DDI it will be ignored and the DDI specification will remain in use.
        /// <summary>
        public string LimitMaxOccurs { get; set; }
        /// <summary>
        /// This field, if set to true, provides an indication that the default value supplied in the fixedValue attribute is the only one which is allowed for the profile - other values will be overridden with the default (a warning should be issued to the creator of the instance); the value must be a valid one per the DDI schemas.
        /// <summary>
        public bool FixedValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AlternateName != null) { xEl.Add(AlternateName.ToXml("AlternateName")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Instructions != null) { xEl.Add(Instructions.ToXml("Instructions")); }
            xEl.Add(new XElement(ns + "IsRequired", IsRequired));
            if (Xpath != null)
            {
                xEl.Add(new XElement(ns + "Xpath", Xpath));
            }
            if (DefaultValue_string != null)
            {
                xEl.Add(new XElement(ns + "DefaultValue_string", DefaultValue_string));
            }
            if (LimitMaxOccurs != null)
            {
                xEl.Add(new XElement(ns + "LimitMaxOccurs", LimitMaxOccurs));
            }
            xEl.Add(new XElement(ns + "FixedValue", FixedValue));
            return xEl;
        }
    }
}

