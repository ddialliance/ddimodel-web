using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the use of all or part of a CodeList as a representation used by a question response domain or variable value representation.
    /// <summary>
    public partial class CodeRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// A reference to the CodeList included in this representation using the Reference structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CodeList CodeListReference { get; set; }
        /// <summary>
        /// Allows further specification of the codes to use from the CodeList by defining the level or only the most discrete codes of a hierarchical CodeList, the range of codes to use, or an itemized sub-set.
        /// <summary>
        public CodeSubsetInformationType CodeSubsetInformation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (CodeListReference != null)
            {
                xEl.Add(new XElement(ns + "CodeListReference", 
                    new XElement(ns + "URN", CodeListReference.URN), 
                    new XElement(ns + "Agency", CodeListReference.Agency), 
                    new XElement(ns + "ID", CodeListReference.ID), 
                    new XElement(ns + "Version", CodeListReference.Version), 
                    new XElement(ns + "TypeOfObject", CodeListReference.GetType().Name)));
            }
            if (CodeSubsetInformation != null) { xEl.Add(CodeSubsetInformation.ToXml("CodeSubsetInformation")); }
            return xEl;
        }
    }
}

