using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains information on the hierarchy of the geographic structure. In addition to the standard name, label, and description identifies one or more AuthorizedSources for the level codes/descriptions provided and a set of GeographicLevels in-line or by reference.
    /// <summary>
    public partial class GeographicStructureScheme : Maintainable
    {
        /// <summary>
        /// A name for the GeographicStructure. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> GeographicStructureSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeGeographicStructureSchemeName() { return GeographicStructureSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the GeographicStructure. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the GeographicStructure. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// The inclusion of an existing GeographicStructureScheme in the parent scheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicStructureScheme> GeographicStructureSchemeReference { get; set; } = new List<GeographicStructureScheme>();
        public bool ShouldSerializeGeographicStructureSchemeReference() { return GeographicStructureSchemeReference.Count > 0; }
        /// <summary>
        /// Used to describe any level of geography, including overall coverage and each of the lower levels.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicStructure> GeographicStructureReference { get; set; } = new List<GeographicStructure>();
        public bool ShouldSerializeGeographicStructureReference() { return GeographicStructureReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of GeographicStructure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeographicStructureGroup> GeographicStructureGroupReference { get; set; } = new List<GeographicStructureGroup>();
        public bool ShouldSerializeGeographicStructureGroupReference() { return GeographicStructureGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "GeographicStructureScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (GeographicStructureSchemeName != null && GeographicStructureSchemeName.Count > 0)
            {
                foreach (var item in GeographicStructureSchemeName)
                {
                    xEl.Add(item.ToXml("GeographicStructureSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GeographicStructureSchemeReference != null && GeographicStructureSchemeReference.Count > 0)
            {
                foreach (var item in GeographicStructureSchemeReference)
                {
                    xEl.Add(new XElement(ns + "GeographicStructureSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicStructureReference != null && GeographicStructureReference.Count > 0)
            {
                foreach (var item in GeographicStructureReference)
                {
                    xEl.Add(new XElement(ns + "GeographicStructureReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeographicStructureGroupReference != null && GeographicStructureGroupReference.Count > 0)
            {
                foreach (var item in GeographicStructureGroupReference)
                {
                    xEl.Add(new XElement(ns + "GeographicStructureGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

