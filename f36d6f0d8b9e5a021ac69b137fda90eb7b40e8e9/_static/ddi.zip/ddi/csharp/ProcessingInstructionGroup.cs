using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a group of processing instructions for administrative or conceptual purposes, which may be hierarchical. In addition to the standard name, label, and description contains references to included Generation or General Instructions, and other ProcessingInstructionGroups.
    /// <summary>
    public partial class ProcessingInstructionGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a processing instruction group. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfProcessingInstructionGroup { get; set; }
        /// <summary>
        /// A name for the ProcessingInstructionGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ProcessingInstructionGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeProcessingInstructionGroupName() { return ProcessingInstructionGroupName.Count > 0; }
        /// <summary>
        /// A display label for the ProcessingInstructionGroup. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ProcessingInstructionGroup. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent General Instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeneralInstruction GeneralInstructionReference { get; set; }
        /// <summary>
        /// Reference to constituent Generation Instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction GenerationInstructionReference { get; set; }
        /// <summary>
        /// Reference to constituent processing instruction group. This allows for nesting of processing instruction groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstructionGroup ProcessingInstructionGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ProcessingInstructionGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfProcessingInstructionGroup != null) { xEl.Add(TypeOfProcessingInstructionGroup.ToXml("TypeOfProcessingInstructionGroup")); }
            if (ProcessingInstructionGroupName != null && ProcessingInstructionGroupName.Count > 0)
            {
                foreach (var item in ProcessingInstructionGroupName)
                {
                    xEl.Add(item.ToXml("ProcessingInstructionGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (GeneralInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "GeneralInstructionReference", 
                    new XElement(ns + "URN", GeneralInstructionReference.URN), 
                    new XElement(ns + "Agency", GeneralInstructionReference.Agency), 
                    new XElement(ns + "ID", GeneralInstructionReference.ID), 
                    new XElement(ns + "Version", GeneralInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", GeneralInstructionReference.GetType().Name)));
            }
            if (GenerationInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "GenerationInstructionReference", 
                    new XElement(ns + "URN", GenerationInstructionReference.URN), 
                    new XElement(ns + "Agency", GenerationInstructionReference.Agency), 
                    new XElement(ns + "ID", GenerationInstructionReference.ID), 
                    new XElement(ns + "Version", GenerationInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", GenerationInstructionReference.GetType().Name)));
            }
            if (ProcessingInstructionGroupReference != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionGroupReference", 
                    new XElement(ns + "URN", ProcessingInstructionGroupReference.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionGroupReference.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionGroupReference.ID), 
                    new XElement(ns + "Version", ProcessingInstructionGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

