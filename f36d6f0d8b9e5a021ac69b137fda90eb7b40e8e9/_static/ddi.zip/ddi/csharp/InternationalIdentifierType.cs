using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An identifier whose scope of uniqueness is broader than the local archive. Common forms of an international identifier are ISBN, ISSN, DOI or similar designator. Provides both the value of the identifier and the agency who manages it.
    /// <summary>
    public partial class InternationalIdentifierType
    {
        /// <summary>
        /// An identifier as it should be listed for identification purposes.
        /// <summary>
        public string IdentifierContent { get; set; }
        /// <summary>
        /// The identification of the Agency which assigns and manages the identifier, i.e., ISBN, ISSN, DOI, etc.
        /// <summary>
        public CodeValueType ManagingAgency { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (IdentifierContent != null)
            {
                xEl.Add(new XElement(ns + "IdentifierContent", IdentifierContent));
            }
            if (ManagingAgency != null) { xEl.Add(ManagingAgency.ToXml("ManagingAgency")); }
            return xEl;
        }
    }
}

