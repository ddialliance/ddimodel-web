using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use to specify the area of land, water, total or other area coverage in terms of square miles/kilometers or other measure.
    /// <summary>
    public partial class AreaCoverageType
    {
        /// <summary>
        /// Specify the type of area covered i.e. Total, Land, Water, etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfArea { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, Square Kilometer, Square Mile. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// The area measure expressed as a decimal for the measurement unit designated.
        /// <summary>
        public decimal AreaMeasure { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TypeOfArea != null) { xEl.Add(TypeOfArea.ToXml("TypeOfArea")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (AreaMeasure != null)
            {
                xEl.Add(new XElement(ns + "AreaMeasure", AreaMeasure));
            }
            return xEl;
        }
    }
}

