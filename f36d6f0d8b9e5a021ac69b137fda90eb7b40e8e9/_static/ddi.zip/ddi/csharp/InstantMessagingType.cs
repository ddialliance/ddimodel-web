using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Indicates type of Instant messaging account identification
    /// <summary>
    public partial class InstantMessagingType
    {
        /// <summary>
        /// Indicates Instant messaging account identification
        /// <summary>
        public string IMIdentification { get; set; }
        /// <summary>
        /// Indicates type of Instant messaging account used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfInstantMessaging { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }
        /// <summary>
        /// Set to "true" if this is the preferred address for instant messaging.
        /// <summary>
        public bool IsPreferred { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (IMIdentification != null)
            {
                xEl.Add(new XElement(ns + "IMIdentification", IMIdentification));
            }
            if (TypeOfInstantMessaging != null) { xEl.Add(TypeOfInstantMessaging.ToXml("TypeOfInstantMessaging")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            xEl.Add(new XElement(ns + "IsPreferred", IsPreferred));
            return xEl;
        }
    }
}

