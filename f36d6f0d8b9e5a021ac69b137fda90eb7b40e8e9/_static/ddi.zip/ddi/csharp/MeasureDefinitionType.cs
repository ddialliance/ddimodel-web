using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the structure and type of measure captured within the cells. This may be repeated to describe multiple measure for the cells (i.e., count, percent of universe, dimensional percent, index, text, suppression flag, etc.). Includes a reference to the defining variable and an optional aggregation definition for use in defining content relying on the use of independent and dependent variables (such as the percentage of a specific dimension (like a row or column percent on a table).
    /// <summary>
    public partial class MeasureDefinitionType : IdentifiableType
    {
        /// <summary>
        /// A reference to the variable that defines the measure of the NCube.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// Identifies the independent (denominator) and dependent (numerator) dimensions for calculating aggregate measures such as percent. When two or more independent or dependent dimensions are listed here, the value is defined as the intersection of the listed dimensions.
        /// <summary>
        public AggregationDefinitionType AggregationDefinition { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (AggregationDefinition != null) { xEl.Add(AggregationDefinition.ToXml("AggregationDefinition")); }
            return xEl;
        }
    }
}

