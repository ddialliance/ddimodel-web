using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This is archive information specific to the creation, maintenance, and archiving of the ResourcePackage provided either in-line or by reference. This packaging element differentiates this "Archive" from one being published as a product within a ResourcePackage.
    /// <summary>
    public partial class ResourcePackageArchiveType
    {
        /// <summary>
        /// Allows for in-line entry of an Archive related to the creation and maintenance of the ResourcePackage.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Archive> ArchiveReference { get; set; } = new List<Archive>();
        public bool ShouldSerializeArchiveReference() { return ArchiveReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ArchiveReference != null && ArchiveReference.Count > 0)
            {
                foreach (var item in ArchiveReference)
                {
                    xEl.Add(new XElement(ns + "ArchiveReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

