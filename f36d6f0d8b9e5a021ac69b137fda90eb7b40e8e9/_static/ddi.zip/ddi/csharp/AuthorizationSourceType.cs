using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the authorizing agency for the study and allows for the full text of the authorization (law, regulation, or other form of authorization). May be used to list authorizations from oversight committees and other regulatory agencies.
    /// <summary>
    public partial class AuthorizationSourceType
    {
        /// <summary>
        /// References the authorizing agency, organization, or individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> AuthorizingAgencyReference_Organization { get; set; } = new List<Organization>();
        public bool ShouldSerializeAuthorizingAgencyReference_Organization() { return AuthorizingAgencyReference_Organization.Count > 0; }
        /// <summary>
        /// References the authorizing agency, organization, or individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Individual> AuthorizingAgencyReference_Individual { get; set; } = new List<Individual>();
        public bool ShouldSerializeAuthorizingAgencyReference_Individual() { return AuthorizingAgencyReference_Individual.Count > 0; }
        /// <summary>
        /// Text of the authorization. May be repeated for multiple languages.
        /// <summary>
        public List<StructuredStringType> StatementOfAuthorization { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeStatementOfAuthorization() { return StatementOfAuthorization.Count > 0; }
        /// <summary>
        /// Provide a legal citation to a law authorizing the study/data collection. For example, a legal citation for a law authorizing a country's census.
        /// <summary>
        public List<string> LegalMandate { get; set; } = new List<string>();
        public bool ShouldSerializeLegalMandate() { return LegalMandate.Count > 0; }
        /// <summary>
        /// Identifies the date of Authorization.
        /// <summary>
        public CogsDate AuthorizationDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AuthorizingAgencyReference_Organization != null && AuthorizingAgencyReference_Organization.Count > 0)
            {
                foreach (var item in AuthorizingAgencyReference_Organization)
                {
                    xEl.Add(new XElement(ns + "AuthorizingAgencyReference_Organization", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (AuthorizingAgencyReference_Individual != null && AuthorizingAgencyReference_Individual.Count > 0)
            {
                foreach (var item in AuthorizingAgencyReference_Individual)
                {
                    xEl.Add(new XElement(ns + "AuthorizingAgencyReference_Individual", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (StatementOfAuthorization != null && StatementOfAuthorization.Count > 0)
            {
                foreach (var item in StatementOfAuthorization)
                {
                    xEl.Add(item.ToXml("StatementOfAuthorization"));
                }
            }
            if (LegalMandate != null && LegalMandate.Count > 0)
            {
                xEl.Add(
                    from item in LegalMandate
                    select new XElement(ns + "LegalMandate", item.ToString()));
            }
            if (AuthorizationDate != null && AuthorizationDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "AuthorizationDate", AuthorizationDate.ToString()));
            }
            return xEl;
        }
    }
}

