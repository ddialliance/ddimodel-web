using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A link to a form used by the metadata containing the form number, a statement regarding the contents of the form, a statement as to the mandatory nature of the form and a privacy level designation.
    /// <summary>
    public partial class FormType
    {
        /// <summary>
        /// The number or other means of identifying the form.
        /// <summary>
        public string FormNumber { get; set; }
        /// <summary>
        /// The URN or URL of the form.
        /// <summary>
        public Uri URI { get; set; }
        /// <summary>
        /// A statement regarding the use, coverage, and purpose of the form.
        /// <summary>
        public InternationalStringType Statement { get; set; }
        /// <summary>
        /// Set to "true" if the form is required. Set to "false" if the form is optional.
        /// <summary>
        public bool IsRequired { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (FormNumber != null)
            {
                xEl.Add(new XElement(ns + "FormNumber", FormNumber));
            }
            if (URI != null)
            {
                xEl.Add(new XElement(ns + "URI", URI));
            }
            if (Statement != null) { xEl.Add(Statement.ToXml("Statement")); }
            xEl.Add(new XElement(ns + "IsRequired", IsRequired));
            return xEl;
        }
    }
}

