using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing the Missing Values within a managed representation so that they can be reused by multiple variables and questions. Variable has a separate Missing Values location for this representation. Questions must use a StructuredMixedResponseDomain to include both standard response and Missing Value responses in a single question. In addition to the name, label, and description of the representation, the structure defines the type of the missing values, a optional generation instruction for deriving the value to be recorded, and the ability to define a blank as a missing value.
    /// <summary>
    public partial class ManagedMissingValuesRepresentation : Versionable
    {
        /// <summary>
        /// A name for the missing value. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedMissingValuesRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedMissingValuesRepresentationName() { return ManagedMissingValuesRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the managed representation. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the managed representation. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// In-line description of a CodeRepresentationBase created for the purpose of capturing missing values with associated labels.
        /// <summary>
        public CodeRepresentationBaseType MissingCodeRepresentation { get; set; }
        /// <summary>
        /// In-line description of a NumericRepresentationBase created for the purpose of capturing missing values as a set of numbers or a range.
        /// <summary>
        public NumericRepresentationBaseType MissingNumericRepresentation { get; set; }
        /// <summary>
        /// In-line description of a TextRepresentationBase created for the purpose of capturing missing values as text content.
        /// <summary>
        public TextRepresentationBaseType MissingTextRepresentation { get; set; }
        /// <summary>
        /// An optional reference to a GenerationInstruction describing how to generate the value for this representation when used as a response domain or missing value representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction ProcessingInstructionReference_GenerationInstruction { get; set; }
        /// <summary>
        /// An optional reference to a GenerationInstruction describing how to generate the value for this representation when used as a response domain or missing value representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeneralInstruction ProcessingInstructionReference_GeneralInstruction { get; set; }
        /// <summary>
        /// Designates no response (white space, null) to be treated as a missing value.
        /// <summary>
        public bool IsBlankMissingValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ManagedMissingValuesRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedMissingValuesRepresentationName != null && ManagedMissingValuesRepresentationName.Count > 0)
            {
                foreach (var item in ManagedMissingValuesRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedMissingValuesRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (MissingCodeRepresentation != null) { xEl.Add(MissingCodeRepresentation.ToXml("MissingCodeRepresentation")); }
            if (MissingNumericRepresentation != null) { xEl.Add(MissingNumericRepresentation.ToXml("MissingNumericRepresentation")); }
            if (MissingTextRepresentation != null) { xEl.Add(MissingTextRepresentation.ToXml("MissingTextRepresentation")); }
            if (ProcessingInstructionReference_GenerationInstruction != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference_GenerationInstruction", 
                    new XElement(ns + "URN", ProcessingInstructionReference_GenerationInstruction.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference_GenerationInstruction.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference_GenerationInstruction.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference_GenerationInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference_GenerationInstruction.GetType().Name)));
            }
            if (ProcessingInstructionReference_GeneralInstruction != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference_GeneralInstruction", 
                    new XElement(ns + "URN", ProcessingInstructionReference_GeneralInstruction.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference_GeneralInstruction.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference_GeneralInstruction.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference_GeneralInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference_GeneralInstruction.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsBlankMissingValue", IsBlankMissingValue));
            return xEl;
        }
    }
}

