using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Holds the name of the creator and/or a reference to the creator as described within a DDI Organization scheme. Repeat this element for multiple creators.
    /// <summary>
    public partial class CreatorType
    {
        /// <summary>
        /// Full name of the creator and affiliation. Language equivalents should be expressed within the International String structure.
        /// <summary>
        public BibliographicNameType CreatorName { get; set; }
        /// <summary>
        /// Reference to a creator as described within a DDI Organization Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual CreatorReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CreatorName != null) { xEl.Add(CreatorName.ToXml("CreatorName")); }
            if (CreatorReference != null)
            {
                xEl.Add(new XElement(ns + "CreatorReference", 
                    new XElement(ns + "URN", CreatorReference.URN), 
                    new XElement(ns + "Agency", CreatorReference.Agency), 
                    new XElement(ns + "ID", CreatorReference.ID), 
                    new XElement(ns + "Version", CreatorReference.Version), 
                    new XElement(ns + "TypeOfObject", CreatorReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

