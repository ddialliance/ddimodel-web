using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A reference to a General or Generation Instruction that was used by the parent object, e.g. an instruction used to derive a Variable or used by a ProcessingEvent. The basic Reference structure is extended to allow for the use of Binding to link specific source parameters to the InParameter of the instruction at the point of use. If there is a conflict between a Binding in the iinstruction of a specific source to an InParameter and the Binding information provided in the ProcessingInstructionReference, the Binding information in the reference overrides that found in the instruction. TypeOfObject should be set to ProcessingInstruction.
    /// <summary>
    public partial class ProcessingInstructionReferenceType : ReferenceType
    {
        /// <summary>
        /// A structure used to link the content of a parameter declared as the source to a parameter declared as the target. For example, linking the output of a question to the input of a generation instruction. Question A has an OutParameter X. Generation Instruction has an InParameter Y used in the recode instruction. Binding defines the content of InParameter Y to be whatever is provided by OutParameter X for use in the calculation of the recode.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            return xEl;
        }
    }
}

