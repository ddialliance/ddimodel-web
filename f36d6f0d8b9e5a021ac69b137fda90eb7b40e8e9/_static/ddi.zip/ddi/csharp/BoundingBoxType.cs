using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Set of north, south, east, west coordinates defining a rectangle that encompasses the full extent of geographic coverage.
    /// <summary>
    public partial class BoundingBoxType
    {
        /// <summary>
        /// West longitude of the bounding box. (xmin)
        /// <summary>
        [Range(-180, )]
        public decimal WestLongitude { get; set; }
        /// <summary>
        /// East longitude of the bounding box. (xmax)
        /// <summary>
        [Range(-180, )]
        public decimal EastLongitude { get; set; }
        /// <summary>
        /// South latitude of the bounding box. (ymin)
        /// <summary>
        [Range(-90, )]
        public decimal SouthLatitude { get; set; }
        /// <summary>
        /// North latitude of the bounding box. (ymax)
        /// <summary>
        [Range(-90, )]
        public decimal NorthLatitude { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (WestLongitude != null)
            {
                xEl.Add(new XElement(ns + "WestLongitude", WestLongitude));
            }
            if (EastLongitude != null)
            {
                xEl.Add(new XElement(ns + "EastLongitude", EastLongitude));
            }
            if (SouthLatitude != null)
            {
                xEl.Add(new XElement(ns + "SouthLatitude", SouthLatitude));
            }
            if (NorthLatitude != null)
            {
                xEl.Add(new XElement(ns + "NorthLatitude", NorthLatitude));
            }
            return xEl;
        }
    }
}

