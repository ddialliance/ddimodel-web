using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Storage format arranged variable by variable. Item values are listed in record order with the assumption that each record will occupy the position in each array.
    /// <summary>
    public partial class VariableSetType
    {
        /// <summary>
        /// The set of values associated with a single variable (one for each record in storage order of records).
        /// <summary>
        public List<VariableItemType> VariableItem { get; set; } = new List<VariableItemType>();
        public bool ShouldSerializeVariableItem() { return VariableItem.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (VariableItem != null && VariableItem.Count > 0)
            {
                foreach (var item in VariableItem)
                {
                    xEl.Add(item.ToXml("VariableItem"));
                }
            }
            return xEl;
        }
    }
}

