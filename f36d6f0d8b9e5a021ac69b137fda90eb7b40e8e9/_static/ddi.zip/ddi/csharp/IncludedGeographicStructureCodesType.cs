using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specifies the Geographic Structure Codes included in the representation by providing a reference to the authorized source of the code, the GeographicStructure used, and any excluded levels.
    /// <summary>
    public partial class IncludedGeographicStructureCodesType
    {
        /// <summary>
        /// A reference to the Authorized Source of the value used by this representation. A GeographicStructure may have more than one Authorized Source included in the listing.
        /// <summary>
        public AuthorizedSourceType AuthorizedSourceReference { get; set; }
        /// <summary>
        /// A reference to the GeographicStructure used by this representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicStructure GeographicStructureReference { get; set; }
        /// <summary>
        /// A reference to a Structure Level that is excluded, not used by, this representation. May be repeated to exclude multiple Structure values.
        /// <summary>
        public List<GeographicLevelType> ExcludedGeographicLevelReference { get; set; } = new List<GeographicLevelType>();
        public bool ShouldSerializeExcludedGeographicLevelReference() { return ExcludedGeographicLevelReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AuthorizedSourceReference != null) { xEl.Add(AuthorizedSourceReference.ToXml("AuthorizedSourceReference")); }
            if (GeographicStructureReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicStructureReference", 
                    new XElement(ns + "URN", GeographicStructureReference.URN), 
                    new XElement(ns + "Agency", GeographicStructureReference.Agency), 
                    new XElement(ns + "ID", GeographicStructureReference.ID), 
                    new XElement(ns + "Version", GeographicStructureReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicStructureReference.GetType().Name)));
            }
            if (ExcludedGeographicLevelReference != null && ExcludedGeographicLevelReference.Count > 0)
            {
                foreach (var item in ExcludedGeographicLevelReference)
                {
                    xEl.Add(item.ToXml("ExcludedGeographicLevelReference"));
                }
            }
            return xEl;
        }
    }
}

