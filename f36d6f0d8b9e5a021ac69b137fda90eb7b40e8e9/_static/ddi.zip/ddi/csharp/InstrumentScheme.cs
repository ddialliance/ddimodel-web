using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a set of instruments maintained by an agency. In addition to the standard name, label, and description, allows for the inclusion of an existing InstrumentScheme by reference and contains Instruments and InstrumentGroups inline an by reference.
    /// <summary>
    public partial class InstrumentScheme : Maintainable
    {
        /// <summary>
        /// A name for the InstrumentScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> InstrumentSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeInstrumentSchemeName() { return InstrumentSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the InstrumentScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the InstrumentScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for inclusion by reference of another Instrument Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InstrumentScheme> InstrumentSchemeReference { get; set; } = new List<InstrumentScheme>();
        public bool ShouldSerializeInstrumentSchemeReference() { return InstrumentSchemeReference.Count > 0; }
        /// <summary>
        /// Describes an instrument within this instrument scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Instrument> InstrumentReference { get; set; } = new List<Instrument>();
        public bool ShouldSerializeInstrumentReference() { return InstrumentReference.Count > 0; }
        /// <summary>
        /// Describes a group of instruments as in instrument group within an instrument scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InstrumentGroup> InstrumentGroupReference { get; set; } = new List<InstrumentGroup>();
        public bool ShouldSerializeInstrumentGroupReference() { return InstrumentGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "InstrumentScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (InstrumentSchemeName != null && InstrumentSchemeName.Count > 0)
            {
                foreach (var item in InstrumentSchemeName)
                {
                    xEl.Add(item.ToXml("InstrumentSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InstrumentSchemeReference != null && InstrumentSchemeReference.Count > 0)
            {
                foreach (var item in InstrumentSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstrumentReference != null && InstrumentReference.Count > 0)
            {
                foreach (var item in InstrumentReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstrumentGroupReference != null && InstrumentGroupReference.Count > 0)
            {
                foreach (var item in InstrumentGroupReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

