using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Metadata regarding the methodologies used concerning data collection, determining the timing and repetition patterns for data collection, and sampling procedures. Identifies areas where there were deviations from the planned sampling approach, the software used for data collection, and references to any quality standards or statements regarding the processes surrounding the planning and implementation of data collection.
    /// <summary>
    public partial class Methodology : Versionable
    {
        /// <summary>
        /// A basic structure for describing the methodology used for collecting data. Repeat this element if multiple methodologies are used.
        /// <summary>
        public List<DataCollectionMethodologyType> DataCollectionMethodology { get; set; } = new List<DataCollectionMethodologyType>();
        public bool ShouldSerializeDataCollectionMethodology() { return DataCollectionMethodology.Count > 0; }
        /// <summary>
        /// Describes how time fits into the data collection methodology.
        /// <summary>
        public List<TimeMethodType> TimeMethod { get; set; } = new List<TimeMethodType>();
        public bool ShouldSerializeTimeMethod() { return TimeMethod.Count > 0; }
        /// <summary>
        /// Describes the type of sample, sample design and provides details on drawing the sample. May be repeated to provide descriptions of individual facets of a single sample design or when multiple sampling methods are used. When multiple descriptions are used, the use of a controlled vocabulary to identify the parts and relationships is strongly recommended.
        /// <summary>
        public List<SamplingProcedureType> SamplingProcedure { get; set; } = new List<SamplingProcedureType>();
        public bool ShouldSerializeSamplingProcedure() { return SamplingProcedure.Count > 0; }
        /// <summary>
        /// Describes any deviations from the planned sample design.
        /// <summary>
        public List<DeviationFromSampleDesignType> DeviationFromSampleDesign { get; set; } = new List<DeviationFromSampleDesignType>();
        public bool ShouldSerializeDeviationFromSampleDesign() { return DeviationFromSampleDesign.Count > 0; }
        /// <summary>
        /// Specification of a software package used to instantiate a data collection method.
        /// <summary>
        public List<SoftwareType> DataCollectionSoftware { get; set; } = new List<SoftwareType>();
        public bool ShouldSerializeDataCollectionSoftware() { return DataCollectionSoftware.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the study methodology, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Methodology");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DataCollectionMethodology != null && DataCollectionMethodology.Count > 0)
            {
                foreach (var item in DataCollectionMethodology)
                {
                    xEl.Add(item.ToXml("DataCollectionMethodology"));
                }
            }
            if (TimeMethod != null && TimeMethod.Count > 0)
            {
                foreach (var item in TimeMethod)
                {
                    xEl.Add(item.ToXml("TimeMethod"));
                }
            }
            if (SamplingProcedure != null && SamplingProcedure.Count > 0)
            {
                foreach (var item in SamplingProcedure)
                {
                    xEl.Add(item.ToXml("SamplingProcedure"));
                }
            }
            if (DeviationFromSampleDesign != null && DeviationFromSampleDesign.Count > 0)
            {
                foreach (var item in DeviationFromSampleDesign)
                {
                    xEl.Add(item.ToXml("DeviationFromSampleDesign"));
                }
            }
            if (DataCollectionSoftware != null && DataCollectionSoftware.Count > 0)
            {
                foreach (var item in DataCollectionSoftware)
                {
                    xEl.Add(item.ToXml("DataCollectionSoftware"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

