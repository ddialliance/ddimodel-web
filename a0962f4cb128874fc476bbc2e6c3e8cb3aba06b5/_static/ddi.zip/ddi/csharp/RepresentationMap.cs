using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Maps between any two managed representations. In addition to representation types held in a ManagagedRepresentationScheme, managed representations include CategoryScheme and coded representations which include CodeList, GeographicStructureCode or GeographicLocationCode. Note that the source can be any managed representation including a CodeList, GeographicStructure or GeographicLocation. Note that comparisons between two category schemes is best handled by CategoryMap. In addition to the standard name, label, and description of the RepresentationMap, identifies the source representation and target representation (which should be a CodeList, GeographicStructure, or GeographicLocation), describes the correspondence between the source and target, allows for the use of a GenerationInstruction to describe the recoding process, and indicates if this a general mapping or a mapping for a specific purpose.
    /// <summary>
    public partial class RepresentationMap : Versionable
    {
        /// <summary>
        /// A name for the RepresentationMap. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RepresentationMapName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRepresentationMapName() { return RepresentationMapName.Count > 0; }
        /// <summary>
        /// A display label for the RepresentationMap. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the RepresentationMap. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides a reference to the managed content of a representation which acts as the source object in the Source/Target comparison pair. May be a ManagedRepresentation or a specific CategoryScheme, CodeList, GeographicRepresentation, or GeographicLocation. Allows for the optional reference to a Concept when context is important. For example, a ManagedNumericRepresentation within the context of Age.
        /// <summary>
        public SourceRepresentationType SourceRepresentation { get; set; }
        /// <summary>
        /// Provides a reference to the managed content of a representation which acts as the target object in the Source/Target comparison pair. May be a ManagedRepresentation or a specific CategoryScheme, CodeList, GeographicRepresentation, or GeographicLocation. Supports the ability to limit code coverage as appropriate for the coding structure referenced.
        /// <summary>
        public TargetRepresentationType TargetRepresentation { get; set; }
        /// <summary>
        /// Describe the level of similarity and difference between the Source and the Target contents.
        /// <summary>
        public CorrespondenceType Correspondence { get; set; }
        /// <summary>
        /// Allows for use of programmatic logic to construct a detailed comparison map between individual codes in the source and target structures by reference. TypeOfObject should be set to GenerationInstruction or GeneralInstruction. This reference allows for specifying ParameterLinkages at point of use.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeneralInstruction ProcessingInstructionReference_GeneralInstruction { get; set; }
        /// <summary>
        /// Allows for use of programmatic logic to construct a detailed comparison map between individual codes in the source and target structures by reference. TypeOfObject should be set to GenerationInstruction or GeneralInstruction. This reference allows for specifying ParameterLinkages at point of use.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction ProcessingInstructionReference_GenerationInstruction { get; set; }
        /// <summary>
        /// Set to "true" when a Concept has been identified in the SourceRepresentation.
        /// <summary>
        public bool ContextSpecificComparison { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "RepresentationMap");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RepresentationMapName != null && RepresentationMapName.Count > 0)
            {
                foreach (var item in RepresentationMapName)
                {
                    xEl.Add(item.ToXml("RepresentationMapName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SourceRepresentation != null) { xEl.Add(SourceRepresentation.ToXml("SourceRepresentation")); }
            if (TargetRepresentation != null) { xEl.Add(TargetRepresentation.ToXml("TargetRepresentation")); }
            if (Correspondence != null) { xEl.Add(Correspondence.ToXml("Correspondence")); }
            if (ProcessingInstructionReference_GeneralInstruction != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference_GeneralInstruction", 
                    new XElement(ns + "URN", ProcessingInstructionReference_GeneralInstruction.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference_GeneralInstruction.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference_GeneralInstruction.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference_GeneralInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference_GeneralInstruction.GetType().Name)));
            }
            if (ProcessingInstructionReference_GenerationInstruction != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference_GenerationInstruction", 
                    new XElement(ns + "URN", ProcessingInstructionReference_GenerationInstruction.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference_GenerationInstruction.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference_GenerationInstruction.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference_GenerationInstruction.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference_GenerationInstruction.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "ContextSpecificComparison", ContextSpecificComparison));
            return xEl;
        }
    }
}

