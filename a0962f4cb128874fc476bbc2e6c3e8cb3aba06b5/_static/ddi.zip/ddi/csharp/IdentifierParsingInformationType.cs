using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides structural information for parsing the identification code structure of the Authorized Source into its separate parts.
    /// <summary>
    public partial class IdentifierParsingInformationType
    {
        /// <summary>
        /// Identifies the parent portions of the code string as individual segments. Repeat for each parental segment.
        /// <summary>
        public List<IdentificationPortionType> ParentIdentificationPortion { get; set; } = new List<IdentificationPortionType>();
        public bool ShouldSerializeParentIdentificationPortion() { return ParentIdentificationPortion.Count > 0; }
        /// <summary>
        /// Identifies the unique portion of the code string as a segment.
        /// <summary>
        public IdentificationPortionType UniqueIdentificationPortion { get; set; }
        /// <summary>
        /// The array base is the value of the designation for the first item in an array and is set to either 0 or 1. Unix based systems and most current programming systems use an array base of 0. Traditional codebooks normally set the array base at 1, for example the first data item in a fixed format ASCII file record begins at character 1.
        /// <summary>
        [StringValidation(new string[] {
            "0"
,             "1"
        })]
        public string ArrayBase_string { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ParentIdentificationPortion != null && ParentIdentificationPortion.Count > 0)
            {
                foreach (var item in ParentIdentificationPortion)
                {
                    xEl.Add(item.ToXml("ParentIdentificationPortion"));
                }
            }
            if (UniqueIdentificationPortion != null) { xEl.Add(UniqueIdentificationPortion.ToXml("UniqueIdentificationPortion")); }
            if (ArrayBase_string != null)
            {
                xEl.Add(new XElement(ns + "ArrayBase_string", ArrayBase_string));
            }
            return xEl;
        }
    }
}

