using System;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace ddi
{
    /// <summary>
    /// IIdentifiable class which all object Inherit from. Used to Serialize to Json
    /// <summary>
    public partial interface IIdentifiable
    {
        string URN { get; set; }
        string Agency { get; set; }
        string ID { get; set; }
        string Version { get; set; }
    }
}
