using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the relationships among logical records in the dataset. Date Relationship is needed to create the appropriate link between the logical record and the physical storage description. Data Relationship is optional because a logical product can contain only a category scheme and/or code scheme. In addition to the standard name, label, and description, it contains structures to describe the LogicalRecord and RecordRelationship.
    /// <summary>
    public partial class DataRelationship : Versionable
    {
        /// <summary>
        /// A name for the DataRelationship. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DataRelationshipName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDataRelationshipName() { return DataRelationshipName.Count > 0; }
        /// <summary>
        /// A display label for the DataRelationship. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the DataRelationship. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A logical record is a description of all of the elements (variables or NCubes) related to a single case or analysis unit. Required to link a description of a physical record structure to its logical record.
        /// <summary>
        public List<LogicalRecordType> LogicalRecord { get; set; } = new List<LogicalRecordType>();
        public bool ShouldSerializeLogicalRecord() { return LogicalRecord.Count > 0; }
        /// <summary>
        /// Describes the relationship between records of different types or of the same type within a longitudinal study. Identifies the key and linking value relationships. All relationships are pairwise. Multiple pairwise relationships maybe needed to clarify all record relationships within a logical product or data set.
        /// <summary>
        public List<RecordRelationshipType> RecordRelationship { get; set; } = new List<RecordRelationshipType>();
        public bool ShouldSerializeRecordRelationship() { return RecordRelationship.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DataRelationship");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DataRelationshipName != null && DataRelationshipName.Count > 0)
            {
                foreach (var item in DataRelationshipName)
                {
                    xEl.Add(item.ToXml("DataRelationshipName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (LogicalRecord != null && LogicalRecord.Count > 0)
            {
                foreach (var item in LogicalRecord)
                {
                    xEl.Add(item.ToXml("LogicalRecord"));
                }
            }
            if (RecordRelationship != null && RecordRelationship.Count > 0)
            {
                foreach (var item in RecordRelationship)
                {
                    xEl.Add(item.ToXml("RecordRelationship"));
                }
            }
            return xEl;
        }
    }
}

