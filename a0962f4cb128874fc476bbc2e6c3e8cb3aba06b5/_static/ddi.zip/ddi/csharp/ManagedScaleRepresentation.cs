using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A means of capturing a managed representation of a Scale for use by a Response Domain Reference or Value Representation Reference. In addition to the name, label, and description of the representation, the structure defines the dimensions of the scale, an intersect for a multi-dimensional scale, and display layout.
    /// <summary>
    public partial class ManagedScaleRepresentation : Versionable
    {
        /// <summary>
        /// A name for the ManagedScaleRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedScaleRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedScaleRepresentationName() { return ManagedScaleRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the representation. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the representation. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// A description of a dimension of the scale. Note that most scales will have only one dimension.
        /// <summary>
        public List<ScaleDimensionType> ScaleDimension { get; set; } = new List<ScaleDimensionType>();
        public bool ShouldSerializeScaleDimension() { return ScaleDimension.Count > 0; }
        /// <summary>
        /// Identifies the point at which the scales of a multidimensional scale intersect.
        /// <summary>
        public List<DimensionIntersectType> DimensionIntersect { get; set; } = new List<DimensionIntersectType>();
        public bool ShouldSerializeDimensionIntersect() { return DimensionIntersect.Count > 0; }
        /// <summary>
        /// Defines they layout such as containing a drawn scale line, a list of values only, an outline (the boundaries of the area defined by 2 or more intersecting scales such as a diamond of opposites), or some other layout design. Allows for the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType DisplayLayout { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedScaleRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedScaleRepresentationName != null && ManagedScaleRepresentationName.Count > 0)
            {
                foreach (var item in ManagedScaleRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedScaleRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (ScaleDimension != null && ScaleDimension.Count > 0)
            {
                foreach (var item in ScaleDimension)
                {
                    xEl.Add(item.ToXml("ScaleDimension"));
                }
            }
            if (DimensionIntersect != null && DimensionIntersect.Count > 0)
            {
                foreach (var item in DimensionIntersect)
                {
                    xEl.Add(item.ToXml("DimensionIntersect"));
                }
            }
            if (DisplayLayout != null) { xEl.Add(DisplayLayout.ToXml("DisplayLayout")); }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

