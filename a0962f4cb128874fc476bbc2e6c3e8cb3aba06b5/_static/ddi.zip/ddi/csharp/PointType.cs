using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A geographic point consisting of an X and Y coordinate. Each coordinate value is expressed separately providing its value and format.
    /// <summary>
    public partial class PointType
    {
        /// <summary>
        /// An X coordinate (latitudinal equivalent) value and format expressed using the Spatial Coordinate structure.
        /// <summary>
        public SpatialCoordinateType XCoordinate { get; set; }
        /// <summary>
        /// A Y coordinate (longitudinal equivalent) value and format expressed using the Spatial Coordinate structure.
        /// <summary>
        public SpatialCoordinateType YCoordinate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (XCoordinate != null) { xEl.Add(XCoordinate.ToXml("XCoordinate")); }
            if (YCoordinate != null) { xEl.Add(YCoordinate.ToXml("YCoordinate")); }
            return xEl;
        }
    }
}

