using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of control constructs maintained by an agency and used in the instrument or computational instruction. ControlConstructs describe the ordering and flow of questions within an instrument or information through a process. In addition to the standard name, label and description can include an existing ControlConstructScheme by reference and describe individual Control Constructs of varying types.
    /// <summary>
    public partial class ControlConstructScheme : Maintainable
    {
        /// <summary>
        /// A name for the ControlConstructScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ControlConstructSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeControlConstructSchemeName() { return ControlConstructSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the ControlConstructScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ControlConstructScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides for inclusion by reference of external Control Construct Schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstructScheme> ControlConstructSchemeReference { get; set; } = new List<ControlConstructScheme>();
        public bool ShouldSerializeControlConstructSchemeReference() { return ControlConstructSchemeReference.Count > 0; }
        /// <summary>
        /// Extensible structure for control elements used in describing flow logic within the instrument.: IfThenElse, RepeatUntil, RepeatWhile, Loop, Sequence, ComputationItem, StatementItem, and QuestionConstruct.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of ControlConstructs.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstructGroup> ControlConstructGroupReference { get; set; } = new List<ControlConstructGroup>();
        public bool ShouldSerializeControlConstructGroupReference() { return ControlConstructGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ControlConstructScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ControlConstructSchemeName != null && ControlConstructSchemeName.Count > 0)
            {
                foreach (var item in ControlConstructSchemeName)
                {
                    xEl.Add(item.ToXml("ControlConstructSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ControlConstructSchemeReference != null && ControlConstructSchemeReference.Count > 0)
            {
                foreach (var item in ControlConstructSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ControlConstructGroupReference != null && ControlConstructGroupReference.Count > 0)
            {
                foreach (var item in ControlConstructGroupReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

