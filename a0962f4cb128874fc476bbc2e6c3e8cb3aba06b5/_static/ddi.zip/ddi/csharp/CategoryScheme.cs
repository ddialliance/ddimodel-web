using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A scheme containing a set of Categories managed by an agency. These are used to manage category definitions used as a domain for data element and basic content for a category representations. In addition to the name, label, and description of the scheme, the structure supports the inclusion of another CategoryScheme by reference, a set of Category descriptions either in-line or by reference, and the description of a CategoryGroup either in-line or by reference.
    /// <summary>
    public partial class CategoryScheme : Maintainable
    {
        /// <summary>
        /// A name for the scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> CategorySchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeCategorySchemeName() { return CategorySchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the scheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for inclusion by reference of other category schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CategoryScheme> CategorySchemeReference { get; set; } = new List<CategoryScheme>();
        public bool ShouldSerializeCategorySchemeReference() { return CategorySchemeReference.Count > 0; }
        /// <summary>
        /// A description of a particular category or response. OECD Glossary of Statistical Terms: Generic term for items at any level within a classification, typically tabulation categories, sections, subsections, divisions, subdivisions, groups, subgroups, classes and subclasses.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Category> CategoryReference { get; set; } = new List<Category>();
        public bool ShouldSerializeCategoryReference() { return CategoryReference.Count > 0; }
        /// <summary>
        /// Allows categories to be grouped with or without hierarchical structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CategoryGroup> CategoryGroupReference { get; set; } = new List<CategoryGroup>();
        public bool ShouldSerializeCategoryGroupReference() { return CategoryGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "CategoryScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CategorySchemeName != null && CategorySchemeName.Count > 0)
            {
                foreach (var item in CategorySchemeName)
                {
                    xEl.Add(item.ToXml("CategorySchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CategorySchemeReference != null && CategorySchemeReference.Count > 0)
            {
                foreach (var item in CategorySchemeReference)
                {
                    xEl.Add(new XElement(ns + "CategorySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CategoryReference != null && CategoryReference.Count > 0)
            {
                foreach (var item in CategoryReference)
                {
                    xEl.Add(new XElement(ns + "CategoryReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CategoryGroupReference != null && CategoryGroupReference.Count > 0)
            {
                foreach (var item in CategoryGroupReference)
                {
                    xEl.Add(new XElement(ns + "CategoryGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

