using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Adds the attribute identifying this as an identifiable object as well as the MaintainableObject. All identifiable objects should provide their contextual information, the identity of their maintainable parent. The deprecated form of the URN contains all the information to identify and object and its context. A Canonical URN scoped to the Maintainable contains the ID of the Maintainable as part of its structure. To provide full contextual information use the MaintainableObject structure. The use of the Canonical URN scoped to the agency or the identification sequence alone requires the content of the MaintainableObject to provide full contextual information. All content of Identifiable is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. See DDI 3.2 Technical Documentation: Part I for further details.
    /// <summary>
    public partial class IdentifiableType : AbstractIdentifiableType
    {
        /// <summary>
        /// This section provides information on the Maintainable Parent of this object at its point of origination. This content will not change over time unless the version of the object changes. Note that if the ID, Agency, Version sequence is used, and the scope of uniqueness of the referenced object is the Maintainable, then the ID of the Maintainable is needed to create the structured ID portion of the canonical URN. If the system uses the deprecated URN, both the Maintainable ID and TypeOfMaintainableObject are required to create the deprecated URN structure.
        /// <summary>
        public MaintainableObjectType MaintainableObject { get; set; }
        /// <summary>
        /// This is a fixed flag informing the system or user that this element is identifiable and may be referenced.
        /// <summary>
        public bool IsIdentifiable { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("AbstractIdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (MaintainableObject != null) { xEl.Add(MaintainableObject.ToXml("MaintainableObject")); }
            xEl.Add(new XElement(ns + "IsIdentifiable", IsIdentifiable));
            return xEl;
        }
    }
}

