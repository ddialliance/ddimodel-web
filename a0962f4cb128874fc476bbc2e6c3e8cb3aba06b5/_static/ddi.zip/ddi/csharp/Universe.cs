using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a universe which may also be known as a population. A Universe describes the "object" of a Data Element Concept or Data Element as defined by ISO/IEC 11179. A universe may be organized into hierarchical sub-universes. In addition to the standard name, label, and description, the universe may provide a generation code (how the universe is differentiated or split out from another universe), a definition of hierarchical sub-settings for the universe, and an attribute that indicates if the description of the universe is stated in terms of what the universe includes.
    /// <summary>
    public partial class Universe : Versionable
    {
        /// <summary>
        /// A name for the Universe. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> UniverseName { get; set; } = new List<NameType>();
        public bool ShouldSerializeUniverseName() { return UniverseName.Count > 0; }
        /// <summary>
        /// A display label for the Universe. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Universe. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A concept that defines or aids in understanding the content of the universe. For example the Universe "Males" may link to the concept of "Male".
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept DefiningConceptReference { get; set; }
        /// <summary>
        /// An expression of the universe in terms of the code used to generate or define it. For example how a given universe may be differentiated within a parent universe.
        /// <summary>
        public List<CommandCodeType> UniverseGenerationCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeUniverseGenerationCode() { return UniverseGenerationCode.Count > 0; }
        /// <summary>
        /// A sub-universe class provides a definition to the universes contained within it. For example the Sub-Universe Class of Gender for the Universe Resident Population may contain the Universe Males and the Universe Females
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SubUniverseClass> SubUniverseClassReference { get; set; } = new List<SubUniverseClass>();
        public bool ShouldSerializeSubUniverseClassReference() { return SubUniverseClassReference.Count > 0; }
        /// <summary>
        /// The default value is "true". The description statement of a universe is generally stated in inclusive terms such as "All persons residing in Europe". Occasionally a universe is defined by what it excludes, i.e., "All persons residing in Europe except for those residing on U.S. Military bases". In this case the value would be changed to "false".
        /// <summary>
        public bool IsInclusive { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Universe");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UniverseName != null && UniverseName.Count > 0)
            {
                foreach (var item in UniverseName)
                {
                    xEl.Add(item.ToXml("UniverseName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DefiningConceptReference != null)
            {
                xEl.Add(new XElement(ns + "DefiningConceptReference", 
                    new XElement(ns + "URN", DefiningConceptReference.URN), 
                    new XElement(ns + "Agency", DefiningConceptReference.Agency), 
                    new XElement(ns + "ID", DefiningConceptReference.ID), 
                    new XElement(ns + "Version", DefiningConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", DefiningConceptReference.GetType().Name)));
            }
            if (UniverseGenerationCode != null && UniverseGenerationCode.Count > 0)
            {
                foreach (var item in UniverseGenerationCode)
                {
                    xEl.Add(item.ToXml("UniverseGenerationCode"));
                }
            }
            if (SubUniverseClassReference != null && SubUniverseClassReference.Count > 0)
            {
                foreach (var item in SubUniverseClassReference)
                {
                    xEl.Add(new XElement(ns + "SubUniverseClassReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "IsInclusive", IsInclusive));
            return xEl;
        }
    }
}

