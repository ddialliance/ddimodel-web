using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Designates the response domain and the cells using the specified response domain within a QuestionGrid.
    /// <summary>
    public partial class GridResponseDomainType
    {
        /// <summary>
        /// This is a substitution head and can be replaced by any valid member of the substitution group for ResponseDomain.
        /// <summary>
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ResponseDomainReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ResponseDomainReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ResponseDomainReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ResponseDomainReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ResponseDomainReference_ManagedTextRepresentation { get; set; }
        /// <summary>
        /// Identifies the cell or cells in a grid to which the item is attached by a reference to a specific cell coordinate in a grid or by identifying a range of values along a dimension.
        /// <summary>
        public List<GridAttachmentType> GridAttachment { get; set; } = new List<GridAttachmentType>();
        public bool ShouldSerializeGridAttachment() { return GridAttachment.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ResponseDomainReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ResponseDomainReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ResponseDomainReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference_ManagedTextRepresentation.GetType().Name)));
            }
            if (GridAttachment != null && GridAttachment.Count > 0)
            {
                foreach (var item in GridAttachment)
                {
                    xEl.Add(item.ToXml("GridAttachment"));
                }
            }
            return xEl;
        }
    }
}

