using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A description of the budget for any of the main publication types that can contain a reference to an external budget document.
    /// <summary>
    public partial class BudgetType
    {
        /// <summary>
        /// A description of the overall budget of the project. Supports structured content including tables.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// References to one or more external budget documents.
        /// <summary>
        public List<OtherMaterialType> BudgetDocument { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeBudgetDocument() { return BudgetDocument.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (BudgetDocument != null && BudgetDocument.Count > 0)
            {
                foreach (var item in BudgetDocument)
                {
                    xEl.Add(item.ToXml("BudgetDocument"));
                }
            }
            return xEl;
        }
    }
}

