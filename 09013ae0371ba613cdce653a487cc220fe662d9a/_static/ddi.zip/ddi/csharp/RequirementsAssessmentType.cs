using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of whether specific requirements for the activities providing these results were met.
    /// <summary>
    public partial class RequirementsAssessmentType
    {
        /// <summary>
        /// Identifies the type of requirement being assessed such as staffing, funding, source materials, etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public string TypeOfRequirementsAssessment { get; set; }
        /// <summary>
        /// A description of the Requirements Assessment. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A boolean statement of whether the requirement was satisfied or not. A value of "true" indicates that the minimum requirement was satisfied. Note any specific information in the Description.
        /// <summary>
        public bool IsSatisfied { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfRequirementsAssessment != null)
            {
                xEl.Add(new XElement(ns + "TypeOfRequirementsAssessment", TypeOfRequirementsAssessment));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            xEl.Add(new XElement(ns + "IsSatisfied", IsSatisfied));
            return xEl;
        }
    }
}

