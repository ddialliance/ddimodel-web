using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Value of variable indicating this record type, multiple entries allow for multiple valid values or ranges. Includes a reference to the variable an the specified related value. TypeOfObject should be set to Variabele.
    /// <summary>
    public partial class ConditionalVariableReferenceType : ReferenceType
    {
        /// <summary>
        /// Use to specify the value of variable for which this is a case specification (i.e., GeoLevel in the example for Case Specification).
        /// <summary>
        public RelatedValueType RelatedValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (RelatedValue != null) { xEl.Add(RelatedValue.ToXml("RelatedValue")); }
            return xEl;
        }
    }
}

