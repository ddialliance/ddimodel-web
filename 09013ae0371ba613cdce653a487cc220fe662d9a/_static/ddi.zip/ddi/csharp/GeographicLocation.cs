using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes specific instances of GeographicLocations associated with a specified GeographicLevel in a GeographicStructure. In addition to the standard name, level, and description, specifies the Geographic Level either by reference to an existing description in a GeographicStructure or by a textual description, identifies the authorization source for naming and coding identification a set of individual LocationValues.
    /// <summary>
    public partial class GeographicLocation : Versionable
    {
        /// <summary>
        /// A name for the GeographicLocation. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> GeographicLocationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeGeographicLocationName() { return GeographicLocationName.Count > 0; }
        /// <summary>
        /// A display label for the GeographicLocation. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the GeographicLocation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing GeographicLevel describing structural level to which these locations belong.
        /// <summary>
        public GeographicLevelType GeographicLevelReference { get; set; }
        /// <summary>
        /// A description of the GeographicLevel. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType GeographicLevelDescription { get; set; }
        /// <summary>
        /// An identifiable authorization source repeated for each identifying code type. This allows the codes to be used as representations for response domains and value representations by designating a specific set of locations and the code of an authorization source. An authorization source should differentiate between codes derived for different purposes within the same agency.
        /// <summary>
        public List<AuthorizedSourceType> AuthorizedSource { get; set; } = new List<AuthorizedSourceType>();
        public bool ShouldSerializeAuthorizedSource() { return AuthorizedSource.Count > 0; }
        /// <summary>
        /// A location of the specified geographic level providing information on its name, identification codes, temporal and spatial coverage.
        /// <summary>
        public List<LocationValueType> LocationValue { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializeLocationValue() { return LocationValue.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "GeographicLocation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (GeographicLocationName != null && GeographicLocationName.Count > 0)
            {
                foreach (var item in GeographicLocationName)
                {
                    xEl.Add(item.ToXml("GeographicLocationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GeographicLevelReference != null) { xEl.Add(GeographicLevelReference.ToXml("GeographicLevelReference")); }
            if (GeographicLevelDescription != null) { xEl.Add(GeographicLevelDescription.ToXml("GeographicLevelDescription")); }
            if (AuthorizedSource != null && AuthorizedSource.Count > 0)
            {
                foreach (var item in AuthorizedSource)
                {
                    xEl.Add(item.ToXml("AuthorizedSource"));
                }
            }
            if (LocationValue != null && LocationValue.Count > 0)
            {
                foreach (var item in LocationValue)
                {
                    xEl.Add(item.ToXml("LocationValue"));
                }
            }
            return xEl;
        }
    }
}

