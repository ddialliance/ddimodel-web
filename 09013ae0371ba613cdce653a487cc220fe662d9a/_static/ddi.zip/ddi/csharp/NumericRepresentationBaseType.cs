using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the representation for a numeric response. May be a range or specific value, or a list of ranges.
    /// <summary>
    public partial class NumericRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// Defines the valid number range or number values for the representation.
        /// <summary>
        public List<NumberRangeType> NumberRange { get; set; } = new List<NumberRangeType>();
        public bool ShouldSerializeNumberRange() { return NumberRange.Count > 0; }
        /// <summary>
        /// Identification of the numeric type such as integer, decimal, etc. supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType NumericTypeCode { get; set; }
        /// <summary>
        /// A format for number expressed as a string.
        /// <summary>
        public string Format { get; set; }
        /// <summary>
        /// The scale of the number expressed as an integer (for example a number expressed in 100's, 5 = 500 would have a scale of 100).
        /// <summary>
        public int Scale { get; set; }
        /// <summary>
        /// The number of decimal positions expressed as an integer (precision of the number).
        /// <summary>
        public int DecimalPositions { get; set; }
        /// <summary>
        /// The interval between valid responses expressed as an integer.
        /// <summary>
        public int Interval_IntervalType { get; set; }
        /// <summary>
        /// The level to which a number is considered to be accurate. Expressed as a decimal. 
        /// <summary>
        public decimal Accuracy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (NumberRange != null && NumberRange.Count > 0)
            {
                foreach (var item in NumberRange)
                {
                    xEl.Add(item.ToXml("NumberRange"));
                }
            }
            if (NumericTypeCode != null) { xEl.Add(NumericTypeCode.ToXml("NumericTypeCode")); }
            if (Format != null)
            {
                xEl.Add(new XElement(ns + "Format", Format));
            }
            xEl.Add(new XElement(ns + "Scale", Scale));
            xEl.Add(new XElement(ns + "DecimalPositions", DecimalPositions));
            xEl.Add(new XElement(ns + "Interval_IntervalType", Interval_IntervalType));
            if (Accuracy != null)
            {
                xEl.Add(new XElement(ns + "Accuracy", Accuracy));
            }
            return xEl;
        }
    }
}

