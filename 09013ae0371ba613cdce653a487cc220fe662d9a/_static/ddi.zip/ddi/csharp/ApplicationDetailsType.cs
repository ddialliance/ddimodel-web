using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides sample stage level details where needed. Repeat for individual stages or sub-stages.
    /// <summary>
    public partial class ApplicationDetailsType
    {
        /// <summary>
        /// References the sample plan stage or sub-stage in an overall sample plan.
        /// <summary>
        public StageType SampleStageReference { get; set; }
        /// <summary>
        /// Reference to sample frame used. Note that this is the actual sample frame used and may differ from the recommended sample frame found in the sample plan stage referenced for this procedure. Deviation from the recommended sample frame should be described in FrameLimitations.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SampleFrame SampleFrameReference { get; set; }
        /// <summary>
        /// Description of limitations of the usage of the frame for the data collection.  Clarify (over/under) coverage issues, lack of needed fields, and needs to support over-sampling or deviation from recommended sample frame found in sample plan stage.
        /// <summary>
        public StructuredStringType FrameLimitations { get; set; }
        /// <summary>
        /// The desired sample size for this particular sample plan express in relation to its strata number if relevant. Provides means of expressing the formula used for determining the sample size.
        /// <summary>
        public List<TargetSampleSizeType> TargetSampleSize { get; set; } = new List<TargetSampleSizeType>();
        public bool ShouldSerializeTargetSampleSize() { return TargetSampleSize.Count > 0; }
        /// <summary>
        /// Date or date range when sample was drawn.
        /// <summary>
        public DateType DateOfSample { get; set; }
        /// <summary>
        /// A reference to an organization or individual responsible for sampling.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ResponsibleForSamplingReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeResponsibleForSamplingReference() { return ResponsibleForSamplingReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (SampleStageReference != null) { xEl.Add(SampleStageReference.ToXml("SampleStageReference")); }
            if (SampleFrameReference != null)
            {
                xEl.Add(new XElement(ns + "SampleFrameReference", 
                    new XElement(ns + "URN", SampleFrameReference.URN), 
                    new XElement(ns + "Agency", SampleFrameReference.Agency), 
                    new XElement(ns + "ID", SampleFrameReference.ID), 
                    new XElement(ns + "Version", SampleFrameReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleFrameReference.GetType().Name)));
            }
            if (FrameLimitations != null) { xEl.Add(FrameLimitations.ToXml("FrameLimitations")); }
            if (TargetSampleSize != null && TargetSampleSize.Count > 0)
            {
                foreach (var item in TargetSampleSize)
                {
                    xEl.Add(item.ToXml("TargetSampleSize"));
                }
            }
            if (DateOfSample != null) { xEl.Add(DateOfSample.ToXml("DateOfSample")); }
            if (ResponsibleForSamplingReference != null && ResponsibleForSamplingReference.Count > 0)
            {
                foreach (var item in ResponsibleForSamplingReference)
                {
                    xEl.Add(new XElement(ns + "ResponsibleForSamplingReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

