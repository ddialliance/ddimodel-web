using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// All sampling plans have at least one stage.  Stages are used to reduce the size of the survey population frame from which to identify sampling units.  For instance, the US Current Population Survey samples geographic areas first before identifying households to contact within those areas.  Cost and sampling error considerations weigh heavily in these decisions.
    /// <summary>
    public partial class StageType : IdentifiableType
    {
        /// <summary>
        /// Condition for using this stage. Use only when multiple top level stages are used.
        /// <summary>
        public StructuredStringType SplitCondition { get; set; }
        /// <summary>
        /// Describes the minimum requirements of the frame needed to use this sample stage. For example, if a stratification by age is specified in the stage the sample frame would need to support this stratification.
        /// <summary>
        public StructuredStringType FrameRequirements { get; set; }
        /// <summary>
        /// Identifies a specific sample frame or frames appropriate for this plan.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> RecommendedFrameReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeRecommendedFrameReference() { return RecommendedFrameReference.Count > 0; }
        /// <summary>
        /// Describe all stratifications here. Note that each stratified group will be sampled using the same sampling plan. For example stratifying a state by ZIP Code areas in each of 5 mean income quintiles and then doing a random sample of the households in set of ZIP Codes. Allows for oversampling of identified subpopulations.
        /// <summary>
        public List<StratificationType> Stratification { get; set; } = new List<StratificationType>();
        public bool ShouldSerializeStratification() { return Stratification.Count > 0; }
        /// <summary>
        /// Sampling unit for this stage
        /// <summary>
        public CodeValueType SamplingUnit { get; set; }
        /// <summary>
        /// Indicate PlanCode if different from parent. Note that all strata resulting from the stratification process must use the same sampling plan.
        /// <summary>
        public CodeValueType TypeOfPlan { get; set; }
        /// <summary>
        /// If known and available, provide the selection probability for each sampling unit.  This is one number for equal probability sampling, such as SRS.  For PPS, a description of the size criterion is needed.  For other unequal designs, a description of of how the probabilities are assigned is needed.
        /// <summary>
        public StructuredStringType SelectionProbability { get; set; }
        /// <summary>
        /// A substage assumes that its sample frame is the result of its parent stage.
        /// <summary>
        public List<SubStageType> SubStage { get; set; } = new List<SubStageType>();
        public bool ShouldSerializeSubStage() { return SubStage.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (SplitCondition != null) { xEl.Add(SplitCondition.ToXml("SplitCondition")); }
            if (FrameRequirements != null) { xEl.Add(FrameRequirements.ToXml("FrameRequirements")); }
            if (RecommendedFrameReference != null && RecommendedFrameReference.Count > 0)
            {
                foreach (var item in RecommendedFrameReference)
                {
                    xEl.Add(new XElement(ns + "RecommendedFrameReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Stratification != null && Stratification.Count > 0)
            {
                foreach (var item in Stratification)
                {
                    xEl.Add(item.ToXml("Stratification"));
                }
            }
            if (SamplingUnit != null) { xEl.Add(SamplingUnit.ToXml("SamplingUnit")); }
            if (TypeOfPlan != null) { xEl.Add(TypeOfPlan.ToXml("TypeOfPlan")); }
            if (SelectionProbability != null) { xEl.Add(SelectionProbability.ToXml("SelectionProbability")); }
            if (SubStage != null && SubStage.Count > 0)
            {
                foreach (var item in SubStage)
                {
                    xEl.Add(item.ToXml("SubStage"));
                }
            }
            return xEl;
        }
    }
}

