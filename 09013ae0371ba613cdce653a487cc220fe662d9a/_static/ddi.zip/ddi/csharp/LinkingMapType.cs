using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a link from a local object to a deposited object via reference and designates if the added material should Override, act as AddedContent, or DeleteContent in the original deposited material. A description of the link or reason for new material may be provided.
    /// <summary>
    public partial class LinkingMapType
    {
        /// <summary>
        /// A reference to the local object that is to be related to a depository object. If the relationship action is set to delete then no local object needs to be designated.
        /// <summary>
        public IdentifiableType LocalObjectReference_IdentifiableType { get; set; }
        /// <summary>
        /// A reference to the local object that is to be related to a depository object. If the relationship action is set to delete then no local object needs to be designated.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Versionable LocalObjectReference_Versionable { get; set; }
        /// <summary>
        /// A reference to the local object that is to be related to a depository object. If the relationship action is set to delete then no local object needs to be designated.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable LocalObjectReference_Maintainable { get; set; }
        /// <summary>
        /// A reference to the deposited object.
        /// <summary>
        public IdentifiableType DepositoryObjectReference_IdentifiableType { get; set; }
        /// <summary>
        /// A reference to the deposited object.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Versionable DepositoryObjectReference_Versionable { get; set; }
        /// <summary>
        /// A reference to the deposited object.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable DepositoryObjectReference_Maintainable { get; set; }
        /// <summary>
        /// Provides a structured means of stating if the local object overrides (replaces) the depository object, adds information to the deposited object, deletes the content of the depository object without replacing it. or restricts access the deposited object by attaching an embargo or access restriction to it. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType RelationshipAction { get; set; }
        /// <summary>
        /// A description of the link such as the reason for adding or changing local content. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (LocalObjectReference_IdentifiableType != null) { xEl.Add(LocalObjectReference_IdentifiableType.ToXml("LocalObjectReference_IdentifiableType")); }
            if (LocalObjectReference_Versionable != null)
            {
                xEl.Add(new XElement(ns + "LocalObjectReference_Versionable", 
                    new XElement(ns + "URN", LocalObjectReference_Versionable.URN), 
                    new XElement(ns + "Agency", LocalObjectReference_Versionable.Agency), 
                    new XElement(ns + "ID", LocalObjectReference_Versionable.ID), 
                    new XElement(ns + "Version", LocalObjectReference_Versionable.Version), 
                    new XElement(ns + "TypeOfObject", LocalObjectReference_Versionable.GetType().Name)));
            }
            if (LocalObjectReference_Maintainable != null)
            {
                xEl.Add(new XElement(ns + "LocalObjectReference_Maintainable", 
                    new XElement(ns + "URN", LocalObjectReference_Maintainable.URN), 
                    new XElement(ns + "Agency", LocalObjectReference_Maintainable.Agency), 
                    new XElement(ns + "ID", LocalObjectReference_Maintainable.ID), 
                    new XElement(ns + "Version", LocalObjectReference_Maintainable.Version), 
                    new XElement(ns + "TypeOfObject", LocalObjectReference_Maintainable.GetType().Name)));
            }
            if (DepositoryObjectReference_IdentifiableType != null) { xEl.Add(DepositoryObjectReference_IdentifiableType.ToXml("DepositoryObjectReference_IdentifiableType")); }
            if (DepositoryObjectReference_Versionable != null)
            {
                xEl.Add(new XElement(ns + "DepositoryObjectReference_Versionable", 
                    new XElement(ns + "URN", DepositoryObjectReference_Versionable.URN), 
                    new XElement(ns + "Agency", DepositoryObjectReference_Versionable.Agency), 
                    new XElement(ns + "ID", DepositoryObjectReference_Versionable.ID), 
                    new XElement(ns + "Version", DepositoryObjectReference_Versionable.Version), 
                    new XElement(ns + "TypeOfObject", DepositoryObjectReference_Versionable.GetType().Name)));
            }
            if (DepositoryObjectReference_Maintainable != null)
            {
                xEl.Add(new XElement(ns + "DepositoryObjectReference_Maintainable", 
                    new XElement(ns + "URN", DepositoryObjectReference_Maintainable.URN), 
                    new XElement(ns + "Agency", DepositoryObjectReference_Maintainable.Agency), 
                    new XElement(ns + "ID", DepositoryObjectReference_Maintainable.ID), 
                    new XElement(ns + "Version", DepositoryObjectReference_Maintainable.Version), 
                    new XElement(ns + "TypeOfObject", DepositoryObjectReference_Maintainable.GetType().Name)));
            }
            if (RelationshipAction != null) { xEl.Add(RelationshipAction.ToXml("RelationshipAction")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

