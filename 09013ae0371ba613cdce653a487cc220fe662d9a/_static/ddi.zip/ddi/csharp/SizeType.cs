using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Consists of an integer value and specification of the unit. The unit may be specified using a controlled vocabulary.
    /// <summary>
    public partial class SizeType : CodeValueType
    {
        /// <summary>
        /// The number of units.
        /// <summary>
        public int NumberOfUnits { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("CodeValueType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "NumberOfUnits", NumberOfUnits));
            return xEl;
        }
    }
}

