using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Evaluation for the purpose of reviewing the study, data collection, data processing, or management processes. Results may feed into a revision process for future data collection or management. Identifies the type of evaluation undertaken, who did the evaluation, the evaluation process, outcomes and completion date.
    /// <summary>
    public partial class ExPostEvaluationType
    {
        /// <summary>
        /// Brief identification of the type of evaluation. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfEvaluation { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfEvaluation() { return TypeOfEvaluation.Count > 0; }
        /// <summary>
        /// Identifies the evaluator and specifies the role of the evaluator using an external controlled vocabulary.
        /// <summary>
        public List<EvaluatorType> Evaluator { get; set; } = new List<EvaluatorType>();
        public bool ShouldSerializeEvaluator() { return Evaluator.Count > 0; }
        /// <summary>
        /// Describes the process of the Evaluation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> EvaluationProcess { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeEvaluationProcess() { return EvaluationProcess.Count > 0; }
        /// <summary>
        /// Describes the outcomes of the evaluation process. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> Outcomes { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeOutcomes() { return Outcomes.Count > 0; }
        /// <summary>
        /// Identifies the date the evaluation was completed.
        /// <summary>
        public CogsDate CompletionDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfEvaluation != null && TypeOfEvaluation.Count > 0)
            {
                foreach (var item in TypeOfEvaluation)
                {
                    xEl.Add(item.ToXml("TypeOfEvaluation"));
                }
            }
            if (Evaluator != null && Evaluator.Count > 0)
            {
                foreach (var item in Evaluator)
                {
                    xEl.Add(item.ToXml("Evaluator"));
                }
            }
            if (EvaluationProcess != null && EvaluationProcess.Count > 0)
            {
                foreach (var item in EvaluationProcess)
                {
                    xEl.Add(item.ToXml("EvaluationProcess"));
                }
            }
            if (Outcomes != null && Outcomes.Count > 0)
            {
                foreach (var item in Outcomes)
                {
                    xEl.Add(item.ToXml("Outcomes"));
                }
            }
            if (CompletionDate != null && CompletionDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "CompletionDate", CompletionDate.ToString()));
            }
            return xEl;
        }
    }
}

