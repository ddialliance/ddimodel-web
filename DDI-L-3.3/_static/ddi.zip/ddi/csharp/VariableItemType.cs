using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The set of values associated with a single variable (one for each record in storage order of records).
    /// <summary>
    public partial class VariableItemType
    {
        /// <summary>
        /// Reference to the variable associated with the values given.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// Value associated with the referenced variable in record storage order.
        /// <summary>
        public List<ValueType> Value { get; set; } = new List<ValueType>();
        public bool ShouldSerializeValue() { return Value.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (Value != null && Value.Count > 0)
            {
                foreach (var item in Value)
                {
                    xEl.Add(item.ToXml("Value"));
                }
            }
            return xEl;
        }
    }
}

