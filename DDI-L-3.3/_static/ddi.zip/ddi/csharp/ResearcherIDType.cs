using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Captures an individuals assigned researcher ID within a specified system. Includes the type or researcher ID provided, the ID, a URI of the location or link, and a description of the researcher ID provided. E.g., Rajiv Agrwal, type=researcherID, ID=A-8725-2008), URI=www.researcherid.com/rid/A-8725-2008 which brings you to the researchers page.
    /// <summary>
    public partial class ResearcherIDType
    {
        /// <summary>
        /// Brief description of the ID type. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfID { get; set; }
        /// <summary>
        /// The value of the researcher ID.
        /// <summary>
        public string ResearcherIdentification { get; set; }
        /// <summary>
        /// The URI (URN or URL) of the of the researcher ID.
        /// <summary>
        public Uri URI { get; set; }
        /// <summary>
        /// A description of the purpose and use of the researcher ID. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfID != null) { xEl.Add(TypeOfID.ToXml("TypeOfID")); }
            if (ResearcherIdentification != null)
            {
                xEl.Add(new XElement(ns + "ResearcherIdentification", ResearcherIdentification));
            }
            if (URI != null)
            {
                xEl.Add(new XElement(ns + "URI", URI));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            return xEl;
        }
    }
}

