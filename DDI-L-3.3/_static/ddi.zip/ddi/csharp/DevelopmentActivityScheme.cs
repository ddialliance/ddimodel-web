using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of Development Activities maintained by an agency, and used in defining the development of a data capture object. In addition to the standard name, label, and description allows for the inclusion of an existing DevelopmentActivityScheme by reference and descriptions of DevelopmentActivity and DevelopmentActivityGroup either in-line or by reference.
    /// <summary>
    public partial class DevelopmentActivityScheme : Maintainable
    {
        /// <summary>
        /// A name for the DevelopmentActivityScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentActivitySchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentActivitySchemeName() { return DevelopmentActivitySchemeName.Count > 0; }
        /// <summary>
        /// A display label for the DevelopmentActivityScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the DevelopmentActivityScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing DevelopmentActivityScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivityScheme> DevelopmentActivitySchemeReference { get; set; } = new List<DevelopmentActivityScheme>();
        public bool ShouldSerializeDevelopmentActivitySchemeReference() { return DevelopmentActivitySchemeReference.Count > 0; }
        /// <summary>
        /// Extensible structure for development activity elements used in describing the development of a questionnaire.: ContentReviewActivity, TranslationActivity, and PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivity> DevelopmentActivityReference { get; set; } = new List<DevelopmentActivity>();
        public bool ShouldSerializeDevelopmentActivityReference() { return DevelopmentActivityReference.Count > 0; }
        /// <summary>
        /// A description of a group of DevelopmentActivity for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivityGroup> DevelopmentActivityGroupReference { get; set; } = new List<DevelopmentActivityGroup>();
        public bool ShouldSerializeDevelopmentActivityGroupReference() { return DevelopmentActivityGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentActivityScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentActivitySchemeName != null && DevelopmentActivitySchemeName.Count > 0)
            {
                foreach (var item in DevelopmentActivitySchemeName)
                {
                    xEl.Add(item.ToXml("DevelopmentActivitySchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentActivitySchemeReference != null && DevelopmentActivitySchemeReference.Count > 0)
            {
                foreach (var item in DevelopmentActivitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentActivityReference != null && DevelopmentActivityReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentActivityGroupReference != null && DevelopmentActivityGroupReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityGroupReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

