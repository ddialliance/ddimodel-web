using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A reference to a concept with similar meaning and a description of their differences. Formal comparison is done using a ConceptMap. The similar concept structure allows specification of similar concepts to address cases where confusion may affect the appropriate use of the concept.
    /// <summary>
    public partial class SimilarConceptType
    {
        /// <summary>
        /// Reference to a concept with a similar definition.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept SimilarConceptReference { get; set; }
        /// <summary>
        /// Description of the difference between the two concepts.  Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Difference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (SimilarConceptReference != null)
            {
                xEl.Add(new XElement(ns + "SimilarConceptReference", 
                    new XElement(ns + "URN", SimilarConceptReference.URN), 
                    new XElement(ns + "Agency", SimilarConceptReference.Agency), 
                    new XElement(ns + "ID", SimilarConceptReference.ID), 
                    new XElement(ns + "Version", SimilarConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", SimilarConceptReference.GetType().Name)));
            }
            if (Difference != null) { xEl.Add(Difference.ToXml("Difference")); }
            return xEl;
        }
    }
}

