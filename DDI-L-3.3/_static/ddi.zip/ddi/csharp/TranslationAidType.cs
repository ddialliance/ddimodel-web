using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes available aids for translation typed by a controlled vocabulary and supporting a description and resource identification where appropriate. This may include items such as the availability of an interpreter, key word material, etc.
    /// <summary>
    public partial class TranslationAidType
    {
        /// <summary>
        /// Specifies the type of translation aid available. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfTranslationAid { get; set; }
        /// <summary>
        /// Description of the translation aid. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides a reference to the translation aid resource using the structure of OtherMaterial.
        /// <summary>
        public TranslationAidResourceType TranslationAidResource { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfTranslationAid != null) { xEl.Add(TypeOfTranslationAid.ToXml("TypeOfTranslationAid")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (TranslationAidResource != null) { xEl.Add(TranslationAidResource.ToXml("TranslationAidResource")); }
            return xEl;
        }
    }
}

