using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Data capture development covers the development planning, process, and outcome for a partial or full questionnaire. Development normally included the development of the question wording, possible response domains and their presentation, translation for language or cultural variance in the population, and question order. Extensive work is often done for individual questions that may be reused by different questionnaires with the organization or for topical areas or populations that are difficult to measure. In addition to the standard name, label, and description information DataCaptureDevelopment contains structures to capture the development plan, the development implementation, and the results or outcome of the development implementation. DataCaptureDevelopment is a Maintainable object and any Note or OtherMaterial related to one of its objects should be placed within the Note and OtherMaterial section of DataCaptureDevelopment.
    /// <summary>
    public partial class DataCaptureDevelopment : Versionable
    {
        /// <summary>
        /// A name for the Data Capture Development. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DataCaptureDevelopmentName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDataCaptureDevelopmentName() { return DataCaptureDevelopmentName.Count > 0; }
        /// <summary>
        /// A display label for the Data Capture Development. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Data Capture Development. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describes the set of development activities that should take place.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentPlan> DevelopmentPlanReference { get; set; } = new List<DevelopmentPlan>();
        public bool ShouldSerializeDevelopmentPlanReference() { return DevelopmentPlanReference.Count > 0; }
        /// <summary>
        /// Describes the implementation of a development plan for a specific set of development objects. May provide specific details using Control Construct to order Development Steps.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentImplementation> DevelopmentImplementationReference { get; set; } = new List<DevelopmentImplementation>();
        public bool ShouldSerializeDevelopmentImplementationReference() { return DevelopmentImplementationReference.Count > 0; }
        /// <summary>
        /// Separates the capture of development implementation results from the process plan and general activities. Allows for capture of the overall results, details of individual steps, or separate iterations of that step.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentResults> DevelopmentResultsReference { get; set; } = new List<DevelopmentResults>();
        public bool ShouldSerializeDevelopmentResultsReference() { return DevelopmentResultsReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DataCaptureDevelopment");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DataCaptureDevelopmentName != null && DataCaptureDevelopmentName.Count > 0)
            {
                foreach (var item in DataCaptureDevelopmentName)
                {
                    xEl.Add(item.ToXml("DataCaptureDevelopmentName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentPlanReference != null && DevelopmentPlanReference.Count > 0)
            {
                foreach (var item in DevelopmentPlanReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentPlanReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentImplementationReference != null && DevelopmentImplementationReference.Count > 0)
            {
                foreach (var item in DevelopmentImplementationReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentImplementationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentResultsReference != null && DevelopmentResultsReference.Count > 0)
            {
                foreach (var item in DevelopmentResultsReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentResultsReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

