using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides information about the individual, agency and/or grant(s) which funded the described entity. Lists a reference to the agency or individual as described in a DDI Organization Scheme, the role of the funder, the grant number(s) and a description of the funding activity.
    /// <summary>
    public partial class FundingInformationType
    {
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, that served as a funding source.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> AgencyOrganizationReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeAgencyOrganizationReference() { return AgencyOrganizationReference.Count > 0; }
        /// <summary>
        /// Role of the funding organization or individual. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType FunderRole { get; set; }
        /// <summary>
        /// The identification code of the grant or other monetary award which provided funding for the described object.
        /// <summary>
        public List<string> GrantNumber { get; set; } = new List<string>();
        public bool ShouldSerializeGrantNumber() { return GrantNumber.Count > 0; }
        /// <summary>
        /// Additional information regarding the role and actions of the this funding source. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Link to a document related to the funding such as application or funding announcement using the OtherMaterial structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public OtherMaterial FundingDocumentReference { get; set; }
        /// <summary>
        /// Dates for which the funding is provided.
        /// <summary>
        public DateType FundingPeriod { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (AgencyOrganizationReference != null && AgencyOrganizationReference.Count > 0)
            {
                foreach (var item in AgencyOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "AgencyOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (FunderRole != null) { xEl.Add(FunderRole.ToXml("FunderRole")); }
            if (GrantNumber != null && GrantNumber.Count > 0)
            {
                xEl.Add(
                    from item in GrantNumber
                    select new XElement(ns + "GrantNumber", item.ToString()));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (FundingDocumentReference != null)
            {
                xEl.Add(new XElement(ns + "FundingDocumentReference", 
                    new XElement(ns + "URN", FundingDocumentReference.URN), 
                    new XElement(ns + "Agency", FundingDocumentReference.Agency), 
                    new XElement(ns + "ID", FundingDocumentReference.ID), 
                    new XElement(ns + "Version", FundingDocumentReference.Version), 
                    new XElement(ns + "TypeOfObject", FundingDocumentReference.GetType().Name)));
            }
            if (FundingPeriod != null) { xEl.Add(FundingPeriod.ToXml("FundingPeriod")); }
            return xEl;
        }
    }
}

