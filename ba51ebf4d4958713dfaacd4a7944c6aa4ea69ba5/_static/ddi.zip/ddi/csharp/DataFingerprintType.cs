using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for assigning a hash value (digital fingerprint) to the data or data file. Set the attribute flag to "data" when the hash value provides a digital fingerprint to the data contained in the file regardless of the storage format (ASCII, SAS, binary, etc.). One approach to compute a data fingerprint is the Universal Numerical Fingerprint (UNF). Set the attribute flag to "dataFile" if the digital fingerprint is only for the data file in its current storage format.
    /// <summary>
    public partial class DataFingerprintType
    {
        /// <summary>
        /// Contains the value of the specified digital fingerprint.
        /// <summary>
        public string DigitalFingerprintValue { get; set; }
        /// <summary>
        /// Specifies the type of the fingerprint (what algorithm or scheme).
        /// <summary>
        public string AlgorithmSpecification { get; set; }
        /// <summary>
        /// Contains the version of the algorithm.
        /// <summary>
        public string AlgorithmVersion { get; set; }
        /// <summary>
        /// Brief identification of the type of data fingerprint used. The data fingerprint may be for the data file (storage format specific) or data (format neutral).
        /// <summary>
        [StringValidation(new string[] {
            "data"
,             "dataFile"
        })]
        public string Type { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (DigitalFingerprintValue != null)
            {
                xEl.Add(new XElement(ns + "DigitalFingerprintValue", DigitalFingerprintValue));
            }
            if (AlgorithmSpecification != null)
            {
                xEl.Add(new XElement(ns + "AlgorithmSpecification", AlgorithmSpecification));
            }
            if (AlgorithmVersion != null)
            {
                xEl.Add(new XElement(ns + "AlgorithmVersion", AlgorithmVersion));
            }
            if (Type != null)
            {
                xEl.Add(new XElement(ns + "Type", Type));
            }
            return xEl;
        }
    }
}

