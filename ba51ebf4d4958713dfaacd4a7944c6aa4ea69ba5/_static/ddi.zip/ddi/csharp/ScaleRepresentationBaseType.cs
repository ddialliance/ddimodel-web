using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A means of capturing the structure of Scale for use as a question response domain or variable value representation. In addition to the basic objects of the representation, the structure defines the dimensions of the scale, an intersect for a multi-dimensional scale, and display layout.
    /// <summary>
    public partial class ScaleRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// A description of a dimension of the scale. Note that most scales will have only one dimension.
        /// <summary>
        public List<ScaleDimensionType> ScaleDimension { get; set; } = new List<ScaleDimensionType>();
        public bool ShouldSerializeScaleDimension() { return ScaleDimension.Count > 0; }
        /// <summary>
        /// Identifies the point at which the scales of a multidimensional scale intersect.
        /// <summary>
        public List<DimensionIntersectType> DimensionIntersect { get; set; } = new List<DimensionIntersectType>();
        public bool ShouldSerializeDimensionIntersect() { return DimensionIntersect.Count > 0; }
        /// <summary>
        /// Defines they layout such as containing a drawn scale line, a list of values only, an outline (the boundaries of the area defined by 2 or more intersecting scales such as a diamond of opposites), or some other layout design. Allows for the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType DisplayLayout { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (ScaleDimension != null && ScaleDimension.Count > 0)
            {
                foreach (var item in ScaleDimension)
                {
                    xEl.Add(item.ToXml("ScaleDimension"));
                }
            }
            if (DimensionIntersect != null && DimensionIntersect.Count > 0)
            {
                foreach (var item in DimensionIntersect)
                {
                    xEl.Add(item.ToXml("DimensionIntersect"));
                }
            }
            if (DisplayLayout != null) { xEl.Add(DisplayLayout.ToXml("DisplayLayout")); }
            return xEl;
        }
    }
}

