using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Designates the response domain and the cells using the specified response domain within a QuestionGrid.
    /// <summary>
    public partial class GridResponseDomainType
    {
        /// <summary>
        /// This is a substitution head and can be replaced by any valid member of the substitution group for ResponseDomain.
        /// <summary>
        [JsonConverter(typeof(SubstitutionConverter))]
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ResponseDomainReference { get; set; }
        /// <summary>
        /// Identifies the cell or cells in a grid to which the item is attached by a reference to a specific cell coordinate in a grid or by identifying a range of values along a dimension.
        /// <summary>
        public List<GridAttachmentType> GridAttachment { get; set; } = new List<GridAttachmentType>();
        public bool ShouldSerializeGridAttachment() { return GridAttachment.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference", 
                    new XElement(ns + "URN", ResponseDomainReference.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference.ID), 
                    new XElement(ns + "Version", ResponseDomainReference.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference.GetType().Name)));
            }
            if (GridAttachment != null && GridAttachment.Count > 0)
            {
                foreach (var item in GridAttachment)
                {
                    xEl.Add(item.ToXml("GridAttachment"));
                }
            }
            return xEl;
        }
    }
}

