using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A substitution for DevelopmentActivity which describes the specifics of translation, looking at source and target languages, aids available for translation, and translator requirements regarding language ability and method of translation.
    /// <summary>
    public partial class TranslationActivity : DevelopmentActivity
    {
        /// <summary>
        /// Describes the method of translation required through use of a controlled vocabulary and description. Repeat for multiple methods.
        /// <summary>
        public List<TranslationMethodType> TranslationMethod { get; set; } = new List<TranslationMethodType>();
        public bool ShouldSerializeTranslationMethod() { return TranslationMethod.Count > 0; }
        /// <summary>
        /// Provides a detailed description of the requirements for an acceptable translation and indicate if the translation should be oral and/or written.
        /// <summary>
        public TranslationRequirementsType TranslationRequirements { get; set; }
        /// <summary>
        /// Describes available aids for translation typed by a controlled vocabulary and supporting a description and resource identification where appropriate. This may include items such as the availability of an interpreter, key word material, etc.
        /// <summary>
        public List<TranslationAidType> TranslationAid { get; set; } = new List<TranslationAidType>();
        public bool ShouldSerializeTranslationAid() { return TranslationAid.Count > 0; }
        /// <summary>
        /// Describes both minimum and preferred language abilities sought for the translation work as a set of source and target language requirements. Details requirements for the translator in terms of language ability for reading, speaking, and writing the source and target languages. Repeat for each language pair sought.
        /// <summary>
        public List<TranslatorRequirementsType> TranslatorRequirements { get; set; } = new List<TranslatorRequirementsType>();
        public bool ShouldSerializeTranslatorRequirements() { return TranslatorRequirements.Count > 0; }
        /// <summary>
        /// List the language or language codes in a space delimited array. The language original may or may not be provided in this bundle of language specific strings.
        /// <summary>
        public List<string> TranslationSourceLanguage { get; set; } = new List<string>();
        public bool ShouldSerializeTranslationSourceLanguage() { return TranslationSourceLanguage.Count > 0; }
        /// <summary>
        /// List the language or language codes in a space delimited array.
        /// <summary>
        public List<string> TranslationTargetLanguage { get; set; } = new List<string>();
        public bool ShouldSerializeTranslationTargetLanguage() { return TranslationTargetLanguage.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "TranslationActivity");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TranslationMethod != null && TranslationMethod.Count > 0)
            {
                foreach (var item in TranslationMethod)
                {
                    xEl.Add(item.ToXml("TranslationMethod"));
                }
            }
            if (TranslationRequirements != null) { xEl.Add(TranslationRequirements.ToXml("TranslationRequirements")); }
            if (TranslationAid != null && TranslationAid.Count > 0)
            {
                foreach (var item in TranslationAid)
                {
                    xEl.Add(item.ToXml("TranslationAid"));
                }
            }
            if (TranslatorRequirements != null && TranslatorRequirements.Count > 0)
            {
                foreach (var item in TranslatorRequirements)
                {
                    xEl.Add(item.ToXml("TranslatorRequirements"));
                }
            }
            if (TranslationSourceLanguage != null && TranslationSourceLanguage.Count > 0)
            {
                foreach (var item in TranslationSourceLanguage)
                {
                    xEl.Add(new XElement(ns + "TranslationSourceLanguage", item));
                }
            }
            if (TranslationTargetLanguage != null && TranslationTargetLanguage.Count > 0)
            {
                foreach (var item in TranslationTargetLanguage)
                {
                    xEl.Add(new XElement(ns + "TranslationTargetLanguage", item));
                }
            }
            return xEl;
        }
    }
}

