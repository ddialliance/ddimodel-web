using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes both minimum and preferred language abilities sought for the translation work as a set of source and target language requirements.
    /// <summary>
    public partial class TranslatorRequirementsType
    {
        /// <summary>
        /// Describes both minimum and preferred language abilities sought for the translation work for the source language.
        /// <summary>
        public LanguageAbilitySoughtType TranslationSourceLanguageAbility { get; set; }
        /// <summary>
        /// Describes both minimum and preferred language abilities sought for the translation work for the target language.
        /// <summary>
        public LanguageAbilitySoughtType TranslationTargetLanguageAbility { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TranslationSourceLanguageAbility != null) { xEl.Add(TranslationSourceLanguageAbility.ToXml("TranslationSourceLanguageAbility")); }
            if (TranslationTargetLanguageAbility != null) { xEl.Add(TranslationTargetLanguageAbility.ToXml("TranslationTargetLanguageAbility")); }
            return xEl;
        }
    }
}

