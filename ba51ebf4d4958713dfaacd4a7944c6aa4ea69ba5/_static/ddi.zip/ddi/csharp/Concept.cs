using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a concept per ISO/IEC 11179. In addition to the standard name, label, and description, can identify similar concepts, the concept which this concept is a subclass of, a concept that is used to characterize this concept, and a reference to the Universe associated with this concept. It is the linking of a concept to a specific universe (object) that defines this as a data element concept.
    /// <summary>
    public partial class Concept : Versionable
    {
        /// <summary>
        /// A name for the Concept. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptName() { return ConceptName.Count > 0; }
        /// <summary>
        /// A display label for the Concept. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Concept. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to a concept expressing a similar idea plus a description of the differences. Used to assist in disambiguation of concepts.
        /// <summary>
        public List<SimilarConceptType> SimilarConcept { get; set; } = new List<SimilarConceptType>();
        public bool ShouldSerializeSimilarConcept() { return SimilarConcept.Count > 0; }
        /// <summary>
        /// Reference to a Concept that is used for qualifying this data element concept. The referenced Concept should have its isCharacteristic attribute set to true.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> SubclassOfReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeSubclassOfReference() { return SubclassOfReference.Count > 0; }
        /// <summary>
        /// If set to "true" this concept is used to describe a characteristic of another concept.
        /// <summary>
        public bool IsCharacteristic { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Concept");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptName != null && ConceptName.Count > 0)
            {
                foreach (var item in ConceptName)
                {
                    xEl.Add(item.ToXml("ConceptName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SimilarConcept != null && SimilarConcept.Count > 0)
            {
                foreach (var item in SimilarConcept)
                {
                    xEl.Add(item.ToXml("SimilarConcept"));
                }
            }
            if (SubclassOfReference != null && SubclassOfReference.Count > 0)
            {
                foreach (var item in SubclassOfReference)
                {
                    xEl.Add(new XElement(ns + "SubclassOfReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "IsCharacteristic", IsCharacteristic));
            return xEl;
        }
    }
}

