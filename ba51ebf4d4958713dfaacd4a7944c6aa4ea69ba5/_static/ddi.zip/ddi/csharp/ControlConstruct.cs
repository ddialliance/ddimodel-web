using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the basic, extensible structure for control elements used in describing flow logic within the instrument. The only data point which is inherited by the extended constructs based on this type is the identification of the control construct.
    /// <summary>
    public partial class ControlConstruct : Versionable
    {

        /// <summary>
        /// Set the TypeDescriminator
        /// <summary>
        public ControlConstruct() { this.TypeDescriminator = this.GetType().Name; }

        /// <summary>
        /// Type descriminator for json serialization
        /// <summary>
        [JsonProperty("$type")]
        public string TypeDescriminator { get; set; }

        /// <summary>
        /// A name for the ControlConstruct. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConstructName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConstructName() { return ConstructName.Count > 0; }
        /// <summary>
        /// A display label for the ControlConstruct. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ControlConstruct. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A parameter that may accept content from outside its parent element.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// An identify for the output of the control construct.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// A structure used to bind the content of a parameter declared as the source to a parameter declared as the target. For example, binding the output of a question to the input of a generation instruction. Question A has an OutParameter X. Generation Instruction has an InParameter Y used in the recode instruction. Binding defines the content of InParameter Y to be whatever is provided by OutParameter X for use in the calculation of the recode.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// A pointer to an external aid presented by the instrument such as a text card, image, audio, or audiovisual aid. Typically a URN. Use type attribute to describe the type of external aid provided. Example of terms to use would include: imageOnly audioOnly audioVisual multiMedia. ExternalAid will be available each time the control construct is invoked. Care should be taken when placing an ExternalAid in RepeatWhile, RepeatUntil and Loop constructs as it will recur each time the conditional statement is checked. This does not include interviewer instructions, which are handled separately.
        /// <summary>
        public List<ExternalAidType> ExternalAid { get; set; } = new List<ExternalAidType>();
        public bool ShouldSerializeExternalAid() { return ExternalAid.Count > 0; }
        /// <summary>
        /// Contains a reference to an interviewer instruct ruction held in a structure other than DDI XML. Uses the OtherMaterial structure to describe and link to the external object.
        /// <summary>
        public ExternalInterviewerInstructionType ExternalInterviewerInstruction { get; set; }
        /// <summary>
        /// Reference to an interviewer instruction expressed as DDI XML.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instruction InterviewerInstructionReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ControlConstruct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConstructName != null && ConstructName.Count > 0)
            {
                foreach (var item in ConstructName)
                {
                    xEl.Add(item.ToXml("ConstructName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (ExternalAid != null && ExternalAid.Count > 0)
            {
                foreach (var item in ExternalAid)
                {
                    xEl.Add(item.ToXml("ExternalAid"));
                }
            }
            if (ExternalInterviewerInstruction != null) { xEl.Add(ExternalInterviewerInstruction.ToXml("ExternalInterviewerInstruction")); }
            if (InterviewerInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "InterviewerInstructionReference", 
                    new XElement(ns + "URN", InterviewerInstructionReference.URN), 
                    new XElement(ns + "Agency", InterviewerInstructionReference.Agency), 
                    new XElement(ns + "ID", InterviewerInstructionReference.ID), 
                    new XElement(ns + "Version", InterviewerInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", InterviewerInstructionReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

