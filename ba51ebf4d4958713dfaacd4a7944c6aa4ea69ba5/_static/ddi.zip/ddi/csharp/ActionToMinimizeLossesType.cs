using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes action taken to minimize loss of data from the collection event. This may include a brief term, such as from a controlled vocabulary, and a full description of the actions taken. If multiple actions were taken repeat this element.
    /// <summary>
    public partial class ActionToMinimizeLossesType : IdentifiableType
    {
        /// <summary>
        /// A brief textual description of the action taken to minimize loss of data. Supports the use of an external controlled vocabulary
        /// <summary>
        public CodeValueType TypeOfActionToMinimizeLosses { get; set; }
        /// <summary>
        /// Full description of the action taken to minimize loss of data. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfActionToMinimizeLosses != null) { xEl.Add(TypeOfActionToMinimizeLosses.ToXml("TypeOfActionToMinimizeLosses")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

