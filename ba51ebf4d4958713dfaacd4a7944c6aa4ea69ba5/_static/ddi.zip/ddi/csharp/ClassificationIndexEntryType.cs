using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Classification Index Entry is a word or a short text (e.g. the name of a locality, an economic activity or an occupational title) describing a type of object/unit or object property to which a Classification Item applies, together with the code of the corresponding Classification Item. Each Classification Index Entry typically refers to one item of the Statistical Classification. Although a Classification Index Entry may be associated with a Classification Item at any Level of a Statistical Classification, Classification Index Entries are normally associated with Classification Items at the lowest Level. 
    /// <summary>
    public partial class ClassificationIndexEntryType
    {
        /// <summary>
        /// Text describing the type of object/unit or object property.
        /// <summary>
        public string EntryText { get; set; }
        /// <summary>
        /// the Classification Item with which the Classification Index Entry is associated.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationItem CodesClassificationItem { get; set; }
        /// <summary>
        /// Date from which the Classification Index Entry became valid. The date must be defined if the Classification Index Entry belongs to a floating Classification Index.
        /// <summary>
        public CogsDate ValidFrom { get; set; }
        /// <summary>
        /// Date at which the Classification Index Entry became invalid. The date must be defined if the Classification Index Entry belongs to a floating Classification Index and is no longer valid.
        /// <summary>
        public CogsDate ValidTo { get; set; }
        /// <summary>
        /// Additional information which drives the coding process. Required when coding is dependent upon one or many other factors.
        /// <summary>
        public StructuredStringType CodingInstructions { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (EntryText != null)
            {
                xEl.Add(new XElement(ns + "EntryText", EntryText));
            }
            if (CodesClassificationItem != null)
            {
                xEl.Add(new XElement(ns + "CodesClassificationItem", 
                    new XElement(ns + "URN", CodesClassificationItem.URN), 
                    new XElement(ns + "Agency", CodesClassificationItem.Agency), 
                    new XElement(ns + "ID", CodesClassificationItem.ID), 
                    new XElement(ns + "Version", CodesClassificationItem.Version), 
                    new XElement(ns + "TypeOfObject", CodesClassificationItem.GetType().Name)));
            }
            if (ValidFrom != null && ValidFrom.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidFrom", ValidFrom.ToString()));
            }
            if (ValidTo != null && ValidTo.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidTo", ValidTo.ToString()));
            }
            if (CodingInstructions != null) { xEl.Add(CodingInstructions.ToXml("CodingInstructions")); }
            return xEl;
        }
    }
}

