using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a group of Development Activities for administrative or conceptual purposes, which may be hierarchical. In addition to the standard name, label, and description contains references to included Development Activities, and other DevelopmentActivityGroups.
    /// <summary>
    public partial class DevelopmentActivityGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a Development Activities Group. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfDevelopmentActivityGroup { get; set; }
        /// <summary>
        /// A name for the DevelopmentActivityGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentActivityGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentActivityGroupName() { return DevelopmentActivityGroupName.Count > 0; }
        /// <summary>
        /// A display label for the DevelopmentActivityGroup. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the DevelopmentActivityGroup. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to a constituent DevelopmentActivity for inclusion in the group. TypeOfObject should be ContentReviewActivity, TranslationActivity, or PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public DevelopmentActivity DevelopmentActivityReference { get; set; }
        /// <summary>
        /// Reference to constituent Development Activity group. This allows for nesting of processing instruction groups. TypeOfObject should be DevelopmentActivityGroup.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public DevelopmentActivityGroup DevelopmentActivityGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentActivityGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfDevelopmentActivityGroup != null) { xEl.Add(TypeOfDevelopmentActivityGroup.ToXml("TypeOfDevelopmentActivityGroup")); }
            if (DevelopmentActivityGroupName != null && DevelopmentActivityGroupName.Count > 0)
            {
                foreach (var item in DevelopmentActivityGroupName)
                {
                    xEl.Add(item.ToXml("DevelopmentActivityGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (DevelopmentActivityReference != null)
            {
                xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                    new XElement(ns + "URN", DevelopmentActivityReference.URN), 
                    new XElement(ns + "Agency", DevelopmentActivityReference.Agency), 
                    new XElement(ns + "ID", DevelopmentActivityReference.ID), 
                    new XElement(ns + "Version", DevelopmentActivityReference.Version), 
                    new XElement(ns + "TypeOfObject", DevelopmentActivityReference.GetType().Name)));
            }
            if (DevelopmentActivityGroupReference != null)
            {
                xEl.Add(new XElement(ns + "DevelopmentActivityGroupReference", 
                    new XElement(ns + "URN", DevelopmentActivityGroupReference.URN), 
                    new XElement(ns + "Agency", DevelopmentActivityGroupReference.Agency), 
                    new XElement(ns + "ID", DevelopmentActivityGroupReference.ID), 
                    new XElement(ns + "Version", DevelopmentActivityGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", DevelopmentActivityGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

