using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes individual items held or distributed by the archive in connection with a study, group of studies, or resource packages. What constitutes an item is determined by the archive. Provides identification information on the item within the context of the archive including citation, a statement on its location, call number (internal identifier), URI, format, media type, and source. The item is classified by a study class designation, information on access restrictions, and availability status. Content information on the number of data files associated with the item, the completeness of the collection of objects represented by this item as well as descriptions of nested items are provided.
    /// <summary>
    public class ItemType
    {
        /// <summary>
        /// A citation for the item. May additionally be rendered in native qualified Dublin Core (dc and dcterms).
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// Describes the location of the item within the archive. Repeat for multiple locations such as separate stores for access and archival copies.
        /// <summary>
        public List<InternationalStringType> LocationInArchive { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeLocationInArchive() { return LocationInArchive.Count > 0; }
        /// <summary>
        /// The name, code, or number used by the archive to uniquely identify the item within the archive.
        /// <summary>
        public string CallNumber { get; set; }
        /// <summary>
        /// The URL or URN for the item.
        /// <summary>
        public Uri URI { get; set; }
        /// <summary>
        /// Describes the item's format.
        /// <summary>
        public CodeValueType ItemFormat { get; set; }
        /// <summary>
        /// Describes the medium, or media, for the item.
        /// <summary>
        public CodeValueType Media { get; set; }
        /// <summary>
        /// An archive specific classification for the item. This may be a topical classification, a classification of intended processing levels, or information on the processing status.
        /// <summary>
        public StudyClassType StudyClass { get; set; }
        /// <summary>
        /// Access restriction information applying to the item. If none are specified the default restrictions of the archive or parent collection or item apply.
        /// <summary>
        public AccessType Access { get; set; }
        /// <summary>
        /// The original archive for the described item, expressed as a reference to an organization listed in the organization scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> OriginalArchiveOrganizationReference { get; set; } = new List<Organization>();
        public bool ShouldSerializeOriginalArchiveOrganizationReference() { return OriginalArchiveOrganizationReference.Count > 0; }
        /// <summary>
        /// A statement of availability for the item. This is a positive statement (as opposed to access restrictions) which may be used for publication or other purposes. Allows for structured content.
        /// <summary>
        public StructuredStringType AvailabilityStatus { get; set; }
        /// <summary>
        /// The number of data files in the described item, expressed as an integer. This is a check sum and should be updated as the contents of the collection changes. The use of this element is best restricted to completed collections where change in the number of objects is not dynamic.
        /// <summary>
        public int DataFileQuantity { get; set; }
        /// <summary>
        /// Describes the completeness of the collection for the item and its related data files and sub-items. Note coverage gaps as well as unique content . This statement may be used for publication or other purposes. Allows for structured content.
        /// <summary>
        public StructuredStringType CollectionCompleteness { get; set; }
        /// <summary>
        /// Allows for the nesting of Item descriptions with a item.
        /// <summary>
        public List<ItemType> Item { get; set; } = new List<ItemType>();
        public bool ShouldSerializeItem() { return Item.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (LocationInArchive != null && LocationInArchive.Count > 0)
            {
                foreach (var item in LocationInArchive)
                {
                    xEl.Add(item.ToXml("LocationInArchive"));
                }
            }
            if (CallNumber != null)
            {
                xEl.Add(new XElement(ns + "CallNumber", CallNumber));
            }
            if (URI != null)
            {
                xEl.Add(new XElement(ns + "URI", URI));
            }
            if (ItemFormat != null) { xEl.Add(ItemFormat.ToXml("ItemFormat")); }
            if (Media != null) { xEl.Add(Media.ToXml("Media")); }
            if (StudyClass != null) { xEl.Add(StudyClass.ToXml("StudyClass")); }
            if (Access != null) { xEl.Add(Access.ToXml("Access")); }
            if (OriginalArchiveOrganizationReference != null && OriginalArchiveOrganizationReference.Count > 0)
            {
                foreach (var item in OriginalArchiveOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "OriginalArchiveOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (AvailabilityStatus != null) { xEl.Add(AvailabilityStatus.ToXml("AvailabilityStatus")); }
            xEl.Add(new XElement(ns + "DataFileQuantity", DataFileQuantity));
            if (CollectionCompleteness != null) { xEl.Add(CollectionCompleteness.ToXml("CollectionCompleteness")); }
            if (Item != null && Item.Count > 0)
            {
                foreach (var item in Item)
                {
                    xEl.Add(item.ToXml("Item"));
                }
            }
            return xEl;
        }
    }
}

