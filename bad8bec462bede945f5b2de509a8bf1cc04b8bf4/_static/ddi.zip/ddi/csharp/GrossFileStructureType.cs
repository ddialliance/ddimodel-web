using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Includes information about the file structure, as well as other characteristics that are specific to the physical instance. Information includes place of production, processing checks to validate the content, processing status, the software used to create the data file, and check sums for the number of cases and overall record count.
    /// <summary>
    public class GrossFileStructureType : IdentifiableType
    {
        /// <summary>
        /// Indicates the place where the physical instance was produced expressed as a simple string.
        /// <summary>
        public string PlaceOfProduction { get; set; }
        /// <summary>
        /// Documents processing checks and other operations performed on the data file.
        /// <summary>
        public List<StructuredStringType> ProcessingCheck { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeProcessingCheck() { return ProcessingCheck.Count > 0; }
        /// <summary>
        /// Processing status of the data file. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType ProcessingStatus { get; set; }
        /// <summary>
        /// Indicates the software that was used to create the data file.
        /// <summary>
        public SoftwareType CreationSoftware { get; set; }
        /// <summary>
        /// Number of cases or observations in the data file. Caution in using optional checksums is recommended. Conflict between checksums and the items being counted can cause problems with warning flags during processing. If using checksum to capture information for internal processing purposes, the use of automatically generated check sums is strongly urged.
        /// <summary>
        public int CaseQuantity { get; set; }
        /// <summary>
        /// Overall record count in the data file. Caution in using optional checksums is recommended. Conflict between checksums and the items being counted can cause problems with warning flags during processing. If using checksum to capture information for internal processing purposes, the use of automatically generated check sums is strongly urged.
        /// <summary>
        public int OverallRecordCount { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (PlaceOfProduction != null)
            {
                xEl.Add(new XElement(ns + "PlaceOfProduction", PlaceOfProduction));
            }
            if (ProcessingCheck != null && ProcessingCheck.Count > 0)
            {
                foreach (var item in ProcessingCheck)
                {
                    xEl.Add(item.ToXml("ProcessingCheck"));
                }
            }
            if (ProcessingStatus != null) { xEl.Add(ProcessingStatus.ToXml("ProcessingStatus")); }
            if (CreationSoftware != null) { xEl.Add(CreationSoftware.ToXml("CreationSoftware")); }
            xEl.Add(new XElement(ns + "CaseQuantity", CaseQuantity));
            xEl.Add(new XElement(ns + "OverallRecordCount", OverallRecordCount));
            return xEl;
        }
    }
}

