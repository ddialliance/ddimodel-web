using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Information on a specific data collection event including details on who was involved in data collection, the source of the data, the date and frequency of collection, mode of collection, identification of the instrument used for collection, information on the actual situation under which data was collected, actions taken to minimize loss of data, and reference to a quality standard or statement regarding the handling of the data collection process during this event.
    /// <summary>
    public class CollectionEventType : IdentifiableType
    {
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for the data collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> DataCollectorOrganizationReference_Organization { get; set; } = new List<Organization>();
        public bool ShouldSerializeDataCollectorOrganizationReference_Organization() { return DataCollectorOrganizationReference_Organization.Count > 0; }
        /// <summary>
        /// Reference to an organization or individual, defined in the organization scheme, responsible for the data collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Individual> DataCollectorOrganizationReference_Individual { get; set; } = new List<Individual>();
        public bool ShouldSerializeDataCollectorOrganizationReference_Individual() { return DataCollectorOrganizationReference_Individual.Count > 0; }
        /// <summary>
        /// Describes a source of the data.
        /// <summary>
        public List<DataSourceType> DataSource { get; set; } = new List<DataSourceType>();
        public bool ShouldSerializeDataSource() { return DataSource.Count > 0; }
        /// <summary>
        /// Provides a date or range of dates for the described data collection event as well as  a cycle number when the collection is part of a series of data collection events.
        /// <summary>
        public DateType DataCollectionDate { get; set; }
        /// <summary>
        /// Documents the intended frequency of data collection, for example monthly, yearly, weekly, etc., preferably using an optional controlled vocabulary in the IntendedFrequency element. Date of first collection should be provided in StartDate as a basis for defining periodicity. EndDate should be entered for data collection cycles with a known or anticipated end date. EndDate is omitted in data collection series that are intended to be on-going.
        /// <summary>
        public List<DataCollectionFrequencyType> DataCollectionFrequency { get; set; } = new List<DataCollectionFrequencyType>();
        public bool ShouldSerializeDataCollectionFrequency() { return DataCollectionFrequency.Count > 0; }
        /// <summary>
        /// Describes the mode of data collection.
        /// <summary>
        public List<ModeOfCollectionType> ModeOfCollection { get; set; } = new List<ModeOfCollectionType>();
        public bool ShouldSerializeModeOfCollection() { return ModeOfCollection.Count > 0; }
        /// <summary>
        /// References the instrument or instruments used during the process of collecting data for this collection event period.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Instrument> InstrumentReference { get; set; } = new List<Instrument>();
        public bool ShouldSerializeInstrumentReference() { return InstrumentReference.Count > 0; }
        /// <summary>
        /// Describes the situation in which the data collection event takes place. If a number of collection situation types occurred repeat this element.
        /// <summary>
        public List<CollectionSituationType> CollectionSituation { get; set; } = new List<CollectionSituationType>();
        public bool ShouldSerializeCollectionSituation() { return CollectionSituation.Count > 0; }
        /// <summary>
        /// Describes action taken to minimize loss of data from the collection event.
        /// <summary>
        public List<ActionToMinimizeLossesType> ActionToMinimizeLosses { get; set; } = new List<ActionToMinimizeLossesType>();
        public bool ShouldSerializeActionToMinimizeLosses() { return ActionToMinimizeLosses.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the study methodology, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DataCollectorOrganizationReference_Organization != null && DataCollectorOrganizationReference_Organization.Count > 0)
            {
                foreach (var item in DataCollectorOrganizationReference_Organization)
                {
                    xEl.Add(new XElement(ns + "DataCollectorOrganizationReference_Organization", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataCollectorOrganizationReference_Individual != null && DataCollectorOrganizationReference_Individual.Count > 0)
            {
                foreach (var item in DataCollectorOrganizationReference_Individual)
                {
                    xEl.Add(new XElement(ns + "DataCollectorOrganizationReference_Individual", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataSource != null && DataSource.Count > 0)
            {
                foreach (var item in DataSource)
                {
                    xEl.Add(item.ToXml("DataSource"));
                }
            }
            if (DataCollectionDate != null) { xEl.Add(DataCollectionDate.ToXml("DataCollectionDate")); }
            if (DataCollectionFrequency != null && DataCollectionFrequency.Count > 0)
            {
                foreach (var item in DataCollectionFrequency)
                {
                    xEl.Add(item.ToXml("DataCollectionFrequency"));
                }
            }
            if (ModeOfCollection != null && ModeOfCollection.Count > 0)
            {
                foreach (var item in ModeOfCollection)
                {
                    xEl.Add(item.ToXml("ModeOfCollection"));
                }
            }
            if (InstrumentReference != null && InstrumentReference.Count > 0)
            {
                foreach (var item in InstrumentReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CollectionSituation != null && CollectionSituation.Count > 0)
            {
                foreach (var item in CollectionSituation)
                {
                    xEl.Add(item.ToXml("CollectionSituation"));
                }
            }
            if (ActionToMinimizeLosses != null && ActionToMinimizeLosses.Count > 0)
            {
                foreach (var item in ActionToMinimizeLosses)
                {
                    xEl.Add(item.ToXml("ActionToMinimizeLosses"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

