using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An attribute may be any object which should be attached to all or part of the NCube. It may be defined as a Variable or contain textual content (such as a footnote).
    /// <summary>
    public class AttributeType : IdentifiableType
    {
        /// <summary>
        /// A reference to a variable that describes the attribute.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// The value of the attachment expressed as a string, if not a variable.
        /// <summary>
        public string AttachmentValue { get; set; }
        /// <summary>
        /// Reference to the CoordinateRegion that defines the attachment point for the attribute.
        /// <summary>
        public CoordinateRegionType AttachmentRegionReference { get; set; }
        /// <summary>
        /// Reference to the MeasureDefinition that the attribute is attached to.
        /// <summary>
        public List<MeasureDefinitionType> MeasureDefinitionReference { get; set; } = new List<MeasureDefinitionType>();
        public bool ShouldSerializeMeasureDefinitionReference() { return MeasureDefinitionReference.Count > 0; }
        /// <summary>
        /// Reference to the specified Value of the MeasureDefinition that the attribute is attached to.
        /// <summary>
        public List<ValueType> Value { get; set; } = new List<ValueType>();
        public bool ShouldSerializeValue() { return Value.Count > 0; }
        /// <summary>
        /// Describes the attachment level of the attribute as Cube, CoordinateRegion, Dimension, Measurement, or MeasurementValue.
        /// <summary>
        [StringValidation(new string[] {
            "Cube"
,             "CoordinateRegion"
,             "Dimension"
,             "Measurement"
,             "MeasurementValue"
        })]
        public string AttachmentLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (AttachmentValue != null)
            {
                xEl.Add(new XElement(ns + "AttachmentValue", AttachmentValue));
            }
            if (AttachmentRegionReference != null) { xEl.Add(AttachmentRegionReference.ToXml("AttachmentRegionReference")); }
            if (MeasureDefinitionReference != null && MeasureDefinitionReference.Count > 0)
            {
                foreach (var item in MeasureDefinitionReference)
                {
                    xEl.Add(item.ToXml("MeasureDefinitionReference"));
                }
            }
            if (Value != null && Value.Count > 0)
            {
                foreach (var item in Value)
                {
                    xEl.Add(item.ToXml("Value"));
                }
            }
            if (AttachmentLevel != null)
            {
                xEl.Add(new XElement(ns + "AttachmentLevel", AttachmentLevel));
            }
            return xEl;
        }
    }
}

