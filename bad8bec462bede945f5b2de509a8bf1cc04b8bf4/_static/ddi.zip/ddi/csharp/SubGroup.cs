using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The subgroup element is a container for a group that is a child of a higher-level group described in this module, but may also be a parent to other (subordinate) groups. A studyunit can be fully described, or just referenced, within its subgroup container. The purpose of sub-groups is described using the attributes which summarize relationships along the dimensions of time, panel, geography, instrument and language. These attributes allow the purpose to be machine-actionable, while the sub-group also includes an element for describing the purpose in human-readable format. A SubGroup contains a Citation, Abstract, information on authorization, the universe of the sub-group, series statement, quality statements, funding information, purpose, coverage, analysis units covered, kind of data, other materials, and embargo information. It then allows all maintainable structures within the StudyUnit to be expressed at the SubGroup level.
    /// <summary>
    public class SubGroup : Versionable
    {
        /// <summary>
        /// The citation for the sub-group. DDI strongly recommends that at minimum a Title be provided.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// An abstract of the sub-group unit describing the nature and scope of the data collection, special characteristics of its content. Note that detailed information on the purpose of the sub-group and structured coverage information are to be entered in Purpose and Coverage. Abstract supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Abstract { get; set; }
        /// <summary>
        /// Identifies the authorizing agency for the sub-group and allows for the full text of the authorization (law, regulation, or other form of authorization). May be used to list authorizations from oversight committees and other regulatory agencies.
        /// <summary>
        public List<AuthorizationSourceType> AuthorizationSource { get; set; } = new List<AuthorizationSourceType>();
        public bool ShouldSerializeAuthorizationSource() { return AuthorizationSource.Count > 0; }
        /// <summary>
        /// Reference to the universe statement from the universe scheme, describing the sub-group of persons or other elements that are the object of research and to which any analytic results refer. Age, nationality, and residence commonly help to delineate a given universe, but any of a number of factors may be involved, such as sex, race, income, veteran status, criminal convictions, etc. The universe may consist of elements other than persons, such as housing units, court cases, deaths, countries, etc. In general, it should be possible to tell from the description of the universe whether a given individual or element (hypothetical or real) is a member of the population under sub-group. A universe may be described as "inclusive" or "exclusive". This sub-group level reference is normally to the top level of the UniverseScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// A sub-group, particularly one in a series, may be the result of two series merging into a single sub-group. The new sub-group belongs to both series. For example, Niger now fields the UNICEF Multiple Indicators Cluster Survey (MICS) and the Demographic and Health Survey as a single merged instrument.
        /// <summary>
        public List<SeriesStatementType> SeriesStatement { get; set; } = new List<SeriesStatementType>();
        public bool ShouldSerializeSeriesStatement() { return SeriesStatement.Count > 0; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the subgroup overall, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// A reference to a QualityStatementScheme containing statements of quality related to the quality of the sub-group methodology, metadata, or data. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatementScheme> QualityStatementSchemeReference { get; set; } = new List<QualityStatementScheme>();
        public bool ShouldSerializeQualityStatementSchemeReference() { return QualityStatementSchemeReference.Count > 0; }
        /// <summary>
        /// Contains details of the sub-group unit's funding, including information about grants, agencies, etc.
        /// <summary>
        public List<FundingInformationType> FundingInformation { get; set; } = new List<FundingInformationType>();
        public bool ShouldSerializeFundingInformation() { return FundingInformation.Count > 0; }
        /// <summary>
        /// The purpose of the sub-group, why the sub-group took place. This should include detailed information on the investigator's primary sub-group questions or hypotheses as well as information on any legal basis for the data collection, such as laws requiring the collection of census data for apportionment purposes. Legal or other authorization should be provided in detail within AuthorizationSource. Purpose supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Purpose { get; set; }
        /// <summary>
        /// Describes the coverage of the sub-group unit. Detailed information on Topical, Temporal, and Spatial Coverage is contained here. Note that Coverage at this level should be inclusive all lower level modules or section. Lower level descriptions serve to constrain coverage within the scope described here.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Allows the use of a controlled vocabulary to list all of the units of analysis used in the sub-group. Should be repeated to describe multiple units of analysis.
        /// <summary>
        public List<CodeValueType> AnalysisUnit { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeAnalysisUnit() { return AnalysisUnit.Count > 0; }
        /// <summary>
        /// A narrative of the units of analysis in the sub-group unit. Uses an InternationalString to support multiple languages.
        /// <summary>
        public InternationalStringType AnalysisUnitsCovered { get; set; }
        /// <summary>
        /// Briefly describes the kind of data documented in the logical product(s) of a sub-group unit. Examples include survey data, census/enumeration data, administrative data, measurement data, assessment data, demographic data, voting data, etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<KindOfDataType> KindOfData { get; set; } = new List<KindOfDataType>();
        public bool ShouldSerializeKindOfData() { return KindOfData.Count > 0; }
        /// <summary>
        /// Contains references to other materials relevant to the sub-group unit, whether in DDI form or external. Links can be made from items in this section to any identifiable element in the instance. Best practice is to include OtherMaterial inside the maintainable containing the objects that are related to the OtherMaterial.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }
        /// <summary>
        /// Embargo information about the sub-group unit. References to embargo information in this section can be made from individual variables.
        /// <summary>
        public List<EmbargoType> Embargo { get; set; } = new List<EmbargoType>();
        public bool ShouldSerializeEmbargo() { return Embargo.Count > 0; }
        /// <summary>
        /// ConceptualComponent applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualComponent> ConceptualComponentReference { get; set; } = new List<ConceptualComponent>();
        public bool ShouldSerializeConceptualComponentReference() { return ConceptualComponentReference.Count > 0; }
        /// <summary>
        /// DataCollection applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DataCollection> DataCollectionReference { get; set; } = new List<DataCollection>();
        public bool ShouldSerializeDataCollectionReference() { return DataCollectionReference.Count > 0; }
        /// <summary>
        /// LogicalProduct applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<BaseLogicalProduct> LogicalProductReference { get; set; } = new List<BaseLogicalProduct>();
        public bool ShouldSerializeLogicalProductReference() { return LogicalProductReference.Count > 0; }
        /// <summary>
        /// PhysicalDataProduct applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalDataProduct> PhysicalDataProductReference { get; set; } = new List<PhysicalDataProduct>();
        public bool ShouldSerializePhysicalDataProductReference() { return PhysicalDataProductReference.Count > 0; }
        /// <summary>
        /// PhysicalInstance applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<PhysicalInstance> PhysicalInstanceReference { get; set; } = new List<PhysicalInstance>();
        public bool ShouldSerializePhysicalInstanceReference() { return PhysicalInstanceReference.Count > 0; }
        /// <summary>
        /// Archive applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Archive> ArchiveReference { get; set; } = new List<Archive>();
        public bool ShouldSerializeArchiveReference() { return ArchiveReference.Count > 0; }
        /// <summary>
        /// DDIProfile applying to the sub-group as a whole.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DDIProfile> DDIProfileReference { get; set; } = new List<DDIProfile>();
        public bool ShouldSerializeDDIProfileReference() { return DDIProfileReference.Count > 0; }
        /// <summary>
        /// In-line Comparison of differences between related objects in different study units or due to versioning.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Comparison> ComparisonReference { get; set; } = new List<Comparison>();
        public bool ShouldSerializeComparisonReference() { return ComparisonReference.Count > 0; }
        /// <summary>
        /// A StudyUnit within the SubGroup provided in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<StudyUnit> StudyUnitReference { get; set; } = new List<StudyUnit>();
        public bool ShouldSerializeStudyUnitReference() { return StudyUnitReference.Count > 0; }
        /// <summary>
        /// A description of study units comprising a sub-sub-group within the main SubGroup.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SubGroup> SubGroupReference { get; set; } = new List<SubGroup>();
        public bool ShouldSerializeSubGroupReference() { return SubGroupReference.Count > 0; }
        /// <summary>
        /// Indicates how all members of the sub-group are related along the dimension of time (for example single occurrence, multiple occurrence, etc.).
        /// <summary>
        [StringValidation(new string[] {
            "T0"
,             "T1"
,             "T2"
,             "T3"
,             "T4"
,             "T5"
        })]
        public string Time { get; set; }
        /// <summary>
        /// Indicates how all members of the sub-group are related in terms of the instruments used to collect data (single, multiple, etc.).
        /// <summary>
        [StringValidation(new string[] {
            "I0"
,             "I1"
,             "I2"
,             "I3"
        })]
        public string CaptureInstrument { get; set; }
        /// <summary>
        /// Indicates how all members of the sub-group are related in terms of type of panel (single, rolling, etc.).
        /// <summary>
        [StringValidation(new string[] {
            "P0"
,             "P1"
,             "P2"
,             "P3"
,             "P4"
        })]
        public string Panel { get; set; }
        /// <summary>
        /// Indicates how all members of the sub-group are related along the dimension of geography.
        /// <summary>
        [StringValidation(new string[] {
            "G0"
,             "G1"
,             "G2"
,             "G3"
,             "G4"
        })]
        public string Geography { get; set; }
        /// <summary>
        /// Indicates how all members of the sub-group are related in terms of physical data products in relation to data collection efforts.
        /// <summary>
        [StringValidation(new string[] {
            "D0"
,             "D1"
,             "D2"
,             "D3"
,             "D4"
        })]
        public string DataProduct { get; set; }
        /// <summary>
        /// Indicates how all members of the sub-group are related in terms of language relationships such as parallel content in multiple languages, translations (full or partial), etc.
        /// <summary>
        [StringValidation(new string[] {
            "L0"
,             "L1"
,             "L2"
,             "L3"
,             "L4"
,             "L5"
,             "L6"
,             "L7"
        })]
        public string LanguageRelationship { get; set; }
        /// <summary>
        /// Provides a user-defined sub-grouping property, different from those supplied in other attributes.
        /// <summary>
        public string UserDefinedGroupProperty { get; set; }
        /// <summary>
        /// Provides a value for the user-defined sub-group property supplied in userDefinedSubGroupProperty.
        /// <summary>
        public string UserDefinedGroupPropertyValue { get; set; }
        /// <summary>
        /// Default is true, and allows for inheritance of all properties and modules, and the use of lower-level over-rides. If set to false, inheritance is switched off for specific sub-groups.
        /// <summary>
        public bool IsInheritable { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "SubGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (Abstract != null) { xEl.Add(Abstract.ToXml("Abstract")); }
            if (AuthorizationSource != null && AuthorizationSource.Count > 0)
            {
                foreach (var item in AuthorizationSource)
                {
                    xEl.Add(item.ToXml("AuthorizationSource"));
                }
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (SeriesStatement != null && SeriesStatement.Count > 0)
            {
                foreach (var item in SeriesStatement)
                {
                    xEl.Add(item.ToXml("SeriesStatement"));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementSchemeReference != null && QualityStatementSchemeReference.Count > 0)
            {
                foreach (var item in QualityStatementSchemeReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (FundingInformation != null && FundingInformation.Count > 0)
            {
                foreach (var item in FundingInformation)
                {
                    xEl.Add(item.ToXml("FundingInformation"));
                }
            }
            if (Purpose != null) { xEl.Add(Purpose.ToXml("Purpose")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (AnalysisUnit != null && AnalysisUnit.Count > 0)
            {
                foreach (var item in AnalysisUnit)
                {
                    xEl.Add(item.ToXml("AnalysisUnit"));
                }
            }
            if (AnalysisUnitsCovered != null) { xEl.Add(AnalysisUnitsCovered.ToXml("AnalysisUnitsCovered")); }
            if (KindOfData != null && KindOfData.Count > 0)
            {
                foreach (var item in KindOfData)
                {
                    xEl.Add(item.ToXml("KindOfData"));
                }
            }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            if (Embargo != null && Embargo.Count > 0)
            {
                foreach (var item in Embargo)
                {
                    xEl.Add(item.ToXml("Embargo"));
                }
            }
            if (ConceptualComponentReference != null && ConceptualComponentReference.Count > 0)
            {
                foreach (var item in ConceptualComponentReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualComponentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DataCollectionReference != null && DataCollectionReference.Count > 0)
            {
                foreach (var item in DataCollectionReference)
                {
                    xEl.Add(new XElement(ns + "DataCollectionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LogicalProductReference != null && LogicalProductReference.Count > 0)
            {
                foreach (var item in LogicalProductReference)
                {
                    xEl.Add(new XElement(ns + "LogicalProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalDataProductReference != null && PhysicalDataProductReference.Count > 0)
            {
                foreach (var item in PhysicalDataProductReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalDataProductReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (PhysicalInstanceReference != null && PhysicalInstanceReference.Count > 0)
            {
                foreach (var item in PhysicalInstanceReference)
                {
                    xEl.Add(new XElement(ns + "PhysicalInstanceReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ArchiveReference != null && ArchiveReference.Count > 0)
            {
                foreach (var item in ArchiveReference)
                {
                    xEl.Add(new XElement(ns + "ArchiveReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DDIProfileReference != null && DDIProfileReference.Count > 0)
            {
                foreach (var item in DDIProfileReference)
                {
                    xEl.Add(new XElement(ns + "DDIProfileReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ComparisonReference != null && ComparisonReference.Count > 0)
            {
                foreach (var item in ComparisonReference)
                {
                    xEl.Add(new XElement(ns + "ComparisonReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (StudyUnitReference != null && StudyUnitReference.Count > 0)
            {
                foreach (var item in StudyUnitReference)
                {
                    xEl.Add(new XElement(ns + "StudyUnitReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SubGroupReference != null && SubGroupReference.Count > 0)
            {
                foreach (var item in SubGroupReference)
                {
                    xEl.Add(new XElement(ns + "SubGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Time != null)
            {
                xEl.Add(new XElement(ns + "Time", Time));
            }
            if (CaptureInstrument != null)
            {
                xEl.Add(new XElement(ns + "CaptureInstrument", CaptureInstrument));
            }
            if (Panel != null)
            {
                xEl.Add(new XElement(ns + "Panel", Panel));
            }
            if (Geography != null)
            {
                xEl.Add(new XElement(ns + "Geography", Geography));
            }
            if (DataProduct != null)
            {
                xEl.Add(new XElement(ns + "DataProduct", DataProduct));
            }
            if (LanguageRelationship != null)
            {
                xEl.Add(new XElement(ns + "LanguageRelationship", LanguageRelationship));
            }
            if (UserDefinedGroupProperty != null)
            {
                xEl.Add(new XElement(ns + "UserDefinedGroupProperty", UserDefinedGroupProperty));
            }
            if (UserDefinedGroupPropertyValue != null)
            {
                xEl.Add(new XElement(ns + "UserDefinedGroupPropertyValue", UserDefinedGroupPropertyValue));
            }
            xEl.Add(new XElement(ns + "IsInheritable", IsInheritable));
            return xEl;
        }
    }
}

