using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the information needed to identify a specific record or case within a record type. Repeating the field allows multiple means of identifying a case referencing multiple variables.
    /// <summary>
    public class ConditionalIdentifierType
    {
        /// <summary>
        /// Case specification allows different unique identifiers to be used based on the value of an identified variable. In some cases the value of a variable (such as a geographic level) results in a different set of variables required to identify a unique case. Case specification is used to capture these combinations. For example: a file containing State, County, and Place records. The unique identifier for a State requires a combination of GeoLevel=State and the variable STATE. Place would require a combination of GeoLevel=Place and the variables STATE and PLACE.
        /// <summary>
        public List<CaseSpecificationType> CaseSpecification { get; set; } = new List<CaseSpecificationType>();
        public bool ShouldSerializeCaseSpecification() { return CaseSpecification.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CaseSpecification != null && CaseSpecification.Count > 0)
            {
                foreach (var item in CaseSpecification)
                {
                    xEl.Add(item.ToXml("CaseSpecification"));
                }
            }
            return xEl;
        }
    }
}

