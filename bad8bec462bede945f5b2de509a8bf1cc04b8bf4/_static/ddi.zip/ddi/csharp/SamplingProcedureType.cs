using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the type of sample, sample design and provides details on drawing the sample. In addition to the descriptive narrative supports the use of a brief term or controlled vocabulary to classify the type of sampling procedure described.
    /// <summary>
    public class SamplingProcedureType : IdentifiableType
    {
        /// <summary>
        /// Allows brief identification of sampling procedure used with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfSamplingProcedure { get; set; }
        /// <summary>
        /// Full description of the sampling procedure. This may include information on the sample frame, sampling methodology, and procedures for identifying and selecting sub-populations. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingProcedure != null) { xEl.Add(TypeOfSamplingProcedure.ToXml("TypeOfSamplingProcedure")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

