using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An archive specific classification. This may be a topical classification, a classification of intended processing levels, or information on the processing status. Consists of a description of the study class and a term used to specify the class type.
    /// <summary>
    public class StudyClassType
    {
        /// <summary>
        /// A description of the purpose in classifying the object and how it conforms to the classification. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A term used to classify the study class. As these are archive specific, DDI strongly recommends the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType ClassType { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ClassType != null) { xEl.Add(ClassType.ToXml("ClassType")); }
            return xEl;
        }
    }
}

