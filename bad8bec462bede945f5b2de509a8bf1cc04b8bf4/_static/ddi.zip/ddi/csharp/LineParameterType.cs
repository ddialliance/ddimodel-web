using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specification of the line and offset for the beginning and end of the segment.
    /// <summary>
    public class LineParameterType
    {
        /// <summary>
        /// Number of lines from beginning of the document.
        /// <summary>
        public int StartLine { get; set; }
        /// <summary>
        /// Number of characters from start of the line specified in StartLine.
        /// <summary>
        public int StartOffset { get; set; }
        /// <summary>
        /// Number of lines from beginning of the document.
        /// <summary>
        public int EndLine { get; set; }
        /// <summary>
        /// Number of characters from the start of the line specified in EndLine.
        /// <summary>
        public int EndOffset { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "StartLine", StartLine));
            xEl.Add(new XElement(ns + "StartOffset", StartOffset));
            xEl.Add(new XElement(ns + "EndLine", EndLine));
            xEl.Add(new XElement(ns + "EndOffset", EndOffset));
            return xEl;
        }
    }
}

