using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A QuestionBlock is a specific structure used in educational and other types of testing where an object (Stimulus Material) is provided and a set of questions are asked regarding the object. The QuestionBlock generally has related QuestionBlocks that measure similar skills or aptitudes and is used randomly within a set of questionnaires to create multiple versions of a single questionnaire that can be used with large groups for testing purposes. Assembly of the QuestionBlocks into a questionnaire may the result of selection based on an experimental design model. It contains information on what the QuestionBlock is intended to measure, input and output parameters for the QuestionBlock, a description of the stimulus material and the questions related to it, instructions on sequencing and number of allowed responses, references to external aids and instructions, and an estimate of the time needed to complete the question. Note that the QuestionBlock is a reusable format for use in any number of applied uses. External aids, instructions, response sequencing etc. should contain information consistent with the general use of the QuestionBlock (QuestionItems and QuestionGrids will contain information specific to the individual question). Additional materials and information can be added within the QuestionConstruct which is the applied use of a question.
    /// <summary>
    public class QuestionBlock : Versionable
    {
        /// <summary>
        /// A name for the QuestionBlock. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QuestionBlockName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQuestionBlockName() { return QuestionBlockName.Count > 0; }
        /// <summary>
        /// Provides an identity for input objects required for the QuestionBlock.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// Provides an identify for the output objects of the QuestionBlock.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// A structure used to bind the content of a parameter declared as the source to a parameter declared as the target. For example, binding the OutParameter of one Question to the InParameter of another Question in order to personalize a question text. Care should be taken to bind only reusable information at this level. Binding is also available at the QuestionConstruct to reflect bindings particular to the use of the question in a specific question flow or instrument.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// The purpose of the QuestionBlock in terms of what it is designed to test. May contain information on specific aspects of the Block and its construction.
        /// <summary>
        public StructuredStringType QuestionBlockIntent { get; set; }
        /// <summary>
        /// Material that is visual, verbal and/or auditory used to communicate ideas or information which can be researched or provide a source for a response. For example, a picture about which a number of questions are asked, or a sound for which a measurable response is taken (as in a hearing test).
        /// <summary>
        public OtherMaterialType StimulusMaterial { get; set; }
        /// <summary>
        /// Reference to a QuestionItem containing a question regarding the stimulus material.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public QuestionItem QuestionItemReference { get; set; }
        /// <summary>
        /// Reference to a QuestionGrid containing a question regarding the stimulus material.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public QuestionGrid QuestionGridReference { get; set; }
        /// <summary>
        /// Allows for recommending that the sequence of questions should vary according to a specified pattern, i.e., random, rotation, etc.
        /// <summary>
        public QuestionSequenceType QuestionSequence { get; set; }
        /// <summary>
        /// Indicates the minimum and maximum number of responses to expect from the QuestionBlock.
        /// <summary>
        public ResponseCardinalityType ResponseCardinality { get; set; }
        /// <summary>
        /// A reference to the concept the QuestionBlock is intended to gather data on.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> ConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeConceptReference() { return ConceptReference.Count > 0; }
        /// <summary>
        /// A pointer to an external aid presented by the instrument such as a text card, image, audio, or audiovisual aid. Typically a URN. Use type attribute to describe the type of external aid provided. Example of terms to use would include: imageOnly audioOnly audioVisual multiMedia.
        /// <summary>
        public List<OtherMaterialType> ExternalAid { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeExternalAid() { return ExternalAid.Count > 0; }
        /// <summary>
        /// External reference to an interviewer instruction not expressed as DDI XML using OtherMaterial.
        /// <summary>
        public ExternalInterviewerInstructionType ExternalInterviewerInstruction { get; set; }
        /// <summary>
        /// Reference to an interviewer instruction expressed as DDI XML.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instruction InterviewerInstructionReference { get; set; }
        /// <summary>
        /// The estimated amount of time required to answer a question expressed in seconds. Decimal values should be used to define fractions of seconds.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "QuestionBlock");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QuestionBlockName != null && QuestionBlockName.Count > 0)
            {
                foreach (var item in QuestionBlockName)
                {
                    xEl.Add(item.ToXml("QuestionBlockName"));
                }
            }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (QuestionBlockIntent != null) { xEl.Add(QuestionBlockIntent.ToXml("QuestionBlockIntent")); }
            if (StimulusMaterial != null) { xEl.Add(StimulusMaterial.ToXml("StimulusMaterial")); }
            if (QuestionItemReference != null)
            {
                xEl.Add(new XElement(ns + "QuestionItemReference", 
                    new XElement(ns + "URN", QuestionItemReference.URN), 
                    new XElement(ns + "Agency", QuestionItemReference.Agency), 
                    new XElement(ns + "ID", QuestionItemReference.ID), 
                    new XElement(ns + "Version", QuestionItemReference.Version), 
                    new XElement(ns + "TypeOfObject", QuestionItemReference.GetType().Name)));
            }
            if (QuestionGridReference != null)
            {
                xEl.Add(new XElement(ns + "QuestionGridReference", 
                    new XElement(ns + "URN", QuestionGridReference.URN), 
                    new XElement(ns + "Agency", QuestionGridReference.Agency), 
                    new XElement(ns + "ID", QuestionGridReference.ID), 
                    new XElement(ns + "Version", QuestionGridReference.Version), 
                    new XElement(ns + "TypeOfObject", QuestionGridReference.GetType().Name)));
            }
            if (QuestionSequence != null) { xEl.Add(QuestionSequence.ToXml("QuestionSequence")); }
            if (ResponseCardinality != null) { xEl.Add(ResponseCardinality.ToXml("ResponseCardinality")); }
            if (ConceptReference != null && ConceptReference.Count > 0)
            {
                foreach (var item in ConceptReference)
                {
                    xEl.Add(new XElement(ns + "ConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalAid != null && ExternalAid.Count > 0)
            {
                foreach (var item in ExternalAid)
                {
                    xEl.Add(item.ToXml("ExternalAid"));
                }
            }
            if (ExternalInterviewerInstruction != null) { xEl.Add(ExternalInterviewerInstruction.ToXml("ExternalInterviewerInstruction")); }
            if (InterviewerInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "InterviewerInstructionReference", 
                    new XElement(ns + "URN", InterviewerInstructionReference.URN), 
                    new XElement(ns + "Agency", InterviewerInstructionReference.Agency), 
                    new XElement(ns + "ID", InterviewerInstructionReference.ID), 
                    new XElement(ns + "Version", InterviewerInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", InterviewerInstructionReference.GetType().Name)));
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

