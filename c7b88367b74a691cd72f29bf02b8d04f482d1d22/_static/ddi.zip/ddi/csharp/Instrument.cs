using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the type of instrument used for data collection or capture. In addition to the standard name, label, and description contains a classification of the type of instrument, a reference to an external instance of the instrument (such as an image of a questionnaire or programming script) and a reference to the Sequence control construct that contains the flow for data collection or capture.
    /// <summary>
    public partial class Instrument : Versionable
    {
        /// <summary>
        /// A name for the Instrument. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> InstrumentName { get; set; } = new List<NameType>();
        public bool ShouldSerializeInstrumentName() { return InstrumentName.Count > 0; }
        /// <summary>
        /// A display label for the Instrument. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the Instrument. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describes the type of the instrument, according to the documenters type classification. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfInstrument { get; set; }
        /// <summary>
        /// A reference to an external representation of the data collection instrument, such as an image of a questionnaire or programming script.
        /// <summary>
        public List<Uri> ExternalInstrumentLocation { get; set; } = new List<Uri>();
        public bool ShouldSerializeExternalInstrumentLocation() { return ExternalInstrumentLocation.Count > 0; }
        /// <summary>
        /// A reference to the Sequence control construct that initiates the flow of the instrument content.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ControlConstruct ControlConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Instrument");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (InstrumentName != null && InstrumentName.Count > 0)
            {
                foreach (var item in InstrumentName)
                {
                    xEl.Add(item.ToXml("InstrumentName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (TypeOfInstrument != null) { xEl.Add(TypeOfInstrument.ToXml("TypeOfInstrument")); }
            if (ExternalInstrumentLocation != null && ExternalInstrumentLocation.Count > 0)
            {
                foreach (var item in ExternalInstrumentLocation)
                {
                    xEl.Add(new XElement(ns + "ExternalInstrumentLocation", item));
                }
            }
            if (ControlConstructReference != null)
            {
                xEl.Add(new XElement(ns + "ControlConstructReference", 
                    new XElement(ns + "URN", ControlConstructReference.URN), 
                    new XElement(ns + "Agency", ControlConstructReference.Agency), 
                    new XElement(ns + "ID", ControlConstructReference.ID), 
                    new XElement(ns + "Version", ControlConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", ControlConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

