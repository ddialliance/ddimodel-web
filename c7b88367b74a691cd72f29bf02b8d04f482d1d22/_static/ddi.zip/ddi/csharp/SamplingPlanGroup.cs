using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a group of sampling plans, which may be hierarchical.
    /// <summary>
    public partial class SamplingPlanGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a sampling plan group. Note that this element can contain either a term from a controlled vocabulary list or a textual description. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public CodeValueType TypeOfSamplingPlanGroup { get; set; }
        /// <summary>
        /// A name for a sampling plan group which may be repeated to express differing names for different systems.
        /// <summary>
        public List<NameType> SamplingPlanGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSamplingPlanGroupName() { return SamplingPlanGroupName.Count > 0; }
        /// <summary>
        /// A display label for the sampling plan group. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Additional textual description of the sampling plan group. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other elements that the sampling plans refer to, and to which any analytic results refer.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept measured by the sampling plans in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to constituent SamplingPlan.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlan SamplingPlanReference { get; set; }
        /// <summary>
        /// Reference to constituent sampling plan group. This allows for nesting of sampling plan groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlanGroup SamplingPlanGroupReference { get; set; }
        /// <summary>
        /// Indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingPlanGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingPlanGroup != null) { xEl.Add(TypeOfSamplingPlanGroup.ToXml("TypeOfSamplingPlanGroup")); }
            if (SamplingPlanGroupName != null && SamplingPlanGroupName.Count > 0)
            {
                foreach (var item in SamplingPlanGroupName)
                {
                    xEl.Add(item.ToXml("SamplingPlanGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (SamplingPlanReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanReference", 
                    new XElement(ns + "URN", SamplingPlanReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanReference.ID), 
                    new XElement(ns + "Version", SamplingPlanReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanReference.GetType().Name)));
            }
            if (SamplingPlanGroupReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanGroupReference", 
                    new XElement(ns + "URN", SamplingPlanGroupReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanGroupReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanGroupReference.ID), 
                    new XElement(ns + "Version", SamplingPlanGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

