using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of sampling plans maintained by an agency, and used in the instrument.
    /// <summary>
    public partial class SamplingPlanScheme : Maintainable
    {
        /// <summary>
        /// A name for a sampling plan scheme which may be repeated to express differing names for different systems. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SamplingPlanSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSamplingPlanSchemeName() { return SamplingPlanSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the sampling plan scheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the use of the sampling plan scheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides for inclusion by reference of external sampling plan schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingPlanScheme> SamplingPlanSchemeReference { get; set; } = new List<SamplingPlanScheme>();
        public bool ShouldSerializeSamplingPlanSchemeReference() { return SamplingPlanSchemeReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sampling plan) belonging to the sampling plan scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingPlan> SamplingPlanReference { get; set; } = new List<SamplingPlan>();
        public bool ShouldSerializeSamplingPlanReference() { return SamplingPlanReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sampling plan) belonging to the sampling plan Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingPlanGroup> SamplingPlanGroupReference { get; set; } = new List<SamplingPlanGroup>();
        public bool ShouldSerializeSamplingPlanGroupReference() { return SamplingPlanGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingPlanScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SamplingPlanSchemeName != null && SamplingPlanSchemeName.Count > 0)
            {
                foreach (var item in SamplingPlanSchemeName)
                {
                    xEl.Add(item.ToXml("SamplingPlanSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SamplingPlanSchemeReference != null && SamplingPlanSchemeReference.Count > 0)
            {
                foreach (var item in SamplingPlanSchemeReference)
                {
                    xEl.Add(new XElement(ns + "SamplingPlanSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingPlanReference != null && SamplingPlanReference.Count > 0)
            {
                foreach (var item in SamplingPlanReference)
                {
                    xEl.Add(new XElement(ns + "SamplingPlanReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingPlanGroupReference != null && SamplingPlanGroupReference.Count > 0)
            {
                foreach (var item in SamplingPlanGroupReference)
                {
                    xEl.Add(new XElement(ns + "SamplingPlanGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

