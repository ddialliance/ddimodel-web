using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of sample frames maintained by an agency, and used in the instrument.
    /// <summary>
    public partial class SampleFrameScheme : Maintainable
    {
        /// <summary>
        /// A name for the sample frame scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SampleFrameSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSampleFrameSchemeName() { return SampleFrameSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the sample frame scheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the use of the sample frame scheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides for inclusion by reference of external sample frame schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrameScheme> SampleFrameSchemeReference { get; set; } = new List<SampleFrameScheme>();
        public bool ShouldSerializeSampleFrameSchemeReference() { return SampleFrameSchemeReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sample frame) belonging to the sample frame Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> SampleFrameReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeSampleFrameReference() { return SampleFrameReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sample frame group) belonging to the sample frame Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrameGroup> SampleFrameGroupReference { get; set; } = new List<SampleFrameGroup>();
        public bool ShouldSerializeSampleFrameGroupReference() { return SampleFrameGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SampleFrameScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SampleFrameSchemeName != null && SampleFrameSchemeName.Count > 0)
            {
                foreach (var item in SampleFrameSchemeName)
                {
                    xEl.Add(item.ToXml("SampleFrameSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SampleFrameSchemeReference != null && SampleFrameSchemeReference.Count > 0)
            {
                foreach (var item in SampleFrameSchemeReference)
                {
                    xEl.Add(new XElement(ns + "SampleFrameSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleFrameReference != null && SampleFrameReference.Count > 0)
            {
                foreach (var item in SampleFrameReference)
                {
                    xEl.Add(new XElement(ns + "SampleFrameReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleFrameGroupReference != null && SampleFrameGroupReference.Count > 0)
            {
                foreach (var item in SampleFrameGroupReference)
                {
                    xEl.Add(new XElement(ns + "SampleFrameGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

