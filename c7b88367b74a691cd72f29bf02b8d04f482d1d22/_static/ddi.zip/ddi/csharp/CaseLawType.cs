using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Refers to a case law ruling related to the Classification Item. 
    /// <summary>
    public partial class CaseLawType
    {
        /// <summary>
        /// Case Law Name
        /// <summary>
        public List<NameType> CaseLawName { get; set; } = new List<NameType>();
        public bool ShouldSerializeCaseLawName() { return CaseLawName.Count > 0; }
        /// <summary>
        /// A description of the case law
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Date of the case law ruling
        /// <summary>
        public CogsDate CaseLawDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (CaseLawName != null && CaseLawName.Count > 0)
            {
                foreach (var item in CaseLawName)
                {
                    xEl.Add(item.ToXml("CaseLawName"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CaseLawDate != null && CaseLawDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "CaseLawDate", CaseLawDate.ToString()));
            }
            return xEl;
        }
    }
}

