using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a ConceptualVariable which provides the link between a concept to a specific universe (object) that defines this as a ConceptualVariable. In addition to the standard name, label, and description, it provides the two primary components of a ConceptualVariable by referencing a concept and its related universe. Note that the concept referenced may itself contain sub-concepts and/or references to similar concepts. This maps to the GSIM ConceptualVariable and has a basis in the ISO/IEC 11179 RepresentedVariableConcept.
    /// <summary>
    public partial class ConceptualVariable : Versionable
    {
        /// <summary>
        /// A name for the ConceptualVariable. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptualVariableName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptualVariableName() { return ConceptualVariableName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptualVariable. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ConceptualVariable. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to a Concept that is being linked to a Universe identified by the UniverseReference. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to a unit type being associated with this conceptual variable. TypeOfObject should be set to UnitType.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public UnitType UnitTypeReference { get; set; }
        /// <summary>
        /// Reference to a previously created category scheme that represents the conceptual variable's enumerated conceptual domain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ConceptualVariable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptualVariableName != null && ConceptualVariableName.Count > 0)
            {
                foreach (var item in ConceptualVariableName)
                {
                    xEl.Add(item.ToXml("ConceptualVariableName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (UnitTypeReference != null)
            {
                xEl.Add(new XElement(ns + "UnitTypeReference", 
                    new XElement(ns + "URN", UnitTypeReference.URN), 
                    new XElement(ns + "Agency", UnitTypeReference.Agency), 
                    new XElement(ns + "ID", UnitTypeReference.ID), 
                    new XElement(ns + "Version", UnitTypeReference.Version), 
                    new XElement(ns + "TypeOfObject", UnitTypeReference.GetType().Name)));
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

