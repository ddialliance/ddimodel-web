using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of the process used to generate the category content. Includes a reference to component parts, a description of the generation process, a structured command, and other materials that are needed in the generation process. The item may be designated as a derivation process (default value) and be qualified in some way by a qualification attribute.
    /// <summary>
    public partial class GenerationType
    {
        /// <summary>
        /// Reference to a category used in the generation process.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Category> ComponentReference { get; set; } = new List<Category>();
        public bool ShouldSerializeComponentReference() { return ComponentReference.Count > 0; }
        /// <summary>
        /// A description of the generation process. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Structured information used by a system to generate the category.
        /// <summary>
        public List<CommandCodeType> CommandCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeCommandCode() { return CommandCode.Count > 0; }
        /// <summary>
        /// External documentation required for creating the generation - for example, a chart or table for defining poverty.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterial> OtherMaterialReference { get; set; } = new List<OtherMaterial>();
        public bool ShouldSerializeOtherMaterialReference() { return OtherMaterialReference.Count > 0; }
        /// <summary>
        /// If not a derivation process set this attribute to "false".
        /// <summary>
        public bool IsDerived { get; set; }
        /// <summary>
        /// A qualification for the generation process expressed as a simple string.
        /// <summary>
        public string Qualification { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ComponentReference != null && ComponentReference.Count > 0)
            {
                foreach (var item in ComponentReference)
                {
                    xEl.Add(new XElement(ns + "ComponentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CommandCode != null && CommandCode.Count > 0)
            {
                foreach (var item in CommandCode)
                {
                    xEl.Add(item.ToXml("CommandCode"));
                }
            }
            if (OtherMaterialReference != null && OtherMaterialReference.Count > 0)
            {
                foreach (var item in OtherMaterialReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "IsDerived", IsDerived));
            if (Qualification != null)
            {
                xEl.Add(new XElement(ns + "Qualification", Qualification));
            }
            return xEl;
        }
    }
}

