using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The unfiltered values of any number of statistics by category value representing the full response distribution of the variable.
    /// <summary>
    public partial class UnfilteredCategoryStatisticsType
    {
        /// <summary>
        /// A structure that is repeated for each category value for which one or more statistics are recorded. Each VariableCategory has one category value and any number of associated statistics.
        /// <summary>
        public List<VariableCategoryType> VariableCategory { get; set; } = new List<VariableCategoryType>();
        public bool ShouldSerializeVariableCategory() { return VariableCategory.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableCategory != null && VariableCategory.Count > 0)
            {
                foreach (var item in VariableCategory)
                {
                    xEl.Add(item.ToXml("VariableCategory"));
                }
            }
            return xEl;
        }
    }
}

