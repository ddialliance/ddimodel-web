using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This is an abstract structure which serves as a substitution base for current and future LogicalProduct definitions relating to specific data types. Used as an extension base for all other LogicalProducts within its substitution group, it ensures that all DDI LogicalProduct descriptions will contain a consistent means of linking a physical data file to its logical (intellectual) description via the LogicalRecord found in DataRelationship. The extension base includes the standard name, label, and description, coverage information, a structure to define data relationships (identifies each logical record and the relationship(s) between them), as well as OtherMaterial related to its contents.
    /// <summary>
    public partial class BaseLogicalProduct : Maintainable
    {

        /// <summary>
        /// Set the TypeDescriminator
        /// <summary>
        public BaseLogicalProduct() { this.TypeDescriminator = this.GetType().Name; }

        /// <summary>
        /// Type descriminator for json serialization
        /// <summary>
        [JsonProperty("$type")]
        public string TypeDescriminator { get; set; }

        /// <summary>
        /// A name for the LogicalProduct. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> LogicalProductName { get; set; } = new List<NameType>();
        public bool ShouldSerializeLogicalProductName() { return LogicalProductName.Count > 0; }
        /// <summary>
        /// A display label for the LogicalProduct. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the LogicalProduct. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// The Coverage statement at this level may be used to restrict the coverage described in the StudyUnit module. For example if this specific logical product from a population and housing census only covers housing questions or only provides State and County level data these should be noted here. If there are no changes in the coverage from the coverage of the StudyUnit module, no entry is needed here.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Contains a written description of how the logical contents of the file relate to each other for programming purposes. For example, noting that there are household, family and person items where the household is identified by variable, the unique family by the concatenation of variable_H and variable_F, and the unique person within a household by the concatenation of variable_H and variable_P.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DataRelationship> DataRelationshipReference { get; set; } = new List<DataRelationship>();
        public bool ShouldSerializeDataRelationshipReference() { return DataRelationshipReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "BaseLogicalProduct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (LogicalProductName != null && LogicalProductName.Count > 0)
            {
                foreach (var item in LogicalProductName)
                {
                    xEl.Add(item.ToXml("LogicalProductName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (DataRelationshipReference != null && DataRelationshipReference.Count > 0)
            {
                foreach (var item in DataRelationshipReference)
                {
                    xEl.Add(new XElement(ns + "DataRelationshipReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

