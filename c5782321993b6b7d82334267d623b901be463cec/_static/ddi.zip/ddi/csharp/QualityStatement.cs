using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A statement of quality which may be related to an external standard or contain a simple statement of internal quality goals or expectations. When relating to an external standard information on compliance may be added providing a reference to a ComplianceConcept, an ExternalComplianceCode, as well as a description. Optionally, a general statement of quality may be provided using OtherQualityStatement.
    /// <summary>
    public partial class QualityStatement : Versionable
    {
        /// <summary>
        /// Name of the QualityStatement using the DDI Name structure.
        /// <summary>
        public List<NameType> QualityStatementName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQualityStatementName() { return QualityStatementName.Count > 0; }
        /// <summary>
        /// A display label for the QualityStatement. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the QualityStatement. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A formal description of a quality standard, and the quality concepts which it requires.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public QualityStandard QualityStandardReference { get; set; }
        /// <summary>
        /// Describes the steps taken to ensure quality that are not related to a specific standard. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat the OtherQualityStatement for differing content if needed.
        /// <summary>
        public StructuredStringType OtherStatementOfQuality { get; set; }
        /// <summary>
        /// A descriptive statement regarding the application of the selected standard or other means of quality control.
        /// <summary>
        public StructuredStringType ComplianceStatement { get; set; }
        /// <summary>
        /// Allows for a quality statement based on frameworks to be described using itemized properties. A reference to a concept, a coded value, or both can be used to specify the property from the standard framework identified in StandardUsed. ComplianceDescription can provide further details or a general description of compliance with a standard.
        /// <summary>
        public List<ComplianceType> Compliance { get; set; } = new List<ComplianceType>();
        public bool ShouldSerializeCompliance() { return Compliance.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QualityStatement");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QualityStatementName != null && QualityStatementName.Count > 0)
            {
                foreach (var item in QualityStatementName)
                {
                    xEl.Add(item.ToXml("QualityStatementName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (QualityStandardReference != null)
            {
                xEl.Add(new XElement(ns + "QualityStandardReference", 
                    new XElement(ns + "URN", QualityStandardReference.URN), 
                    new XElement(ns + "Agency", QualityStandardReference.Agency), 
                    new XElement(ns + "ID", QualityStandardReference.ID), 
                    new XElement(ns + "Version", QualityStandardReference.Version), 
                    new XElement(ns + "TypeOfObject", QualityStandardReference.GetType().Name)));
            }
            if (OtherStatementOfQuality != null) { xEl.Add(OtherStatementOfQuality.ToXml("OtherStatementOfQuality")); }
            if (ComplianceStatement != null) { xEl.Add(ComplianceStatement.ToXml("ComplianceStatement")); }
            if (Compliance != null && Compliance.Count > 0)
            {
                foreach (var item in Compliance)
                {
                    xEl.Add(item.ToXml("Compliance"));
                }
            }
            return xEl;
        }
    }
}

