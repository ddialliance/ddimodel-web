using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// For each dimension in the grid define the applicable values as "all values", a "specific value" or a range. If a rangeMinimum or rangeMaximum is provided without the other, the assumption is unbounded for the object not included.
    /// <summary>
    public partial class SelectDimensionType
    {
        /// <summary>
        /// The rank value of the dimension for which the selection criteria apply.
        /// <summary>
        public int Rank { get; set; }
        /// <summary>
        /// If set to "true" applies to the full set of dimension values. If set to "false" use specificValue, rangeMinimum and rangeMaximum as appropriate to define the subset of values needed.
        /// <summary>
        public bool AllValues { get; set; }
        /// <summary>
        /// May contain a single value or a delimited array of values.
        /// <summary>
        public string SpecificValue { get; set; }
        /// <summary>
        /// The inclusive minimum value of the range. Use when the values or subset of values are ordered and contiguous and may be expressed as a range.
        /// <summary>
        public string RangeMinimum { get; set; }
        /// <summary>
        /// The inclusive maximum value of the range. Use when the values or subset of values are ordered and contiguous and may be expressed as a range.
        /// <summary>
        public string RangeMaximum { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "Rank", Rank));
            xEl.Add(new XElement(ns + "AllValues", AllValues));
            if (SpecificValue != null)
            {
                xEl.Add(new XElement(ns + "SpecificValue", SpecificValue));
            }
            if (RangeMinimum != null)
            {
                xEl.Add(new XElement(ns + "RangeMinimum", RangeMinimum));
            }
            if (RangeMaximum != null)
            {
                xEl.Add(new XElement(ns + "RangeMaximum", RangeMaximum));
            }
            return xEl;
        }
    }
}

