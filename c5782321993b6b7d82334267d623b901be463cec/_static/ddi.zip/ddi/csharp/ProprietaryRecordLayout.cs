using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the BaseRecordLayout substitution group intended for use when the data items are stored in an external proprietary format. In addition to the link to the PhysicalStructure provided by BaseRecordLayout, the record layout is this namespace (m4) identifies the character set and array base for the external data, identifies the software of the proprietary system, provides a description of how the data item is addressed within the system, provides default values for numeric data types, text data types, dateTime data types, whether coded data should be treated as numeric or text, a default variable scheme, proprietary information, and a full description of each data item including its link to the variable description and system address.
    /// <summary>
    public partial class ProprietaryRecordLayout : BaseRecordLayout
    {
        /// <summary>
        /// Character set used in the data file (e.g., US ASCII, EBCDIC, UTF-8). This is a required field. The DDI Alliance has provided a controlled vocabulary (CharacterSet) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType CharacterSet { get; set; }
        /// <summary>
        /// Sets the array base for any arrays used in the definition (that is, whether the first value is in position 0 or 1, etc.). This may be the data array in a delimited data file or the measure array for measures that are bundled and stored in a single location. Array base is generally set to either 0 or 1. There is no override provided as systems processing a record would use a consistent array base.
        /// <summary>
        public int ArrayBase { get; set; }
        /// <summary>
        /// Specification of a software package used to instantiate a data collection method.
        /// <summary>
        public SoftwareType SystemSoftware { get; set; }
        /// <summary>
        /// Provides minimum information on data item address system, such as variable ID or Name, etc.
        /// <summary>
        public DataItemAddressType DataItemAddress { get; set; }
        /// <summary>
        /// Declares the most common data type used for numeric data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation DefaultNumericDataTypeReference { get; set; }
        /// <summary>
        /// Declares the most common data type used for textual data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation DefaultTextDataTypeReference { get; set; }
        /// <summary>
        /// Declares the most common data type used for date-time data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation DefaultDateTimeDataTypeReference { get; set; }
        /// <summary>
        /// Indicates that coded data should be treated as numeric, and defines the numeric type.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation CodedDataAsNumeric { get; set; }
        /// <summary>
        /// Indicates that coded data should be treated as text, and defines the text type.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation CodedDataAsText { get; set; }
        /// <summary>
        /// References a variable scheme for the RecordLayout. This can be overridden by individual data items if they are from a different variable scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public VariableScheme DefaultVariableSchemeReference { get; set; }
        /// <summary>
        /// Contains information proprietary to the software package which produced the data file. This is expressed as a set of key(name)/ value pairs.
        /// <summary>
        public ProprietaryInfoType ProprietaryInfo { get; set; }
        /// <summary>
        /// Describes a single data item within the file including its variable reference, information on the data type, and any item specific proprietary information.
        /// <summary>
        public List<DataItemPType> DataItemP { get; set; } = new List<DataItemPType>();
        public bool ShouldSerializeDataItemP() { return DataItemP.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ProprietaryRecordLayout");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CharacterSet != null) { xEl.Add(CharacterSet.ToXml("CharacterSet")); }
            xEl.Add(new XElement(ns + "ArrayBase", ArrayBase));
            if (SystemSoftware != null) { xEl.Add(SystemSoftware.ToXml("SystemSoftware")); }
            if (DataItemAddress != null) { xEl.Add(DataItemAddress.ToXml("DataItemAddress")); }
            if (DefaultNumericDataTypeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultNumericDataTypeReference", 
                    new XElement(ns + "URN", DefaultNumericDataTypeReference.URN), 
                    new XElement(ns + "Agency", DefaultNumericDataTypeReference.Agency), 
                    new XElement(ns + "ID", DefaultNumericDataTypeReference.ID), 
                    new XElement(ns + "Version", DefaultNumericDataTypeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultNumericDataTypeReference.GetType().Name)));
            }
            if (DefaultTextDataTypeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultTextDataTypeReference", 
                    new XElement(ns + "URN", DefaultTextDataTypeReference.URN), 
                    new XElement(ns + "Agency", DefaultTextDataTypeReference.Agency), 
                    new XElement(ns + "ID", DefaultTextDataTypeReference.ID), 
                    new XElement(ns + "Version", DefaultTextDataTypeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultTextDataTypeReference.GetType().Name)));
            }
            if (DefaultDateTimeDataTypeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultDateTimeDataTypeReference", 
                    new XElement(ns + "URN", DefaultDateTimeDataTypeReference.URN), 
                    new XElement(ns + "Agency", DefaultDateTimeDataTypeReference.Agency), 
                    new XElement(ns + "ID", DefaultDateTimeDataTypeReference.ID), 
                    new XElement(ns + "Version", DefaultDateTimeDataTypeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultDateTimeDataTypeReference.GetType().Name)));
            }
            if (CodedDataAsNumeric != null)
            {
                xEl.Add(new XElement(ns + "CodedDataAsNumeric", 
                    new XElement(ns + "URN", CodedDataAsNumeric.URN), 
                    new XElement(ns + "Agency", CodedDataAsNumeric.Agency), 
                    new XElement(ns + "ID", CodedDataAsNumeric.ID), 
                    new XElement(ns + "Version", CodedDataAsNumeric.Version), 
                    new XElement(ns + "TypeOfObject", CodedDataAsNumeric.GetType().Name)));
            }
            if (CodedDataAsText != null)
            {
                xEl.Add(new XElement(ns + "CodedDataAsText", 
                    new XElement(ns + "URN", CodedDataAsText.URN), 
                    new XElement(ns + "Agency", CodedDataAsText.Agency), 
                    new XElement(ns + "ID", CodedDataAsText.ID), 
                    new XElement(ns + "Version", CodedDataAsText.Version), 
                    new XElement(ns + "TypeOfObject", CodedDataAsText.GetType().Name)));
            }
            if (DefaultVariableSchemeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultVariableSchemeReference", 
                    new XElement(ns + "URN", DefaultVariableSchemeReference.URN), 
                    new XElement(ns + "Agency", DefaultVariableSchemeReference.Agency), 
                    new XElement(ns + "ID", DefaultVariableSchemeReference.ID), 
                    new XElement(ns + "Version", DefaultVariableSchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultVariableSchemeReference.GetType().Name)));
            }
            if (ProprietaryInfo != null) { xEl.Add(ProprietaryInfo.ToXml("ProprietaryInfo")); }
            if (DataItemP != null && DataItemP.Count > 0)
            {
                foreach (var item in DataItemP)
                {
                    xEl.Add(item.ToXml("DataItemP"));
                }
            }
            return xEl;
        }
    }
}

