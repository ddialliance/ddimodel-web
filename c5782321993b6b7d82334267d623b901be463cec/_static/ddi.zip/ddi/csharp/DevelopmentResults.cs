using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Separates the capture of development implementation results from the process plan and general activities. Allows for capture of the overall results, details of individual steps, or separate iterations of that step.
    /// <summary>
    public partial class DevelopmentResults : Versionable
    {
        /// <summary>
        /// A name for the DevelopmentResults. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentResultsName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentResultsName() { return DevelopmentResultsName.Count > 0; }
        /// <summary>
        /// A display label for the Development Results. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the overall Development Results. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// References the Development Implementation which the results refer to. TypeOfObject should be DevelopmentImplementation
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentImplementation> DevelopmentImplementationReference { get; set; } = new List<DevelopmentImplementation>();
        public bool ShouldSerializeDevelopmentImplementationReference() { return DevelopmentImplementationReference.Count > 0; }
        /// <summary>
        /// The date or date range of obtaining results from the development work.
        /// <summary>
        public DateType ResultsDate { get; set; }
        /// <summary>
        /// Details of specific results of the development plan and process. May refer to specific development activities or DevelopmentSteps within a DevelopmentProcess.
        /// <summary>
        public List<ResultDetailType> ResultDetail { get; set; } = new List<ResultDetailType>();
        public bool ShouldSerializeResultDetail() { return ResultDetail.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentResults");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentResultsName != null && DevelopmentResultsName.Count > 0)
            {
                foreach (var item in DevelopmentResultsName)
                {
                    xEl.Add(item.ToXml("DevelopmentResultsName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentImplementationReference != null && DevelopmentImplementationReference.Count > 0)
            {
                foreach (var item in DevelopmentImplementationReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentImplementationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResultsDate != null) { xEl.Add(ResultsDate.ToXml("ResultsDate")); }
            if (ResultDetail != null && ResultDetail.Count > 0)
            {
                foreach (var item in ResultDetail)
                {
                    xEl.Add(item.ToXml("ResultDetail"));
                }
            }
            return xEl;
        }
    }
}

