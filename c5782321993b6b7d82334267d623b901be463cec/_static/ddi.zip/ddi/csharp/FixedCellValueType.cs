using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the ability to fix the value of a grid cell and defines the cell or cells. Designates the fixed value to be used and the location of the cell or cells within the grid.
    /// <summary>
    public partial class FixedCellValueType
    {
        /// <summary>
        /// Identifies the value to which the cell(s) defined in GridAttachment should be fixed. Supports the use of meaningful leading or trailing spaces. Note that care should be taken to make sure this is a valid value within the response domain of the cell.
        /// <summary>
        public ValueType Value { get; set; }
        /// <summary>
        /// Identifies the cell or cells in a grid to which the label is attached by a reference to a specific cell coordinate in a grid or by identifying a range of values along a dimension.
        /// <summary>
        public List<GridAttachmentType> GridAttachment { get; set; } = new List<GridAttachmentType>();
        public bool ShouldSerializeGridAttachment() { return GridAttachment.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            if (GridAttachment != null && GridAttachment.Count > 0)
            {
                foreach (var item in GridAttachment)
                {
                    xEl.Add(item.ToXml("GridAttachment"));
                }
            }
            return xEl;
        }
    }
}

