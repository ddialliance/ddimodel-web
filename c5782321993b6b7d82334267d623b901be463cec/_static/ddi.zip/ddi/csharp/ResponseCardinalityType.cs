using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Indicates the minimum and maximum number of occurrences of a response within the given parameters.
    /// <summary>
    public partial class ResponseCardinalityType
    {
        /// <summary>
        /// Minimum number of responses accepted expressed and an integer.
        /// <summary>
        public int MinimumResponses { get; set; }
        /// <summary>
        /// Maximum number of responses accepted expressed and an integer.
        /// <summary>
        public int MaximumResponses { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "MinimumResponses", MinimumResponses));
            xEl.Add(new XElement(ns + "MaximumResponses", MaximumResponses));
            return xEl;
        }
    }
}

