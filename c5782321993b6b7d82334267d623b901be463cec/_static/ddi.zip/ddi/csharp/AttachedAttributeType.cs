using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// References the attribute description in the NCube and provides for a choice between describing an explicit value, or a location in a file where the value can be found.
    /// <summary>
    public partial class AttachedAttributeType
    {
        /// <summary>
        /// Reference to the attribute described in an NCube.
        /// <summary>
        public AttributeType AttributeReference { get; set; }
        /// <summary>
        /// Description of the physical location of the attribute value in the data file.
        /// <summary>
        public PhysicalLocationType PhysicalLocation { get; set; }
        /// <summary>
        /// Contains the value for the attribute.
        /// <summary>
        public ValueType Value { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (AttributeReference != null) { xEl.Add(AttributeReference.ToXml("AttributeReference")); }
            if (PhysicalLocation != null) { xEl.Add(PhysicalLocation.ToXml("PhysicalLocation")); }
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            return xEl;
        }
    }
}

