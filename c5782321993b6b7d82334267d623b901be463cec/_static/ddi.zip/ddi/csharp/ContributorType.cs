using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Holds the name of the contributor, their role, and optional reference to the contributor as described within a DDI Organization scheme. Repeat this element for multiple creators.
    /// <summary>
    public partial class ContributorType
    {
        /// <summary>
        /// Full name of the contributor. Language equivalents should be expressed within the International String structure.
        /// <summary>
        public BibliographicNameType ContributorName { get; set; }
        /// <summary>
        /// The role of the contributor. Language equivalents should be expressed within the International String structure.
        /// <summary>
        public List<CodeValueType> ContributorRole { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeContributorRole() { return ContributorRole.Count > 0; }
        /// <summary>
        /// Reference to a creator as described within a DDI Organization Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual ContributorReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ContributorName != null) { xEl.Add(ContributorName.ToXml("ContributorName")); }
            if (ContributorRole != null && ContributorRole.Count > 0)
            {
                foreach (var item in ContributorRole)
                {
                    xEl.Add(item.ToXml("ContributorRole"));
                }
            }
            if (ContributorReference != null)
            {
                xEl.Add(new XElement(ns + "ContributorReference", 
                    new XElement(ns + "URN", ContributorReference.URN), 
                    new XElement(ns + "Agency", ContributorReference.Agency), 
                    new XElement(ns + "ID", ContributorReference.ID), 
                    new XElement(ns + "Version", ContributorReference.Version), 
                    new XElement(ns + "TypeOfObject", ContributorReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

