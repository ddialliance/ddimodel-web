using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the region of an image, recording, or text where an action where a specified action is performed and the type of action taken (i.e., Mark an "X" where the actor should be standing on the picture of the stage.).
    /// <summary>
    public partial class ActionType
    {
        /// <summary>
        /// Identifies the region of the object where the action needs to occur based on the object type by specifying a segment of the object.
        /// <summary>
        public SegmentType RegionOfAction { get; set; }
        /// <summary>
        /// Describes the specific actions that should take place. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the provision of a regular expression to describe a mark (such as a specific letter or number).
        /// <summary>
        public string RegExp { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (RegionOfAction != null) { xEl.Add(RegionOfAction.ToXml("RegionOfAction")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            return xEl;
        }
    }
}

