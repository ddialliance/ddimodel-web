using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of sampling information maintained by an agency including sampling plans, sample frames, and samples.
    /// <summary>
    public partial class SamplingInformationScheme : Maintainable
    {
        /// <summary>
        /// A name for the sampling information scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SamplingInformationSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSamplingInformationSchemeName() { return SamplingInformationSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the sampling information scheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the use of the sampling information scheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides for inclusion by reference of external sampling information schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingInformationScheme> SamplingInformationSchemeReference { get; set; } = new List<SamplingInformationScheme>();
        public bool ShouldSerializeSamplingInformationSchemeReference() { return SamplingInformationSchemeReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sample frame) belonging to the sampling information Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> SampleFrameReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeSampleFrameReference() { return SampleFrameReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sampling plan) belonging to the sampling information Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingPlan> SamplingPlanReference { get; set; } = new List<SamplingPlan>();
        public bool ShouldSerializeSamplingPlanReference() { return SamplingPlanReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sample) belonging to the sampling information Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Sample> SampleReference { get; set; } = new List<Sample>();
        public bool ShouldSerializeSampleReference() { return SampleReference.Count > 0; }
        /// <summary>
        /// An item (that is, a sampling information group) belonging to the sampling information Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingInformationGroup> SamplingInformationGroupReference { get; set; } = new List<SamplingInformationGroup>();
        public bool ShouldSerializeSamplingInformationGroupReference() { return SamplingInformationGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingInformationScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SamplingInformationSchemeName != null && SamplingInformationSchemeName.Count > 0)
            {
                foreach (var item in SamplingInformationSchemeName)
                {
                    xEl.Add(item.ToXml("SamplingInformationSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SamplingInformationSchemeReference != null && SamplingInformationSchemeReference.Count > 0)
            {
                foreach (var item in SamplingInformationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "SamplingInformationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleFrameReference != null && SampleFrameReference.Count > 0)
            {
                foreach (var item in SampleFrameReference)
                {
                    xEl.Add(new XElement(ns + "SampleFrameReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingPlanReference != null && SamplingPlanReference.Count > 0)
            {
                foreach (var item in SamplingPlanReference)
                {
                    xEl.Add(new XElement(ns + "SamplingPlanReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SampleReference != null && SampleReference.Count > 0)
            {
                foreach (var item in SampleReference)
                {
                    xEl.Add(new XElement(ns + "SampleReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingInformationGroupReference != null && SamplingInformationGroupReference.Count > 0)
            {
                foreach (var item in SamplingInformationGroupReference)
                {
                    xEl.Add(new XElement(ns + "SamplingInformationGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

