using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the specific measure of the cell by reference and provides information on the storage location of the value for the measure. When individual measures are stored in separately identifiable locations repeat Measure to define each measure and storage location. When multiple measures are stored as an ordered array in a single location list each measure in the array as a MeasureReference with its specified arrayOrder within a single Measure definition.
    /// <summary>
    public partial class MeasureType
    {
        /// <summary>
        /// Reference to the MeasureDefinition in NCube.
        /// <summary>
        public List<MeasureDefinitionType> MeasureDefinitionReference { get; set; } = new List<MeasureDefinitionType>();
        public bool ShouldSerializeMeasureDefinitionReference() { return MeasureDefinitionReference.Count > 0; }
        /// <summary>
        /// Description of the physical location of the measure value in the data file.
        /// <summary>
        public PhysicalLocationType PhysicalLocation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MeasureDefinitionReference != null && MeasureDefinitionReference.Count > 0)
            {
                foreach (var item in MeasureDefinitionReference)
                {
                    xEl.Add(item.ToXml("MeasureDefinitionReference"));
                }
            }
            if (PhysicalLocation != null) { xEl.Add(PhysicalLocation.ToXml("PhysicalLocation")); }
            return xEl;
        }
    }
}

