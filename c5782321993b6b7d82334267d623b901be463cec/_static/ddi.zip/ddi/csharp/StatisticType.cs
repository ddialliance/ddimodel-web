using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The value (expressed as a decimal) of the statistics and whether it is weighted and/or includes missing values.
    /// <summary>
    public partial class StatisticType
    {
        /// <summary>
        /// 
        /// <summary>
        public decimal DecimalValue { get; set; }
        /// <summary>
        /// Set to "true" if the statistic is weighted using the weight designated in VariableStatistics.
        /// <summary>
        public bool IsWeighted { get; set; }
        /// <summary>
        /// Defines the cases included in determining the statistic. The options are total=all cases, valid and missing (invalid); validOnly=Only valid values, missing (invalid) are not included in the calculation; missingOnly=Only missing (invalid) cases included in the calculation.
        /// <summary>
        [StringValidation(new string[] {
            "total"
,             "validOnly"
,             "missingOnly"
        })]
        public string ComputationBase { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (DecimalValue != null)
            {
                xEl.Add(new XElement(ns + "DecimalValue", DecimalValue));
            }
            xEl.Add(new XElement(ns + "IsWeighted", IsWeighted));
            if (ComputationBase != null)
            {
                xEl.Add(new XElement(ns + "ComputationBase", ComputationBase));
            }
            return xEl;
        }
    }
}

