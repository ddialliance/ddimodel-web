using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A comprehensive list of the ConceptualVariables measured by the data that are being documented and/or maintained by an agency. In addition to the standard name, label, and description, allows for the inclusion of an existing ConceptualVariableScheme by reference, the inclusion of descriptions for ConceptualVariables and ConceptualVariableGroups in-line or by reference.
    /// <summary>
    public partial class ConceptualVariableScheme : Maintainable
    {
        /// <summary>
        /// A name for the ConceptualVariableScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptualVariableSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptualVariableSchemeName() { return ConceptualVariableSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptualVariableScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ConceptualVariableScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing ConceptualVariableScheme for inclusion. TypeOfObject should be set to a ConceptualVariableScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualVariableScheme> ConceptualVariableSchemeReference { get; set; } = new List<ConceptualVariableScheme>();
        public bool ShouldSerializeConceptualVariableSchemeReference() { return ConceptualVariableSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a ConceptualVariable which provides the link between a concept to a specific unit type (object) that defines this as a ConceptualVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualVariable> ConceptualVariableReference { get; set; } = new List<ConceptualVariable>();
        public bool ShouldSerializeConceptualVariableReference() { return ConceptualVariableReference.Count > 0; }
        /// <summary>
        /// Allows for grouping of ConceptualVariables for administrative or conceptual purposes; groups may have a hierarchical structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ConceptualVariableGroup> ConceptualVariableGroupReference { get; set; } = new List<ConceptualVariableGroup>();
        public bool ShouldSerializeConceptualVariableGroupReference() { return ConceptualVariableGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ConceptualVariableScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConceptualVariableSchemeName != null && ConceptualVariableSchemeName.Count > 0)
            {
                foreach (var item in ConceptualVariableSchemeName)
                {
                    xEl.Add(item.ToXml("ConceptualVariableSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptualVariableSchemeReference != null && ConceptualVariableSchemeReference.Count > 0)
            {
                foreach (var item in ConceptualVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptualVariableReference != null && ConceptualVariableReference.Count > 0)
            {
                foreach (var item in ConceptualVariableReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptualVariableGroupReference != null && ConceptualVariableGroupReference.Count > 0)
            {
                foreach (var item in ConceptualVariableGroupReference)
                {
                    xEl.Add(new XElement(ns + "ConceptualVariableGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

