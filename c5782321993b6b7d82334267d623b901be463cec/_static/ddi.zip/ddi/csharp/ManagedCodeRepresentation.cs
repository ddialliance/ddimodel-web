using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the use of all or part of a CodeList as a representation used by a question response domain or variable value representation.
    /// <summary>
    public partial class ManagedCodeRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// A reference to the CodeList included in this representation using the Reference structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CodeList CodeListReference { get; set; }
        /// <summary>
        /// A reference to the StatisticalClassification included in this representation using the Reference structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public StatisticalClassification StatisticalClassificationReference { get; set; }
        /// <summary>
        /// Allows further specification of the codes to use from the CodeList by defining the level or only the most discrete codes of a hierarchical CodeList, the range of codes to use, or an itemized sub-set.
        /// <summary>
        public CodeSubsetInformationType CodeSubsetInformation { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedCodeRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (CodeListReference != null)
            {
                xEl.Add(new XElement(ns + "CodeListReference", 
                    new XElement(ns + "URN", CodeListReference.URN), 
                    new XElement(ns + "Agency", CodeListReference.Agency), 
                    new XElement(ns + "ID", CodeListReference.ID), 
                    new XElement(ns + "Version", CodeListReference.Version), 
                    new XElement(ns + "TypeOfObject", CodeListReference.GetType().Name)));
            }
            if (StatisticalClassificationReference != null)
            {
                xEl.Add(new XElement(ns + "StatisticalClassificationReference", 
                    new XElement(ns + "URN", StatisticalClassificationReference.URN), 
                    new XElement(ns + "Agency", StatisticalClassificationReference.Agency), 
                    new XElement(ns + "ID", StatisticalClassificationReference.ID), 
                    new XElement(ns + "Version", StatisticalClassificationReference.Version), 
                    new XElement(ns + "TypeOfObject", StatisticalClassificationReference.GetType().Name)));
            }
            if (CodeSubsetInformation != null) { xEl.Add(CodeSubsetInformation.ToXml("CodeSubsetInformation")); }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

