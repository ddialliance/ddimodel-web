using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the official DDI ID of a maintenance agency as a value taken from the registry cited in @registryID.
    /// <summary>
    public partial class DDIMaintenanceAgencyIDType
    {
        /// <summary>
        /// 
        /// <summary>
        public string StringValue { get; set; }
        /// <summary>
        /// Currently there is only a single DDI Agency Registry. Use "DDIAgencyRegistry".
        /// <summary>
        public string RegistryID { get; set; }
        /// <summary>
        /// The date when this agency ID was registered or become active.
        /// <summary>
        [JsonConverter(typeof(DateTimeConverter))]
        public DateTimeOffset ActivationDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (StringValue != null)
            {
                xEl.Add(new XElement(ns + "StringValue", StringValue));
            }
            if (RegistryID != null)
            {
                xEl.Add(new XElement(ns + "RegistryID", RegistryID));
            }
            if (ActivationDate != default(DateTimeOffset))
            {
                xEl.Add(new XElement(ns + "ActivationDate", ActivationDate.ToString("yyyy-MM-dd\\THH:mm:ss.FFFFFFFK")));
            }
            return xEl;
        }
    }
}

