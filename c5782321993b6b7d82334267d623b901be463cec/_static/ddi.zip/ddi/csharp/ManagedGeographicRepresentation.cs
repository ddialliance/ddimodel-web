using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures the representation for a geographic point to ensure collection of relevant information using a single response domain structure. The point may be associated with a polygon (such as the centroid of the polygon) or a line (end or shape points of a line). The structure provides a description of the default values for the datum type, coordinate system used, the coordinate zone, error correction method, standard offset, the geographic object being positioned, the type of address match if used, the point format, and spatial primitive type. It provides response options for the coordinate pairs being captured, and alternate values for the offset, geo-referenced object and coordinate system if a different one is used to capture a specific response.
    /// <summary>
    public partial class ManagedGeographicRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// A name for the ManagedGeographicRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example, different names for different systems.
        /// <summary>
        public List<NameType> ManagedGeographicRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedGeographicRepresentationName() { return ManagedGeographicRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// The standard datum format used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType Datum { get; set; }
        /// <summary>
        /// The standard coordinate system used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType CoordinateSystem { get; set; }
        /// <summary>
        /// The standard coordinate zone being used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType CoordinateZone { get; set; }
        /// <summary>
        /// The standard coordinate source being used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType CoordinateSource { get; set; }
        /// <summary>
        /// The standard method of error correction being used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType ErrorCorrection { get; set; }
        /// <summary>
        /// A definition of the standard offset used when taking a coordinate reading on the geo-referenced object.
        /// <summary>
        public string Offset { get; set; }
        /// <summary>
        /// The standard object for which the geographic coordinates are being captured. This could be a household, village centroid, etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType GeoreferencedObject { get; set; }
        /// <summary>
        /// Use for coordinates obtained through address matching only. Identify the address matching method. Example: street segment match, ZIP code centroid, etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType AddressMatchType { get; set; }
        /// <summary>
        /// Field to capture coordinate pairs as individual pairs or as an array of pairs.
        /// <summary>
        public List<CoordinatePairsType> CoordinatePairs { get; set; } = new List<CoordinatePairsType>();
        public bool ShouldSerializeCoordinatePairs() { return CoordinatePairs.Count > 0; }
        /// <summary>
        /// If unable to use the standard offset, allows entry of a non-standard offset figure.
        /// <summary>
        public TextDomainType AlternateOffset { get; set; }
        /// <summary>
        /// If the default geo-referenced object is unavailable or cannot be measured, allows identification of an alternate object.
        /// <summary>
        public TextDomainType AlternateObject { get; set; }
        /// <summary>
        /// Specifies the coordinate system used for a response if different from that stated in the response structure.
        /// <summary>
        public TextDomainType AlternateCoordinateSystem { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }
        /// <summary>
        /// The type attribute is used by the documenter to describe the numeric response domain.
        /// <summary>
        [StringValidation(new string[] {
            "DecimalDegree"
,             "DegreesMinutesSeconds"
,             "DecimalMinutes"
,             "Meters"
,             "Feet"
        })]
        public string PointFormat { get; set; }
        /// <summary>
        /// Indicates the spatial primitive object which the point references.
        /// <summary>
        [StringValidation(new string[] {
            "Point"
,             "Polygon"
,             "Line"
,             "LinearRing"
        })]
        public string SpatialPrimitive { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedGeographicRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedGeographicRepresentationName != null && ManagedGeographicRepresentationName.Count > 0)
            {
                foreach (var item in ManagedGeographicRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedGeographicRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (Datum != null) { xEl.Add(Datum.ToXml("Datum")); }
            if (CoordinateSystem != null) { xEl.Add(CoordinateSystem.ToXml("CoordinateSystem")); }
            if (CoordinateZone != null) { xEl.Add(CoordinateZone.ToXml("CoordinateZone")); }
            if (CoordinateSource != null) { xEl.Add(CoordinateSource.ToXml("CoordinateSource")); }
            if (ErrorCorrection != null) { xEl.Add(ErrorCorrection.ToXml("ErrorCorrection")); }
            if (Offset != null)
            {
                xEl.Add(new XElement(ns + "Offset", Offset));
            }
            if (GeoreferencedObject != null) { xEl.Add(GeoreferencedObject.ToXml("GeoreferencedObject")); }
            if (AddressMatchType != null) { xEl.Add(AddressMatchType.ToXml("AddressMatchType")); }
            if (CoordinatePairs != null && CoordinatePairs.Count > 0)
            {
                foreach (var item in CoordinatePairs)
                {
                    xEl.Add(item.ToXml("CoordinatePairs"));
                }
            }
            if (AlternateOffset != null) { xEl.Add(AlternateOffset.ToXml("AlternateOffset")); }
            if (AlternateObject != null) { xEl.Add(AlternateObject.ToXml("AlternateObject")); }
            if (AlternateCoordinateSystem != null) { xEl.Add(AlternateCoordinateSystem.ToXml("AlternateCoordinateSystem")); }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            if (PointFormat != null)
            {
                xEl.Add(new XElement(ns + "PointFormat", PointFormat));
            }
            if (SpatialPrimitive != null)
            {
                xEl.Add(new XElement(ns + "SpatialPrimitive", SpatialPrimitive));
            }
            return xEl;
        }
    }
}

