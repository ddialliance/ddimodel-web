using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a single data item within the record, linking it to its description in a variable and providing information on its data type and any item specific proprietary information.
    /// <summary>
    public partial class DataItemPType
    {
        /// <summary>
        /// Reference to a Variable describing the content of the data item.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// Allows an override of the default data type, using the language of the proprietary software. A controlled vocabulary is recommended.
        /// <summary>
        public CodeValueType ProprietaryDataType { get; set; }
        /// <summary>
        /// Indicates the proprietary output format.
        /// <summary>
        public CodeValueType ProprietaryOutputFormat { get; set; }
        /// <summary>
        /// Contains proprietary information specific to the data item. This is expressed as a set of key (name)-value pairs.
        /// <summary>
        public ProprietaryInfoType ProprietaryInfo { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (ProprietaryDataType != null) { xEl.Add(ProprietaryDataType.ToXml("ProprietaryDataType")); }
            if (ProprietaryOutputFormat != null) { xEl.Add(ProprietaryOutputFormat.ToXml("ProprietaryOutputFormat")); }
            if (ProprietaryInfo != null) { xEl.Add(ProprietaryInfo.ToXml("ProprietaryInfo")); }
            return xEl;
        }
    }
}

