using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Container for a URN following the pattern designed by DDIURNType. Provides a fixed type attribute signifying that it is a URN.
    /// <summary>
    public partial class URNType
    {
        /// <summary>
        /// 
        /// <summary>
        public Uri AnyURIValue { get; set; }
        /// <summary>
        /// Specifies that this URI is a URN. In future, other types of URI may be allowed here.
        /// <summary>
        public string Type { get; set; }
        /// <summary>
        /// Identifies the format of the DDI URN as being canonical or deprecated.
        /// <summary>
        [StringValidation(new string[] {
            "Canonical"
,             "Deprecated"
        })]
        public string TypeOfIdentifier { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (AnyURIValue != null)
            {
                xEl.Add(new XElement(ns + "AnyURIValue", AnyURIValue));
            }
            if (Type != null)
            {
                xEl.Add(new XElement(ns + "Type", Type));
            }
            if (TypeOfIdentifier != null)
            {
                xEl.Add(new XElement(ns + "TypeOfIdentifier", TypeOfIdentifier));
            }
            return xEl;
        }
    }
}

