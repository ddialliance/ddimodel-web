using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Indicates the range of items expressed as a string, such as an alphabetic range.
    /// <summary>
    public partial class RangeType
    {
        /// <summary>
        /// A display label for the text range. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// The algorithm used to determine the sort order of the text content. This includes whether the text is left to right, right to left, handling of spaces an capitalization, and ordering of text characters. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType CollationAlgorithm { get; set; }
        /// <summary>
        /// Specifies the units in the range.
        /// <summary>
        public string RangeUnit { get; set; }
        /// <summary>
        /// Minimum value in the range.
        /// <summary>
        public RangeValueType MinimumValue { get; set; }
        /// <summary>
        /// Maximum value in the range.
        /// <summary>
        public RangeValueType MaximumValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (CollationAlgorithm != null) { xEl.Add(CollationAlgorithm.ToXml("CollationAlgorithm")); }
            if (RangeUnit != null)
            {
                xEl.Add(new XElement(ns + "RangeUnit", RangeUnit));
            }
            if (MinimumValue != null) { xEl.Add(MinimumValue.ToXml("MinimumValue")); }
            if (MaximumValue != null) { xEl.Add(MaximumValue.ToXml("MaximumValue")); }
            return xEl;
        }
    }
}

