using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Unit Type is a class of objects of interest. A Unit Type is used to describe a class or group of Units based on a single characteristic with no specification of time and geography. For example, the Unit Type of "Person" groups together a set of Units based on the characteristic that they are "Persons". It concerns not only Unit Types used in dissemination, but anywhere in the statistical process. For example, using administrative data might involve the use of a fiscal unit. "Object class (ISO 11179)" is a synonym of UnitType. [GSIM 1.2]
    /// <summary>
    public partial class UnitType : Versionable
    {
        /// <summary>
        /// Name of the UnitType using the DDI Name structure.
        /// <summary>
        public List<NameType> UnitTypeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeUnitTypeName() { return UnitTypeName.Count > 0; }
        /// <summary>
        /// A display label for the UnitType. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the UnitType. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the Concept that defines the UnitType. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "UnitType");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UnitTypeName != null && UnitTypeName.Count > 0)
            {
                foreach (var item in UnitTypeName)
                {
                    xEl.Add(item.ToXml("UnitTypeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

