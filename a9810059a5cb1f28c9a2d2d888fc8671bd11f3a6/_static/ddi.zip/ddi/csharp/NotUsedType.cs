using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies DDI objects expressed as an XPath that are not supported by the system or agency using this profile.
    /// <summary>
    public partial class NotUsedType
    {
        /// <summary>
        /// The value of the item
        /// <summary>
        public string Value { get; set; }

        /// <summary>
        /// Contains an XPath which points to an element or attribute in DDI instances which is not used by the profile. All subelements of an unused element are assumed to be included unless explicitly addressed by the profile. The number of supported repetitions may be included in the XPath expression.
        /// <summary>
        public string Xpath { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Xpath != null)
            {
                xEl.Add(new XElement(ns + "Xpath", Xpath));
            }
            return xEl;
        }
    }
}

