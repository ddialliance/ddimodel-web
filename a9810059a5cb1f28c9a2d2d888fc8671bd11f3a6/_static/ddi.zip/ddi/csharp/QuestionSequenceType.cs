using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the ordering of questions when not otherwise indicated. Extends the standard sequencing information to indicate how and if StimulusMaterial should be treated in the resequencing.
    /// <summary>
    public partial class QuestionSequenceType : SpecificSequenceType
    {
        /// <summary>
        /// Clarifies how stimulus material is to be handled within the resequencing using a controlled vocabulary. Options: "include"=Include StimulusMaterial in resequencing without restriction; "preceding"=Attach each StimulusMaterial to the preceding question; "following"=Attach each StimulusMaterial to the question following it; and the default value of "within"=Resequencing occurs within each set of questions as delimited by StimulusMaterial
        /// <summary>
        [StringValidation(new string[] {
            "include"
,             "preceding"
,             "following"
,             "within"
        })]
        public string HandlingOfStimulusMaterial { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("SpecificSequenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (HandlingOfStimulusMaterial != null)
            {
                xEl.Add(new XElement(ns + "HandlingOfStimulusMaterial", HandlingOfStimulusMaterial));
            }
            return xEl;
        }
    }
}

