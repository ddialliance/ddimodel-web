using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the variables contained in the logical record by indicating that all variable contained in the logical product are included, inclusion of a scheme of variable to include, or listing individual variables to include. When the attribute allVariablesInLogicalProduct is set to "false" use the VariableSchemeReference (which allows for exclusions) and VariableUsedReference to specify the included variables.
    /// <summary>
    public partial class VariablesInRecordType
    {
        /// <summary>
        /// Reference to a VariableScheme whose members are included in the logical record. Note that individual items may be excluded from the scheme if not used by the logical record.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableScheme> VariableSchemeReference { get; set; } = new List<VariableScheme>();
        public bool ShouldSerializeVariableSchemeReference() { return VariableSchemeReference.Count > 0; }
        /// <summary>
        /// Reference to a variable to include in the logical record. This may be used to supplement the contents of an included VariableScheme or to list all the variables individually.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> VariableUsedReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeVariableUsedReference() { return VariableUsedReference.Count > 0; }
        /// <summary>
        /// Set to "true" when the logical record contains all the variables identified within the logical product module.
        /// <summary>
        public bool AllVariablesInLogicalProduct { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableSchemeReference != null && VariableSchemeReference.Count > 0)
            {
                foreach (var item in VariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "VariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableUsedReference != null && VariableUsedReference.Count > 0)
            {
                foreach (var item in VariableUsedReference)
                {
                    xEl.Add(new XElement(ns + "VariableUsedReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "AllVariablesInLogicalProduct", AllVariablesInLogicalProduct));
            return xEl;
        }
    }
}

