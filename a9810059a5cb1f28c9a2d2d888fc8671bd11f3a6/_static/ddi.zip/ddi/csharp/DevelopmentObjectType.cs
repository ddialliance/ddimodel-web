using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A description of the development objects of a Development Implementation or Development Step. Supports a general description as well as specific references to allowed development objects.
    /// <summary>
    public partial class DevelopmentObjectType
    {
        /// <summary>
        /// A description of the development objects that are the intended objects of a Development Plan or specific objects of a Development Step. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the Question type that is the target of the development work. TypeOfObject should be QuestionItem, QuestionGrid, or QuestionBlock.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Question QuestionReference { get; set; }
        /// <summary>
        /// Reference to the Measurement that is the target of the development work. TypeOfObject should be Measurement.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public MeasurementItem MeasurementReference { get; set; }
        /// <summary>
        /// Reference to the Instrument that is the target of the development work. TypeOfObject should be Instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instrument InstrumentReference { get; set; }
        /// <summary>
        /// Reference to the ControlConstruct that is the target of the development work. TypeOfObject should reflect the type of ControlConstruct being referenced. Value should be IfThenElse, RepeatUntil, RepeatWhile, Loop, Sequence, ComputationItem, StatementItem, MeasurementConstruct, QuestionConstruct, Split, SplitJoin, SamplingStage, SampleStep, DevelopmentStep.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ControlConstruct ControlConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (QuestionReference != null)
            {
                xEl.Add(new XElement(ns + "QuestionReference", 
                    new XElement(ns + "URN", QuestionReference.URN), 
                    new XElement(ns + "Agency", QuestionReference.Agency), 
                    new XElement(ns + "ID", QuestionReference.ID), 
                    new XElement(ns + "Version", QuestionReference.Version), 
                    new XElement(ns + "TypeOfObject", QuestionReference.GetType().Name)));
            }
            if (MeasurementReference != null)
            {
                xEl.Add(new XElement(ns + "MeasurementReference", 
                    new XElement(ns + "URN", MeasurementReference.URN), 
                    new XElement(ns + "Agency", MeasurementReference.Agency), 
                    new XElement(ns + "ID", MeasurementReference.ID), 
                    new XElement(ns + "Version", MeasurementReference.Version), 
                    new XElement(ns + "TypeOfObject", MeasurementReference.GetType().Name)));
            }
            if (InstrumentReference != null)
            {
                xEl.Add(new XElement(ns + "InstrumentReference", 
                    new XElement(ns + "URN", InstrumentReference.URN), 
                    new XElement(ns + "Agency", InstrumentReference.Agency), 
                    new XElement(ns + "ID", InstrumentReference.ID), 
                    new XElement(ns + "Version", InstrumentReference.Version), 
                    new XElement(ns + "TypeOfObject", InstrumentReference.GetType().Name)));
            }
            if (ControlConstructReference != null)
            {
                xEl.Add(new XElement(ns + "ControlConstructReference", 
                    new XElement(ns + "URN", ControlConstructReference.URN), 
                    new XElement(ns + "Agency", ControlConstructReference.Agency), 
                    new XElement(ns + "ID", ControlConstructReference.ID), 
                    new XElement(ns + "Version", ControlConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", ControlConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

