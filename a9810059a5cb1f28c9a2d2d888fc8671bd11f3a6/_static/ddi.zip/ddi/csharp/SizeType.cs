using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Consists of an integer value and specification of the unit. The unit may be specified using a controlled vocabulary.
    /// <summary>
    public partial class SizeType
    {
        /// <summary>
        /// Reference to an existing UnitType using the Reference structure. TypeOfObject should be set to UnitType.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public UnitType UnitTypeReference { get; set; }
        /// <summary>
        /// Indicate the number of units of the UnitType specified.
        /// <summary>
        public int NumberOfUnits { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (UnitTypeReference != null)
            {
                xEl.Add(new XElement(ns + "UnitTypeReference", 
                    new XElement(ns + "URN", UnitTypeReference.URN), 
                    new XElement(ns + "Agency", UnitTypeReference.Agency), 
                    new XElement(ns + "ID", UnitTypeReference.ID), 
                    new XElement(ns + "Version", UnitTypeReference.Version), 
                    new XElement(ns + "TypeOfObject", UnitTypeReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "NumberOfUnits", NumberOfUnits));
            return xEl;
        }
    }
}

