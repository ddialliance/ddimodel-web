using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a statistical summary of the data in the related file as a set of variable level and category level statistics. May refer to a set of statistics provided in another physical instance (for example if the same data is held in multiple storage formats) or if the summary statistics are held as a separate data set.
    /// <summary>
    public partial class StatisticalSummaryType
    {
        /// <summary>
        /// Reference to a PhysicalInstance that describes a data file containing the summary and/or category statistics OR contains the statistics in-line as in the case of the same data stored as an ASCII file and as an ORACLE file where the summary and category statistics are listed only in one of the physical instance files.
        /// <summary>
        public List<StatisticalDataLocationType> StatisticalDataLocation { get; set; } = new List<StatisticalDataLocationType>();
        public bool ShouldSerializeStatisticalDataLocation() { return StatisticalDataLocation.Count > 0; }
        /// <summary>
        /// One or more statistical measures that describe the responses to a particular variable. Include both variable and category level statistics.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableStatistics> VariableStatisticsReference { get; set; } = new List<VariableStatistics>();
        public bool ShouldSerializeVariableStatisticsReference() { return VariableStatisticsReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (StatisticalDataLocation != null && StatisticalDataLocation.Count > 0)
            {
                foreach (var item in StatisticalDataLocation)
                {
                    xEl.Add(item.ToXml("StatisticalDataLocation"));
                }
            }
            if (VariableStatisticsReference != null && VariableStatisticsReference.Count > 0)
            {
                foreach (var item in VariableStatisticsReference)
                {
                    xEl.Add(new XElement(ns + "VariableStatisticsReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

