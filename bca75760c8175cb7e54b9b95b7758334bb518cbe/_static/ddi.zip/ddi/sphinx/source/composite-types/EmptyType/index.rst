EmptyType
---------

Element with no content. It is an abstract type, used to extend into subclasses.

.. contents::

Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/EmptyType.svg

Properties
~~~~~~~~~~



