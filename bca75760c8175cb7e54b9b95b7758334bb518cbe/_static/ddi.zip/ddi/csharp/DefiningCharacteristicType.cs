using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Use to attach one or more characteristics to the parent object. The defining characteristic supports the use of a controlled vocabulary and may provide a time period for which the classification is valid.
    /// <summary>
    public class DefiningCharacteristicType
    {
        /// <summary>
        /// A characteristic which defines the area. These are often useful in terms of selection. For example a U.S. Block may be classified as Urban, Rural, or Mixed. The characteristic supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType Characteristic { get; set; }
        /// <summary>
        /// The time period for which the characteristic is valid.
        /// <summary>
        public DateType GeographicTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Characteristic != null) { xEl.Add(Characteristic.ToXml("Characteristic")); }
            if (GeographicTime != null) { xEl.Add(GeographicTime.ToXml("GeographicTime")); }
            return xEl;
        }
    }
}

