using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a set of variables, one from the source record and one from the target record used as all or part of a link between the source and target records.
    /// <summary>
    public class SourceTargetLinkType
    {
        /// <summary>
        /// A reference to the variable in the Source Record containing the value that is equal to the value in the identified variable in the Target Record.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable SourceLinkVariableReference { get; set; }
        /// <summary>
        /// A reference to the variable in the Target Record containing the value that is equal to the value in the identified variable in the Source Record.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable TargetLinkVariableReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (SourceLinkVariableReference != null)
            {
                xEl.Add(new XElement(ns + "SourceLinkVariableReference", 
                    new XElement(ns + "URN", SourceLinkVariableReference.URN), 
                    new XElement(ns + "Agency", SourceLinkVariableReference.Agency), 
                    new XElement(ns + "ID", SourceLinkVariableReference.ID), 
                    new XElement(ns + "Version", SourceLinkVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", SourceLinkVariableReference.GetType().Name)));
            }
            if (TargetLinkVariableReference != null)
            {
                xEl.Add(new XElement(ns + "TargetLinkVariableReference", 
                    new XElement(ns + "URN", TargetLinkVariableReference.URN), 
                    new XElement(ns + "Agency", TargetLinkVariableReference.Agency), 
                    new XElement(ns + "ID", TargetLinkVariableReference.ID), 
                    new XElement(ns + "Version", TargetLinkVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", TargetLinkVariableReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

