using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for a specific machine actionable description of the restriction process using a ProcessingInstructionReference, if one currently exists, or through a CommandCode. In the case of a physical instance, the RestrictionProcess would be the same as a case, record or variable selection process.
    /// <summary>
    public class RestrictionProcessType
    {
        /// <summary>
        /// Reference to a ProcessingInstruction containing the process instructions for restricting a level of coverage.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction ProcessingInstructionReference { get; set; }
        /// <summary>
        /// The process instructions for restricting a level of coverage expressed as a command code.
        /// <summary>
        public CommandCodeType CommandCode { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ProcessingInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference", 
                    new XElement(ns + "URN", ProcessingInstructionReference.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference.GetType().Name)));
            }
            if (CommandCode != null) { xEl.Add(CommandCode.ToXml("CommandCode")); }
            return xEl;
        }
    }
}

