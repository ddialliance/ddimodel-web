using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the independent (denominator) and dependent (numerator) dimensions for calculating aggregate measures such as percent. When two or more independent or dependent dimensions are listed here, the value is defined as the intersection of the listed dimensions.
    /// <summary>
    public class AggregationDefinitionType
    {
        /// <summary>
        /// The rank of a dimension that acts as the denominator (independent variable).
        /// <summary>
        public List<int> IndependentDimension { get; set; } = new List<int>();
        public bool ShouldSerializeIndependentDimension() { return IndependentDimension.Count > 0; }
        /// <summary>
        /// The rank of a dimension that acts as the numerator (dependent variable).
        /// <summary>
        public List<int> DependentDimension { get; set; } = new List<int>();
        public bool ShouldSerializeDependentDimension() { return DependentDimension.Count > 0; }
        /// <summary>
        /// When true indicates that total count of the NCube as described by the universe acts as the independent variable (denominator) and that all dimensions are used to define the dependent variable (numerator). When false, use the IndependentDimension and DependentDimension elements to assign each rank to its appropriate role.
        /// <summary>
        public bool IsNCubeUniverse { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            xEl.Add(
                from item in IndependentDimension
                select new XElement(ns + "IndependentDimension", item));
            xEl.Add(
                from item in DependentDimension
                select new XElement(ns + "DependentDimension", item));
            xEl.Add(new XElement(ns + "IsNCubeUniverse", IsNCubeUniverse));
            return xEl;
        }
    }
}

