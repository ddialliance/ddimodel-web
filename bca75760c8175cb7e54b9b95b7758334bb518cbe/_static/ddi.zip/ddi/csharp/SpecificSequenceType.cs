using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the ordering of items when not otherwise indicated. There are a set number of values for ItemSequenceType, but also a provision for describing an alternate ordering using a command language.
    /// <summary>
    public class SpecificSequenceType
    {
        /// <summary>
        /// Identifies the type of sequence to use. Values include InOrderOfAppearance, Random, Rotate, and Other.
        /// <summary>
        [StringValidation(new string[] {
            "InOrderOfAppearance"
,             "Random"
,             "Rotate"
,             "Other"
        })]
        public string ItemSequenceType { get; set; }
        /// <summary>
        /// Information on the command used to generate an alternative means of determining sequence changes. If used, the ItemSequenceType should be "Other".
        /// <summary>
        public CommandCodeType AlternateSequenceType { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ItemSequenceType != null)
            {
                xEl.Add(new XElement(ns + "ItemSequenceType", ItemSequenceType));
            }
            if (AlternateSequenceType != null) { xEl.Add(AlternateSequenceType.ToXml("AlternateSequenceType")); }
            return xEl;
        }
    }
}

