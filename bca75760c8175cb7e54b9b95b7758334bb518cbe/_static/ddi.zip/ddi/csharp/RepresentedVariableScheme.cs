using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of RepresentedVariables managed by an agency. RepresentedVariables are the core reusable parts of a Variable. RepresentedVariable maps to the GSIM Represented Variable. In addition to the standard name, label, and description, allows for the inclusion of an existing RepresentedVariableScheme by reference and RepresentedVariables either in-line or by reference. RepresentedVariables may be grouped for management purposes.
    /// <summary>
    public class RepresentedVariableScheme : Maintainable
    {
        /// <summary>
        /// A name for the RepresentedVariableScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RepresentedVariableSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRepresentedVariableSchemeName() { return RepresentedVariableSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the RepresentedVariableScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the RepresentedVariableScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing RepresentedVariableScheme by reference. TypeOfObject should be set to RepresentedVariableScheme
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariableScheme> RepresentedVariableSchemeReference { get; set; } = new List<RepresentedVariableScheme>();
        public bool ShouldSerializeRepresentedVariableSchemeReference() { return RepresentedVariableSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a RepresentedVariable contained in the RepresentedVariableScheme. A RepresentedVariable contains a reference to the Concept and Universe (or ConceptualVariable) as well as the representation of the RepresentedVariable. Representation may be provided in-line or by reference to a managed representation. RepresentedVariables are the core reusable parts of a Variable. RepresentedVariable maps to the GSIM Represented Variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariable> RepresentedVariableReference { get; set; } = new List<RepresentedVariable>();
        public bool ShouldSerializeRepresentedVariableReference() { return RepresentedVariableReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of RepresentedVariables. RepresentedVariables may be grouped for a wide range of reasons including conceptual or universe grouping, usage, subject or keyword relationships, or other grouping reason that will assist in the management of a group of RepresentedVariables.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariableGroup> RepresentedVariableGroupReference { get; set; } = new List<RepresentedVariableGroup>();
        public bool ShouldSerializeRepresentedVariableGroupReference() { return RepresentedVariableGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "RepresentedVariableScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RepresentedVariableSchemeName != null && RepresentedVariableSchemeName.Count > 0)
            {
                foreach (var item in RepresentedVariableSchemeName)
                {
                    xEl.Add(item.ToXml("RepresentedVariableSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RepresentedVariableSchemeReference != null && RepresentedVariableSchemeReference.Count > 0)
            {
                foreach (var item in RepresentedVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentedVariableReference != null && RepresentedVariableReference.Count > 0)
            {
                foreach (var item in RepresentedVariableReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentedVariableGroupReference != null && RepresentedVariableGroupReference.Count > 0)
            {
                foreach (var item in RepresentedVariableGroupReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

