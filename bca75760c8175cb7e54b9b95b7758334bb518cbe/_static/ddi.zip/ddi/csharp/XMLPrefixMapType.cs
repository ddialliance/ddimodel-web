using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Maps a specified prefix to a namespace. For each XML namespace used in the profile's XPath expressions, the XML namespaces must have their prefix specified using this element.
    /// <summary>
    public class XMLPrefixMapType
    {
        /// <summary>
        /// Specify the exact prefix used.
        /// <summary>
        public string XMLPrefix { get; set; }
        /// <summary>
        /// Specify the namespace which the prefix represents.
        /// <summary>
        public string XMLNamespace { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (XMLPrefix != null)
            {
                xEl.Add(new XElement(ns + "XMLPrefix", XMLPrefix));
            }
            if (XMLNamespace != null)
            {
                xEl.Add(new XElement(ns + "XMLNamespace", XMLNamespace));
            }
            return xEl;
        }
    }
}

