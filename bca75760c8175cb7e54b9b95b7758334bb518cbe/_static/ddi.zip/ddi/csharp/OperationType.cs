using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A generic operation description used as a type by specified operations. Describes the operation and identifies the organization or individual responsible for performing it.
    /// <summary>
    public class OperationType
    {
        /// <summary>
        /// A description of the operation.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to an organization or individual responsible for the operation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> AgencyOrganizationReference_Organization { get; set; } = new List<Organization>();
        public bool ShouldSerializeAgencyOrganizationReference_Organization() { return AgencyOrganizationReference_Organization.Count > 0; }
        /// <summary>
        /// A reference to an organization or individual responsible for the operation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Individual> AgencyOrganizationReference_Individual { get; set; } = new List<Individual>();
        public bool ShouldSerializeAgencyOrganizationReference_Individual() { return AgencyOrganizationReference_Individual.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (AgencyOrganizationReference_Organization != null && AgencyOrganizationReference_Organization.Count > 0)
            {
                foreach (var item in AgencyOrganizationReference_Organization)
                {
                    xEl.Add(new XElement(ns + "AgencyOrganizationReference_Organization", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (AgencyOrganizationReference_Individual != null && AgencyOrganizationReference_Individual.Count > 0)
            {
                foreach (var item in AgencyOrganizationReference_Individual)
                {
                    xEl.Add(new XElement(ns + "AgencyOrganizationReference_Individual", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

