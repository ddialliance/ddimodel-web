using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Details of a telephone number including the number, type of number, a privacy setting and an indication of whether this is the preferred contact number.
    /// <summary>
    public class TelephoneType
    {
        /// <summary>
        /// The telephone number including country code if appropriate.
        /// <summary>
        public string TelephoneNumber { get; set; }
        /// <summary>
        /// Indicates type of telephone number provided (home, fax, office, cell, etc.). Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfTelephone { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }
        /// <summary>
        /// Set to "true" if this is the preferred telephone number for contact.
        /// <summary>
        public bool IsPreferred { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TelephoneNumber != null)
            {
                xEl.Add(new XElement(ns + "TelephoneNumber", TelephoneNumber));
            }
            if (TypeOfTelephone != null) { xEl.Add(TypeOfTelephone.ToXml("TypeOfTelephone")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            xEl.Add(new XElement(ns + "IsPreferred", IsPreferred));
            return xEl;
        }
    }
}

