using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Category statistics for the variable when the filter variable contains the specified value.
    /// <summary>
    public class FilterVariableCategoryType
    {
        /// <summary>
        /// Provides the specific value of the variable being used as a filter. References a specific Code within the variable if using a CodeRepresentation. May alternately provide the Value of the Category.
        /// <summary>
        public string FilterCategoryValue { get; set; }
        /// <summary>
        /// Category statistics for the specified value of the variable (when the filter variable contains the specified value). Repeat for each value of the variable.
        /// <summary>
        public List<VariableCategoryType> VariableCategory { get; set; } = new List<VariableCategoryType>();
        public bool ShouldSerializeVariableCategory() { return VariableCategory.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (FilterCategoryValue != null)
            {
                xEl.Add(new XElement(ns + "FilterCategoryValue", FilterCategoryValue));
            }
            if (VariableCategory != null && VariableCategory.Count > 0)
            {
                foreach (var item in VariableCategory)
                {
                    xEl.Add(item.ToXml("VariableCategory"));
                }
            }
            return xEl;
        }
    }
}

