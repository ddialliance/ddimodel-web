using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. Provides a sequence order for operations expressed as control constructs. The sequence can be typed to support local processing or classification flags and alternate sequencing instructions (such as randomize for each respondent).
    /// <summary>
    public class Sequence : ControlConstruct
    {
        /// <summary>
        /// Provides the ability to "type" a sequence for classification or processing purposes. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfSequence { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfSequence() { return TypeOfSequence.Count > 0; }
        /// <summary>
        /// References control constructs in the order that they should appear within the instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstruct> ControlConstructReference { get; set; } = new List<ControlConstruct>();
        public bool ShouldSerializeControlConstructReference() { return ControlConstructReference.Count > 0; }
        /// <summary>
        /// Describes alternate ordering for different cases using the SpecificSequence structure. If you set the sequence to anything other than order of appearance the only allowable children are QuestionConstruct or Sequence. Contents must be randomizable.
        /// <summary>
        public SpecificSequenceType ConstructSequence { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Sequence");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSequence != null && TypeOfSequence.Count > 0)
            {
                foreach (var item in TypeOfSequence)
                {
                    xEl.Add(item.ToXml("TypeOfSequence"));
                }
            }
            if (ControlConstructReference != null && ControlConstructReference.Count > 0)
            {
                foreach (var item in ControlConstructReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConstructSequence != null) { xEl.Add(ConstructSequence.ToXml("ConstructSequence")); }
            return xEl;
        }
    }
}

