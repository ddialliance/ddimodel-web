using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A sub-universe group provides a definition to the universes contained within it. For example the Sub-Universe Group of Gender for the Universe Resident Population may contain the Universe Males and the Universe Females. In addition to the standard name, label, and description, the SubUniverseClass references a concept which defines it, and references to the universes and or other sub-universe groups it contains. The contents of the SubUniverseClass may be designated as ordered.
    /// <summary>
    public class SubUniverseClass : Versionable
    {
        /// <summary>
        /// A name for the SubUniverseClass. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SubUniverseClassName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSubUniverseClassName() { return SubUniverseClassName.Count > 0; }
        /// <summary>
        /// A display label for the SubUniverseClass. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public LabelType Label { get; set; }
        /// <summary>
        /// A description of the content and purpose of the SubUniverseClass. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A concept that provides a grouping factor for the universes contained by the SubUniverseClass. For example if the parent Universe is Population of the World and the two universes in the group are Male and Female the defining concept may be Sex.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept DefiningConceptReference { get; set; }
        /// <summary>
        /// A reference to a universe contained in this SubUniverseClass. Note that two different parent universes may contain references to the same universe within a sub-universe group. For example, the Universe "Population of Europe" and the Universe "Population of the United States" may both have a reference to the SubUniverseClass with the defining concept of Gender and member Universes "Males" and "Females". The SubUniverseClass is ALWAYS a restriction of its parent universe so that in one case it would be "Males within the Population of Europe" and in the other usage "Males within the Population of the United States". A question or variable should reference each relevant universe to define the appropriate intersect group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// A reference to a SubUniverseClass contained in this SubUniverseClass (a means of nesting hierarchies).
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SubUniverseClass SubUniverseClassReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "SubUniverseClass");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SubUniverseClassName != null && SubUniverseClassName.Count > 0)
            {
                foreach (var item in SubUniverseClassName)
                {
                    xEl.Add(item.ToXml("SubUniverseClassName"));
                }
            }
            if (Label != null) { xEl.Add(Label.ToXml("Label")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DefiningConceptReference != null)
            {
                xEl.Add(new XElement(ns + "DefiningConceptReference", 
                    new XElement(ns + "URN", DefiningConceptReference.URN), 
                    new XElement(ns + "Agency", DefiningConceptReference.Agency), 
                    new XElement(ns + "ID", DefiningConceptReference.ID), 
                    new XElement(ns + "Version", DefiningConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", DefiningConceptReference.GetType().Name)));
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (SubUniverseClassReference != null)
            {
                xEl.Add(new XElement(ns + "SubUniverseClassReference", 
                    new XElement(ns + "URN", SubUniverseClassReference.URN), 
                    new XElement(ns + "Agency", SubUniverseClassReference.Agency), 
                    new XElement(ns + "ID", SubUniverseClassReference.ID), 
                    new XElement(ns + "Version", SubUniverseClassReference.Version), 
                    new XElement(ns + "TypeOfObject", SubUniverseClassReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

