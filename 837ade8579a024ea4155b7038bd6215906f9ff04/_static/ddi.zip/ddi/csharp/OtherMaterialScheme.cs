using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This scheme contains a set of other materials referenced by the metadata. In addition to the name, label, and description of the scheme, the structure supports the inclusion of another OtherMaterialScheme by reference and a set of OtherMaterial descriptions either in-line or by reference.
    /// <summary>
    public partial class OtherMaterialScheme : Maintainable
    {
        /// <summary>
        /// A name for the OtherMaterialScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> OtherMaterialSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeOtherMaterialSchemeName() { return OtherMaterialSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the OtherMaterialScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the OtherMaterialScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing OtherMaterialScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterialScheme> OtherMaterialSchemeReference { get; set; } = new List<OtherMaterialScheme>();
        public bool ShouldSerializeOtherMaterialSchemeReference() { return OtherMaterialSchemeReference.Count > 0; }
        /// <summary>
        /// In-line description of a OtherMaterial. These are used by reference at various points in the lifecycle.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterial> OtherMaterialReference { get; set; } = new List<OtherMaterial>();
        public bool ShouldSerializeOtherMaterialReference() { return OtherMaterialReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of OtherMaterials.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OtherMaterialGroup> OtherMaterialGroupReference { get; set; } = new List<OtherMaterialGroup>();
        public bool ShouldSerializeOtherMaterialGroupReference() { return OtherMaterialGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "OtherMaterialScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (OtherMaterialSchemeName != null && OtherMaterialSchemeName.Count > 0)
            {
                foreach (var item in OtherMaterialSchemeName)
                {
                    xEl.Add(item.ToXml("OtherMaterialSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (OtherMaterialSchemeReference != null && OtherMaterialSchemeReference.Count > 0)
            {
                foreach (var item in OtherMaterialSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OtherMaterialReference != null && OtherMaterialReference.Count > 0)
            {
                foreach (var item in OtherMaterialReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OtherMaterialGroupReference != null && OtherMaterialGroupReference.Count > 0)
            {
                foreach (var item in OtherMaterialGroupReference)
                {
                    xEl.Add(new XElement(ns + "OtherMaterialGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

