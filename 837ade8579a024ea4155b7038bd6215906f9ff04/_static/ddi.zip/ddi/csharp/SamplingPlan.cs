using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An inline description of a sampling plan (how the sample is drawn). A sampling plan is intended to be versioned over time and can be reused by multiple studies.
    /// <summary>
    public partial class SamplingPlan : Versionable
    {
        /// <summary>
        /// A controlled vocabulary covering probability and non-probability sampling methods and modeling approaches. If this is a multi-stage sample the plan at this level should indicate the broadest description of the sampling approaches used in each stage.
        /// <summary>
        public CodeValueType TypeOfSamplingPlan { get; set; }
        /// <summary>
        /// A name for a sampling plan which may be repeated to express differing names for different systems. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SamplingPlanName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSamplingPlanName() { return SamplingPlanName.Count > 0; }
        /// <summary>
        /// A full display label for the sampling plan, repeatable for different context or applications. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Full description of the sampling plan. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A description of the population that the survey is intended to question (i.e. "Likely voters").
        /// <summary>
        public PopulationType IntendedTargetPopulation { get; set; }
        /// <summary>
        /// The survey population is the set of elements identified by the frame.  For instance, pre-election polls have "likely voters" as a target population, but the survey is conducted using RDD (usually).  The survey population is households with active land-line telephones, because that's who we can initially identify.  Survey questions help narrow the respondents into the desired set, but then eliminating sampled units increases variance.  It is reusable in the sense that the same survey population will be used each time the named frame is used.
        /// <summary>
        public PopulationType IntendedSurveyPopulation { get; set; }
        /// <summary>
        /// Rationale for dividing the frame at this stage into subsets and using a different sampling technique (e.g., Simple Random Sampling or Probability Proportional to Size) on each subset.
        /// <summary>
        public StructuredStringType SplitRationale { get; set; }
        /// <summary>
        /// Generally reference to a single SamplingStage or to a Sequence which orders multiple SamplingStages. TypeOfObject should be any valid member of the group of Control Constructs.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ControlConstruct ControlConstructReference { get; set; }
        /// <summary>
        /// Describe the purpose for stratifying the sampling process.
        /// <summary>
        public StratificationRationaleType StratificationRationale { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingPlan");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingPlan != null) { xEl.Add(TypeOfSamplingPlan.ToXml("TypeOfSamplingPlan")); }
            if (SamplingPlanName != null && SamplingPlanName.Count > 0)
            {
                foreach (var item in SamplingPlanName)
                {
                    xEl.Add(item.ToXml("SamplingPlanName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (IntendedTargetPopulation != null) { xEl.Add(IntendedTargetPopulation.ToXml("IntendedTargetPopulation")); }
            if (IntendedSurveyPopulation != null) { xEl.Add(IntendedSurveyPopulation.ToXml("IntendedSurveyPopulation")); }
            if (SplitRationale != null) { xEl.Add(SplitRationale.ToXml("SplitRationale")); }
            if (ControlConstructReference != null)
            {
                xEl.Add(new XElement(ns + "ControlConstructReference", 
                    new XElement(ns + "URN", ControlConstructReference.URN), 
                    new XElement(ns + "Agency", ControlConstructReference.Agency), 
                    new XElement(ns + "ID", ControlConstructReference.ID), 
                    new XElement(ns + "Version", ControlConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", ControlConstructReference.GetType().Name)));
            }
            if (StratificationRationale != null) { xEl.Add(StratificationRationale.ToXml("StratificationRationale")); }
            return xEl;
        }
    }
}

