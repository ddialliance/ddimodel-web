using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contact information for the individual or organization including location specification, address, URL, phone numbers, and other means of communication access. Address, location, telephone, and other means of communication can be repeated to express multiple means of a single type or change over time. Each major piece of contact information (with exception of URL contains the element EffectiveDates in order to date stamp the period for which the information is valid.
    /// <summary>
    public partial class ContactInformationType
    {
        /// <summary>
        /// . May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<LocationNameType> LocationName { get; set; } = new List<LocationNameType>();
        public bool ShouldSerializeLocationName() { return LocationName.Count > 0; }
        /// <summary>
        /// Location address identifying each part of the address as separate elements.
        /// <summary>
        public List<AddressType> Address { get; set; } = new List<AddressType>();
        public bool ShouldSerializeAddress() { return Address.Count > 0; }
        /// <summary>
        /// Telephone number for the location
        /// <summary>
        public List<TelephoneType> Telephone { get; set; } = new List<TelephoneType>();
        public bool ShouldSerializeTelephone() { return Telephone.Count > 0; }
        /// <summary>
        /// URL for the location's website.
        /// <summary>
        public List<URLType> URL { get; set; } = new List<URLType>();
        public bool ShouldSerializeURL() { return URL.Count > 0; }
        /// <summary>
        /// Generic email address for the location
        /// <summary>
        public List<EmailType> Email { get; set; } = new List<EmailType>();
        public bool ShouldSerializeEmail() { return Email.Count > 0; }
        /// <summary>
        /// Instant Messaging identification for the location
        /// <summary>
        public List<InstantMessagingType> InstantMessaging { get; set; } = new List<InstantMessagingType>();
        public bool ShouldSerializeInstantMessaging() { return InstantMessaging.Count > 0; }
        /// <summary>
        /// The geographic region for which this location operates. For example, the Kansas City office of the United States Bureau of the Census has responsibility for a region covering a number of states.
        /// <summary>
        public CodeValueType RegionalCoverage { get; set; }
        /// <summary>
        /// Type of location e.g. home, primary office, alternate office etc.
        /// <summary>
        public CodeValueType TypeOfLocation { get; set; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (LocationName != null && LocationName.Count > 0)
            {
                foreach (var item in LocationName)
                {
                    xEl.Add(item.ToXml("LocationName"));
                }
            }
            if (Address != null && Address.Count > 0)
            {
                foreach (var item in Address)
                {
                    xEl.Add(item.ToXml("Address"));
                }
            }
            if (Telephone != null && Telephone.Count > 0)
            {
                foreach (var item in Telephone)
                {
                    xEl.Add(item.ToXml("Telephone"));
                }
            }
            if (URL != null && URL.Count > 0)
            {
                foreach (var item in URL)
                {
                    xEl.Add(item.ToXml("URL"));
                }
            }
            if (Email != null && Email.Count > 0)
            {
                foreach (var item in Email)
                {
                    xEl.Add(item.ToXml("Email"));
                }
            }
            if (InstantMessaging != null && InstantMessaging.Count > 0)
            {
                foreach (var item in InstantMessaging)
                {
                    xEl.Add(item.ToXml("InstantMessaging"));
                }
            }
            if (RegionalCoverage != null) { xEl.Add(RegionalCoverage.ToXml("RegionalCoverage")); }
            if (TypeOfLocation != null) { xEl.Add(TypeOfLocation.ToXml("TypeOfLocation")); }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            return xEl;
        }
    }
}

