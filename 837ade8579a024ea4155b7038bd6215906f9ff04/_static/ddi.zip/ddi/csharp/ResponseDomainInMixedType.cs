using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A structure that provides both the response domain and information on how it should be attached, or related, to other specified response domains in the question. If no AttachmentLocation information is provided it is assumed that multiple response domains or response text occurs in sequence.
    /// <summary>
    public partial class ResponseDomainInMixedType
    {
        /// <summary>
        /// The response domain being used. An abstract element. May be substituted by any valid object of substitution type ResponseDomain.
        /// <summary>
        [JsonConverter(typeof(SubstitutionConverter))]
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ResponseDomainReference { get; set; }
        /// <summary>
        /// Allows attachment of a secondary response domain to a specific item within another response domain used in the question. For example, attach a TextDomain to the value "Other" using the TextDomain label (Please specify) as a label for the TextDomain.
        /// <summary>
        public AttachmentLocationType AttachmentLocation { get; set; }
        /// <summary>
        /// If another response domain will be attached to the response domain listed withinResponseDomainInMixed provide a value in attachmentBase to allow for unique identification within this question. AttachmentLocation contains an attribute attachmentDomain which will provide a link from the domain that is being attached to the domain it is being attached to.
        /// <summary>
        public int AttachmentBase { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference", 
                    new XElement(ns + "URN", ResponseDomainReference.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference.ID), 
                    new XElement(ns + "Version", ResponseDomainReference.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference.GetType().Name)));
            }
            if (AttachmentLocation != null) { xEl.Add(AttachmentLocation.ToXml("AttachmentLocation")); }
            xEl.Add(new XElement(ns + "AttachmentBase", AttachmentBase));
            return xEl;
        }
    }
}

