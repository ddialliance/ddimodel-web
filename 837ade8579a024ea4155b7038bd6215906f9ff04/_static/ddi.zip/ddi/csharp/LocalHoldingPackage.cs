using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows a depository to hold the contents of a DDI StudyUnit, Group, or ResourcePackage as received while providing locally created value added material and processing information without having to alter the maintenance agency or version of the original material. Contains the depository object by reference plus local added content including the objects added and a link to the location of the addition or change in the deposited object.
    /// <summary>
    public partial class LocalHoldingPackage : Maintainable
    {
        /// <summary>
        /// A reference to the StudyUnit as deposited.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public StudyUnit DepositoryStudyUnitReference { get; set; }
        /// <summary>
        /// A reference to the Group as deposited.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Group DepositoryGroupReference { get; set; }
        /// <summary>
        /// A reference to a ResourcePackage as deposited.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ResourcePackage DepositoryResourcePackageReference { get; set; }
        /// <summary>
        /// A concept that defines or aids in understanding the content of the local holding package.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept DefiningConceptReference { get; set; }
        /// <summary>
        /// A reference to the ResourcePackage as deposited.
        /// <summary>
        public LocalAddedContentType LocalAddedContent { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "LocalHoldingPackage");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DepositoryStudyUnitReference != null)
            {
                xEl.Add(new XElement(ns + "DepositoryStudyUnitReference", 
                    new XElement(ns + "URN", DepositoryStudyUnitReference.URN), 
                    new XElement(ns + "Agency", DepositoryStudyUnitReference.Agency), 
                    new XElement(ns + "ID", DepositoryStudyUnitReference.ID), 
                    new XElement(ns + "Version", DepositoryStudyUnitReference.Version), 
                    new XElement(ns + "TypeOfObject", DepositoryStudyUnitReference.GetType().Name)));
            }
            if (DepositoryGroupReference != null)
            {
                xEl.Add(new XElement(ns + "DepositoryGroupReference", 
                    new XElement(ns + "URN", DepositoryGroupReference.URN), 
                    new XElement(ns + "Agency", DepositoryGroupReference.Agency), 
                    new XElement(ns + "ID", DepositoryGroupReference.ID), 
                    new XElement(ns + "Version", DepositoryGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", DepositoryGroupReference.GetType().Name)));
            }
            if (DepositoryResourcePackageReference != null)
            {
                xEl.Add(new XElement(ns + "DepositoryResourcePackageReference", 
                    new XElement(ns + "URN", DepositoryResourcePackageReference.URN), 
                    new XElement(ns + "Agency", DepositoryResourcePackageReference.Agency), 
                    new XElement(ns + "ID", DepositoryResourcePackageReference.ID), 
                    new XElement(ns + "Version", DepositoryResourcePackageReference.Version), 
                    new XElement(ns + "TypeOfObject", DepositoryResourcePackageReference.GetType().Name)));
            }
            if (DefiningConceptReference != null)
            {
                xEl.Add(new XElement(ns + "DefiningConceptReference", 
                    new XElement(ns + "URN", DefiningConceptReference.URN), 
                    new XElement(ns + "Agency", DefiningConceptReference.Agency), 
                    new XElement(ns + "ID", DefiningConceptReference.ID), 
                    new XElement(ns + "Version", DefiningConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", DefiningConceptReference.GetType().Name)));
            }
            if (LocalAddedContent != null) { xEl.Add(LocalAddedContent.ToXml("LocalAddedContent")); }
            return xEl;
        }
    }
}

