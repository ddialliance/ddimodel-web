using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes both minimum and preferred language abilities sought for the translation work as a set of source and target language requirements.
    /// <summary>
    public partial class LanguageAbilitySoughtType
    {
        /// <summary>
        /// Identifies the language and the individuals ability to read, write, and speak the designated language using a controlled vocabulary.
        /// <summary>
        public IndividualLanguageType MinimumLanguageAbility { get; set; }
        /// <summary>
        /// Identifies the language and the individuals ability to read, write, and speak the designated language using a controlled vocabulary.
        /// <summary>
        public IndividualLanguageType PreferredLanguageAbility { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MinimumLanguageAbility != null) { xEl.Add(MinimumLanguageAbility.ToXml("MinimumLanguageAbility")); }
            if (PreferredLanguageAbility != null) { xEl.Add(PreferredLanguageAbility.ToXml("PreferredLanguageAbility")); }
            return xEl;
        }
    }
}

