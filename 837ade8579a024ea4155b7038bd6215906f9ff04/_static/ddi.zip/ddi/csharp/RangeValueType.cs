using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a bounding value of a string.
    /// <summary>
    public partial class RangeValueType : ValueType
    {
        /// <summary>
        /// Set to "true" if the value is included in the range.
        /// <summary>
        public bool Included { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ValueType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "Included", Included));
            return xEl;
        }
    }
}

