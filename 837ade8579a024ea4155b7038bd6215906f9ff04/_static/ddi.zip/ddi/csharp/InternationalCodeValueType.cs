using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for string content which may be taken from an externally maintained controlled vocabulary. If the content is from a controlled vocabulary provide the code value, as well as a reference to the code list from which the value is taken. This differs from a CodeValue only by the provision of a language-location specification. DDI uses the International CodeValue in cases where controlled vocabularies are assumed to be highly language specific, such as nationally maintained subject headings, thesauri, or keywords derived from the content of documents. The ability to identify language is especially important when supporting searches by external language-specific search engines. Provide as many of the identifying attributes as needed to adequately identify the controlled vocabulary.
    /// <summary>
    public partial class InternationalCodeValueType : StringType
    {
        /// <summary>
        /// The ID of the code controlled vocabulary that the content was taken from.
        /// <summary>
        public string ControlledVocabularyID { get; set; }
        /// <summary>
        /// The name of the controlledVocabulary.
        /// <summary>
        public string ControlledVocabularyName { get; set; }
        /// <summary>
        /// The name of the agency maintaining the controlledVocabulary.
        /// <summary>
        public string ControlledVocabularyAgencyName { get; set; }
        /// <summary>
        /// The version number of the controlledVocabulary.
        /// <summary>
        public string ControlledVocabularyVersionID { get; set; }
        /// <summary>
        /// If the value of the string is "Other" or the equivalent from the controlledVocabulary, this attribute can provide a more specific value not found in the codelist.
        /// <summary>
        public string OtherValue { get; set; }
        /// <summary>
        /// The URN of the codelist.
        /// <summary>
        public string ControlledVocabularyURN { get; set; }
        /// <summary>
        /// If maintained within a scheme, the URN of the scheme containing the controlledVocabulary.
        /// <summary>
        public string ControlledVocabularySchemeURN { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("StringType").Descendants())
            {
                xEl.Add(el);
            }
            if (ControlledVocabularyID != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularyID", ControlledVocabularyID));
            }
            if (ControlledVocabularyName != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularyName", ControlledVocabularyName));
            }
            if (ControlledVocabularyAgencyName != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularyAgencyName", ControlledVocabularyAgencyName));
            }
            if (ControlledVocabularyVersionID != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularyVersionID", ControlledVocabularyVersionID));
            }
            if (OtherValue != null)
            {
                xEl.Add(new XElement(ns + "OtherValue", OtherValue));
            }
            if (ControlledVocabularyURN != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularyURN", ControlledVocabularyURN));
            }
            if (ControlledVocabularySchemeURN != null)
            {
                xEl.Add(new XElement(ns + "ControlledVocabularySchemeURN", ControlledVocabularySchemeURN));
            }
            return xEl;
        }
    }
}

