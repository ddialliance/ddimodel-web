using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structure a single Question which may contain one or more response domains (i.e., a list of valid category responses where if "Other" is indicated a text response can be used to specify the intent of "Other"). The structure provides detail on the intent of the question, the text of the question, the valid response options and the number of allowed responses, references to external aids and instructions, and an estimation of the time needed to respond to the question. Note that the QuestionItem is a reusable format for use in any number of applied uses. External aids, instructions, response sequencing etc. should contain information consistent with the general use of the QuestionItem. Additional materials and information can be added within the QuestionConstruct which is the applied use of a question.
    /// <summary>
    public partial class QuestionItem : Question
    {
        /// <summary>
        /// A name for the QuestionItem. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QuestionItemName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQuestionItemName() { return QuestionItemName.Count > 0; }
        /// <summary>
        /// A display label for the QuestionItem. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the QuestionItem. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides an identity for input objects required for the QuestionItem.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// Provides an identify for the output objects of the QuestionItem.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// A structure used to bind the content of a parameter declared as the source to a parameter declared as the target. For example, binding the OutParameter of one Question to the InParameter of another Question in order to personalize a question text. Care should be taken to bind only reusable information at this level. Binding is also available at the QuestionConstruct to reflect bindings particular to the use of the question in a specific question flow or instrument.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// The text of a question. Supports the use of DynamicText. Note that when using QuestionText, the full QuestionText must be repeated for multi-language versions of the content. Different languages may handle the dynamic portions in different locations and/or with different content. Therefore languages cannot be mixed within a dynamic text except when the full text itself has multiple language sections, for example, a foreign language term in a text. The DisplayText may also be repeated to provide a dynamic and plain text version of the display. This allows for accurate rendering of the QuestionText in a non-dynamic environment like print.
        /// <summary>
        public List<DynamicTextType> QuestionText { get; set; } = new List<DynamicTextType>();
        public bool ShouldSerializeQuestionText() { return QuestionText.Count > 0; }
        /// <summary>
        /// The purpose of the QuestionItem in terms of what it is designed to measure. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType QuestionIntent { get; set; }
        /// <summary>
        /// Contains a response domain for the question item. Typically used to describe simple response domains (textual, numeric, etc.).
        /// <summary>
        [JsonConverter(typeof(SubstitutionConverter))]
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ResponseDomainReference { get; set; }
        /// <summary>
        /// Use in cases where the question requires the option for multiple response domains, such as a category response and a text response to specify a value for "Other", or when text needs to be inserted before, after, or between response options for the question.
        /// <summary>
        public StructuredMixedResponseDomainType StructuredMixedResponseDomain { get; set; }
        /// <summary>
        /// Allows the designation of the minimum and maximum number of responses allowed for this question. Note that each response domain has its own response cardinality.
        /// <summary>
        public ResponseCardinalityType ResponseCardinality { get; set; }
        /// <summary>
        /// A reference to the concept associated with the response to the question.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> ConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeConceptReference() { return ConceptReference.Count > 0; }
        /// <summary>
        /// A pointer to an external aid presented by the instrument such as a text card, image, audio, or audiovisual aid. Typically a URN. Use type attribute to describe the type of external aid provided. Example of terms to use would include: imageOnly audioOnly audioVisual multiMedia.
        /// <summary>
        public List<ExternalAidType> ExternalAid { get; set; } = new List<ExternalAidType>();
        public bool ShouldSerializeExternalAid() { return ExternalAid.Count > 0; }
        /// <summary>
        /// External reference to an interviewer instruction not expressed as DDI XML using OtherMaterial.
        /// <summary>
        public ExternalInterviewerInstructionType ExternalInterviewerInstruction { get; set; }
        /// <summary>
        /// Reference to an interviewer instruction expressed as DDI XML.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instruction InterviewerInstructionReference { get; set; }
        /// <summary>
        /// Reference to the RepresentedVariable that describes the data to be collected by this question. The RepresentedVariable contains the broad reusable specification of the Variable, i.e., concept, universe, and value representation. When more than one ResponseDomain exists, one RepresentedVariable should be created for each ResponseDomain in the same order as the corresponding ResponseDomain. TypeOfObject should be set to RepresentedVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariable> RepresentedVariableReference { get; set; } = new List<RepresentedVariable>();
        public bool ShouldSerializeRepresentedVariableReference() { return RepresentedVariableReference.Count > 0; }
        /// <summary>
        /// The estimated amount of time required to answer a question expressed in seconds. Decimal values should be used to define fractions of seconds.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QuestionItem");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QuestionItemName != null && QuestionItemName.Count > 0)
            {
                foreach (var item in QuestionItemName)
                {
                    xEl.Add(item.ToXml("QuestionItemName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (QuestionText != null && QuestionText.Count > 0)
            {
                foreach (var item in QuestionText)
                {
                    xEl.Add(item.ToXml("QuestionText"));
                }
            }
            if (QuestionIntent != null) { xEl.Add(QuestionIntent.ToXml("QuestionIntent")); }
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference", 
                    new XElement(ns + "URN", ResponseDomainReference.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference.ID), 
                    new XElement(ns + "Version", ResponseDomainReference.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference.GetType().Name)));
            }
            if (StructuredMixedResponseDomain != null) { xEl.Add(StructuredMixedResponseDomain.ToXml("StructuredMixedResponseDomain")); }
            if (ResponseCardinality != null) { xEl.Add(ResponseCardinality.ToXml("ResponseCardinality")); }
            if (ConceptReference != null && ConceptReference.Count > 0)
            {
                foreach (var item in ConceptReference)
                {
                    xEl.Add(new XElement(ns + "ConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalAid != null && ExternalAid.Count > 0)
            {
                foreach (var item in ExternalAid)
                {
                    xEl.Add(item.ToXml("ExternalAid"));
                }
            }
            if (ExternalInterviewerInstruction != null) { xEl.Add(ExternalInterviewerInstruction.ToXml("ExternalInterviewerInstruction")); }
            if (InterviewerInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "InterviewerInstructionReference", 
                    new XElement(ns + "URN", InterviewerInstructionReference.URN), 
                    new XElement(ns + "Agency", InterviewerInstructionReference.Agency), 
                    new XElement(ns + "ID", InterviewerInstructionReference.ID), 
                    new XElement(ns + "Version", InterviewerInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", InterviewerInstructionReference.GetType().Name)));
            }
            if (RepresentedVariableReference != null && RepresentedVariableReference.Count > 0)
            {
                foreach (var item in RepresentedVariableReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

