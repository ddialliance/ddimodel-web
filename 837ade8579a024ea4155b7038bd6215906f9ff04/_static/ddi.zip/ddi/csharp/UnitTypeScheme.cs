using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This scheme contains a set of Unit Types referenced by the metadata at different points in the lifecycle. In addition to the name, label, and description of the scheme, the structure supports the inclusion of another UnitTypeScheme by reference and a set of UnitType descriptions either in-line or by reference.
    /// <summary>
    public partial class UnitTypeScheme : Maintainable
    {
        /// <summary>
        /// A name for the scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> UnitTypeSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeUnitTypeSchemeName() { return UnitTypeSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the scheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing UnitTypeScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UnitTypeScheme> UnitTypeSchemeReference { get; set; } = new List<UnitTypeScheme>();
        public bool ShouldSerializeUnitTypeSchemeReference() { return UnitTypeSchemeReference.Count > 0; }
        /// <summary>
        /// In-line description of a UnitType. These are used by reference at various points in the lifecycle.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UnitType> UnitTypeReference { get; set; } = new List<UnitType>();
        public bool ShouldSerializeUnitTypeReference() { return UnitTypeReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of UnitTypes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<UnitTypeGroup> UnitTypeGroupReference { get; set; } = new List<UnitTypeGroup>();
        public bool ShouldSerializeUnitTypeGroupReference() { return UnitTypeGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "UnitTypeScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UnitTypeSchemeName != null && UnitTypeSchemeName.Count > 0)
            {
                foreach (var item in UnitTypeSchemeName)
                {
                    xEl.Add(item.ToXml("UnitTypeSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UnitTypeSchemeReference != null && UnitTypeSchemeReference.Count > 0)
            {
                foreach (var item in UnitTypeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "UnitTypeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UnitTypeReference != null && UnitTypeReference.Count > 0)
            {
                foreach (var item in UnitTypeReference)
                {
                    xEl.Add(new XElement(ns + "UnitTypeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UnitTypeGroupReference != null && UnitTypeGroupReference.Count > 0)
            {
                foreach (var item in UnitTypeGroupReference)
                {
                    xEl.Add(new XElement(ns + "UnitTypeGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

