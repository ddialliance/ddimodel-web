using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the method of pretest administration using a controlled vocabulary and description.
    /// <summary>
    public partial class MethodOfAdministrationType
    {
        /// <summary>
        /// Specifies the type of administration method  used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfAdministrationMethod { get; set; }
        /// <summary>
        /// Description of the administration method. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfAdministrationMethod != null) { xEl.Add(TypeOfAdministrationMethod.ToXml("TypeOfAdministrationMethod")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

