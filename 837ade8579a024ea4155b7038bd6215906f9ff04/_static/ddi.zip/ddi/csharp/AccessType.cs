using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes access to the holdings of the archive or to a specific data product. In addition to the name, label, and description for access. This item includes a confidentiality statement, descriptions of the access permissions required, restrictions to access, citation requirements, depositor requirements, conditions for access, a disclaimer, any time limits for access restrictions, and contact information regarding access.
    /// <summary>
    public partial class AccessType : IdentifiableType
    {
        /// <summary>
        /// The type of data access condition. The use of a controlled vocabulary is strongly recommended. 
        /// <summary>
        public CodeValueType TypeOfAccess { get; set; }
        /// <summary>
        /// A name by which the description of access is known. May be expressed in multiple languages. Repeat the element to express names with different content, for example, different names for different systems.
        /// <summary>
        public List<NameType> AccessTypeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeAccessTypeName() { return AccessTypeName.Count > 0; }
        /// <summary>
        /// A display label for the description of access. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the access description. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A statement regarding the confidentiality of the related data or metadata. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType ConfidentialityStatement { get; set; }
        /// <summary>
        /// A link to a form used to provide access to the data or metadata including a statement of the purpose of the form.
        /// <summary>
        public List<FormType> AccessPermission { get; set; } = new List<FormType>();
        public bool ShouldSerializeAccessPermission() { return AccessPermission.Count > 0; }
        /// <summary>
        /// A statement regarding restrictions to access. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Restrictions { get; set; }
        /// <summary>
        /// A statement regarding the citation requirement. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType CitationRequirement { get; set; }
        /// <summary>
        /// A statement of deposit requirements for the data.  Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType DepositRequirement { get; set; }
        /// <summary>
        /// Conditions for access to the metadata and/or data.  Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType AccessConditions { get; set; }
        /// <summary>
        /// A disclaimer regarding the liability of the data producers or providers. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Disclaimer { get; set; }
        /// <summary>
        /// The date or date range of the access restriction for all or portions of the data. Includes a reason for the access restriction as well as the user group to which the restriction applies.
        /// <summary>
        public AccessRestrictionDateType AccessRestrictionDate { get; set; }
        /// <summary>
        /// A reference to an organization or individual to contact for further information regarding the metadata or data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ContactOrganizationReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeContactOrganizationReference() { return ContactOrganizationReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfAccess != null) { xEl.Add(TypeOfAccess.ToXml("TypeOfAccess")); }
            if (AccessTypeName != null && AccessTypeName.Count > 0)
            {
                foreach (var item in AccessTypeName)
                {
                    xEl.Add(item.ToXml("AccessTypeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConfidentialityStatement != null) { xEl.Add(ConfidentialityStatement.ToXml("ConfidentialityStatement")); }
            if (AccessPermission != null && AccessPermission.Count > 0)
            {
                foreach (var item in AccessPermission)
                {
                    xEl.Add(item.ToXml("AccessPermission"));
                }
            }
            if (Restrictions != null) { xEl.Add(Restrictions.ToXml("Restrictions")); }
            if (CitationRequirement != null) { xEl.Add(CitationRequirement.ToXml("CitationRequirement")); }
            if (DepositRequirement != null) { xEl.Add(DepositRequirement.ToXml("DepositRequirement")); }
            if (AccessConditions != null) { xEl.Add(AccessConditions.ToXml("AccessConditions")); }
            if (Disclaimer != null) { xEl.Add(Disclaimer.ToXml("Disclaimer")); }
            if (AccessRestrictionDate != null) { xEl.Add(AccessRestrictionDate.ToXml("AccessRestrictionDate")); }
            if (ContactOrganizationReference != null && ContactOrganizationReference.Count > 0)
            {
                foreach (var item in ContactOrganizationReference)
                {
                    xEl.Add(new XElement(ns + "ContactOrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

