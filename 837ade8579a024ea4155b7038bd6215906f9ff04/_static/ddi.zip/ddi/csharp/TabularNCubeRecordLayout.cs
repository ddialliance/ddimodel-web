using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the BaseRecordLayout substitution group intended for use with tabular formats of NCube Instances held in an external file with location for data items arranged as two-dimensional rows (identified by row and column). In addition to the link to the PhysicalStructure provided by BaseRecordLayout, the record layout is this namespace (m3) identifies the character set and array base for the stored data, a full description of each data item contained within an NCube Instance including a link to its description (matrix address) and its physical location in the file.
    /// <summary>
    public partial class TabularNCubeRecordLayout : BaseRecordLayout
    {
        /// <summary>
        /// Character set used in the data file (e.g., US ASCII, EBCDIC, UTF-8). This is a required field. The DDI Alliance has provided a controlled vocabulary (CharacterSet) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType CharacterSet { get; set; }
        /// <summary>
        /// Sets the array base for any arrays used in the definition (that is, whether the first value is in position 0 or 1, etc.). This may be the data array in a delimited data file or the measure array for measures that are bundled and stored in a single location. Array base is generally set to either 0 or 1. There is no override provided as systems processing a record would use a consistent array base.
        /// <summary>
        public int ArrayBase { get; set; }
        /// <summary>
        /// A container for defining an instance of an NCube, indicating the matrix address of each cell and where the data for each measure within a cell of the NCube is stored. Allows specifying the values of the attributes attached to a NCube.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeInstanceT> NCubeInstanceTReference { get; set; } = new List<NCubeInstanceT>();
        public bool ShouldSerializeNCubeInstanceTReference() { return NCubeInstanceTReference.Count > 0; }
        /// <summary>
        /// Notes the column and row position of the top left corner of the data table in the spreadsheet.
        /// <summary>
        public TopLeftTableAnchorType TopLeftTableAnchor { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "TabularNCubeRecordLayout");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CharacterSet != null) { xEl.Add(CharacterSet.ToXml("CharacterSet")); }
            xEl.Add(new XElement(ns + "ArrayBase", ArrayBase));
            if (NCubeInstanceTReference != null && NCubeInstanceTReference.Count > 0)
            {
                foreach (var item in NCubeInstanceTReference)
                {
                    xEl.Add(new XElement(ns + "NCubeInstanceTReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (TopLeftTableAnchor != null) { xEl.Add(TopLeftTableAnchor.ToXml("TopLeftTableAnchor")); }
            return xEl;
        }
    }
}

