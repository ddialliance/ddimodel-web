using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the information needed to identify an individual case within a record type. This may be the variable or concatenated variable used to identify a unique case of a particular record type. Often referred to as a unique key. There may be more than one means of identifying a record. For example a US Census Summary File has a LogicalRecordIdentifer that is unique to the original file within which it was published. A specific geography has a set of fields that uniquely identify it.
    /// <summary>
    public partial class CaseIdentificationType
    {
        /// <summary>
        /// Reference to the variable containing the unique identifier. This may be a concatenated variable which indicates the combination of variable required to create a unique identification. If more than one variable reference is included the combination of the variable field contents must be unique and all variables are required for case identification.
        /// <summary>
        public FixedIdentifierType FixedIdentifier { get; set; }
        /// <summary>
        /// Describes the information needed to identify a specific record or case within a record type. Repeating the field allows multiple means of identifying a case referencing multiple variables.
        /// <summary>
        public ConditionalIdentifierType ConditionalIdentifier { get; set; }
        /// <summary>
        /// Indicates whether the case identifier is the primary key.
        /// <summary>
        public bool IsPrimary { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (FixedIdentifier != null) { xEl.Add(FixedIdentifier.ToXml("FixedIdentifier")); }
            if (ConditionalIdentifier != null) { xEl.Add(ConditionalIdentifier.ToXml("ConditionalIdentifier")); }
            xEl.Add(new XElement(ns + "IsPrimary", IsPrimary));
            return xEl;
        }
    }
}

