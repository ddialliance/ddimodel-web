using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A substitution for DevelopmentActivity which specifies the details for performing a pretest of a set of questions or questionnaire. Includes reference to the Sample Frame and Sample Method for the pretest, and the data collection process in terms of method of administration, mode of collection, delivery method, and identification of any additional data collected.
    /// <summary>
    public partial class PretestActivity : DevelopmentActivity
    {
        /// <summary>
        /// A reference to the Sample Frame used in selecting the the sample from the parent population.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SampleFrame SampleFrameReference { get; set; }
        /// <summary>
        /// Reference to the sampling plan used with the sample frame.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlan SamplingPlanReference { get; set; }
        /// <summary>
        /// Description of the method and mode of data collection in administering the pretest. Notes any additional data collected in the administration of the pretest.
        /// <summary>
        public List<PretestAdministrationType> PretestAdministration { get; set; } = new List<PretestAdministrationType>();
        public bool ShouldSerializePretestAdministration() { return PretestAdministration.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "PretestActivity");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SampleFrameReference != null)
            {
                xEl.Add(new XElement(ns + "SampleFrameReference", 
                    new XElement(ns + "URN", SampleFrameReference.URN), 
                    new XElement(ns + "Agency", SampleFrameReference.Agency), 
                    new XElement(ns + "ID", SampleFrameReference.ID), 
                    new XElement(ns + "Version", SampleFrameReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleFrameReference.GetType().Name)));
            }
            if (SamplingPlanReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanReference", 
                    new XElement(ns + "URN", SamplingPlanReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanReference.ID), 
                    new XElement(ns + "Version", SamplingPlanReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanReference.GetType().Name)));
            }
            if (PretestAdministration != null && PretestAdministration.Count > 0)
            {
                foreach (var item in PretestAdministration)
                {
                    xEl.Add(item.ToXml("PretestAdministration"));
                }
            }
            return xEl;
        }
    }
}

