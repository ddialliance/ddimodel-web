using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A scheme containing a set of RecordLayouts describing the location of individual data items within the physical record and how to address them (locate and retrieve). RecordLayouts provide a link to the PhysicalStructure description and to individual variables or NCubes describing the data items.
    /// <summary>
    public partial class RecordLayoutScheme : Maintainable
    {
        /// <summary>
        /// A name for the RecordLayoutScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RecordLayoutSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRecordLayoutSchemeName() { return RecordLayoutSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the RecordLayoutScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the RecordLayoutScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing RecordLayoutScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutScheme> RecordLayoutSchemeReference { get; set; } = new List<RecordLayoutScheme>();
        public bool ShouldSerializeRecordLayoutSchemeReference() { return RecordLayoutSchemeReference.Count > 0; }
        /// <summary>
        /// Allows for the inclusion of a RecordLayout by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RecordLayout RecordLayoutReference { get; set; }
        /// <summary>
        /// Allows for the inclusion of a RecordLayout by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public InLineNCubeRecordLayout InLineNCubeRecordLayoutReference { get; set; }
        /// <summary>
        /// Allows for the inclusion of a RecordLayout by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public TabularNCubeRecordLayout TabularNCubeRecordLayoutReference { get; set; }
        /// <summary>
        /// Allows for the inclusion of a RecordLayout by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProprietaryRecordLayout ProprietaryRecordLayoutReference { get; set; }
        /// <summary>
        /// Describes a group of RecordLayout descriptions for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutGroup> RecordLayoutGroupReference { get; set; } = new List<RecordLayoutGroup>();
        public bool ShouldSerializeRecordLayoutGroupReference() { return RecordLayoutGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "RecordLayoutScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RecordLayoutSchemeName != null && RecordLayoutSchemeName.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeName)
                {
                    xEl.Add(item.ToXml("RecordLayoutSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecordLayoutSchemeReference != null && RecordLayoutSchemeReference.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "RecordLayoutReference", 
                    new XElement(ns + "URN", RecordLayoutReference.URN), 
                    new XElement(ns + "Agency", RecordLayoutReference.Agency), 
                    new XElement(ns + "ID", RecordLayoutReference.ID), 
                    new XElement(ns + "Version", RecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", RecordLayoutReference.GetType().Name)));
            }
            if (InLineNCubeRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "InLineNCubeRecordLayoutReference", 
                    new XElement(ns + "URN", InLineNCubeRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", InLineNCubeRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", InLineNCubeRecordLayoutReference.ID), 
                    new XElement(ns + "Version", InLineNCubeRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", InLineNCubeRecordLayoutReference.GetType().Name)));
            }
            if (TabularNCubeRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "TabularNCubeRecordLayoutReference", 
                    new XElement(ns + "URN", TabularNCubeRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", TabularNCubeRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", TabularNCubeRecordLayoutReference.ID), 
                    new XElement(ns + "Version", TabularNCubeRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", TabularNCubeRecordLayoutReference.GetType().Name)));
            }
            if (ProprietaryRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "ProprietaryRecordLayoutReference", 
                    new XElement(ns + "URN", ProprietaryRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", ProprietaryRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", ProprietaryRecordLayoutReference.ID), 
                    new XElement(ns + "Version", ProprietaryRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", ProprietaryRecordLayoutReference.GetType().Name)));
            }
            if (RecordLayoutGroupReference != null && RecordLayoutGroupReference.Count > 0)
            {
                foreach (var item in RecordLayoutGroupReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

