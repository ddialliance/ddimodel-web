using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the BaseRecordLayout substitution group intended for use with archival formats of microdata held in an external file with fixed or delimited locations for data items. In addition to the link to the PhysicalStructure provided by BaseRecordLayout, the record layout is this namespace (p) identifies the character set and array base for the stored data, an optional reference to the default VariableScheme for the data items, a flag indicating that the variable names are provided on the first row of the data file, and a full description of each data item including a link to its description and its physical location in the record.
    /// <summary>
    public partial class RecordLayout : BaseRecordLayout
    {
        /// <summary>
        /// Character set used in the data file (e.g., US ASCII, EBCDIC, UTF-8). This is a required field. The DDI Alliance has provided a controlled vocabulary (CharacterSet) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType CharacterSet { get; set; }
        /// <summary>
        /// Sets the array base for any arrays used in the definition (that is, whether the first value is in position 0 or 1, etc.). This may be the data array in a delimited data file or the measure array for measures that are bundled and stored in a single location. Array base is generally set to either 0 or 1. There is no override provided as systems processing a record would use a consistent array base.
        /// <summary>
        public int ArrayBase { get; set; }
        /// <summary>
        /// References a variable scheme for the RecordLayout. This can be overridden by individual data items if they are from a different variable scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public VariableScheme DefaultVariableSchemeReference { get; set; }
        /// <summary>
        /// Includes a reference to a variable, and information about its data item location and its data type/format.
        /// <summary>
        public List<DataItemType> DataItem { get; set; } = new List<DataItemType>();
        public bool ShouldSerializeDataItem() { return DataItem.Count > 0; }
        /// <summary>
        /// A container for defining an instance of an NCube, indicating the matrix address of each cell and where the data for each measure within a cell of the NCube is stored. Allows specifying the values of the attributes attached to a NCube.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeInstance> NCubeInstanceReference { get; set; } = new List<NCubeInstance>();
        public bool ShouldSerializeNCubeInstanceReference() { return NCubeInstanceReference.Count > 0; }
        /// <summary>
        /// Set this item to "true" if the first row of the file contains the names of the variables (data items).
        /// <summary>
        public bool NamesOnFirstRow { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "RecordLayout");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CharacterSet != null) { xEl.Add(CharacterSet.ToXml("CharacterSet")); }
            xEl.Add(new XElement(ns + "ArrayBase", ArrayBase));
            if (DefaultVariableSchemeReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultVariableSchemeReference", 
                    new XElement(ns + "URN", DefaultVariableSchemeReference.URN), 
                    new XElement(ns + "Agency", DefaultVariableSchemeReference.Agency), 
                    new XElement(ns + "ID", DefaultVariableSchemeReference.ID), 
                    new XElement(ns + "Version", DefaultVariableSchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultVariableSchemeReference.GetType().Name)));
            }
            if (DataItem != null && DataItem.Count > 0)
            {
                foreach (var item in DataItem)
                {
                    xEl.Add(item.ToXml("DataItem"));
                }
            }
            if (NCubeInstanceReference != null && NCubeInstanceReference.Count > 0)
            {
                foreach (var item in NCubeInstanceReference)
                {
                    xEl.Add(new XElement(ns + "NCubeInstanceReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "NamesOnFirstRow", NamesOnFirstRow));
            return xEl;
        }
    }
}

