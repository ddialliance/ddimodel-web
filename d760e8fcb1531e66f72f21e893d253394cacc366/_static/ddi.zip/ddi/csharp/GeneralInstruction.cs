using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Processing instructions that pertain to data collection or data processing overall such as handling of non-response to questions, imputation practices, suppression rules, etc. General instructions should be listed separately to allow for referencing of specific processes.
    /// <summary>
    public partial class GeneralInstruction : Versionable
    {
        /// <summary>
        /// A description of the general instruction. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Structured information used by a system to process the instruction.
        /// <summary>
        public List<CommandCodeType> CommandCode { get; set; } = new List<CommandCodeType>();
        public bool ShouldSerializeCommandCode() { return CommandCode.Count > 0; }
        /// <summary>
        /// Used when attribute of the containing GeneralInstruction isOverride equals true. This element provides the reference to the GeneralInstruction being overridden by the use of this instruction. For example a special confidentiality process used for a select set of variables rather than the normal process.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeneralInstruction OverriddenCodeReference_GeneralInstruction { get; set; }
        /// <summary>
        /// Used when attribute of the containing GeneralInstruction isOverride equals true. This element provides the reference to the GeneralInstruction being overridden by the use of this instruction. For example a special confidentiality process used for a select set of variables rather than the normal process.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GenerationInstruction OverriddenCodeReference_GenerationInstruction { get; set; }
        /// <summary>
        /// If set to "true", indicates that this coding instruction overrides a more generally used process.
        /// <summary>
        public bool IsOverride { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "GeneralInstruction");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CommandCode != null && CommandCode.Count > 0)
            {
                foreach (var item in CommandCode)
                {
                    xEl.Add(item.ToXml("CommandCode"));
                }
            }
            if (OverriddenCodeReference_GeneralInstruction != null)
            {
                xEl.Add(new XElement(ns + "OverriddenCodeReference_GeneralInstruction", 
                    new XElement(ns + "URN", OverriddenCodeReference_GeneralInstruction.URN), 
                    new XElement(ns + "Agency", OverriddenCodeReference_GeneralInstruction.Agency), 
                    new XElement(ns + "ID", OverriddenCodeReference_GeneralInstruction.ID), 
                    new XElement(ns + "Version", OverriddenCodeReference_GeneralInstruction.Version), 
                    new XElement(ns + "TypeOfObject", OverriddenCodeReference_GeneralInstruction.GetType().Name)));
            }
            if (OverriddenCodeReference_GenerationInstruction != null)
            {
                xEl.Add(new XElement(ns + "OverriddenCodeReference_GenerationInstruction", 
                    new XElement(ns + "URN", OverriddenCodeReference_GenerationInstruction.URN), 
                    new XElement(ns + "Agency", OverriddenCodeReference_GenerationInstruction.Agency), 
                    new XElement(ns + "ID", OverriddenCodeReference_GenerationInstruction.ID), 
                    new XElement(ns + "Version", OverriddenCodeReference_GenerationInstruction.Version), 
                    new XElement(ns + "TypeOfObject", OverriddenCodeReference_GenerationInstruction.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOverride", IsOverride));
            return xEl;
        }
    }
}

