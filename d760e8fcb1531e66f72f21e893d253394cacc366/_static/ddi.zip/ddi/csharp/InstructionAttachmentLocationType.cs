using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows attachment of an instruction to a specific item in a question structure. For example, to a Label, QuestionText, ResponseDomain, Response domain value, or grid cell.
    /// <summary>
    public partial class InstructionAttachmentLocationType
    {
        /// <summary>
        /// Allows attachment of an instruction to a specific item in a code or category scheme. For example, attach a Definition to a specific Code/Category the value.
        /// <summary>
        public AttachmentLocationType AttachmentLocation { get; set; }
        /// <summary>
        /// Identifies the cell or cells in a grid to which the instruction is attached by a reference to a specific cell coordinate in a grid or by identifying a range of values along a dimension.
        /// <summary>
        public GridAttachmentType GridAttachment { get; set; }
        /// <summary>
        /// Attach the instruction to the Question Label.
        /// <summary>
        public bool AttachToLabel { get; set; }
        /// <summary>
        /// Attach the instruction to the QuestionText.
        /// <summary>
        public bool AttachToQuestionText { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AttachmentLocation != null) { xEl.Add(AttachmentLocation.ToXml("AttachmentLocation")); }
            if (GridAttachment != null) { xEl.Add(GridAttachment.ToXml("GridAttachment")); }
            xEl.Add(new XElement(ns + "AttachToLabel", AttachToLabel));
            xEl.Add(new XElement(ns + "AttachToQuestionText", AttachToQuestionText));
            return xEl;
        }
    }
}

