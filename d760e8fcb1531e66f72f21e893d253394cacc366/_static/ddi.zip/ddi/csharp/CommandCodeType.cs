using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains information on the command used for processing data. Contains a description of the command which should clarify for the user the purpose and process of the command, an in-line provision of the command itself, a reference to an external version of the command such as a coding script, and the option for attaching an extension to DDI to permit insertion of a command code in a foreign namespace. Both Command and CommandFile may be repeated to provide command information in additional programming languages. Multiple Command and CommandFile contents are differentiated by the content of the contained element ProgramLanguage.
    /// <summary>
    public partial class CommandCodeType
    {
        /// <summary>
        /// A description of the purpose and use of the command code provided. Supports multiple languages.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This is an in-line provision of the command itself.
        /// <summary>
        public List<CommandType> Command { get; set; } = new List<CommandType>();
        public bool ShouldSerializeCommand() { return Command.Count > 0; }
        /// <summary>
        /// Identifies and provides a link to an external copy of the command, for example, a SAS Command Code script.
        /// <summary>
        public List<CommandFileType> CommandFile { get; set; } = new List<CommandFileType>();
        public bool ShouldSerializeCommandFile() { return CommandFile.Count > 0; }
        /// <summary>
        /// The is an extension stub to allow for the insertion of command code using an external namespace.
        /// <summary>
        public StructuredCommandType StructuredCommand { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Command != null && Command.Count > 0)
            {
                foreach (var item in Command)
                {
                    xEl.Add(item.ToXml("Command"));
                }
            }
            if (CommandFile != null && CommandFile.Count > 0)
            {
                foreach (var item in CommandFile)
                {
                    xEl.Add(item.ToXml("CommandFile"));
                }
            }
            if (StructuredCommand != null) { xEl.Add(StructuredCommand.ToXml("StructuredCommand")); }
            return xEl;
        }
    }
}

