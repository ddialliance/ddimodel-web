using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A roster is an unlabeled list of numbered rows or columns depending upon orientation. The numbers may or may not be displayed but will be used as information for creating the cell coordinate address. The Roster defines the numbering used for the coordinate system, sets a minimum and maximum number of values, and provides the condition for continuation. The Roster label is used in the same way as the label of the CodeDomain, providing a dimension level header or label.
    /// <summary>
    public partial class RosterType
    {
        /// <summary>
        /// A display label for the roster. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public LabelType Label { get; set; }
        /// <summary>
        /// Provides the condition for continuing to add another iteration to the roster. This may be a human readable condition and/or a machine-actionable command.
        /// <summary>
        public CommandCodeType ConditionForContinuation { get; set; }
        /// <summary>
        /// A base value for the first item on the Roster (normally 0 or 1 but can be set to any value especially when the use of a roster extends an enumerated list expressed as an integer.
        /// <summary>
        public int BaseCodeValue { get; set; }
        /// <summary>
        /// The value added to the last used value to create the iteration value for the current row or column expressed as an integer.
        /// <summary>
        public int CodeIterationValue { get; set; }
        /// <summary>
        /// The minimum number of rows or columns required expressed as an integer.
        /// <summary>
        public int MinimumRequired { get; set; }
        /// <summary>
        /// The maximum number of rows or columns allowed expressed as an integer. Leaving this attribute with no value implies that the maximum allowed is unbounded.
        /// <summary>
        public int MaximumAllowed { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Label != null) { xEl.Add(Label.ToXml("Label")); }
            if (ConditionForContinuation != null) { xEl.Add(ConditionForContinuation.ToXml("ConditionForContinuation")); }
            xEl.Add(new XElement(ns + "BaseCodeValue", BaseCodeValue));
            xEl.Add(new XElement(ns + "CodeIterationValue", CodeIterationValue));
            xEl.Add(new XElement(ns + "MinimumRequired", MinimumRequired));
            xEl.Add(new XElement(ns + "MaximumAllowed", MaximumAllowed));
            return xEl;
        }
    }
}

