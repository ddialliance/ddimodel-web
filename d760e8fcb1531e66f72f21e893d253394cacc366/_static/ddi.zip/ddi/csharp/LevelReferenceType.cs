using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a Reference to a GeographicLevel if available and a name for the level. Only one reference can be provided but multiple name provided.
    /// <summary>
    public partial class LevelReferenceType
    {
        /// <summary>
        /// Reference to the Geographic Level as described in the GeographicStructure. TypeOfObject should be set to GeographicLevel.
        /// <summary>
        public GeographicLevelType GeographicLevelReference { get; set; }
        /// <summary>
        /// Name of a geographic level. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public string LevelName_string { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (GeographicLevelReference != null) { xEl.Add(GeographicLevelReference.ToXml("GeographicLevelReference")); }
            if (LevelName_string != null)
            {
                xEl.Add(new XElement(ns + "LevelName_string", LevelName_string));
            }
            return xEl;
        }
    }
}

