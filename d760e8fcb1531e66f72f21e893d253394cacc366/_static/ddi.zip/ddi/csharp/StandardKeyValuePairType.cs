using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A basic data representation for computing systems and applications expressed as a tuple (attribute key, value). Attribute keys may or may not be unique.
    /// <summary>
    public partial class StandardKeyValuePairType
    {
        /// <summary>
        /// This key (sometimes referred to as a name) expressed as a string. Supports the use of an external controlled vocabulary which is the recommended approach.
        /// <summary>
        public CodeValueType AttributeKey { get; set; }
        /// <summary>
        /// The value assigned to the named Key expressed as a string. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType AttributeValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AttributeKey != null) { xEl.Add(AttributeKey.ToXml("AttributeKey")); }
            if (AttributeValue != null) { xEl.Add(AttributeValue.ToXml("AttributeValue")); }
            return xEl;
        }
    }
}

