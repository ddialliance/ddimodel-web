using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the segment of textual content used by the parent object. Can identify a set of lines and or characters used to define the segment.
    /// <summary>
    public partial class TextualType
    {
        /// <summary>
        /// Specification of the line and offset for the beginning and end of the segment.
        /// <summary>
        public LineParameterType LineParameter { get; set; }
        /// <summary>
        /// Specification of the character offset for the beginning and end of the segment.
        /// <summary>
        public CharacterParameterType CharacterParameter { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (LineParameter != null) { xEl.Add(LineParameter.ToXml("LineParameter")); }
            if (CharacterParameter != null) { xEl.Add(CharacterParameter.ToXml("CharacterParameter")); }
            return xEl;
        }
    }
}

