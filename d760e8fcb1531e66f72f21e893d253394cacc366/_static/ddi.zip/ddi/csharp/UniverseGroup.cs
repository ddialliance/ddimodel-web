using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a group of Universes, which may describe an ordered or hierarchical relationship structure. Specifies the purpose of the group, a name, label, and description of the group, its relationship to a specific universe or concept, and lists the members of the group. Use primarily for administrative purposes. If structuring nesting of Universes to represent a hierarchical set of universes use the SubUniverseClass found in Universe.
    /// <summary>
    public partial class UniverseGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a UniverseGroup. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfUniverseGroup { get; set; }
        /// <summary>
        /// A name for the group. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> UniverseGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeUniverseGroupName() { return UniverseGroupName.Count > 0; }
        /// <summary>
        /// A display label for the UniverseGroup. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the UniverseGroup. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain. This is not a university contained by the group but one that helps define the purpose and application of the group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> GroupingUniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeGroupingUniverseReference() { return GroupingUniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group. Note that this is not a formal linking of a concept to a university such as found in a ConceptualVariable. It is a means of helping to define the context within which this ConceptGroup is relevant.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept GroupingConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent Universe (from the substitution group). TypeOfObject should be set to Universe.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Universe UniverseReference { get; set; }
        /// <summary>
        /// Reference to constituent UniverseGroup. This allows for nesting of UniverseGroups. TypeOfObject should be set to UniverseGroup.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public UniverseGroup UniverseGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "UniverseGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfUniverseGroup != null) { xEl.Add(TypeOfUniverseGroup.ToXml("TypeOfUniverseGroup")); }
            if (UniverseGroupName != null && UniverseGroupName.Count > 0)
            {
                foreach (var item in UniverseGroupName)
                {
                    xEl.Add(item.ToXml("UniverseGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GroupingUniverseReference != null && GroupingUniverseReference.Count > 0)
            {
                foreach (var item in GroupingUniverseReference)
                {
                    xEl.Add(new XElement(ns + "GroupingUniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GroupingConceptReference != null)
            {
                xEl.Add(new XElement(ns + "GroupingConceptReference", 
                    new XElement(ns + "URN", GroupingConceptReference.URN), 
                    new XElement(ns + "Agency", GroupingConceptReference.Agency), 
                    new XElement(ns + "ID", GroupingConceptReference.ID), 
                    new XElement(ns + "Version", GroupingConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", GroupingConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (UniverseReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseReference", 
                    new XElement(ns + "URN", UniverseReference.URN), 
                    new XElement(ns + "Agency", UniverseReference.Agency), 
                    new XElement(ns + "ID", UniverseReference.ID), 
                    new XElement(ns + "Version", UniverseReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseReference.GetType().Name)));
            }
            if (UniverseGroupReference != null)
            {
                xEl.Add(new XElement(ns + "UniverseGroupReference", 
                    new XElement(ns + "URN", UniverseGroupReference.URN), 
                    new XElement(ns + "Agency", UniverseGroupReference.Agency), 
                    new XElement(ns + "ID", UniverseGroupReference.ID), 
                    new XElement(ns + "Version", UniverseGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", UniverseGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

