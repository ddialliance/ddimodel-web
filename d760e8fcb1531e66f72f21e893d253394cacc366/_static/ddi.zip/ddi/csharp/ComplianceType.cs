using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for a quality statement based on frameworks to be described using itemized properties. A reference to a concept, a coded value, or both can be used to specify the property from the standard framework identified in StandardUsed. ComplianceDescription can provide further details or a general description of compliance with a standard.
    /// <summary>
    public partial class ComplianceType
    {
        /// <summary>
        /// A reference to a concept which relates to an area of coverage of the standard.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ComplianceConceptReference { get; set; }
        /// <summary>
        /// Specification of a code which relates to an area of coverage of the standard. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType ExternalComplianceCode { get; set; }
        /// <summary>
        /// Allows for a quality statement based on frameworks to be described using itemized properties. A reference to a concept, a coded value, or both can be used to specify the property from the standard framework identified in StandardUsed. ComplianceDescription can provide further details or a general description of compliance with a standard.
        /// <summary>
        public List<ComplianceType> Compliance { get; set; } = new List<ComplianceType>();
        public bool ShouldSerializeCompliance() { return Compliance.Count > 0; }
        /// <summary>
        /// Describe the measures taken to comply with the standards and/or specific levels of compliance by providing further details or a general description of compliance with the standard.
        /// <summary>
        public StructuredStringType ComplianceDescription { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ComplianceConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ComplianceConceptReference", 
                    new XElement(ns + "URN", ComplianceConceptReference.URN), 
                    new XElement(ns + "Agency", ComplianceConceptReference.Agency), 
                    new XElement(ns + "ID", ComplianceConceptReference.ID), 
                    new XElement(ns + "Version", ComplianceConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ComplianceConceptReference.GetType().Name)));
            }
            if (ExternalComplianceCode != null) { xEl.Add(ExternalComplianceCode.ToXml("ExternalComplianceCode")); }
            if (Compliance != null && Compliance.Count > 0)
            {
                foreach (var item in Compliance)
                {
                    xEl.Add(item.ToXml("Compliance"));
                }
            }
            if (ComplianceDescription != null) { xEl.Add(ComplianceDescription.ToXml("ComplianceDescription")); }
            return xEl;
        }
    }
}

