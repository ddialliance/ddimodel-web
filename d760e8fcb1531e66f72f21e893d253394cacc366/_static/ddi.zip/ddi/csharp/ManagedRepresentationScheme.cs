using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This scheme contains sets of values described by ManagedRepresentation. These are used by reference to define Variable Representation and Question Response Domain. Text representations cover all non-code and non-category representations/response domains that should be treated or analyzed as characters regardless of whether the character is a number or a letter. In addition to the name, label and description of the scheme, the structure allows for the inclusion on an external scheme by reference, definitions of ManagedRepresentations in-line or by reference, and ManagedRepresentationGroups in-line or by reference.
    /// <summary>
    public partial class ManagedRepresentationScheme : Maintainable
    {
        /// <summary>
        /// A name for the scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedRepresentationSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedRepresentationSchemeName() { return ManagedRepresentationSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the scheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to another ManagedRepresentationScheme to include in this scheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ManagedRepresentationScheme> ManagedRepresentationSchemeReference { get; set; } = new List<ManagedRepresentationScheme>();
        public bool ShouldSerializeManagedRepresentationSchemeReference() { return ManagedRepresentationSchemeReference.Count > 0; }
        /// <summary>
        /// A description of a text based representation to be used by a question response domain or variable value representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Versionable> ManagedRepresentationReference { get; set; } = new List<Versionable>();
        public bool ShouldSerializeManagedRepresentationReference() { return ManagedRepresentationReference.Count > 0; }
        /// <summary>
        /// A grouping of ManagedRepresentations for conceptual, administrative or other reasons.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ManagedRepresentationGroup> ManagedRepresentationGroupReference { get; set; } = new List<ManagedRepresentationGroup>();
        public bool ShouldSerializeManagedRepresentationGroupReference() { return ManagedRepresentationGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ManagedRepresentationScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedRepresentationSchemeName != null && ManagedRepresentationSchemeName.Count > 0)
            {
                foreach (var item in ManagedRepresentationSchemeName)
                {
                    xEl.Add(item.ToXml("ManagedRepresentationSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ManagedRepresentationSchemeReference != null && ManagedRepresentationSchemeReference.Count > 0)
            {
                foreach (var item in ManagedRepresentationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ManagedRepresentationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ManagedRepresentationReference != null && ManagedRepresentationReference.Count > 0)
            {
                foreach (var item in ManagedRepresentationReference)
                {
                    xEl.Add(new XElement(ns + "ManagedRepresentationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ManagedRepresentationGroupReference != null && ManagedRepresentationGroupReference.Count > 0)
            {
                foreach (var item in ManagedRepresentationGroupReference)
                {
                    xEl.Add(new XElement(ns + "ManagedRepresentationGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

