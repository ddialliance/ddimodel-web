using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An assessment of the quality of the metadata within the Maintainable object, e.g. the quality of the transcription, completeness, editing status, etc. It indicates the type of metadata quality being assesed, the purpose of providing the measure, and either a value for the quality from a controlled vocabulary and/or a description of the value.
    /// <summary>
    public partial class MetadataQualityType
    {
        /// <summary>
        /// A brief statement of the metadata quality being measured. Supports the use of an external controlled vocabulary. Use of a controlled vocabulary is strongly recommended.
        /// <summary>
        public CodeValueType TypeOfMetadataQuality { get; set; }
        /// <summary>
        /// The purpose of the type of metadata quality and its value. Supports multiple languages and the use of structured content.
        /// <summary>
        public StructuredStringType MeasurePurpose { get; set; }
        /// <summary>
        /// A value representing the measurement of this set of metadata within the context of the TypeOfMetadataQuality indicated. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType MeasureValue { get; set; }
        /// <summary>
        /// A textual description of the quality of this set of metadata which expands on or is provided in lieu of other objects within MetadataQuality. Supports multiple languages and the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TypeOfMetadataQuality != null) { xEl.Add(TypeOfMetadataQuality.ToXml("TypeOfMetadataQuality")); }
            if (MeasurePurpose != null) { xEl.Add(MeasurePurpose.ToXml("MeasurePurpose")); }
            if (MeasureValue != null) { xEl.Add(MeasureValue.ToXml("MeasureValue")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

