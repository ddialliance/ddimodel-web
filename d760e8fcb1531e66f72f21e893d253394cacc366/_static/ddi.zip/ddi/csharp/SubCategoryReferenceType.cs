using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to one or more categories for which the current category is a broader definition. Allows for a reference to the narrower category and the ability to define the relationship as a specialization or part. TypeOfObject should be set to Category.
    /// <summary>
    public partial class SubCategoryReferenceType : ReferenceType
    {
        /// <summary>
        /// Defines the sub-category in terms being generic or partitive in nature. For example, a radial tire is a type of tire (generic) while a tire is a part of a car (partitive). The value refers to the role of the SubCategory within the broader category .
        /// <summary>
        [StringValidation(new string[] {
            "specialization"
,             "isPartOf"
        })]
        public string TypeOfSubCategory { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSubCategory != null)
            {
                xEl.Add(new XElement(ns + "TypeOfSubCategory", TypeOfSubCategory));
            }
            return xEl;
        }
    }
}

