using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specifies by reference the ResourcePackages required to resolve the module.
    /// <summary>
    public partial class RequiredResourcePackagesType
    {
        /// <summary>
        /// References a resource package used by the module.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ResourcePackage> ResourcePackageReference { get; set; } = new List<ResourcePackage>();
        public bool ShouldSerializeResourcePackageReference() { return ResourcePackageReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ResourcePackageReference != null && ResourcePackageReference.Count > 0)
            {
                foreach (var item in ResourcePackageReference)
                {
                    xEl.Add(new XElement(ns + "ResourcePackageReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

