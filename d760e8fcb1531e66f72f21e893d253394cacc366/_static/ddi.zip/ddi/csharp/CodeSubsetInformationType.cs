using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows further specification of the codes to use from the CodeList by defining the level or only the most discrete codes of a hierarchical CodeList, the range of codes to use, or an itemized sub-set.
    /// <summary>
    public partial class CodeSubsetInformationType
    {
        /// <summary>
        /// Identifies the specific level to include using the levelNumber. Repeat if more than one level is included.
        /// <summary>
        public List<int> IncludedLevel { get; set; } = new List<int>();
        public bool ShouldSerializeIncludedLevel() { return IncludedLevel.Count > 0; }
        /// <summary>
        /// Specifies the codes to include in the representation.
        /// <summary>
        public IncludedCodeType IncludedCode { get; set; }
        /// <summary>
        /// Use when only the lowest, most discrete codes in the CodeList will be expressed as valid values. Identifies those levels of a CodeList with a regular hierarchy or those indicates discrete codes within an irregular hierarchy. All other codes will be used as labels within the hierarchy to clearly express content, but will not be valid as a response or representation value.
        /// <summary>
        public DataExistenceType DataExistence { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            xEl.Add(
                from item in IncludedLevel
                select new XElement(ns + "IncludedLevel", item));
            if (IncludedCode != null) { xEl.Add(IncludedCode.ToXml("IncludedCode")); }
            if (DataExistence != null) { xEl.Add(DataExistence.ToXml("DataExistence")); }
            return xEl;
        }
    }
}

