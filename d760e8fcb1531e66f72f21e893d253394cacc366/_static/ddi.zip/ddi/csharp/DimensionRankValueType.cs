using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A dimension describes the rank or order of the dimension within the NCube structure and provides the specific coordinate value of the dimension for the data item. In the case where the value is found within the data file, it provides a reference to the variable containing the value.
    /// <summary>
    public partial class DimensionRankValueType
    {
        /// <summary>
        /// References the Variable holding the dimension value. Use this instead of the value attribute when the value must be obtained from the data file at the location of the variable indicated in the reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// The value of this dimension for this particular data item.
        /// <summary>
        public string Value_string { get; set; }
        /// <summary>
        /// Enter the rank (placement) order in which the value from this dimension appears in the coordinate address of any cell in the NCube matrix.
        /// <summary>
        public int Rank { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (Value_string != null)
            {
                xEl.Add(new XElement(ns + "Value_string", Value_string));
            }
            xEl.Add(new XElement(ns + "Rank", Rank));
            return xEl;
        }
    }
}

