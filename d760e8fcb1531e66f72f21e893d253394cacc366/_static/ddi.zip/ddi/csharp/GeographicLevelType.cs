using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a level within the GeographicStructure. In addition to a name and description, provides one or more GeographicLevelCodes by which it is identified with specified system, any coverage limitations, and parent position within a single hierarchy or if it is the result of layering multiple hierarchies, the lowest component level for each of the layering hierarchies. Allows for an indicator declaring that coverage of the parent level is or is not exhaustive.
    /// <summary>
    public partial class GeographicLevelType : IdentifiableType
    {
        /// <summary>
        /// A name for the GeographicLevel. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> GeographicLevelName { get; set; } = new List<NameType>();
        public bool ShouldSerializeGeographicLevelName() { return GeographicLevelName.Count > 0; }
        /// <summary>
        /// A description of the GeographicLevel. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A code and its authorization source for identifying the level within a specific system.
        /// <summary>
        public List<CodeValueType> GeographicLevelCode { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeGeographicLevelCode() { return GeographicLevelCode.Count > 0; }
        /// <summary>
        /// Describes a limitation of the coverage such as all objects of a specific type that meet population size requirements (i.e., All Places with a population of 10,000 or more).
        /// <summary>
        public InternationalStringType CoverageLimitation { get; set; }
        /// <summary>
        /// Provides references to the base level elements that are used as building blocks for composed geographies. For example, Metropolitan areas that are composed of counties except in the New England States where they are composed of county subdivisions, or School Attendance Boundaries (SABINS) built from Census Blocks. This structure allows for specifying the basic building block for composed areas and any restrictions (coverage limitations). The field may be repeated to provide alternate information on the basic building blocks for areas outside of the coverage limitations described.
        /// <summary>
        public List<PrimaryComponentLevelType> PrimaryComponentLevel { get; set; } = new List<PrimaryComponentLevelType>();
        public bool ShouldSerializePrimaryComponentLevel() { return PrimaryComponentLevel.Count > 0; }
        /// <summary>
        /// Reference to a single containing (parent) geography.
        /// <summary>
        public GeographicLevelType ParentGeographicLevelReference { get; set; }
        /// <summary>
        /// Use for geographic polygons that are the result of layering two or more geographic hierarchies where the polygon being described is the intersect of the layers. For example: State - County - County Subdivision - Place/Remainder - Tract [The portion of a tract that is within a single place (or non-place area) and a single county subdivision] This polygon is made by overlaying the following three geographic hierarchies: 1) State - Place, 2) State - County - Tract, and 3) State - County - Subdivision. The three GeographicLayerBase elements would point to Tract, Place, and County Subdivision.
        /// <summary>
        public List<GeographicLevelType> GeographicLayerBaseReference { get; set; } = new List<GeographicLevelType>();
        public bool ShouldSerializeGeographicLayerBaseReference() { return GeographicLayerBaseReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (GeographicLevelName != null && GeographicLevelName.Count > 0)
            {
                foreach (var item in GeographicLevelName)
                {
                    xEl.Add(item.ToXml("GeographicLevelName"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GeographicLevelCode != null && GeographicLevelCode.Count > 0)
            {
                foreach (var item in GeographicLevelCode)
                {
                    xEl.Add(item.ToXml("GeographicLevelCode"));
                }
            }
            if (CoverageLimitation != null) { xEl.Add(CoverageLimitation.ToXml("CoverageLimitation")); }
            if (PrimaryComponentLevel != null && PrimaryComponentLevel.Count > 0)
            {
                foreach (var item in PrimaryComponentLevel)
                {
                    xEl.Add(item.ToXml("PrimaryComponentLevel"));
                }
            }
            if (ParentGeographicLevelReference != null) { xEl.Add(ParentGeographicLevelReference.ToXml("ParentGeographicLevelReference")); }
            if (GeographicLayerBaseReference != null && GeographicLayerBaseReference.Count > 0)
            {
                foreach (var item in GeographicLayerBaseReference)
                {
                    xEl.Add(item.ToXml("GeographicLayerBaseReference"));
                }
            }
            return xEl;
        }
    }
}

