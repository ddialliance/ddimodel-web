using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Used to describe the levels of the code list hierarchy. The level describes the nesting structure of a hierarchical coding structure. A level could have data attached to it (summary of its children) or no data attached to it (the equivalent of creating a category group in 2.0 and earlier versions Note that the attribute levelNumber is used for referencing specific codes to their level identifier. Although Code Lists can be physically nested, the use of a Level description and the level number on a specific code is needed to specify subsets of the CodeList for use in CodeRepresentations by level specification. Provides a name, description and level number. Specifies the relationship between the categories at that level and interval value if the relationship has the value of Interval.
    /// <summary>
    public partial class LevelType
    {
        /// <summary>
        /// Name of a level in a code scheme. This should be short and explicit, such as Major Industrial Groups (2 digit SIC Codes) or NUTS 1. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> LevelName { get; set; } = new List<NameType>();
        public bool ShouldSerializeLevelName() { return LevelName.Count > 0; }
        /// <summary>
        /// A description of the code Level. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describes the relationships among categories at that respective level. Possible values are either Nominal, Ordinal, or Interval. Note that different levels may have different types of relationships within the same hierarchy. For example, Level 1 items may be ordinal and Level 2 (the children of Level 1 items) may be nominal.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string CategoryRelationship { get; set; }
        /// <summary>
        /// Identifies the interval between each value of the codes at this level. Used only for codes with interval relationship.
        /// <summary>
        public IntervalType Interval_IntervalType { get; set; }
        /// <summary>
        /// Designated identifier for the level; generally increases as the level of indention for nesting increases.
        /// <summary>
        public int LevelNumber { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (LevelName != null && LevelName.Count > 0)
            {
                foreach (var item in LevelName)
                {
                    xEl.Add(item.ToXml("LevelName"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CategoryRelationship != null)
            {
                xEl.Add(new XElement(ns + "CategoryRelationship", CategoryRelationship));
            }
            if (Interval_IntervalType != null) { xEl.Add(Interval_IntervalType.ToXml("Interval_IntervalType")); }
            xEl.Add(new XElement(ns + "LevelNumber", LevelNumber));
            return xEl;
        }
    }
}

