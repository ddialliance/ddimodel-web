using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for grouping of concepts; groups may have a hierarchical structure. This structure should not be used to model semantic concept hierarchies - for this purpose, use the SubclassOfReference element within Concept.
    /// <summary>
    public partial class ConceptGroup : Versionable
    {
        /// <summary>
        /// Specifies the purpose of the ConceptGroup. If conceptual the GroupingConceptReference or GroupingUniverseReference should be used to further define the group. The object allows for specification of the purpose using a brief string or term. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfConceptGroup { get; set; }
        /// <summary>
        /// A name for the ConceptGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ConceptGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeConceptGroupName() { return ConceptGroupName.Count > 0; }
        /// <summary>
        /// A display label for the ConceptGroup. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ConceptGroup. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain. Note that this is not a formal linking of a concept to a university such as found in a ConceptualVariable. It is a means of helping to define the context within which this ConceptGroup is relevant.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> GroupingUniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeGroupingUniverseReference() { return GroupingUniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group. Expresses a conceptual basis for grouping the concepts. Note that this is not a formal linking of a concept to a university such as found in a ConceptualVariable. It is a means of helping to define the context within which this ConceptGroup is relevant.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept GroupingConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to a concept included in the concept group. A concept can be referenced internally, from the concept scheme included in the same conceptual components module, or externally, from another scheme. This element is recursive to allow for the description of hierarchical relationships within the concept group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to a subordinate concept group included in the concept group. A concept group can be referenced internally, from the concept scheme included in the same conceptual components module, or externally, from another scheme. This element is recursive to allow for the description of hierarchical relationships within the concept group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ConceptGroup ConceptGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }
        /// <summary>
        /// Indicates the purpose of a concept group.
        /// <summary>
        public bool IsAdministrativeOnly { get; set; }
        /// <summary>
        /// A value of true indicates that there is a concept which defines the group, and which is comprised of the concepts contained in the group. A group can be conceptual in purpose (that is, have a value of "concept" for the purpose attribute), but not itself have a defining concept.
        /// <summary>
        public bool IsConcept { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ConceptGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfConceptGroup != null) { xEl.Add(TypeOfConceptGroup.ToXml("TypeOfConceptGroup")); }
            if (ConceptGroupName != null && ConceptGroupName.Count > 0)
            {
                foreach (var item in ConceptGroupName)
                {
                    xEl.Add(item.ToXml("ConceptGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (GroupingUniverseReference != null && GroupingUniverseReference.Count > 0)
            {
                foreach (var item in GroupingUniverseReference)
                {
                    xEl.Add(new XElement(ns + "GroupingUniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GroupingConceptReference != null)
            {
                xEl.Add(new XElement(ns + "GroupingConceptReference", 
                    new XElement(ns + "URN", GroupingConceptReference.URN), 
                    new XElement(ns + "Agency", GroupingConceptReference.Agency), 
                    new XElement(ns + "ID", GroupingConceptReference.ID), 
                    new XElement(ns + "Version", GroupingConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", GroupingConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (ConceptGroupReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptGroupReference", 
                    new XElement(ns + "URN", ConceptGroupReference.URN), 
                    new XElement(ns + "Agency", ConceptGroupReference.Agency), 
                    new XElement(ns + "ID", ConceptGroupReference.ID), 
                    new XElement(ns + "Version", ConceptGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            xEl.Add(new XElement(ns + "IsAdministrativeOnly", IsAdministrativeOnly));
            xEl.Add(new XElement(ns + "IsConcept", IsConcept));
            return xEl;
        }
    }
}

