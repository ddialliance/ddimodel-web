using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A user provided identifier that is locally unique within its specific type. The required type attribute points to the local user identification system that defines the values. The optional userIDVersion allows specification of a version number for the identifier. If multiple UserIDs are used they must be differentiated by the type attribute.
    /// <summary>
    public partial class UserIDType : string
    {
        /// <summary>
        /// This is a required attribute containing the local user identification system that maintains and defines the UserID.
        /// <summary>
        public string TypeOfUserID { get; set; }
        /// <summary>
        /// The UserID may designate the version number of the UserID. This is important in cases where the DDI identification system and the UserID system use different structures to record version numbers or if there is a difference between the DDI version number and the UserID's version number.
        /// <summary>
        public string UserIDVersion { get; set; }
        /// <summary>
        /// This is the name of the versioning scheme as defined by the user's system, in cases where the user's system employs more than one versioning scheme. It is specific to the system identified by the typeOfUserID attribute
        /// <summary>
        public string TypeOfUserVersion { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("string").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfUserID != null)
            {
                xEl.Add(new XElement(ns + "TypeOfUserID", TypeOfUserID));
            }
            if (UserIDVersion != null)
            {
                xEl.Add(new XElement(ns + "UserIDVersion", UserIDVersion));
            }
            if (TypeOfUserVersion != null)
            {
                xEl.Add(new XElement(ns + "TypeOfUserVersion", TypeOfUserVersion));
            }
            return xEl;
        }
    }
}

