using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A textual statement used in the Instrument. A substitution for ControlConstruct. In addition to the objects found in ControlConstruct StatementItem adds the text for display at the specified point within the instrument.
    /// <summary>
    public partial class StatementItem : ControlConstruct
    {
        /// <summary>
        /// Text to be displayed by the instrument. Supports the use of DynamicText. Note that when using Dynamic Text, the full DisplayText must be repeated for multi-language versions of the content. Different languages may handle the dynamic portions in different locations and/or with different content. Therefore languages cannot be mixed within a dynamic text except when the full text itself has multiple language sections, for example, a foreign language term in a text. The DisplayText may also be repeated to provide a dynamic and plain text version of the display. This allows for accurate rendering of the display in a non-dynamic environment like print.
        /// <summary>
        public List<DynamicTextType> DisplayText { get; set; } = new List<DynamicTextType>();
        public bool ShouldSerializeDisplayText() { return DisplayText.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "StatementItem");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DisplayText != null && DisplayText.Count > 0)
            {
                foreach (var item in DisplayText)
                {
                    xEl.Add(item.ToXml("DisplayText"));
                }
            }
            return xEl;
        }
    }
}

