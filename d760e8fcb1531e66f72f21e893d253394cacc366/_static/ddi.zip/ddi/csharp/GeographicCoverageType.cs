using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the geographic coverage of the data documented in a particular DDI module. If subordinate to another module, this description should be a sub-set of the parent module's geographic coverage. Contains a definition for a Bounding Box used for coordinate searches, a definition of the geographic coverage, a reference to a variable that describes the geographic structure, definition of the spatial object of the data, a reference to a GeographicStructure and GeographicLocation providing further details of the coverage, and specification of the geographic summary levels for which data are provided, the top and lowest levels of geographic identification provided.
    /// <summary>
    public partial class GeographicCoverageType : IdentifiableType
    {
        /// <summary>
        /// The Bounding Box is a 'rectangle, oriented to the x and y axes, which bounds a geographic feature or a geographic dataset. It is specified by two coordinates: xmin, ymin and xmax, ymax.' [FGDC]. In the DDI, it describes the full extent of the geographic coverage, and is designed to be used by systems that search for geography by coordinates. It is compatible with the description and structure found in FGDC and other geographic metadata structures.
        /// <summary>
        public BoundingBoxType BoundingBox { get; set; }
        /// <summary>
        /// A summary description of the geographic (spatial) coverage of the module. It may include information on all levels of spatial coverage, in addition to the overall coverage. This field can map to Dublin Core Coverage, which does not support structured strings. Therefore, if there is intent to map to Dublin Core, the text should not be marked up with XHTML. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Serves as head of a substitution group for specifying ISO 3166 Country Codes or use of unspecified text. Use of ISO 3166 Country codes strongly recommended. Repeat for each country. If
        /// <summary>
        public List<CountryCodeType> CountryCode { get; set; } = new List<CountryCodeType>();
        public bool ShouldSerializeCountryCode() { return CountryCode.Count > 0; }
        /// <summary>
        /// References a variable describing the geographic levels available in the data such as the variable "Summary Level" in U.S. Census data. This reference is needed for assistance in programming.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable GeographyStructureVariableReference { get; set; }
        /// <summary>
        /// Contains information on the most discrete type of spatial representation to which data described by this module can be attached (point, line, polygon, linear ring). For example, a raw data file with an address attached to each case is 'point'. When the microdata file is anonymized and the geographic information is for a state or other defined area, it is 'polygon'. Some data, such as traffic or criminal incidence data may have a street range identification or 'line', and some such as communications data have a point with a radius or 'linear ring'.
        /// <summary>
        [StringValidation(new string[] {
            "Point"
,             "Polygon"
,             "Line"
,             "LinearRing"
        })]
        public string SpatialObject { get; set; }
        /// <summary>
        /// Reference to the detailed information found in a GeographicStructure. Allows for the exclusion of specified LevelValues.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicStructure GeographicStructureReference { get; set; }
        /// <summary>
        /// Reference to specific LevelValue found in a GeographicStructure. Use when only a limited number of GeographicLevel are used from a GeographicStructure.
        /// <summary>
        public GeographicLevelType GeographicLevelReference { get; set; }
        /// <summary>
        /// Reference to detailed listing of named locations within the data described by a 	GeographicLocation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicLocation GeographicLocationReference { get; set; }
        /// <summary>
        /// Reference to specific LocationValue found in a GeographicLocation. Use when only a limited number of LocationValue are used from a GeographicStructure.
        /// <summary>
        public LocationValueType LocationValueReference { get; set; }
        /// <summary>
        /// May be repeated to reference each geography (geographic level) for which there is summary data. For example, person records may contain summary data on the State, County, or City in which they reside. In data collections where the individual case is a geographic location such as a County, data may be provided that summarizes State or National data. This is often true where data suppression at lower geographies makes it impossible to roll-up or aggregate the data to obtain values for the higher levels.
        /// <summary>
        public List<GeographicLevelType> SummaryDataReference { get; set; } = new List<GeographicLevelType>();
        public bool ShouldSerializeSummaryDataReference() { return SummaryDataReference.Count > 0; }
        /// <summary>
        /// Reference to the top or highest GeographicLevel.
        /// <summary>
        public LevelReferenceType TopLevelReference { get; set; }
        /// <summary>
        /// Reference to the bottom or lowest GeographicLevel.
        /// <summary>
        public LevelReferenceType LowestLevelReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (BoundingBox != null) { xEl.Add(BoundingBox.ToXml("BoundingBox")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (CountryCode != null && CountryCode.Count > 0)
            {
                foreach (var item in CountryCode)
                {
                    xEl.Add(item.ToXml("CountryCode"));
                }
            }
            if (GeographyStructureVariableReference != null)
            {
                xEl.Add(new XElement(ns + "GeographyStructureVariableReference", 
                    new XElement(ns + "URN", GeographyStructureVariableReference.URN), 
                    new XElement(ns + "Agency", GeographyStructureVariableReference.Agency), 
                    new XElement(ns + "ID", GeographyStructureVariableReference.ID), 
                    new XElement(ns + "Version", GeographyStructureVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographyStructureVariableReference.GetType().Name)));
            }
            if (SpatialObject != null)
            {
                xEl.Add(new XElement(ns + "SpatialObject", SpatialObject));
            }
            if (GeographicStructureReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicStructureReference", 
                    new XElement(ns + "URN", GeographicStructureReference.URN), 
                    new XElement(ns + "Agency", GeographicStructureReference.Agency), 
                    new XElement(ns + "ID", GeographicStructureReference.ID), 
                    new XElement(ns + "Version", GeographicStructureReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicStructureReference.GetType().Name)));
            }
            if (GeographicLevelReference != null) { xEl.Add(GeographicLevelReference.ToXml("GeographicLevelReference")); }
            if (GeographicLocationReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicLocationReference", 
                    new XElement(ns + "URN", GeographicLocationReference.URN), 
                    new XElement(ns + "Agency", GeographicLocationReference.Agency), 
                    new XElement(ns + "ID", GeographicLocationReference.ID), 
                    new XElement(ns + "Version", GeographicLocationReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicLocationReference.GetType().Name)));
            }
            if (LocationValueReference != null) { xEl.Add(LocationValueReference.ToXml("LocationValueReference")); }
            if (SummaryDataReference != null && SummaryDataReference.Count > 0)
            {
                foreach (var item in SummaryDataReference)
                {
                    xEl.Add(item.ToXml("SummaryDataReference"));
                }
            }
            if (TopLevelReference != null) { xEl.Add(TopLevelReference.ToXml("TopLevelReference")); }
            if (LowestLevelReference != null) { xEl.Add(LowestLevelReference.ToXml("LowestLevelReference")); }
            return xEl;
        }
    }
}

