using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Lists the value and format type for the coordinate value. Note that this is a single value (X coordinate or Y coordinate) rather than a coordinate pair.
    /// <summary>
    public partial class SpatialCoordinateType
    {
        /// <summary>
        /// The value of the coordinate expressed as a string.
        /// <summary>
        public string CoordinateValue { get; set; }
        /// <summary>
        /// Identifies the type of point coordinate system using a controlled vocabulary. Point formats include decimal degree, degrees minutes seconds, decimal minutes, meters, and feet.
        /// <summary>
        [StringValidation(new string[] {
            "DecimalDegree"
,             "DegreesMinutesSeconds"
,             "DecimalMinutes"
,             "Meters"
,             "Feet"
        })]
        public string CoordinateType { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CoordinateValue != null)
            {
                xEl.Add(new XElement(ns + "CoordinateValue", CoordinateValue));
            }
            if (CoordinateType != null)
            {
                xEl.Add(new XElement(ns + "CoordinateType", CoordinateType));
            }
            return xEl;
        }
    }
}

