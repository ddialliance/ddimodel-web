using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the value of the ResponseDomain to which the new ResponseDomain is attached by specifying its attachmentBase number of the target ResponseDomain in the attribute attachmentDomain. Specifies one or more values within the ResponseDomain to which the object is attached (i.e. single item or set).
    /// <summary>
    public partial class DomainSpecificValueType
    {
        /// <summary>
        /// The value of the target response domain to which the object should be attached.
        /// <summary>
        public List<ValueType> Value { get; set; } = new List<ValueType>();
        public bool ShouldSerializeValue() { return Value.Count > 0; }
        /// <summary>
        /// This is the value of the attribute "attachmentBase" on the ResponseDomainInMixed to which the specified response domain will be attached. This is used to clarify attachment locations when more than two response domains are provided in a StructuredMixedResponseDomain.
        /// <summary>
        public int AttachmentDomain { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Value != null && Value.Count > 0)
            {
                foreach (var item in Value)
                {
                    xEl.Add(item.ToXml("Value"));
                }
            }
            xEl.Add(new XElement(ns + "AttachmentDomain", AttachmentDomain));
            return xEl;
        }
    }
}

