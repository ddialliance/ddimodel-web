using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of a PhysicalStructure providing the primary link to the LogicalRecord and general structural information. Each description can apply to one or more data files containing the same logical records in the same overall structure.
    /// <summary>
    public class PhysicalStructure : Versionable
    {
        /// <summary>
        /// A brief textual description or classification of the format of the file (e.g., SAS save file, Delimited file, Fixed format file, DDI DataSet). Supports the use of an external controlled vocabulary. DDI recommends the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType FileFormat { get; set; }
        /// <summary>
        /// Defines the data type to use unless otherwise specified. Supports the use of an external controlled vocabulary. Similar content to RecommendedDataType.
        /// <summary>
        public CodeValueType DefaultDataType { get; set; }
        /// <summary>
        /// Delimiter definition for delimited (free field) data that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: Empty (default), Tab, Blank, AnyString. If a delimiter is used, free field (delimited data) is assumed; binary formats are not allowed..
        /// <summary>
        public DelimiterType DefaultDelimiter { get; set; }
        /// <summary>
        /// Number of decimal places (expressed as an integer) for data with an implied decimal separator that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Another expression is the decimal scaling factor (SAS). Default: 0.
        /// <summary>
        public int DefaultDecimalPositions { get; set; }
        /// <summary>
        /// The character used to separate the integer and the fraction part of a number (if an explicit separator is used in the data) that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: None (default), Dot, Comma, Other. On the basis of the data definition in DDI documents, data processing tools could compute the necessary precision width on the basis of the format width and the existence of separators. Appropriate data types could be used, i.e. float or double, short or long. The decimal separator definition only makes sense with some XML Schema primitives. This is a default which may be overridden in specific cases.
        /// <summary>
        [StringLength(1)]
        public string DefaultDecimalSeparator { get; set; }
        /// <summary>
        /// The character used to separate groups of digits (if an explicit separator is used in the data) that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: None (default), Dot, Comma, Other. The decimal separator definition makes only sense with some XML Schema primitives. This is a default which may be overridden in specific cases.
        /// <summary>
        [StringLength(1)]
        public string DefaultDigitGroupSeparator { get; set; }
        /// <summary>
        /// The gross or macro level structures of the record structure including the link to the LogicalRecord and information on the number and ordering of each Physical Segment of the LogicalRecord as stored in the data file.
        /// <summary>
        public List<GrossRecordStructureType> GrossRecordStructure { get; set; } = new List<GrossRecordStructureType>();
        public bool ShouldSerializeGrossRecordStructure() { return GrossRecordStructure.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "PhysicalStructure");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (FileFormat != null) { xEl.Add(FileFormat.ToXml("FileFormat")); }
            if (DefaultDataType != null) { xEl.Add(DefaultDataType.ToXml("DefaultDataType")); }
            if (DefaultDelimiter != null) { xEl.Add(DefaultDelimiter.ToXml("DefaultDelimiter")); }
            xEl.Add(new XElement(ns + "DefaultDecimalPositions", DefaultDecimalPositions));
            if (DefaultDecimalSeparator != null)
            {
                xEl.Add(new XElement(ns + "DefaultDecimalSeparator", DefaultDecimalSeparator));
            }
            if (DefaultDigitGroupSeparator != null)
            {
                xEl.Add(new XElement(ns + "DefaultDigitGroupSeparator", DefaultDigitGroupSeparator));
            }
            if (GrossRecordStructure != null && GrossRecordStructure.Count > 0)
            {
                foreach (var item in GrossRecordStructure)
                {
                    xEl.Add(item.ToXml("GrossRecordStructure"));
                }
            }
            return xEl;
        }
    }
}

