using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A structure that links a unique value of a code to a specified category and provides information as to the location of the code within a hierarchy, whether it is discrete, represents a total for the CodeList contents, and if its sub-elements represent a comprehensive coverage of the code. The Code is identifiable, but the value within the code must also be unique within the CodeList.
    /// <summary>
    public class CodeType : IdentifiableType
    {
        /// <summary>
        /// Reference to the category that the code value represents.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Category CategoryReference { get; set; }
        /// <summary>
        /// The value of the code. In a microdata file this would be the value found in the data file. If used as the description of an NCube dimension the value provides the coordinate value for that dimension. Note that r:Value has an attribute xml:space with the default value of "default". If white space is critical to the understanding of this code value (such as critical leading or tailing spaces, or multiple spaces within the code) change the value of xml:space to "preserve".
        /// <summary>
        public ValueType Value { get; set; }
        /// <summary>
        /// Allows for nesting of codes.
        /// <summary>
        public List<CodeType> Code { get; set; } = new List<CodeType>();
        public bool ShouldSerializeCode() { return Code.Count > 0; }
        /// <summary>
        /// Indicates whether the code is discrete (that is, placed at the lowest level in a hierarchy and has no children).
        /// <summary>
        public bool IsDiscrete { get; set; }
        /// <summary>
        /// Level number of the code.
        /// <summary>
        public int LevelNumber { get; set; }
        /// <summary>
        /// Used in hierarchical structures at upper level values to indicate whether or not the subelements of the code are comprehensive in coverage. Not applicable if attribute isDiscrete is set to "true".
        /// <summary>
        [StringValidation(new string[] {
            "True"
,             "False"
,             "Unknown"
        })]
        public string IsComprehensive { get; set; }
        /// <summary>
        /// This expresses a total whether or not isComprehensive is true. If isComprehensive = "true" then if addition is supported by the measure type, the contained categories can be aggregated to calculate the total. If isComprehensive = "false" or "unknown" the content of this field cannot be calculated if the value is not provided in the data.
        /// <summary>
        public bool IsTotal { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CategoryReference != null)
            {
                xEl.Add(new XElement(ns + "CategoryReference", 
                    new XElement(ns + "URN", CategoryReference.URN), 
                    new XElement(ns + "Agency", CategoryReference.Agency), 
                    new XElement(ns + "ID", CategoryReference.ID), 
                    new XElement(ns + "Version", CategoryReference.Version), 
                    new XElement(ns + "TypeOfObject", CategoryReference.GetType().Name)));
            }
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            if (Code != null && Code.Count > 0)
            {
                foreach (var item in Code)
                {
                    xEl.Add(item.ToXml("Code"));
                }
            }
            xEl.Add(new XElement(ns + "IsDiscrete", IsDiscrete));
            xEl.Add(new XElement(ns + "LevelNumber", LevelNumber));
            if (IsComprehensive != null)
            {
                xEl.Add(new XElement(ns + "IsComprehensive", IsComprehensive));
            }
            xEl.Add(new XElement(ns + "IsTotal", IsTotal));
            return xEl;
        }
    }
}

