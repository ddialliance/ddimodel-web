using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing Distributions as a representation so that they can be used as a response domain questions. Primarily used as a response domain in a QuestionGrid. In addition to the base of objects of a representation the structure provides the total value to be distributed between the objects and the number of decimal positions allowed within a response.
    /// <summary>
    public class DistributionRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// Identifies the total value to be distributed among the designated objects.
        /// <summary>
        public decimal DistributionValue { get; set; }
        /// <summary>
        /// Identifies the number of decimal points allowed for the expression of a response.
        /// <summary>
        public int DecimalPositions { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DistributionValue != null)
            {
                xEl.Add(new XElement(ns + "DistributionValue", DistributionValue));
            }
            xEl.Add(new XElement(ns + "DecimalPositions", DecimalPositions));
            return xEl;
        }
    }
}

