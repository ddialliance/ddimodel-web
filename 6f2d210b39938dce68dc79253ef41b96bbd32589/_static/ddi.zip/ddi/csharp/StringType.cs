using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for non-formatted strings that may be translations from other languages, or that may be translatable into other languages. Only one string per language/location type is allowed. String contains the following attributes, xml:lang to designate the language, isTranslated with a default value of false to designate if an object is a translation of another language, isTranslatable with a default value of true to designate if the content can be translated, translationSourceLanguage to indicate the source languages used in creating this translation, and translationDate.
    /// <summary>
    public class StringType : string
    {
        /// <summary>
        /// Indicates the language of content. Note that xml:lang allows for a simple 2 or 3 character language code or a language code extended by a country code , for example en-au for English as used in Australia.
        /// <summary>
        public string Lang { get; set; }
        /// <summary>
        /// Indicates whether content is a translation (true) or an original (false).
        /// <summary>
        public bool IsTranslated { get; set; }
        /// <summary>
        /// Indicates whether content is translatable (true) or not (false). An example of something that is not translatable would be a MNEMONIC of an object or a number.
        /// <summary>
        public bool IsTranslatable { get; set; }
        /// <summary>
        /// List the language or language codes in a space delimited array. The language original may or may not be provided in this bundle of language specific strings.
        /// <summary>
        public List<string> TranslationSourceLanguage { get; set; } = new List<string>();
        public bool ShouldSerializeTranslationSourceLanguage() { return TranslationSourceLanguage.Count > 0; }
        /// <summary>
        /// The date the content was translated. Provision of translation date allows user to verify if translation was available during data collection or other time linked activity.
        /// <summary>
        [JsonConverter(typeof(DateConverter))]
        public DateTimeOffset TranslationDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            xEl.Add(new XElement(ns + "IsTranslated", IsTranslated));
            xEl.Add(new XElement(ns + "IsTranslatable", IsTranslatable));
            if (TranslationSourceLanguage != null && TranslationSourceLanguage.Count > 0)
            {
                foreach (var item in TranslationSourceLanguage)
                {
                    xEl.Add(new XElement(ns + "TranslationSourceLanguage", item));
                }
            }
            if (TranslationDate != default(DateTimeOffset))
            {
                xEl.Add(new XElement(ns + "TranslationDate", TranslationDate.ToString("u").Split(' ')[0]));
            }
            return xEl;
        }
    }
}

