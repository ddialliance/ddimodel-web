using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Adds the attribute identifying this as a maintainable object. All content of Maintainable is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. All content of Maintainable with the exception of 'Note' is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. See DDI 3.2 Technical Documentation: Part I for further details.
    /// <summary>
    public class Maintainable : Versionable
    {
        /// <summary>
        /// This is a fixed flag informing the system or user that in additional to being versionable the element is maintainable in its own right (outside of a parent object).
        /// <summary>
        public bool IsMaintainable { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Maintainable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsMaintainable", IsMaintainable));
            return xEl;
        }
    }
}

