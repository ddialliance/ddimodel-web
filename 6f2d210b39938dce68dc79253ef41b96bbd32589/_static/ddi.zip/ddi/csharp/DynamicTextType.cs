using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structure supporting the use of dynamic text, where portions of the textual contend change depending on external information (pre-loaded data, response to an earlier query, environmental situations, etc.).
    /// <summary>
    public class DynamicTextType
    {
        /// <summary>
        /// This is the head of a substitution group and is never used directly as an element name. Instead it is replaced with either LiteralText or ConditionalText.
        /// <summary>
        public List<TextContentType> TextContent { get; set; } = new List<TextContentType>();
        public bool ShouldSerializeTextContent() { return TextContent.Count > 0; }
        /// <summary>
        /// If textual structure (e.g. size, color, font, etc.) is required to understand the meaning of the content change value to "true".
        /// <summary>
        public bool IsStructureRequired { get; set; }
        /// <summary>
        /// Specifies the language of the intended audience. This is particularly important for clarifying the primary language of a mixed language textual string, for example when language testing and using a foreign word withing the question text.
        /// <summary>
        public string AudienceLanguage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TextContent != null && TextContent.Count > 0)
            {
                foreach (var item in TextContent)
                {
                    xEl.Add(item.ToXml("TextContent"));
                }
            }
            xEl.Add(new XElement(ns + "IsStructureRequired", IsStructureRequired));
            if (AudienceLanguage != null)
            {
                xEl.Add(new XElement(ns + "AudienceLanguage", AudienceLanguage));
            }
            return xEl;
        }
    }
}

