using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the NCubes and any variables in the record external to NCube structures such as case identification variables that are contained in the logical record by indicating that all NCubes contained in the logical product are included, inclusion of a NCubeScheme to include, or listing individual NCubes to include. When the attribute allNCubesInLogicalProduct is set to "false" use the NCubeSchemeReference (which allows for exclusions) and NCubeReference to specify the included variables. A nested VariablesInRecord structure is used to include non-NCube variables in the record.
    /// <summary>
    public class NCubesInRecordType
    {
        /// <summary>
        /// Use VariablesInRecord to describe any variables in the record that are external to the NCube such as case identifiers.
        /// <summary>
        public VariablesInRecordType VariablesInRecord { get; set; }
        /// <summary>
        /// Reference to an NCubeScheme whose members are included in the logical record. Note that individual items may be excluded from the scheme if not used by the logical record.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeScheme> NCubeSchemeReference { get; set; } = new List<NCubeScheme>();
        public bool ShouldSerializeNCubeSchemeReference() { return NCubeSchemeReference.Count > 0; }
        /// <summary>
        /// Reference to an NCube to include in the logical record. This may be used to supplement the contents of an included NCubeScheme or to list all the variables individually.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCube> NCubeReference { get; set; } = new List<NCube>();
        public bool ShouldSerializeNCubeReference() { return NCubeReference.Count > 0; }
        /// <summary>
        /// When the value is true, then the logical record contains all listed NCubes in the logical product module.
        /// <summary>
        public bool AllNCubesInLogicalProduct { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (VariablesInRecord != null) { xEl.Add(VariablesInRecord.ToXml("VariablesInRecord")); }
            if (NCubeSchemeReference != null && NCubeSchemeReference.Count > 0)
            {
                foreach (var item in NCubeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (NCubeReference != null && NCubeReference.Count > 0)
            {
                foreach (var item in NCubeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "AllNCubesInLogicalProduct", AllNCubesInLogicalProduct));
            return xEl;
        }
    }
}

