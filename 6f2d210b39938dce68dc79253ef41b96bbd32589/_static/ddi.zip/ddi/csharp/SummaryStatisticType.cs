using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a summary statistic for a variable.
    /// <summary>
    public class SummaryStatisticType
    {
        /// <summary>
        /// Type of summary statistic, such as count, mean, mode, median, etc. Supports the use of an external controlled vocabulary. DDI strongly recommends the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfSummaryStatistic { get; set; }
        /// <summary>
        /// The value of the statistics and whether it is weighted and/or includes missing values.
        /// <summary>
        public StatisticType Statistic { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TypeOfSummaryStatistic != null) { xEl.Add(TypeOfSummaryStatistic.ToXml("TypeOfSummaryStatistic")); }
            if (Statistic != null) { xEl.Add(Statistic.ToXml("Statistic")); }
            return xEl;
        }
    }
}

