using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A scheme containing a set of RecordLayouts describing the location of individual data items within the physical record and how to address them (locate and retrieve). RecordLayouts provide a link to the PhysicalStructure description and to individual variables or NCubes describing the data items.
    /// <summary>
    public class RecordLayoutScheme : Maintainable
    {
        /// <summary>
        /// A name for the RecordLayoutScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RecordLayoutSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRecordLayoutSchemeName() { return RecordLayoutSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the RecordLayoutScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the RecordLayoutScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing RecordLayoutScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutScheme> RecordLayoutSchemeReference { get; set; } = new List<RecordLayoutScheme>();
        public bool ShouldSerializeRecordLayoutSchemeReference() { return RecordLayoutSchemeReference.Count > 0; }
        /// <summary>
        /// This is the head of a substitution group and may be replaced by any member of the group. Describes the contents and physical layout of a record of data. Different members of the substitution group support different storage formats as well as data records with and without NCube structures.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayout> RecordLayoutReference { get; set; } = new List<RecordLayout>();
        public bool ShouldSerializeRecordLayoutReference() { return RecordLayoutReference.Count > 0; }
        /// <summary>
        /// Describes a group of RecordLayout descriptions for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayoutGroup> RecordLayoutGroupReference { get; set; } = new List<RecordLayoutGroup>();
        public bool ShouldSerializeRecordLayoutGroupReference() { return RecordLayoutGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "RecordLayoutScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RecordLayoutSchemeName != null && RecordLayoutSchemeName.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeName)
                {
                    xEl.Add(item.ToXml("RecordLayoutSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecordLayoutSchemeReference != null && RecordLayoutSchemeReference.Count > 0)
            {
                foreach (var item in RecordLayoutSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutReference != null && RecordLayoutReference.Count > 0)
            {
                foreach (var item in RecordLayoutReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutGroupReference != null && RecordLayoutGroupReference.Count > 0)
            {
                foreach (var item in RecordLayoutGroupReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

