using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// References a parent geography and describes whether the geographic level completely fills its parent level. TypeOfObject should be set to GeographicLevel.
    /// <summary>
    public class ParentGeographicLevelReferenceType : ReferenceType
    {
        /// <summary>
        /// Indicates whether the geographic level completely fills its parent level. Counties are exhaustive within States. Places are NOT exhaustive within States.
        /// <summary>
        public bool IsExhaustiveCoverage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsExhaustiveCoverage", IsExhaustiveCoverage));
            return xEl;
        }
    }
}

