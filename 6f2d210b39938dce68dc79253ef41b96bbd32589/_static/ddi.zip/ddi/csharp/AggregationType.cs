using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the aggregation method and the variables used in the aggregation process. Identifies the method using an external controlled vocabulary and identifies the variables used either in-line or by reference to an existing description.
    /// <summary>
    public class AggregationType
    {
        /// <summary>
        /// Identification of the type of aggregation method used. Supports the use of a controlled vocabulary. DDI strongly recommends the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType AggregationMethod { get; set; }
        /// <summary>
        /// Identifies the independent and dependent variables used in the aggregation process in-line.
        /// <summary>
        public AggregationVariablesType AggregationVariables { get; set; }
        /// <summary>
        /// A reference to an existing AggregationVariables description.
        /// <summary>
        public AggregationVariablesType AggregationVariablesReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AggregationMethod != null) { xEl.Add(AggregationMethod.ToXml("AggregationMethod")); }
            if (AggregationVariables != null) { xEl.Add(AggregationVariables.ToXml("AggregationVariables")); }
            if (AggregationVariablesReference != null) { xEl.Add(AggregationVariablesReference.ToXml("AggregationVariablesReference")); }
            return xEl;
        }
    }
}

