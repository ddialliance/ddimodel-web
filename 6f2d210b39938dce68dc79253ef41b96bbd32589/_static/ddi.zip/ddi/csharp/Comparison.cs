using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A maintainable module containing maps between objects of the same or similar type. Maps allow for pair-wise mapping of two objects by describing their similarities and differences in order to make assertions regarding their comparability. Currently maps allow for the comparison of concepts, variables, questions, categories, universes, and representations that have managed content (code, category, numeric, text, datetime and scale). These mapping(s) inform users on the comparability of two objects and facilitate automation. Note that all maps are pairwise, identifying two schemes and the correlation between two items in those schemes. Due to the complexity of some objects, multiple mappings may be required to cover details of the comparison of component parts, e.g. a QuestionMap may also have a related RepresentationMap. By using a set of pairwise comparisons, it is possible to describe complex correspondences - pairwise comparisons are easier to process. In addition to providing a standard name, label, and description, Comparison consists of a simple stack of comparison maps. Comparison maps are currently limited to those objects that can be referenced and are sufficiently structured to support a clear comparison.
    /// <summary>
    public class Comparison : Maintainable
    {
        /// <summary>
        /// A name for the comparison. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ComparisonName { get; set; } = new List<NameType>();
        public bool ShouldSerializeComparisonName() { return ComparisonName.Count > 0; }
        /// <summary>
        /// A display label for the comparison. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the comparison. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Maps the content of two different concept schemes of objects of the same type providing detail for the comparable items within those two schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenericMap> ConceptMapReference { get; set; } = new List<GenericMap>();
        public bool ShouldSerializeConceptMapReference() { return ConceptMapReference.Count > 0; }
        /// <summary>
        /// Maps the content of two different variable schemes of objects of the same type providing detail for the comparable items within those two schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenericMap> VariableMapReference { get; set; } = new List<GenericMap>();
        public bool ShouldSerializeVariableMapReference() { return VariableMapReference.Count > 0; }
        /// <summary>
        /// Maps the content of two different question schemes of objects of the same type providing detail for the comparable items within those two schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenericMap> QuestionMapReference { get; set; } = new List<GenericMap>();
        public bool ShouldSerializeQuestionMapReference() { return QuestionMapReference.Count > 0; }
        /// <summary>
        /// Maps the content of two different category schemes of objects of the same type providing detail for the comparable items within those two schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenericMap> CategoryMapReference { get; set; } = new List<GenericMap>();
        public bool ShouldSerializeCategoryMapReference() { return CategoryMapReference.Count > 0; }
        /// <summary>
        /// Maps between any two managed representations. In addition to representation types held in a ManagedRepresentationScheme, managed representations include CategoryScheme and coded representations which include CodeList, GeographicStructureCode or GeographicLocationCode. Note that the source can be any managed representation including a CodeList, GeographicStructure or GeographicLocation. Note that comparisons between two category schemes is best handled by CategoryMap.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentationMap> RepresentationMapReference { get; set; } = new List<RepresentationMap>();
        public bool ShouldSerializeRepresentationMapReference() { return RepresentationMapReference.Count > 0; }
        /// <summary>
        /// Maps the content of two different universe schemes of objects of the same type providing detail for the comparable items within those two schemes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenericMap> UniverseMapReference { get; set; } = new List<GenericMap>();
        public bool ShouldSerializeUniverseMapReference() { return UniverseMapReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Comparison");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ComparisonName != null && ComparisonName.Count > 0)
            {
                foreach (var item in ComparisonName)
                {
                    xEl.Add(item.ToXml("ComparisonName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptMapReference != null && ConceptMapReference.Count > 0)
            {
                foreach (var item in ConceptMapReference)
                {
                    xEl.Add(new XElement(ns + "ConceptMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableMapReference != null && VariableMapReference.Count > 0)
            {
                foreach (var item in VariableMapReference)
                {
                    xEl.Add(new XElement(ns + "VariableMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionMapReference != null && QuestionMapReference.Count > 0)
            {
                foreach (var item in QuestionMapReference)
                {
                    xEl.Add(new XElement(ns + "QuestionMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CategoryMapReference != null && CategoryMapReference.Count > 0)
            {
                foreach (var item in CategoryMapReference)
                {
                    xEl.Add(new XElement(ns + "CategoryMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentationMapReference != null && RepresentationMapReference.Count > 0)
            {
                foreach (var item in RepresentationMapReference)
                {
                    xEl.Add(new XElement(ns + "RepresentationMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UniverseMapReference != null && UniverseMapReference.Count > 0)
            {
                foreach (var item in UniverseMapReference)
                {
                    xEl.Add(new XElement(ns + "UniverseMapReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

