using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the control construct substitution group. Describing an action which loops until a limiting condition is met. The ControlConstruct contained in the Loop operates on the LoopVariable until the LoopWhile condition is met, and then control is handed back to the containing control construct.
    /// <summary>
    public class Loop : ControlConstruct
    {
        /// <summary>
        /// A reference to the variable (as used in the associated CommandCode) which is incremented or otherwise manipulated to meet the conditions stated in the LoopWhile condition.
        /// <summary>
        public ParameterType LoopVariableReference { get; set; }
        /// <summary>
        /// Information on the command used to set the initial value for the process. Could be a simple value.
        /// <summary>
        public CommandCodeType InitialValue { get; set; }
        /// <summary>
        /// Information on the command used to determine whether the "LoopWhile" condition is met.
        /// <summary>
        public CommandCodeType LoopWhile { get; set; }
        /// <summary>
        /// Information on the command used to set the incremental or step value for the process. Could be a simple value.
        /// <summary>
        public CommandCodeType StepValue { get; set; }
        /// <summary>
        /// A reference to the ControlConstruct to implement until the LoopWhile condition is met. This could be a single ControlConstruct or a set of ControlConstructs within a Sequence.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ControlConstruct ControlConstructReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Loop");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (LoopVariableReference != null) { xEl.Add(LoopVariableReference.ToXml("LoopVariableReference")); }
            if (InitialValue != null) { xEl.Add(InitialValue.ToXml("InitialValue")); }
            if (LoopWhile != null) { xEl.Add(LoopWhile.ToXml("LoopWhile")); }
            if (StepValue != null) { xEl.Add(StepValue.ToXml("StepValue")); }
            if (ControlConstructReference != null)
            {
                xEl.Add(new XElement(ns + "ControlConstructReference", 
                    new XElement(ns + "URN", ControlConstructReference.URN), 
                    new XElement(ns + "Agency", ControlConstructReference.Agency), 
                    new XElement(ns + "ID", ControlConstructReference.ID), 
                    new XElement(ns + "Version", ControlConstructReference.Version), 
                    new XElement(ns + "TypeOfObject", ControlConstructReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

