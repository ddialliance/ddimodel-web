using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a set of QuestionItems, QuestionGrids, QuestionBlocks, and QuestionGroups. In addition to the standard name, label, and description of the Question Scheme, may contain another QuestionScheme by reference, a listing of Questions by type (in-line or by reference), and a listing of QuestionGroups (in-line or by reference).
    /// <summary>
    public class QuestionScheme : Maintainable
    {
        /// <summary>
        /// A name for the QuestionScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QuestionSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQuestionSchemeName() { return QuestionSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the QuestionScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the inclusion of another QuestionScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionScheme> QuestionSchemeReference { get; set; } = new List<QuestionScheme>();
        public bool ShouldSerializeQuestionSchemeReference() { return QuestionSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a QuestionItem in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionItem> QuestionItemReference { get; set; } = new List<QuestionItem>();
        public bool ShouldSerializeQuestionItemReference() { return QuestionItemReference.Count > 0; }
        /// <summary>
        /// Describes a QuestionGrid in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionGrid> QuestionGridReference { get; set; } = new List<QuestionGrid>();
        public bool ShouldSerializeQuestionGridReference() { return QuestionGridReference.Count > 0; }
        /// <summary>
        /// Describes a QuestionBlock in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionBlock> QuestionBlockReference { get; set; } = new List<QuestionBlock>();
        public bool ShouldSerializeQuestionBlockReference() { return QuestionBlockReference.Count > 0; }
        /// <summary>
        /// Contains a group of Questions, which may be ordered or hierarchical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionGroup> QuestionGroupReference { get; set; } = new List<QuestionGroup>();
        public bool ShouldSerializeQuestionGroupReference() { return QuestionGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "QuestionScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QuestionSchemeName != null && QuestionSchemeName.Count > 0)
            {
                foreach (var item in QuestionSchemeName)
                {
                    xEl.Add(item.ToXml("QuestionSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (QuestionSchemeReference != null && QuestionSchemeReference.Count > 0)
            {
                foreach (var item in QuestionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "QuestionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionItemReference != null && QuestionItemReference.Count > 0)
            {
                foreach (var item in QuestionItemReference)
                {
                    xEl.Add(new XElement(ns + "QuestionItemReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionGridReference != null && QuestionGridReference.Count > 0)
            {
                foreach (var item in QuestionGridReference)
                {
                    xEl.Add(new XElement(ns + "QuestionGridReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionBlockReference != null && QuestionBlockReference.Count > 0)
            {
                foreach (var item in QuestionBlockReference)
                {
                    xEl.Add(new XElement(ns + "QuestionBlockReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QuestionGroupReference != null && QuestionGroupReference.Count > 0)
            {
                foreach (var item in QuestionGroupReference)
                {
                    xEl.Add(new XElement(ns + "QuestionGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

