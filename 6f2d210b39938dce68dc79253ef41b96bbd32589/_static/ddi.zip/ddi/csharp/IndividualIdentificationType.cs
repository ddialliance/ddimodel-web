using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifying information about the individual including name, DDI Maintenance Agency IDs, Researcher IDs, an image and an effective period for the information.
    /// <summary>
    public class IndividualIdentificationType
    {
        /// <summary>
        /// The name or names by which the individual is known. The legal or formal name of the individual should have the isFormal attribute set to true. The preferred name should be noted with the isPreferred attribute.
        /// <summary>
        public List<IndividualNameType> IndividualName { get; set; } = new List<IndividualNameType>();
        public bool ShouldSerializeIndividualName() { return IndividualName.Count > 0; }
        /// <summary>
        /// Contains the official DDI ID of the maintenance agency as registered with the DDI registry by the parent organization or individual. A single organization or individual may have one or more DDI Maintenance Agency IDs registered within the DDI registry (i.e., an organization may have a DDI Maintenance Agency ID for each project managed by the organization) The structure of this string is described by Part I of the Technical Documentation and the content is registered within the DDI registry as a unique identifier.
        /// <summary>
        public List<DDIMaintenanceAgencyIDType> DDIMaintenanceAgencyID { get; set; } = new List<DDIMaintenanceAgencyIDType>();
        public bool ShouldSerializeDDIMaintenanceAgencyID() { return DDIMaintenanceAgencyID.Count > 0; }
        /// <summary>
        /// This is a formally registered unique identifier within a specific system such as a scholars directory. It is used to disambiguate individuals of similar names.
        /// <summary>
        public List<ResearcherIDType> ResearcherID { get; set; } = new List<ResearcherIDType>();
        public bool ShouldSerializeResearcherID() { return ResearcherID.Count > 0; }
        /// <summary>
        /// Image of the individual with date and privacy information.
        /// <summary>
        public List<PrivateImageType> IndividualImage { get; set; } = new List<PrivateImageType>();
        public bool ShouldSerializeIndividualImage() { return IndividualImage.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (IndividualName != null && IndividualName.Count > 0)
            {
                foreach (var item in IndividualName)
                {
                    xEl.Add(item.ToXml("IndividualName"));
                }
            }
            if (DDIMaintenanceAgencyID != null && DDIMaintenanceAgencyID.Count > 0)
            {
                foreach (var item in DDIMaintenanceAgencyID)
                {
                    xEl.Add(item.ToXml("DDIMaintenanceAgencyID"));
                }
            }
            if (ResearcherID != null && ResearcherID.Count > 0)
            {
                foreach (var item in ResearcherID)
                {
                    xEl.Add(item.ToXml("ResearcherID"));
                }
            }
            if (IndividualImage != null && IndividualImage.Count > 0)
            {
                foreach (var item in IndividualImage)
                {
                    xEl.Add(item.ToXml("IndividualImage"));
                }
            }
            return xEl;
        }
    }
}

