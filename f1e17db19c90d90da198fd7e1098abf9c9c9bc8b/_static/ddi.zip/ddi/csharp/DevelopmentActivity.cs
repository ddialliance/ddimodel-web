using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An abstract element serving as the head of a substitution group. May be substituted by an valid object of substitution type DevelopmentActivity. Provides a set of objects available to all members of the stubstitution group. These include a statement of the desired outcome of the development activity, a summary of the process to be followed, recommended staff requirements for each staffing class, a statement of any addition resources (monetary, or other) that are required to complete the activity, and information on the debriefing process.
    /// <summary>
    public partial class DevelopmentActivity : Versionable
    {

        /// <summary>
        /// Set the TypeDescriminator
        /// <summary>
        public DevelopmentActivity() { this.TypeDescriminator = this.GetType().Name; }

        /// <summary>
        /// Type descriminator for json serialization
        /// <summary>
        [JsonProperty("$type")]
        public string TypeDescriminator { get; set; }

        /// <summary>
        /// A name for the Development Activity. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentActivityName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentActivityName() { return DevelopmentActivityName.Count > 0; }
        /// <summary>
        /// A display label for the Development Activity. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Development Activity. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describe the desired outcomes of the development activity. Address why the activity should take place, means of determining successful completion, etc.
        /// <summary>
        public StructuredStringType DesiredOutcome { get; set; }
        /// <summary>
        /// Summarize the process the activity should follow to meet desired outcomes.
        /// <summary>
        public StructuredStringType ProcessSummary { get; set; }
        /// <summary>
        /// Specify requirements for type of staffing needed to complete activity. Repeat for each staff class
        /// <summary>
        public List<RecommendedStaffRequirementsType> RecommendedStaffRequirements { get; set; } = new List<RecommendedStaffRequirementsType>();
        public bool ShouldSerializeRecommendedStaffRequirements() { return RecommendedStaffRequirements.Count > 0; }
        /// <summary>
        /// Describe additional resources required such as funding, staffing, or resource material.
        /// <summary>
        public StructuredStringType AdditionalRequiredResources { get; set; }
        /// <summary>
        /// Describe the debriefing process. This is especially important for assessing the quality of focus groups, cognitive interviews, etc. Specifies if debriefing is required.
        /// <summary>
        public DebriefingProcessType DebriefingProcess { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentActivity");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentActivityName != null && DevelopmentActivityName.Count > 0)
            {
                foreach (var item in DevelopmentActivityName)
                {
                    xEl.Add(item.ToXml("DevelopmentActivityName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DesiredOutcome != null) { xEl.Add(DesiredOutcome.ToXml("DesiredOutcome")); }
            if (ProcessSummary != null) { xEl.Add(ProcessSummary.ToXml("ProcessSummary")); }
            if (RecommendedStaffRequirements != null && RecommendedStaffRequirements.Count > 0)
            {
                foreach (var item in RecommendedStaffRequirements)
                {
                    xEl.Add(item.ToXml("RecommendedStaffRequirements"));
                }
            }
            if (AdditionalRequiredResources != null) { xEl.Add(AdditionalRequiredResources.ToXml("AdditionalRequiredResources")); }
            if (DebriefingProcess != null) { xEl.Add(DebriefingProcess.ToXml("DebriefingProcess")); }
            return xEl;
        }
    }
}

