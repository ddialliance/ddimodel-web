using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structure a single Measurement which may contain one or more response domains (i.e., a list of valid category responses where if "Other" is indicated a text response can be used to specify the intent of "Other"). The structure provides detail on the intent of the measurement, they type of capture, the valid response options and the number of allowed responses, references to external aids and instructions, and an estimation of the time needed to respond to the measurement. Note that the MeasurementItem is a reusable format for use in any number of applied uses. Additional materials and information can be added within the MeasurementConstruct which is the applied use of a measurement.
    /// <summary>
    public partial class MeasurementItem : Versionable
    {
        /// <summary>
        /// A name for the MeasurementItem. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> MeasurementItemName { get; set; } = new List<NameType>();
        public bool ShouldSerializeMeasurementItemName() { return MeasurementItemName.Count > 0; }
        /// <summary>
        /// A display label for the MeasurementItem. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the MeasurementItem. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provides an identity for input objects required for the MeasurementItem.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// Provides an identify for the output objects of the MeasurementItem.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// A structure used to bind the content of a parameter declared as the source to a parameter declared as the target.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// A brief term defining the type of MeasurementItem. Supports the use of an external controlled vocabulary.
        /// <summary>
        public List<CodeValueType> TypeOfMeasurementItem { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeTypeOfMeasurementItem() { return TypeOfMeasurementItem.Count > 0; }
        /// <summary>
        /// The purpose of the MeasurementItem in terms of what it is designed to measure.
        /// <summary>
        public StructuredStringType MeasurementItemIntent { get; set; }
        /// <summary>
        /// Contains a response domain for the measurement item. Typically used to describe simple response domains (textual, numeric, etc.).
        /// <summary>
        [JsonConverter(typeof(SubstitutionConverter))]
        public RepresentationType ResponseDomain { get; set; }
        /// <summary>
        /// The inclusion of a response domain by reference (must be supported by a managed representation). An abstract element. May be substituted by any valid object of substitution type ResponseDomainReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ResponseDomainReference { get; set; }
        /// <summary>
        /// Use in cases where the measurement requires the option for multiple response domains.
        /// <summary>
        public StructuredMixedResponseDomainType StructuredMixedResponseDomain { get; set; }
        /// <summary>
        /// Allows the designation of the minimum and maximum number of responses allowed for this measurement. Note that each response domain has its own response cardinality.
        /// <summary>
        public ResponseCardinalityType ResponseCardinality { get; set; }
        /// <summary>
        /// A reference to the concept associated with the response to the measurement.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> ConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeConceptReference() { return ConceptReference.Count > 0; }
        /// <summary>
        /// A pointer to an external aid presented by the instrument such as a text card, image, audio, or audiovisual aid. Typically a URN. Use type attribute to describe the type of external aid provided. Example of terms to use would include: imageOnly audioOnly audioVisual multiMedia.
        /// <summary>
        public List<ExternalAidType> ExternalAid { get; set; } = new List<ExternalAidType>();
        public bool ShouldSerializeExternalAid() { return ExternalAid.Count > 0; }
        /// <summary>
        /// External reference to an interviewer instruction not expressed as DDI XML using OtherMaterial.
        /// <summary>
        public ExternalInterviewerInstructionType ExternalInterviewerInstruction { get; set; }
        /// <summary>
        /// Reference to an interviewer instruction expressed as DDI XML.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instruction InterviewerInstructionReference { get; set; }
        /// <summary>
        /// Reference to the RepresentedVariable that describes the data to be collected by this measurement. The RepresentedVariable contains the broad reusable specification of the Variable, i.e., concept, universe, and value representation. When more than one ResponseDomain exists, one RepresentedVariable should be created for each ResponseDomain in the same order as the corresponding ResponseDomain. TypeOfObject should be set to RepresentedVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariable> RepresentedVariableReference { get; set; } = new List<RepresentedVariable>();
        public bool ShouldSerializeRepresentedVariableReference() { return RepresentedVariableReference.Count > 0; }
        /// <summary>
        /// The estimated amount of time required to perform the measurement expressed in seconds. Decimal values should be used to define fractions of seconds.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "MeasurementItem");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (MeasurementItemName != null && MeasurementItemName.Count > 0)
            {
                foreach (var item in MeasurementItemName)
                {
                    xEl.Add(item.ToXml("MeasurementItemName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (TypeOfMeasurementItem != null && TypeOfMeasurementItem.Count > 0)
            {
                foreach (var item in TypeOfMeasurementItem)
                {
                    xEl.Add(item.ToXml("TypeOfMeasurementItem"));
                }
            }
            if (MeasurementItemIntent != null) { xEl.Add(MeasurementItemIntent.ToXml("MeasurementItemIntent")); }
            if (ResponseDomain != null) { xEl.Add(ResponseDomain.ToXml("ResponseDomain")); }
            if (ResponseDomainReference != null)
            {
                xEl.Add(new XElement(ns + "ResponseDomainReference", 
                    new XElement(ns + "URN", ResponseDomainReference.URN), 
                    new XElement(ns + "Agency", ResponseDomainReference.Agency), 
                    new XElement(ns + "ID", ResponseDomainReference.ID), 
                    new XElement(ns + "Version", ResponseDomainReference.Version), 
                    new XElement(ns + "TypeOfObject", ResponseDomainReference.GetType().Name)));
            }
            if (StructuredMixedResponseDomain != null) { xEl.Add(StructuredMixedResponseDomain.ToXml("StructuredMixedResponseDomain")); }
            if (ResponseCardinality != null) { xEl.Add(ResponseCardinality.ToXml("ResponseCardinality")); }
            if (ConceptReference != null && ConceptReference.Count > 0)
            {
                foreach (var item in ConceptReference)
                {
                    xEl.Add(new XElement(ns + "ConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ExternalAid != null && ExternalAid.Count > 0)
            {
                foreach (var item in ExternalAid)
                {
                    xEl.Add(item.ToXml("ExternalAid"));
                }
            }
            if (ExternalInterviewerInstruction != null) { xEl.Add(ExternalInterviewerInstruction.ToXml("ExternalInterviewerInstruction")); }
            if (InterviewerInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "InterviewerInstructionReference", 
                    new XElement(ns + "URN", InterviewerInstructionReference.URN), 
                    new XElement(ns + "Agency", InterviewerInstructionReference.Agency), 
                    new XElement(ns + "ID", InterviewerInstructionReference.ID), 
                    new XElement(ns + "Version", InterviewerInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", InterviewerInstructionReference.GetType().Name)));
            }
            if (RepresentedVariableReference != null && RepresentedVariableReference.Count > 0)
            {
                foreach (var item in RepresentedVariableReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

