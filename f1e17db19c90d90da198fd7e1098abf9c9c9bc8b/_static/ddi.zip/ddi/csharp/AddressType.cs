using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Location address identifying each part of the address as separate elements, identifying the type of address, the level of privacy associated with the release of the address, and a flag to identify the preferred address for contact.
    /// <summary>
    public partial class AddressType
    {
        /// <summary>
        /// Indicates address type (i.e. home, office, mailing, etc.)
        /// <summary>
        public CodeValueType TypeOfAddress { get; set; }
        /// <summary>
        /// Number and street including office or suite number. May use multiple lines.
        /// <summary>
        public List<string> Line { get; set; } = new List<string>();
        public bool ShouldSerializeLine() { return Line.Count > 0; }
        /// <summary>
        /// City, Place, or local area used as part of an address.
        /// <summary>
        public string CityPlaceLocal { get; set; }
        /// <summary>
        /// A major subnational division such as a state or province used to identify a major region within an address.
        /// <summary>
        public string StateProvince { get; set; }
        /// <summary>
        /// Postal or ZIP Code
        /// <summary>
        public string PostalCode { get; set; }
        /// <summary>
        /// Country of the location
        /// <summary>
        public CountryCodeType CountryCode { get; set; }
        /// <summary>
        /// Geographic coordinate point for the location
        /// <summary>
        public PointType GeographicPoint { get; set; }
        /// <summary>
        /// Time zone of the location expressed as code.
        /// <summary>
        public CodeValueType TimeZone { get; set; }
        /// <summary>
        /// Clarifies when the identification information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }
        /// <summary>
        /// Set to "true" if this is the preferred location for contacting the organization or individual.
        /// <summary>
        public bool IsPreferred { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfAddress != null) { xEl.Add(TypeOfAddress.ToXml("TypeOfAddress")); }
            if (Line != null && Line.Count > 0)
            {
                xEl.Add(
                    from item in Line
                    select new XElement(ns + "Line", item.ToString()));
            }
            if (CityPlaceLocal != null)
            {
                xEl.Add(new XElement(ns + "CityPlaceLocal", CityPlaceLocal));
            }
            if (StateProvince != null)
            {
                xEl.Add(new XElement(ns + "StateProvince", StateProvince));
            }
            if (PostalCode != null)
            {
                xEl.Add(new XElement(ns + "PostalCode", PostalCode));
            }
            if (CountryCode != null) { xEl.Add(CountryCode.ToXml("CountryCode")); }
            if (GeographicPoint != null) { xEl.Add(GeographicPoint.ToXml("GeographicPoint")); }
            if (TimeZone != null) { xEl.Add(TimeZone.ToXml("TimeZone")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            xEl.Add(new XElement(ns + "IsPreferred", IsPreferred));
            return xEl;
        }
    }
}

