using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This scheme contains a set of quality statements and quality standards referenced by the metadata at different points in the lifecycle. In addition to the name, label, and description of the scheme, the structure supports the inclusion of another QualityStatementScheme by reference and a set of QualityStatement descriptions either in-line or by reference.
    /// <summary>
    public partial class QualityScheme : Maintainable
    {
        /// <summary>
        /// A name for the QualityScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QualitySchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQualitySchemeName() { return QualitySchemeName.Count > 0; }
        /// <summary>
        /// A display label for the QualityScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the QualityScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing QualityScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityScheme> QualitySchemeReference { get; set; } = new List<QualityScheme>();
        public bool ShouldSerializeQualitySchemeReference() { return QualitySchemeReference.Count > 0; }
        /// <summary>
        /// In-line description of a QualityStatement. These are used by reference at various points in the lifecycle.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// In-line description of a QualityStandard. These are used by reference at various points in the lifecycle.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStandard> QualityStandardReference { get; set; } = new List<QualityStandard>();
        public bool ShouldSerializeQualityStandardReference() { return QualityStandardReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of QualityStatements.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatementGroup> QualityStatementGroupReference { get; set; } = new List<QualityStatementGroup>();
        public bool ShouldSerializeQualityStatementGroupReference() { return QualityStatementGroupReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of QualityStandards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStandardGroup> QualityStandardGroupReference { get; set; } = new List<QualityStandardGroup>();
        public bool ShouldSerializeQualityStandardGroupReference() { return QualityStandardGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QualityScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QualitySchemeName != null && QualitySchemeName.Count > 0)
            {
                foreach (var item in QualitySchemeName)
                {
                    xEl.Add(item.ToXml("QualitySchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (QualitySchemeReference != null && QualitySchemeReference.Count > 0)
            {
                foreach (var item in QualitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "QualitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStandardReference != null && QualityStandardReference.Count > 0)
            {
                foreach (var item in QualityStandardReference)
                {
                    xEl.Add(new XElement(ns + "QualityStandardReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementGroupReference != null && QualityStatementGroupReference.Count > 0)
            {
                foreach (var item in QualityStatementGroupReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStandardGroupReference != null && QualityStandardGroupReference.Count > 0)
            {
                foreach (var item in QualityStandardGroupReference)
                {
                    xEl.Add(new XElement(ns + "QualityStandardGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

