using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A structure used to express explicit segments or regions within different types of external materials (Textual, Audio, Video, XML, and Image). Provides the appropriate start, stop, or region definitions for each type.
    /// <summary>
    public partial class SegmentType
    {
        /// <summary>
        /// Defines the segment of textual content used by the parent object. Can identify a set of lines and or characters used to define the segment.
        /// <summary>
        public List<TextualType> Textual { get; set; } = new List<TextualType>();
        public bool ShouldSerializeTextual() { return Textual.Count > 0; }
        /// <summary>
        /// Describes the type and length of the audio segment.
        /// <summary>
        public List<AudioType> Audio { get; set; } = new List<AudioType>();
        public bool ShouldSerializeAudio() { return Audio.Count > 0; }
        /// <summary>
        /// Describes the type and length of the video segment.
        /// <summary>
        public List<VideoType> Video { get; set; } = new List<VideoType>();
        public bool ShouldSerializeVideo() { return Video.Count > 0; }
        /// <summary>
        /// An X-Pointer expression identifying a node in the XML document.
        /// <summary>
        public List<string> XML { get; set; } = new List<string>();
        public bool ShouldSerializeXML() { return XML.Count > 0; }
        /// <summary>
        /// Defines the shape and area of an image used as part of a location representation. The shape is defined as a Rectangle, Circle, or Polygon and Coordinates provides the information required to define it.
        /// <summary>
        public List<ImageAreaType> ImageArea { get; set; } = new List<ImageAreaType>();
        public bool ShouldSerializeImageArea() { return ImageArea.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Textual != null && Textual.Count > 0)
            {
                foreach (var item in Textual)
                {
                    xEl.Add(item.ToXml("Textual"));
                }
            }
            if (Audio != null && Audio.Count > 0)
            {
                foreach (var item in Audio)
                {
                    xEl.Add(item.ToXml("Audio"));
                }
            }
            if (Video != null && Video.Count > 0)
            {
                foreach (var item in Video)
                {
                    xEl.Add(item.ToXml("Video"));
                }
            }
            if (XML != null && XML.Count > 0)
            {
                xEl.Add(
                    from item in XML
                    select new XElement(ns + "XML", item.ToString()));
            }
            if (ImageArea != null && ImageArea.Count > 0)
            {
                foreach (var item in ImageArea)
                {
                    xEl.Add(item.ToXml("ImageArea"));
                }
            }
            return xEl;
        }
    }
}

