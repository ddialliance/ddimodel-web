using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Budget and funding information related to the development work.
    /// <summary>
    public partial class CostStructureType
    {
        /// <summary>
        /// A description and/or reference to a related document providing budget information for the development activities
        /// <summary>
        public List<BudgetType> Budget { get; set; } = new List<BudgetType>();
        public bool ShouldSerializeBudget() { return Budget.Count > 0; }
        /// <summary>
        /// Provides information about the agency and grant(s) which fund the development work.
        /// <summary>
        public List<FundingInformationType> FundingInformation { get; set; } = new List<FundingInformationType>();
        public bool ShouldSerializeFundingInformation() { return FundingInformation.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Budget != null && Budget.Count > 0)
            {
                foreach (var item in Budget)
                {
                    xEl.Add(item.ToXml("Budget"));
                }
            }
            if (FundingInformation != null && FundingInformation.Count > 0)
            {
                foreach (var item in FundingInformation)
                {
                    xEl.Add(item.ToXml("FundingInformation"));
                }
            }
            return xEl;
        }
    }
}

