using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing the Location of an action and the action itself within a repesentation so that they can be used by questions as a response domain. In addition to the basic objects of the representation, the structure briefly describes the object type upon which the action is to take place and the action to take (where an how to mark the object).
    /// <summary>
    public partial class LocationRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// The type of object on which the action takes place such as an image, audio tape, etc. Allows for the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType Object { get; set; }
        /// <summary>
        /// Describes the region of an image, recording, or text where an action where a specified action is performed and the type of action taken (i.e., Mark an "X" where the actor should be standing on the picture of the stage.).
        /// <summary>
        public List<ActionType> Action { get; set; } = new List<ActionType>();
        public bool ShouldSerializeAction() { return Action.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (Object != null) { xEl.Add(Object.ToXml("Object")); }
            if (Action != null && Action.Count > 0)
            {
                foreach (var item in Action)
                {
                    xEl.Add(item.ToXml("Action"));
                }
            }
            return xEl;
        }
    }
}

