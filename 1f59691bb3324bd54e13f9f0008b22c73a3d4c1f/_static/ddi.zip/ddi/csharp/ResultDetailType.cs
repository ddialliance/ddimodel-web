using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Details of specific results of the development plan and process. May refer to specific development activities or DevelopmentSteps within a DevelopmentProcess.
    /// <summary>
    public partial class ResultDetailType
    {
        /// <summary>
        /// Identifies the specific type of result. Supports the use of an external controlled vocabulary.
        /// <summary>
        public string TypeOfResult { get; set; }
        /// <summary>
        /// A description of the Results Detail. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// The date or date range of obtaining results from the development work.
        /// <summary>
        public DateType ResultsDate { get; set; }
        /// <summary>
        /// Description of whether specific requirements for the activities providing these results were met.
        /// <summary>
        public List<RequirementsAssessmentType> RequirementsAssessment { get; set; } = new List<RequirementsAssessmentType>();
        public bool ShouldSerializeRequirementsAssessment() { return RequirementsAssessment.Count > 0; }
        /// <summary>
        /// Reference to one or more Development Activities used by the Development Plan. DevelopmentActivity is a substitution base for a number of types of activities described with appropriate content. TypeOfObject should be ContentReviewActivity, TranslationActivity, or PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivity> DevelopmentActivityReference { get; set; } = new List<DevelopmentActivity>();
        public bool ShouldSerializeDevelopmentActivityReference() { return DevelopmentActivityReference.Count > 0; }
        /// <summary>
        /// Reference to one or more Development Process Steps involved in these results.
        /// <summary>
        public List<DevelopmentProcessStepType> DevelopmentProcessStepReference { get; set; } = new List<DevelopmentProcessStepType>();
        public bool ShouldSerializeDevelopmentProcessStepReference() { return DevelopmentProcessStepReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfResult != null)
            {
                xEl.Add(new XElement(ns + "TypeOfResult", TypeOfResult));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ResultsDate != null) { xEl.Add(ResultsDate.ToXml("ResultsDate")); }
            if (RequirementsAssessment != null && RequirementsAssessment.Count > 0)
            {
                foreach (var item in RequirementsAssessment)
                {
                    xEl.Add(item.ToXml("RequirementsAssessment"));
                }
            }
            if (DevelopmentActivityReference != null && DevelopmentActivityReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentProcessStepReference != null && DevelopmentProcessStepReference.Count > 0)
            {
                foreach (var item in DevelopmentProcessStepReference)
                {
                    xEl.Add(item.ToXml("DevelopmentProcessStepReference"));
                }
            }
            return xEl;
        }
    }
}

