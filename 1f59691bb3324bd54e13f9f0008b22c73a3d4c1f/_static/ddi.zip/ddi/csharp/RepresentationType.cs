using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Abstract type for the head of a substitution group for a variable representation or a question response domain. If specific values are used to denote missing values, these can be indicated as a space-delimited list in the missingValue attribute. If the missing value is indicated by a blank, this should be indicated by setting the value of blankIsMissingValue to true.
    /// <summary>
    public partial class RepresentationType
    {
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// List the values used to represent missing data in a space delimited array. Use of MissingValuesReference is preferred. If this content does not match the values provided in the MissingValuesReference, the content of the MissingValuesReference overrides the content of this attribute.
        /// <summary>
        [StringValidation(null, @"\c+")]
        public string MissingValue { get; set; }
        /// <summary>
        /// When value is true a blank or empty variable content should be treated as a missing value.  Use of MissingValuesReference is preferred.
        /// <summary>
        public bool BlankIsMissingValue { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (MissingValue != null)
            {
                xEl.Add(new XElement(ns + "MissingValue", MissingValue));
            }
            xEl.Add(new XElement(ns + "BlankIsMissingValue", BlankIsMissingValue));
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

