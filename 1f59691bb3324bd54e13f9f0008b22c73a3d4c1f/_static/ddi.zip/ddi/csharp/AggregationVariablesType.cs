using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the independent and dependent variables used in the aggregation process. Note that in the case of calculating a percentage, mean, etc. of a dependent value against the total population of the cell, there is no independent variable.
    /// <summary>
    public partial class AggregationVariablesType : IdentifiableType
    {
        /// <summary>
        /// A reference to a variable, which is an important constraint for the computed aggregation measure and has the potential to invoke a change in a dependent variable like sex for average of income. In the context of calculating percentages, the use of Sex as the independent variable would indicate that the percentages provided represent the percentage of the dependent variable associated with a specific value for Sex (i.e., the dependent variable expressed as a percentage of the total for Males). This would be opposed to the percent for the full population (the percent of the total grid population falling within that particular cell).
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> IndependentVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeIndependentVariableReference() { return IndependentVariableReference.Count > 0; }
        /// <summary>
        /// A reference to a variable, for which the aggregate measure is computed like average of income.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> DependentVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeDependentVariableReference() { return DependentVariableReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (IndependentVariableReference != null && IndependentVariableReference.Count > 0)
            {
                foreach (var item in IndependentVariableReference)
                {
                    xEl.Add(new XElement(ns + "IndependentVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DependentVariableReference != null && DependentVariableReference.Count > 0)
            {
                foreach (var item in DependentVariableReference)
                {
                    xEl.Add(new XElement(ns + "DependentVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

