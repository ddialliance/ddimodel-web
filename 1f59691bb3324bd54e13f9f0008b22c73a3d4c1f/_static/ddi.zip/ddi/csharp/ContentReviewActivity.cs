using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A substitution for DevelopmentActivity which requires no additional information other than the specification of the type of content review taking place for development purposes.
    /// <summary>
    public partial class ContentReviewActivity : DevelopmentActivity
    {
        /// <summary>
        /// Identifies the specific type of content review not done as part of a Focus Group, Cognitive Expert Review, or Cognitive Interview. Supports the use of a controlled vocabulary which is strongly recommended.
        /// <summary>
        public CodeValueType TypeOfContentReview { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ContentReviewActivity");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfContentReview != null) { xEl.Add(TypeOfContentReview.ToXml("TypeOfContentReview")); }
            return xEl;
        }
    }
}

