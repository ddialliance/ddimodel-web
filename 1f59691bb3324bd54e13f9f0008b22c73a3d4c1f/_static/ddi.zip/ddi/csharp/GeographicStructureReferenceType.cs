using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to an existing GeographicStructure using the Reference structure plus the ability to exclude any number of contained GeographicLevels as specified by reference. TypeOfObject should be set to GeographicStructure.
    /// <summary>
    public partial class GeographicStructureReferenceType : ReferenceType
    {
        /// <summary>
        /// Reference to a GeographicLevel within the referenced GeographicStructure which should be excluded. Each excluded GeographicLevel should be specified by reference.
        /// <summary>
        public List<GeographicLevelType> ExcludedGeographicLevelReference { get; set; } = new List<GeographicLevelType>();
        public bool ShouldSerializeExcludedGeographicLevelReference() { return ExcludedGeographicLevelReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (ExcludedGeographicLevelReference != null && ExcludedGeographicLevelReference.Count > 0)
            {
                foreach (var item in ExcludedGeographicLevelReference)
                {
                    xEl.Add(item.ToXml("ExcludedGeographicLevelReference"));
                }
            }
            return xEl;
        }
    }
}

