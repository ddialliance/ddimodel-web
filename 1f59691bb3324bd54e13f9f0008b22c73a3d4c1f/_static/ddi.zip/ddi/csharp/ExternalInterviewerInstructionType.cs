using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specification of an external interviewer instruction not structured in DDI. Uses the structure of OtherMaterial to provide a citation, description, and locator for the object.
    /// <summary>
    public partial class ExternalInterviewerInstructionType
    {
        /// <summary>
        /// Specification of an external interviewer instruction not structured in DDI. Uses the structure of OtherMaterial to provide a citation, description, and locator for the object. TypeOfOtherMaterial should be set to ExternalInterviewInstruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public OtherMaterial OtherMaterialReference { get; set; }
        /// <summary>
        /// Allows attachment of an instruction to a specific item in a question structure. For example, to a Label, QuestionText, ResponseDomain, Response domain value, or grid cell.
        /// <summary>
        public List<InstructionAttachmentLocationType> InstructionAttachmentLocation { get; set; } = new List<InstructionAttachmentLocationType>();
        public bool ShouldSerializeInstructionAttachmentLocation() { return InstructionAttachmentLocation.Count > 0; }
        /// <summary>
        /// If set to "true" indicates that the instruction should always be displayed, not just upon need.
        /// <summary>
        public bool IsDisplayed { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (OtherMaterialReference != null)
            {
                xEl.Add(new XElement(ns + "OtherMaterialReference", 
                    new XElement(ns + "URN", OtherMaterialReference.URN), 
                    new XElement(ns + "Agency", OtherMaterialReference.Agency), 
                    new XElement(ns + "ID", OtherMaterialReference.ID), 
                    new XElement(ns + "Version", OtherMaterialReference.Version), 
                    new XElement(ns + "TypeOfObject", OtherMaterialReference.GetType().Name)));
            }
            if (InstructionAttachmentLocation != null && InstructionAttachmentLocation.Count > 0)
            {
                foreach (var item in InstructionAttachmentLocation)
                {
                    xEl.Add(item.ToXml("InstructionAttachmentLocation"));
                }
            }
            xEl.Add(new XElement(ns + "IsDisplayed", IsDisplayed));
            return xEl;
        }
    }
}

