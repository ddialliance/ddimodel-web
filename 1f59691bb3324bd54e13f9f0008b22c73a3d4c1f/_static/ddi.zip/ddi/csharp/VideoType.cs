using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the type and length of the video segment.
    /// <summary>
    public partial class VideoType
    {
        /// <summary>
        /// The type of video clip provided. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfVideoClip { get; set; }
        /// <summary>
        /// The point to begin the video clip. If no point is provided the assumption is that the start point is the beginning of the clip provided.
        /// <summary>
        public string VideoClipBegin { get; set; }
        /// <summary>
        /// The point to end the video clip. If no point is provided the assumption is that the end point is the end of the clip provided.
        /// <summary>
        public string VideoClipEnd { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfVideoClip != null) { xEl.Add(TypeOfVideoClip.ToXml("TypeOfVideoClip")); }
            if (VideoClipBegin != null)
            {
                xEl.Add(new XElement(ns + "VideoClipBegin", VideoClipBegin));
            }
            if (VideoClipEnd != null)
            {
                xEl.Add(new XElement(ns + "VideoClipEnd", VideoClipEnd));
            }
            return xEl;
        }
    }
}

