using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a set of MeasurementItems and MeasurementGroups. In addition to the standard name, label, and description of the MeasurementScheme, may contain another MeasurementScheme by reference, a listing of MeasurementItems (in-line or by reference), and a listing of MeasurementGroups (in-line or by reference).
    /// <summary>
    public partial class MeasurementScheme : Maintainable
    {
        /// <summary>
        /// A name for the MeasurementScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> MeasurementSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeMeasurementSchemeName() { return MeasurementSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the MeasurementItemScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the inclusion of another MeasurementItemScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementScheme> MeasurementSchemeReference { get; set; } = new List<MeasurementScheme>();
        public bool ShouldSerializeMeasurementSchemeReference() { return MeasurementSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a MeasurementItem in-line.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementItem> MeasurementItemReference { get; set; } = new List<MeasurementItem>();
        public bool ShouldSerializeMeasurementItemReference() { return MeasurementItemReference.Count > 0; }
        /// <summary>
        /// Contains a group of MeasurementItems, which may be ordered or hierarchical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementGroup> MeasurementGroupReference { get; set; } = new List<MeasurementGroup>();
        public bool ShouldSerializeMeasurementGroupReference() { return MeasurementGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "MeasurementScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (MeasurementSchemeName != null && MeasurementSchemeName.Count > 0)
            {
                foreach (var item in MeasurementSchemeName)
                {
                    xEl.Add(item.ToXml("MeasurementSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (MeasurementSchemeReference != null && MeasurementSchemeReference.Count > 0)
            {
                foreach (var item in MeasurementSchemeReference)
                {
                    xEl.Add(new XElement(ns + "MeasurementSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MeasurementItemReference != null && MeasurementItemReference.Count > 0)
            {
                foreach (var item in MeasurementItemReference)
                {
                    xEl.Add(new XElement(ns + "MeasurementItemReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MeasurementGroupReference != null && MeasurementGroupReference.Count > 0)
            {
                foreach (var item in MeasurementGroupReference)
                {
                    xEl.Add(new XElement(ns + "MeasurementGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

