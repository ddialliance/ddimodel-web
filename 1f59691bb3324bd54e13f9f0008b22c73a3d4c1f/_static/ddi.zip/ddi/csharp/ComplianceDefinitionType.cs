using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a list of quality concepts in the quality standard.
    /// <summary>
    public partial class ComplianceDefinitionType
    {
        /// <summary>
        /// A reference to a concept which relates to an area of coverage of the standard.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ComplianceConceptReference { get; set; }
        /// <summary>
        /// Specification of a code which relates to an area of coverage of the standard. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType ExternalComplianceCode { get; set; }
        /// <summary>
        /// Specifies what is required to be seen as in compliance with the Standard. Note minimum requirements for various levels of compliance. 
        /// <summary>
        public StructuredStringType ComplianceRequirements { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ComplianceConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ComplianceConceptReference", 
                    new XElement(ns + "URN", ComplianceConceptReference.URN), 
                    new XElement(ns + "Agency", ComplianceConceptReference.Agency), 
                    new XElement(ns + "ID", ComplianceConceptReference.ID), 
                    new XElement(ns + "Version", ComplianceConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ComplianceConceptReference.GetType().Name)));
            }
            if (ExternalComplianceCode != null) { xEl.Add(ExternalComplianceCode.ToXml("ExternalComplianceCode")); }
            if (ComplianceRequirements != null) { xEl.Add(ComplianceRequirements.ToXml("ComplianceRequirements")); }
            return xEl;
        }
    }
}

