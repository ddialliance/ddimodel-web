using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Serves as a common extension base for different forms of Questions
    /// <summary>
    public partial class Question : Versionable
    {
        /// <summary>
        /// Reference to the development implementation results which gave rise to this version of the object. TypeOfObject should be DevelopmentResults.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentResults> DevelopmentResultsReference { get; set; } = new List<DevelopmentResults>();
        public bool ShouldSerializeDevelopmentResultsReference() { return DevelopmentResultsReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Question");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentResultsReference != null && DevelopmentResultsReference.Count > 0)
            {
                foreach (var item in DevelopmentResultsReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentResultsReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

