using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specify requirements for type of staffing needed to complete activity including the class of staff participating in the activity, requirements for those participants, and the recruitment process.
    /// <summary>
    public partial class RecommendedStaffRequirementsType
    {
        /// <summary>
        /// Specify the class of the staff participating in the activity. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType StaffClass { get; set; }
        /// <summary>
        /// Describe any special or specific requirements for participating staff.
        /// <summary>
        public StructuredStringType ParticipantRequirements { get; set; }
        /// <summary>
        /// Describe the process to be used for staff recruitment in this class.
        /// <summary>
        public StructuredStringType RecruitmentProcess { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (StaffClass != null) { xEl.Add(StaffClass.ToXml("StaffClass")); }
            if (ParticipantRequirements != null) { xEl.Add(ParticipantRequirements.ToXml("ParticipantRequirements")); }
            if (RecruitmentProcess != null) { xEl.Add(RecruitmentProcess.ToXml("RecruitmentProcess")); }
            return xEl;
        }
    }
}

