using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A description of a particular category or response. OECD Glossary of Statistical Terms: Generic term for items at any level within a classification, typically tabulation categories, sections, subsections, divisions, subdivisions, groups, subgroups, classes and subclasses. In addition to the standard name, label, and description, a category may contain a reference to a defining concept, provide information on how the category was generated (membership defined), and indicate if it is the description of a type of missing value.
    /// <summary>
    public partial class Category : Versionable
    {
        /// <summary>
        /// A name for the category. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> CategoryName { get; set; } = new List<NameType>();
        public bool ShouldSerializeCategoryName() { return CategoryName.Count > 0; }
        /// <summary>
        /// A display label for the category. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.or of different types or applications.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the category. Note that comparison of categories is done using the content of description. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the defining concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Describes how the category is derived or generated. A process for describing the determination of category membership.
        /// <summary>
        public GenerationType Generation { get; set; }
        /// <summary>
        /// Reference to one or more categories for which the current category is a broader definition. Allows for a reference to the narrower category and the ability to define the relationship as a specialization or part.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Category> SubCategoryReference { get; set; } = new List<Category>();
        public bool ShouldSerializeSubCategoryReference() { return SubCategoryReference.Count > 0; }
        /// <summary>
        /// If the category is describing a classification of "missing data" set the value of isMissing to "true".
        /// <summary>
        public bool IsMissing { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Category");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CategoryName != null && CategoryName.Count > 0)
            {
                foreach (var item in CategoryName)
                {
                    xEl.Add(item.ToXml("CategoryName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Generation != null) { xEl.Add(Generation.ToXml("Generation")); }
            if (SubCategoryReference != null && SubCategoryReference.Count > 0)
            {
                foreach (var item in SubCategoryReference)
                {
                    xEl.Add(new XElement(ns + "SubCategoryReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            xEl.Add(new XElement(ns + "IsMissing", IsMissing));
            return xEl;
        }
    }
}

