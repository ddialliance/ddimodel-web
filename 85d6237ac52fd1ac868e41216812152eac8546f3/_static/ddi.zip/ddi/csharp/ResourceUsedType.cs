using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a name, label and description for the Development Process and lists the individual development activities which should take place.
    /// <summary>
    public partial class ResourceUsedType
    {
        /// <summary>
        /// Type of resource used. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfResource { get; set; }
        /// <summary>
        /// A description of the Resource. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the resource object used by this development step. If it is an external object create a description as OtherMaterial and reference the OtherMaterial. Use the attribute "objectLanguage" to specify any language preference. Repeat for multiple development objects. TypeOfObject should relate to the object referenced.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Versionable ResourceObjectReference { get; set; }
        /// <summary>
        /// The use of the resource within the DevelopmentProcessingStep. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType ResourceUsage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfResource != null) { xEl.Add(TypeOfResource.ToXml("TypeOfResource")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ResourceObjectReference != null)
            {
                xEl.Add(new XElement(ns + "ResourceObjectReference", 
                    new XElement(ns + "URN", ResourceObjectReference.URN), 
                    new XElement(ns + "Agency", ResourceObjectReference.Agency), 
                    new XElement(ns + "ID", ResourceObjectReference.ID), 
                    new XElement(ns + "Version", ResourceObjectReference.Version), 
                    new XElement(ns + "TypeOfObject", ResourceObjectReference.GetType().Name)));
            }
            if (ResourceUsage != null) { xEl.Add(ResourceUsage.ToXml("ResourceUsage")); }
            return xEl;
        }
    }
}

