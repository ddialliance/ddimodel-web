using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a representation based on categorization. The CategorySchemeReference allows for the exclusion of selected items from the use of the CategoryScheme as a representation.
    /// <summary>
    public partial class ManagedCategoryRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// A reference to a CategoryScheme containing the required categories using the SchemeReference structure. Use Exclude in the SchemeReference to designate any categories NOT to include in this representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedCategoryRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

