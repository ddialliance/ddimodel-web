using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A substitution for DevelopmentActivity which requires no additional information other than the specification of the type of Focus Group taking place for development purposes.
    /// <summary>
    public partial class FocusGroupActivity : DevelopmentActivity
    {
        /// <summary>
        /// Identifies the specific type of Focus Group. Supports the use of a controlled vocabulary which is strongly recommended.
        /// <summary>
        public CodeValueType TypeOfFocusGroup { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "FocusGroupActivity");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfFocusGroup != null) { xEl.Add(TypeOfFocusGroup.ToXml("TypeOfFocusGroup")); }
            return xEl;
        }
    }
}

