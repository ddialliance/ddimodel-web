using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures a response domain based on categorization that is described in an external non-DDI structure. Includes a UsageDescription that should provide information on how the external source is to be used.
    /// <summary>
    public partial class ManagedExternalCategoryRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// References an external, non DDI category. This is the element to use if the Code Scheme being used is not in DDI and cannot be used directly. It provides for both the reference and an explanation of how to use the information accurately within a DDI context.
        /// <summary>
        public Uri ExternalCategoryReference { get; set; }
        /// <summary>
        /// A description of the use of the external category file. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType UsageDescription { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedExternalCategoryRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (ExternalCategoryReference != null)
            {
                xEl.Add(new XElement(ns + "ExternalCategoryReference", ExternalCategoryReference));
            }
            if (UsageDescription != null) { xEl.Add(UsageDescription.ToXml("UsageDescription")); }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

