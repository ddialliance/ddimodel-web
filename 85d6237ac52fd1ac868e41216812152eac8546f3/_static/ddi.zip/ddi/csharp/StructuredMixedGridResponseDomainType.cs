using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a mixture of response domains for the grid cells. Each response domain can be attached to a specific region of the grid, for example a single column or row. It is assumed that each cell will contain either a resonse domain or be declared as containing No Data By Definition. Any cell may also contain an internal label.
    /// <summary>
    public partial class StructuredMixedGridResponseDomainType
    {
        /// <summary>
        /// Identifies a response type found in the grid and defines the cell or cells that contain it.
        /// <summary>
        public GridResponseDomainInMixedType GridResponseDomainInMixed { get; set; }
        /// <summary>
        /// Identifies the cell or cells in the grid that by definition contain no response domains. These cells MAY contain a label.
        /// <summary>
        public GridAttachmentType NoDataByDefinition { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (GridResponseDomainInMixed != null) { xEl.Add(GridResponseDomainInMixed.ToXml("GridResponseDomainInMixed")); }
            if (NoDataByDefinition != null) { xEl.Add(NoDataByDefinition.ToXml("NoDataByDefinition")); }
            return xEl;
        }
    }
}

