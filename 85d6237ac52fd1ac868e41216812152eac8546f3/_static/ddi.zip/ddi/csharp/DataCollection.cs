using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A maintainable module containing information on activities related to data collection/capture and the processing required for the creation a data product. This section covers the methodologies, events, data sources, collection instruments and processes which comprise the collection/capture and processing of data.  Metadata regarding the methodology of the data collection process including, determining repetition patterns, sampling, collection modes, etc. Collection Event specifies data sources, collection instruments, questions and question flow, and data processing activities. This module houses Processing Instructions (General Instructions and Generation Instructions) which may be referenced by variables or comparison maps.The module is described by a name, label, and description, provides spatial, temporal, and topical coverage information on the activities covered by the module, and references to external material related to objects in the module using OtherMaterial. The content of the module is organized within the following sections; Methodology, DataCaptureDevelopment, Collection Event, QuestionScheme (in-line or by reference), ControlConstructScheme (in-line or by references) containing the flow of a questionnaire or data capture process, InterviewerInstructionScheme (in-line or by reference), InstrumentScheme (in-line or by reference), ProcessingEventScheme (in-line or by reference), SamplingScheme (in-line or by reference) and DevelopmentActivityScheme.
    /// <summary>
    public partial class DataCollection : Maintainable
    {
        /// <summary>
        /// A name for the DataCollection module. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DataCollectionModuleName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDataCollectionModuleName() { return DataCollectionModuleName.Count > 0; }
        /// <summary>
        /// A display label for the DataCollection module. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the DataCollection module. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Documents the spatial, temporal, and/or topical coverage of the data collection module.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Methodology covers approaches used for selecting samples, administering surveys or data collection approaches, timing repeated data collection activities, weighting, and quality control.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Methodology MethodologyReference { get; set; }
        /// <summary>
        /// Data capture development covers the development planning, process, and outcome for a partial or full data capture object (question, measurement, instrument, or control construct). Development normally included the development of the question wording, possible response domains and their presentation, translation for language or cultural variance in the population, question/measurement order and mode of delivery (instrument). Extensive work is often done for individual questions/measures that may be reused by different data capture instruments with the organization or for topical areas or populations that are difficult to measure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public DataCaptureDevelopment DataCaptureDevelopmentReference { get; set; }
        /// <summary>
        /// A specific event in the collection or capture process.
        /// <summary>
        public List<CollectionEventType> CollectionEvent { get; set; } = new List<CollectionEventType>();
        public bool ShouldSerializeCollectionEvent() { return CollectionEvent.Count > 0; }
        /// <summary>
        /// Describes a set of questions used for data collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionScheme> QuestionSchemeReference { get; set; } = new List<QuestionScheme>();
        public bool ShouldSerializeQuestionSchemeReference() { return QuestionSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a set of measurements used for data collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<MeasurementScheme> MeasurementSchemeReference { get; set; } = new List<MeasurementScheme>();
        public bool ShouldSerializeMeasurementSchemeReference() { return MeasurementSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a set of control constructs used to order and define processes such as data capture flow, instrument flow, sampling, data capture development activities, etc. Assumes the flow of the object along the prescribed routing (i.e. respondent through a questionnaire, data source through a measurement process, development object through a development process, or data set of a population through a sample sampling plan)Uses InParameters and OutParameters to describe the specific flow of datum captured by, used within, or processed by to create a stored datum in a variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ControlConstructScheme> ControlConstructSchemeReference { get; set; } = new List<ControlConstructScheme>();
        public bool ShouldSerializeControlConstructSchemeReference() { return ControlConstructSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a set of instructions used by the interviewer (respondent in the case of a self administered questionnaire) or instrument to support the accurate collection or capture of data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InterviewerInstructionScheme> InterviewerInstructionSchemeReference { get; set; } = new List<InterviewerInstructionScheme>();
        public bool ShouldSerializeInterviewerInstructionSchemeReference() { return InterviewerInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a set of instruments used to collect or capture data.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InstrumentScheme> InstrumentSchemeReference { get; set; } = new List<InstrumentScheme>();
        public bool ShouldSerializeInstrumentSchemeReference() { return InstrumentSchemeReference.Count > 0; }
        /// <summary>
        /// Describes an instrument within this Data Collection.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Instrument> InstrumentReference { get; set; } = new List<Instrument>();
        public bool ShouldSerializeInstrumentReference() { return InstrumentReference.Count > 0; }
        /// <summary>
        /// Describes a set of processing events used to collect or capture data and process it during or post collection. May include the processes used to capture data in non-questionnaire data capture.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingEventScheme> ProcessingEventSchemeReference { get; set; } = new List<ProcessingEventScheme>();
        public bool ShouldSerializeProcessingEventSchemeReference() { return ProcessingEventSchemeReference.Count > 0; }
        /// <summary>
        /// Describes a set of processing instructions used to collect or capture data and process it during or post collection. May include the processing instructions used to capture data in non-questionnaire data capture.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingInstructionScheme> ProcessingInstructionSchemeReference { get; set; } = new List<ProcessingInstructionScheme>();
        public bool ShouldSerializeProcessingInstructionSchemeReference() { return ProcessingInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// A set of sampling information maintained by an agency including sampling plans, sample frames, and samples.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SamplingInformationScheme> SamplingInformationSchemeReference { get; set; } = new List<SamplingInformationScheme>();
        public bool ShouldSerializeSamplingInformationSchemeReference() { return SamplingInformationSchemeReference.Count > 0; }
        /// <summary>
        /// A set of development activities maintained by an agency, and used in the development, review, or creation of a question, measurement, data capture flow (control construct), or instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivityScheme> DevelopmentActivitySchemeReference { get; set; } = new List<DevelopmentActivityScheme>();
        public bool ShouldSerializeDevelopmentActivitySchemeReference() { return DevelopmentActivitySchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DataCollection");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DataCollectionModuleName != null && DataCollectionModuleName.Count > 0)
            {
                foreach (var item in DataCollectionModuleName)
                {
                    xEl.Add(item.ToXml("DataCollectionModuleName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (MethodologyReference != null)
            {
                xEl.Add(new XElement(ns + "MethodologyReference", 
                    new XElement(ns + "URN", MethodologyReference.URN), 
                    new XElement(ns + "Agency", MethodologyReference.Agency), 
                    new XElement(ns + "ID", MethodologyReference.ID), 
                    new XElement(ns + "Version", MethodologyReference.Version), 
                    new XElement(ns + "TypeOfObject", MethodologyReference.GetType().Name)));
            }
            if (DataCaptureDevelopmentReference != null)
            {
                xEl.Add(new XElement(ns + "DataCaptureDevelopmentReference", 
                    new XElement(ns + "URN", DataCaptureDevelopmentReference.URN), 
                    new XElement(ns + "Agency", DataCaptureDevelopmentReference.Agency), 
                    new XElement(ns + "ID", DataCaptureDevelopmentReference.ID), 
                    new XElement(ns + "Version", DataCaptureDevelopmentReference.Version), 
                    new XElement(ns + "TypeOfObject", DataCaptureDevelopmentReference.GetType().Name)));
            }
            if (CollectionEvent != null && CollectionEvent.Count > 0)
            {
                foreach (var item in CollectionEvent)
                {
                    xEl.Add(item.ToXml("CollectionEvent"));
                }
            }
            if (QuestionSchemeReference != null && QuestionSchemeReference.Count > 0)
            {
                foreach (var item in QuestionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "QuestionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (MeasurementSchemeReference != null && MeasurementSchemeReference.Count > 0)
            {
                foreach (var item in MeasurementSchemeReference)
                {
                    xEl.Add(new XElement(ns + "MeasurementSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ControlConstructSchemeReference != null && ControlConstructSchemeReference.Count > 0)
            {
                foreach (var item in ControlConstructSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ControlConstructSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InterviewerInstructionSchemeReference != null && InterviewerInstructionSchemeReference.Count > 0)
            {
                foreach (var item in InterviewerInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InterviewerInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstrumentSchemeReference != null && InstrumentSchemeReference.Count > 0)
            {
                foreach (var item in InstrumentSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstrumentReference != null && InstrumentReference.Count > 0)
            {
                foreach (var item in InstrumentReference)
                {
                    xEl.Add(new XElement(ns + "InstrumentReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingEventSchemeReference != null && ProcessingEventSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingEventSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingEventSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingInstructionSchemeReference != null && ProcessingInstructionSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (SamplingInformationSchemeReference != null && SamplingInformationSchemeReference.Count > 0)
            {
                foreach (var item in SamplingInformationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "SamplingInformationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentActivitySchemeReference != null && DevelopmentActivitySchemeReference.Count > 0)
            {
                foreach (var item in DevelopmentActivitySchemeReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivitySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

