using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Used to describe the rules and guidelines on how the data is allowed to be handled, transferred, stored and disposed. These confidentiality policies are often dictated by national laws and/or data owners on handling of personal, proprietary, and other sensitive information.
    /// <summary>
    public partial class InformationClassification : Describable
    {
        /// <summary>
        /// Classification of the type of Information Classification. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfInformationClassification { get; set; }
        /// <summary>
        /// Data classification level as determined by an assessment of the need of confidentiality of the data. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType LevelOfInformationClassification { get; set; }
        /// <summary>
        /// A reference to an organization or individual responsible for the information classification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent AgencyOrganizationReference { get; set; }
        /// <summary>
        /// Description of the rules applied to any individual with access to the data, e.g. security clearance, confidentiality agreements, or authentication. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public List<StructuredStringType> DataHandlingPersonnelRules { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeDataHandlingPersonnelRules() { return DataHandlingPersonnelRules.Count > 0; }
        /// <summary>
        /// Description of the rules regarding what encryption level is needed on the data. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public List<StructuredStringType> DataEncryptionRules { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeDataEncryptionRules() { return DataEncryptionRules.Count > 0; }
        /// <summary>
        /// Description of the rules regarding how data is allowed to be stored. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public List<StructuredStringType> DataStorageRules { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeDataStorageRules() { return DataStorageRules.Count > 0; }
        /// <summary>
        /// Description of the rules regarding when and how data should be disposed. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public List<StructuredStringType> DisposalRules { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeDisposalRules() { return DisposalRules.Count > 0; }
        /// <summary>
        /// Description of the rules regarding how data is allowed to be transferred. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public List<StructuredStringType> DataTransferRules { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeDataTransferRules() { return DataTransferRules.Count > 0; }
        /// <summary>
        /// Description and link to the Information Classification policy using the DDI Other Material structure.
        /// <summary>
        public List<AuthorizedPolicySourceType> AuthorizedPolicySource { get; set; } = new List<AuthorizedPolicySourceType>();
        public bool ShouldSerializeAuthorizedPolicySource() { return AuthorizedPolicySource.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "InformationClassification");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfInformationClassification != null) { xEl.Add(TypeOfInformationClassification.ToXml("TypeOfInformationClassification")); }
            if (LevelOfInformationClassification != null) { xEl.Add(LevelOfInformationClassification.ToXml("LevelOfInformationClassification")); }
            if (AgencyOrganizationReference != null)
            {
                xEl.Add(new XElement(ns + "AgencyOrganizationReference", 
                    new XElement(ns + "URN", AgencyOrganizationReference.URN), 
                    new XElement(ns + "Agency", AgencyOrganizationReference.Agency), 
                    new XElement(ns + "ID", AgencyOrganizationReference.ID), 
                    new XElement(ns + "Version", AgencyOrganizationReference.Version), 
                    new XElement(ns + "TypeOfObject", AgencyOrganizationReference.GetType().Name)));
            }
            if (DataHandlingPersonnelRules != null && DataHandlingPersonnelRules.Count > 0)
            {
                foreach (var item in DataHandlingPersonnelRules)
                {
                    xEl.Add(item.ToXml("DataHandlingPersonnelRules"));
                }
            }
            if (DataEncryptionRules != null && DataEncryptionRules.Count > 0)
            {
                foreach (var item in DataEncryptionRules)
                {
                    xEl.Add(item.ToXml("DataEncryptionRules"));
                }
            }
            if (DataStorageRules != null && DataStorageRules.Count > 0)
            {
                foreach (var item in DataStorageRules)
                {
                    xEl.Add(item.ToXml("DataStorageRules"));
                }
            }
            if (DisposalRules != null && DisposalRules.Count > 0)
            {
                foreach (var item in DisposalRules)
                {
                    xEl.Add(item.ToXml("DisposalRules"));
                }
            }
            if (DataTransferRules != null && DataTransferRules.Count > 0)
            {
                foreach (var item in DataTransferRules)
                {
                    xEl.Add(item.ToXml("DataTransferRules"));
                }
            }
            if (AuthorizedPolicySource != null && AuthorizedPolicySource.Count > 0)
            {
                foreach (var item in AuthorizedPolicySource)
                {
                    xEl.Add(item.ToXml("AuthorizedPolicySource"));
                }
            }
            return xEl;
        }
    }
}

