using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the type of evaluation, completion date, evaluation process and outcomes of the ExPost Evaluation. Allows identification of the Evaluator via reference to and organization or individual and provides for the optional use of a controlled vocabulary to define the specific role of the evaluator.
    /// <summary>
    public partial class EvaluatorType
    {
        /// <summary>
        /// Reference to an Organization or Individual involved in performing the evaluation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent EvaluatorReference { get; set; }
        /// <summary>
        /// Describes the role of the evaluator with optional use of a controlled vocabulary.
        /// <summary>
        public List<CodeValueType> EvaluatorRole { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeEvaluatorRole() { return EvaluatorRole.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (EvaluatorReference != null)
            {
                xEl.Add(new XElement(ns + "EvaluatorReference", 
                    new XElement(ns + "URN", EvaluatorReference.URN), 
                    new XElement(ns + "Agency", EvaluatorReference.Agency), 
                    new XElement(ns + "ID", EvaluatorReference.ID), 
                    new XElement(ns + "Version", EvaluatorReference.Version), 
                    new XElement(ns + "TypeOfObject", EvaluatorReference.GetType().Name)));
            }
            if (EvaluatorRole != null && EvaluatorRole.Count > 0)
            {
                foreach (var item in EvaluatorRole)
                {
                    xEl.Add(item.ToXml("EvaluatorRole"));
                }
            }
            return xEl;
        }
    }
}

