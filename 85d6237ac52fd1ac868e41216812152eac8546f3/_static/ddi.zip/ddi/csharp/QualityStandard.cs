using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A formal description of a quality standard, and the quality concepts which it requires.
    /// <summary>
    public partial class QualityStandard : Versionable
    {
        /// <summary>
        /// Name of the QualityStandard using the DDI Name structure.
        /// <summary>
        public List<NameType> QualityStandardName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQualityStandardName() { return QualityStandardName.Count > 0; }
        /// <summary>
        /// A display label for the QualityStandard. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the QualityStandard. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Provide the citation and location of the source published standard using the OtherMaterialType.
        /// <summary>
        public StandardUsedType StandardUsed { get; set; }
        /// <summary>
        /// Provides a list of quality concepts in the quality standard.
        /// <summary>
        public List<ComplianceDefinitionType> ComplianceDefinition { get; set; } = new List<ComplianceDefinitionType>();
        public bool ShouldSerializeComplianceDefinition() { return ComplianceDefinition.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "QualityStandard");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QualityStandardName != null && QualityStandardName.Count > 0)
            {
                foreach (var item in QualityStandardName)
                {
                    xEl.Add(item.ToXml("QualityStandardName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (StandardUsed != null) { xEl.Add(StandardUsed.ToXml("StandardUsed")); }
            if (ComplianceDefinition != null && ComplianceDefinition.Count > 0)
            {
                foreach (var item in ComplianceDefinition)
                {
                    xEl.Add(item.ToXml("ComplianceDefinition"));
                }
            }
            return xEl;
        }
    }
}

