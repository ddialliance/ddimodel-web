using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A ControlConstruct that provides a specialized act for generating a sample.
    /// <summary>
    public partial class SampleStep : ControlConstruct
    {
        /// <summary>
        /// A distinct "strata" within a population used to define a group to be sampled within that population, for example an Income Level or Postal Code.
        /// <summary>
        public List<StructuredStringType> ConditionForAcceptance { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeConditionForAcceptance() { return ConditionForAcceptance.Count > 0; }
        /// <summary>
        /// The Code which contains the value of the variable in programming terms.
        /// <summary>
        public CommandCodeType CommandCode { get; set; }
        /// <summary>
        /// A distinct "strata" within a population used to define a group to be sampled within that population, for example an Income Level or Postal Code.
        /// <summary>
        public StratificationType Stratification { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SampleStep");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ConditionForAcceptance != null && ConditionForAcceptance.Count > 0)
            {
                foreach (var item in ConditionForAcceptance)
                {
                    xEl.Add(item.ToXml("ConditionForAcceptance"));
                }
            }
            if (CommandCode != null) { xEl.Add(CommandCode.ToXml("CommandCode")); }
            if (Stratification != null) { xEl.Add(Stratification.ToXml("Stratification")); }
            return xEl;
        }
    }
}

