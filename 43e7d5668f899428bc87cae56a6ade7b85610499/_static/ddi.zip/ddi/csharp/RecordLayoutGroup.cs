using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains a group of RecordLayout descriptions for administrative or conceptual purposes, which may be hierarchical. In addition to the standard name, label, and description, allows for a classification of the type of group, a reference to a Universe and Concept and inclusion of RecordLayouts and RecordLayoutGroups by reference, plus a flag indicating if the group is ordered.
    /// <summary>
    public partial class RecordLayoutGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a RecordLayoutGroup. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfRecordLayoutGroup { get; set; }
        /// <summary>
        /// A name for the RecordLayoutGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> RecordLayoutGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeRecordLayoutGroupName() { return RecordLayoutGroupName.Count > 0; }
        /// <summary>
        /// A display label for the RecordLayoutGroup. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the RecordLayoutGroup. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other elements that the data refer to, and to which any analytic results refer.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept represented by the record layout in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent RecordLayout.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RecordLayout RecordLayoutReference { get; set; }
        /// <summary>
        /// Reference to constituent RecordLayout.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public InLineNCubeRecordLayout InLineNCubeRecordLayoutReference { get; set; }
        /// <summary>
        /// Reference to constituent RecordLayout.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProprietaryRecordLayout ProprietaryRecordLayoutReference { get; set; }
        /// <summary>
        /// Reference to constituent RecordLayout.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public TabularNCubeRecordLayout TabularNCubeRecordLayoutReference { get; set; }
        /// <summary>
        /// Reference to constituent RecordLayoutGroup. This allows for nesting of variable RecordLayoutGroups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RecordLayoutGroup RecordLayoutGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "RecordLayoutGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfRecordLayoutGroup != null) { xEl.Add(TypeOfRecordLayoutGroup.ToXml("TypeOfRecordLayoutGroup")); }
            if (RecordLayoutGroupName != null && RecordLayoutGroupName.Count > 0)
            {
                foreach (var item in RecordLayoutGroupName)
                {
                    xEl.Add(item.ToXml("RecordLayoutGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (RecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "RecordLayoutReference", 
                    new XElement(ns + "URN", RecordLayoutReference.URN), 
                    new XElement(ns + "Agency", RecordLayoutReference.Agency), 
                    new XElement(ns + "ID", RecordLayoutReference.ID), 
                    new XElement(ns + "Version", RecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", RecordLayoutReference.GetType().Name)));
            }
            if (InLineNCubeRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "InLineNCubeRecordLayoutReference", 
                    new XElement(ns + "URN", InLineNCubeRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", InLineNCubeRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", InLineNCubeRecordLayoutReference.ID), 
                    new XElement(ns + "Version", InLineNCubeRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", InLineNCubeRecordLayoutReference.GetType().Name)));
            }
            if (ProprietaryRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "ProprietaryRecordLayoutReference", 
                    new XElement(ns + "URN", ProprietaryRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", ProprietaryRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", ProprietaryRecordLayoutReference.ID), 
                    new XElement(ns + "Version", ProprietaryRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", ProprietaryRecordLayoutReference.GetType().Name)));
            }
            if (TabularNCubeRecordLayoutReference != null)
            {
                xEl.Add(new XElement(ns + "TabularNCubeRecordLayoutReference", 
                    new XElement(ns + "URN", TabularNCubeRecordLayoutReference.URN), 
                    new XElement(ns + "Agency", TabularNCubeRecordLayoutReference.Agency), 
                    new XElement(ns + "ID", TabularNCubeRecordLayoutReference.ID), 
                    new XElement(ns + "Version", TabularNCubeRecordLayoutReference.Version), 
                    new XElement(ns + "TypeOfObject", TabularNCubeRecordLayoutReference.GetType().Name)));
            }
            if (RecordLayoutGroupReference != null)
            {
                xEl.Add(new XElement(ns + "RecordLayoutGroupReference", 
                    new XElement(ns + "URN", RecordLayoutGroupReference.URN), 
                    new XElement(ns + "Agency", RecordLayoutGroupReference.Agency), 
                    new XElement(ns + "ID", RecordLayoutGroupReference.ID), 
                    new XElement(ns + "Version", RecordLayoutGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", RecordLayoutGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

