using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the specific measure of the cell designating the order value of the Measure within the MeasureDimension and the value of the measure. It is recommended to repeat Measure to define each measure definition and value separately. When Value contains multiple measures expressed as an ordered array list each measure in the array as a MeasureDimensionValue with its specified arrayOrder within a single Measure definition.
    /// <summary>
    public partial class MeasureIType
    {
        /// <summary>
        /// Specifies the orderValue of the Measure in the MeasureDimension described in the NCubeInstance along with its arrayOrder if multiple measures are provided as an array in a single storage location.
        /// <summary>
        public List<MeasureDimensionValueType> MeasureDimensionValue { get; set; } = new List<MeasureDimensionValueType>();
        public bool ShouldSerializeMeasureDimensionValue() { return MeasureDimensionValue.Count > 0; }
        /// <summary>
        /// Value of the Measure expressed as a single value or ordered array.
        /// <summary>
        public ValueType Value { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MeasureDimensionValue != null && MeasureDimensionValue.Count > 0)
            {
                foreach (var item in MeasureDimensionValue)
                {
                    xEl.Add(item.ToXml("MeasureDimensionValue"));
                }
            }
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            return xEl;
        }
    }
}

