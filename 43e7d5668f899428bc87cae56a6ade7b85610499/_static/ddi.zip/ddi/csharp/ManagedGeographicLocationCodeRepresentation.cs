using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for the use of all or part of a GeographicLocation description to be used as a response domain or value representation by a question or variable. In addition to the basic objects of a representation it describes the Geographic Location values available for use by the question or variable.
    /// <summary>
    public partial class ManagedGeographicLocationCodeRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// A name for the ManagedGeographicLocationCodeRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example, different names for different systems.
        /// <summary>
        public List<NameType> ManagedGeographicLocationCodeRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedGeographicLocationCodeRepresentationName() { return ManagedGeographicLocationCodeRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// Identifies the Geographic Location codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicLocationCodesType IncludedGeographicLocationCodes { get; set; }
        /// <summary>
        /// When the code is a concatenation this structure allows you to limit the portion of the concatenated code that this object captures.
        /// <summary>
        public LimitedCodeSegmentCapturedType LimitedCodeSegmentCaptured { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedGeographicLocationCodeRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedGeographicLocationCodeRepresentationName != null && ManagedGeographicLocationCodeRepresentationName.Count > 0)
            {
                foreach (var item in ManagedGeographicLocationCodeRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedGeographicLocationCodeRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (IncludedGeographicLocationCodes != null) { xEl.Add(IncludedGeographicLocationCodes.ToXml("IncludedGeographicLocationCodes")); }
            if (LimitedCodeSegmentCaptured != null) { xEl.Add(LimitedCodeSegmentCaptured.ToXml("LimitedCodeSegmentCaptured")); }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

