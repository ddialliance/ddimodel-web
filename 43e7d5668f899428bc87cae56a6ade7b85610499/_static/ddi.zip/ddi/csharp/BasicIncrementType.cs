using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the start, end, and increment value for an incremental string (numeric, character, or length).
    /// <summary>
    public partial class BasicIncrementType
    {
        /// <summary>
        /// The size of the increment in units (number of characters, length, number of units).
        /// <summary>
        public string Increment { get; set; }
        /// <summary>
        /// The starting value or beginning point of the increment string.
        /// <summary>
        public string StartValue { get; set; }
        /// <summary>
        /// The ending value or end point of the increment string.
        /// <summary>
        public string EndValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Increment != null)
            {
                xEl.Add(new XElement(ns + "Increment", Increment));
            }
            if (StartValue != null)
            {
                xEl.Add(new XElement(ns + "StartValue", StartValue));
            }
            if (EndValue != null)
            {
                xEl.Add(new XElement(ns + "EndValue", EndValue));
            }
            return xEl;
        }
    }
}

