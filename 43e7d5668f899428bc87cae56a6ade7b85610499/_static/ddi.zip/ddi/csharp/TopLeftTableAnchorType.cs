using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Notes the column and row position of the top left corner of the data table in the spreadsheet.
    /// <summary>
    public partial class TopLeftTableAnchorType
    {
        /// <summary>
        /// The column identifier expressed as a string.
        /// <summary>
        public string Column { get; set; }
        /// <summary>
        /// The row number expressed as an integer.
        /// <summary>
        public int Row { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Column != null)
            {
                xEl.Add(new XElement(ns + "Column", Column));
            }
            xEl.Add(new XElement(ns + "Row", Row));
            return xEl;
        }
    }
}

