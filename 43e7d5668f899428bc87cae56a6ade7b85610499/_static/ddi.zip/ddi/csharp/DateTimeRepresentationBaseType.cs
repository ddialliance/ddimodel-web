using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures the representation for any type of time format (including dates, etc.). Regardless of the format of the data the content may be treated as a date and or time and converted to ISO standard structure if sufficient information is supplied.
    /// <summary>
    public partial class DateTimeRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// Describes the format of the date field, in formats such as YYYY/MM or MM-DD-YY, etc. If this element is omitted, then the format is assumed to be the XML Schema format corresponding to the type attribute value.
        /// <summary>
        public CodeValueType DateFieldFormat { get; set; }
        /// <summary>
        /// This is a standard XML date type code and supports the use of an external controlled vocabulary. Examples are date, dateTime, gYearMonth, gYear, and duration. The DDI Alliance has provided a controlled vocabulary (DateType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType DateTypeCode { get; set; }
        /// <summary>
        /// Indicates the high and low values (endpoints) of a non-numeric scale. This can be expressed as a value that matches the DateTime format. Repeatable in order to express as set of non-continuous values.
        /// <summary>
        public List<RangeType> Range { get; set; } = new List<RangeType>();
        public bool ShouldSerializeRange() { return Range.Count > 0; }
        /// <summary>
        /// The regular expression allows for further description of the allowable content of the data.
        /// <summary>
        public string RegExp { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (DateFieldFormat != null) { xEl.Add(DateFieldFormat.ToXml("DateFieldFormat")); }
            if (DateTypeCode != null) { xEl.Add(DateTypeCode.ToXml("DateTypeCode")); }
            if (Range != null && Range.Count > 0)
            {
                foreach (var item in Range)
                {
                    xEl.Add(item.ToXml("Range"));
                }
            }
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            return xEl;
        }
    }
}

