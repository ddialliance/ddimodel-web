using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the data file documented in the physical instance and provides information about its location.
    /// <summary>
    public partial class DataFileIdentificationType
    {
        /// <summary>
        /// Documents the location of the data file as a description. Supports the multi-language content.
        /// <summary>
        public InternationalStringType Location { get; set; }
        /// <summary>
        /// A URN or URL for the data file with a flag to indicate if it is a public copy.
        /// <summary>
        public URIType DataFileURI { get; set; }
        /// <summary>
        /// Specifies the size of the file in bytes.
        /// <summary>
        public int SizeInBytes { get; set; }
        /// <summary>
        /// Set to "true" when this file is the master file (in the case that there are multiple, i.e. backup, copies).
        /// <summary>
        public bool IsMaster { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Location != null) { xEl.Add(Location.ToXml("Location")); }
            if (DataFileURI != null) { xEl.Add(DataFileURI.ToXml("DataFileURI")); }
            xEl.Add(new XElement(ns + "SizeInBytes", SizeInBytes));
            xEl.Add(new XElement(ns + "IsMaster", IsMaster));
            return xEl;
        }
    }
}

