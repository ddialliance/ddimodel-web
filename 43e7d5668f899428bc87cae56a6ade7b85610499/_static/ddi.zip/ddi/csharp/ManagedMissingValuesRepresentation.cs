using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing the Missing Values within a managed representation so that they can be reused by multiple variables and questions. Variable has a separate Missing Values location for this representation. Questions must use a StructuredMixedResponseDomain to include both standard response and Missing Value responses in a single question. In addition to the name, label, and description of the representation, the structure defines the type of the missing values, a optional generation instruction for deriving the value to be recorded, and the ability to define a blank as a missing value.
    /// <summary>
    public partial class ManagedMissingValuesRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// A name for the ManagedMissingValuesRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedMissingValuesRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedMissingValuesRepresentationName() { return ManagedMissingValuesRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the ManagedMissingValuesRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ManagedMissingValuesRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// In-line description of a CodeRepresentationBase created for the purpose of capturing missing values with associated labels.
        /// <summary>
        public CodeRepresentationBaseType MissingCodeRepresentation { get; set; }
        /// <summary>
        /// In-line description of a NumericRepresentationBase created for the purpose of capturing missing values as a set of numbers or a range.
        /// <summary>
        public NumericRepresentationBaseType MissingNumericRepresentation { get; set; }
        /// <summary>
        /// In-line description of a TextRepresentationBase created for the purpose of capturing missing values as text content.
        /// <summary>
        public TextRepresentationBaseType MissingTextRepresentation { get; set; }
        /// <summary>
        /// An optional reference to a GenerationInstruction describing how to generate the value for this representation when used as a response domain or missing value representation. TypeOfObject should be set to GeneralInstruction or GenerationInstruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstruction ProcessingInstructionReference { get; set; }
        /// <summary>
        /// Designates no response (white space, null) to be treated as a missing value.
        /// <summary>
        public bool IsBlankMissingValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedMissingValuesRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedMissingValuesRepresentationName != null && ManagedMissingValuesRepresentationName.Count > 0)
            {
                foreach (var item in ManagedMissingValuesRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedMissingValuesRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (MissingCodeRepresentation != null) { xEl.Add(MissingCodeRepresentation.ToXml("MissingCodeRepresentation")); }
            if (MissingNumericRepresentation != null) { xEl.Add(MissingNumericRepresentation.ToXml("MissingNumericRepresentation")); }
            if (MissingTextRepresentation != null) { xEl.Add(MissingTextRepresentation.ToXml("MissingTextRepresentation")); }
            if (ProcessingInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference", 
                    new XElement(ns + "URN", ProcessingInstructionReference.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsBlankMissingValue", IsBlankMissingValue));
            return xEl;
        }
    }
}

