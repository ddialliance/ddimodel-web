using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Maps the content of two different schemes of objects of the same type providing detail for the comparable items within those two schemes. Note that comparisons can be made between multiple items in the same scheme or two versions of the same scheme. In addition to the standard name, label, and description of the map, identifies the source scheme and target scheme containing those objects, describes the correspondence between the source and target schemes, and provides detailed comparison of the items within those two schemes.
    /// <summary>
    public partial class GenericMap : Versionable
    {
        /// <summary>
        /// A name for the Map. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> MapName { get; set; } = new List<NameType>();
        public bool ShouldSerializeMapName() { return MapName.Count > 0; }
        /// <summary>
        /// A display label for the Map. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Map. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Mappings are unidirectional. The scheme referenced as the source is the scheme contents that would be transformed into the scheme contents identified as the target scheme contents.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable SourceSchemeReference { get; set; }
        /// <summary>
        /// Reference to the scheme containing the target structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable TargetSchemeReference { get; set; }
        /// <summary>
        /// Describe the level of similarity and difference between the Source and the Target schemes.
        /// <summary>
        public CorrespondenceType Correspondence { get; set; }
        /// <summary>
        /// Contains the mappings for individual items within the Source and Target schemes.
        /// <summary>
        public List<ItemMapType> ItemMap { get; set; } = new List<ItemMapType>();
        public bool ShouldSerializeItemMap() { return ItemMap.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "GenericMap");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (MapName != null && MapName.Count > 0)
            {
                foreach (var item in MapName)
                {
                    xEl.Add(item.ToXml("MapName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SourceSchemeReference != null)
            {
                xEl.Add(new XElement(ns + "SourceSchemeReference", 
                    new XElement(ns + "URN", SourceSchemeReference.URN), 
                    new XElement(ns + "Agency", SourceSchemeReference.Agency), 
                    new XElement(ns + "ID", SourceSchemeReference.ID), 
                    new XElement(ns + "Version", SourceSchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", SourceSchemeReference.GetType().Name)));
            }
            if (TargetSchemeReference != null)
            {
                xEl.Add(new XElement(ns + "TargetSchemeReference", 
                    new XElement(ns + "URN", TargetSchemeReference.URN), 
                    new XElement(ns + "Agency", TargetSchemeReference.Agency), 
                    new XElement(ns + "ID", TargetSchemeReference.ID), 
                    new XElement(ns + "Version", TargetSchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", TargetSchemeReference.GetType().Name)));
            }
            if (Correspondence != null) { xEl.Add(Correspondence.ToXml("Correspondence")); }
            if (ItemMap != null && ItemMap.Count > 0)
            {
                foreach (var item in ItemMap)
                {
                    xEl.Add(item.ToXml("ItemMap"));
                }
            }
            return xEl;
        }
    }
}

