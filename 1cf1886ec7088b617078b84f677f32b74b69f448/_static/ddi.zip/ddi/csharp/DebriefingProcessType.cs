using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describe the debriefing process. Specifies if debriefing is required. Supports multiple language versions of the same content as well as optional formatting of the content.
    /// <summary>
    public partial class DebriefingProcessType : StructuredStringType
    {
        /// <summary>
        /// If debriefing is required for this activity set isRequired to "true".
        /// <summary>
        public bool IsRequired { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("StructuredStringType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsRequired", IsRequired));
            return xEl;
        }
    }
}

