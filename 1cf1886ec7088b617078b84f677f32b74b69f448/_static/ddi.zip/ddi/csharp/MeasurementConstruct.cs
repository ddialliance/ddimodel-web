using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A construct which ties measurement content to the programmatic logic of the control constructs. Contains a reference to a MeasurementItem, identifies the response unit, analysis unit, and universe. May provide an estimate of the number of minutes needed to respond.
    /// <summary>
    public partial class MeasurementConstruct : ControlConstruct
    {
        /// <summary>
        /// Reference to a Measurement.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public MeasurementItem MeasurementReference { get; set; }
        /// <summary>
        /// Identifies the intended Response unit (respondent). Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType ResponseUnit { get; set; }
        /// <summary>
        /// The analysis unit, expressed as a term which may come from a controlled vocabulary.
        /// <summary>
        public List<CodeValueType> AnalysisUnit { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeAnalysisUnit() { return AnalysisUnit.Count > 0; }
        /// <summary>
        /// Reference to the universe statement containing a description of the persons or other elements that this measurement refers to.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// The estimated amount of time required to perform the data capture expressed in seconds. Decimal values should be used to define fractions of seconds. At the measurement construct level it refers to the estimated time within the context of is use in a data capture process.
        /// <summary>
        public decimal EstimatedSecondsResponseTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "MeasurementConstruct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (MeasurementReference != null)
            {
                xEl.Add(new XElement(ns + "MeasurementReference", 
                    new XElement(ns + "URN", MeasurementReference.URN), 
                    new XElement(ns + "Agency", MeasurementReference.Agency), 
                    new XElement(ns + "ID", MeasurementReference.ID), 
                    new XElement(ns + "Version", MeasurementReference.Version), 
                    new XElement(ns + "TypeOfObject", MeasurementReference.GetType().Name)));
            }
            if (ResponseUnit != null) { xEl.Add(ResponseUnit.ToXml("ResponseUnit")); }
            if (AnalysisUnit != null && AnalysisUnit.Count > 0)
            {
                foreach (var item in AnalysisUnit)
                {
                    xEl.Add(item.ToXml("AnalysisUnit"));
                }
            }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (EstimatedSecondsResponseTime != null)
            {
                xEl.Add(new XElement(ns + "EstimatedSecondsResponseTime", EstimatedSecondsResponseTime));
            }
            return xEl;
        }
    }
}

