using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a group of instruments for administrative or conceptual purposes, which may be hierarchical. In addition to the standard name, label, and description, contains references to the contained Instruments and InstrumentGroups.
    /// <summary>
    public partial class InstrumentGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a instrument group. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfInstrumentGroup { get; set; }
        /// <summary>
        /// A name for the InstrumentGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> InstrumentGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeInstrumentGroupName() { return InstrumentGroupName.Count > 0; }
        /// <summary>
        /// A display label for the InstrumentGroup. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the InstrumentGroup. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent instrument.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Instrument InstrumentReference { get; set; }
        /// <summary>
        /// Reference to constituent instrument group. This allows for nesting of instrument groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public InstrumentGroup InstrumentGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "InstrumentGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfInstrumentGroup != null) { xEl.Add(TypeOfInstrumentGroup.ToXml("TypeOfInstrumentGroup")); }
            if (InstrumentGroupName != null && InstrumentGroupName.Count > 0)
            {
                foreach (var item in InstrumentGroupName)
                {
                    xEl.Add(item.ToXml("InstrumentGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (InstrumentReference != null)
            {
                xEl.Add(new XElement(ns + "InstrumentReference", 
                    new XElement(ns + "URN", InstrumentReference.URN), 
                    new XElement(ns + "Agency", InstrumentReference.Agency), 
                    new XElement(ns + "ID", InstrumentReference.ID), 
                    new XElement(ns + "Version", InstrumentReference.Version), 
                    new XElement(ns + "TypeOfObject", InstrumentReference.GetType().Name)));
            }
            if (InstrumentGroupReference != null)
            {
                xEl.Add(new XElement(ns + "InstrumentGroupReference", 
                    new XElement(ns + "URN", InstrumentGroupReference.URN), 
                    new XElement(ns + "Agency", InstrumentGroupReference.Agency), 
                    new XElement(ns + "ID", InstrumentGroupReference.ID), 
                    new XElement(ns + "Version", InstrumentGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", InstrumentGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

