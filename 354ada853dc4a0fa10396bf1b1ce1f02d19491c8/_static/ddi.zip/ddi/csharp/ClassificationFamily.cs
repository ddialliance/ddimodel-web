using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Classification Family is a group of Classification Series related from a particular point of view. The Classification Family is related by being based on a common concept (e.g. economic activity).
    /// <summary>
    public partial class ClassificationFamily : Maintainable
    {
        /// <summary>
        /// A name for the Classification Family. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> Name { get; set; } = new List<NameType>();
        public bool ShouldSerializeName() { return Name.Count > 0; }
        /// <summary>
        /// A display label for the ClassificationFamily. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ClassificationFamily. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A Classification Family may refer to a number of Classification Series. TypeOfObject should be set to ClassificationSeries.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationSeries> ClassificationSeriesReference { get; set; } = new List<ClassificationSeries>();
        public bool ShouldSerializeClassificationSeriesReference() { return ClassificationSeriesReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationFamily");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Name != null && Name.Count > 0)
            {
                foreach (var item in Name)
                {
                    xEl.Add(item.ToXml("Name"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ClassificationSeriesReference != null && ClassificationSeriesReference.Count > 0)
            {
                foreach (var item in ClassificationSeriesReference)
                {
                    xEl.Add(new XElement(ns + "ClassificationSeriesReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

