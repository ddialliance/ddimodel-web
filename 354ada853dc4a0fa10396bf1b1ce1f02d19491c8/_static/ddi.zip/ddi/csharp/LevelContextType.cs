using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Level Context provides the depth of a Level within a Statistical Classification together with its membership. Both depth and membership can be specified per Statistical Classification.
    /// <summary>
    public partial class LevelContextType
    {
        /// <summary>
        /// The number associated with the Level Context. Levels are numbered consecutively starting with Level 1 at the highest (most aggregated) Level.
        /// <summary>
        public int LevelNumber { get; set; }
        /// <summary>
        /// The structure of a Statistical Classification is defined by its Levels (classification level). Include here links to the relevant Level. TypeOfObject should be ClassificationLevel.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationLevel ClassificationLevelReference { get; set; }
        /// <summary>
        /// A Statistical Classification is composed of categories structured in one or more Levels. Each category is represented by a Classification Item, which defines the content and the borders of the category. TypeOfObject should be set to ClassificationItem.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ClassificationItem> ClassificationItemReference { get; set; } = new List<ClassificationItem>();
        public bool ShouldSerializeClassificationItemReference() { return ClassificationItemReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "LevelNumber", LevelNumber));
            if (ClassificationLevelReference != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevelReference", 
                    new XElement(ns + "URN", ClassificationLevelReference.URN), 
                    new XElement(ns + "Agency", ClassificationLevelReference.Agency), 
                    new XElement(ns + "ID", ClassificationLevelReference.ID), 
                    new XElement(ns + "Version", ClassificationLevelReference.Version), 
                    new XElement(ns + "TypeOfObject", ClassificationLevelReference.GetType().Name)));
            }
            if (ClassificationItemReference != null && ClassificationItemReference.Count > 0)
            {
                foreach (var item in ClassificationItemReference)
                {
                    xEl.Add(new XElement(ns + "ClassificationItemReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

