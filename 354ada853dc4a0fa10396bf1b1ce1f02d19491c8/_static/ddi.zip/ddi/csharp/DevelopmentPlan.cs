using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a name, label and description for the Development Plan and lists the individual development activities which should take place.
    /// <summary>
    public partial class DevelopmentPlan : Versionable
    {
        /// <summary>
        /// A name for the DevelopmentPlan. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> DevelopmentPlanName { get; set; } = new List<NameType>();
        public bool ShouldSerializeDevelopmentPlanName() { return DevelopmentPlanName.Count > 0; }
        /// <summary>
        /// A display label for the Development Plan. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Development Plan. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describes the objectives of the development work. Supports the use of structured content in multiple languages.
        /// <summary>
        public StructuredStringType DevelopmentObjective { get; set; }
        /// <summary>
        /// A reference to an organization and/or individual to contact for further information on this questionnaire development activity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ContactReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeContactReference() { return ContactReference.Count > 0; }
        /// <summary>
        /// Budget and funding information related to the development work.
        /// <summary>
        public List<CostStructureType> CostStructure { get; set; } = new List<CostStructureType>();
        public bool ShouldSerializeCostStructure() { return CostStructure.Count > 0; }
        /// <summary>
        /// Reference to one or more Development Activities used by the Development Plan. DevelopmentActivity is a substitution base for a number of types of activities described with appropriate content. TypeOfObject should be ContentReviewActivity, TranslationActivity, or PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivity> DevelopmentActivityReference { get; set; } = new List<DevelopmentActivity>();
        public bool ShouldSerializeDevelopmentActivityReference() { return DevelopmentActivityReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentPlan");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentPlanName != null && DevelopmentPlanName.Count > 0)
            {
                foreach (var item in DevelopmentPlanName)
                {
                    xEl.Add(item.ToXml("DevelopmentPlanName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentObjective != null) { xEl.Add(DevelopmentObjective.ToXml("DevelopmentObjective")); }
            if (ContactReference != null && ContactReference.Count > 0)
            {
                foreach (var item in ContactReference)
                {
                    xEl.Add(new XElement(ns + "ContactReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CostStructure != null && CostStructure.Count > 0)
            {
                foreach (var item in CostStructure)
                {
                    xEl.Add(item.ToXml("CostStructure"));
                }
            }
            if (DevelopmentActivityReference != null && DevelopmentActivityReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

