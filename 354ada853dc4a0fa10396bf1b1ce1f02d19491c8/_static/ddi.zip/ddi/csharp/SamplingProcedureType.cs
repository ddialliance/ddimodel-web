using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a sampling procedure. If multiple sampling procedures were used repeat this element for each.
    /// <summary>
    public partial class SamplingProcedureType : IdentifiableType
    {
        /// <summary>
        /// A generic means of classifying a SamplingProcedure. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfSamplingProcedure { get; set; }
        /// <summary>
        /// Full description of the sampling procedure. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to sample plan which describes a process for achieving the sample. TypeOfObject should be SamplingPlan.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlan SamplingPlanReference { get; set; }
        /// <summary>
        /// Reference to sample created using sampling procedure. TypeOfObject should be Sample.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Sample SampleReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingProcedure != null) { xEl.Add(TypeOfSamplingProcedure.ToXml("TypeOfSamplingProcedure")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (SamplingPlanReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanReference", 
                    new XElement(ns + "URN", SamplingPlanReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanReference.ID), 
                    new XElement(ns + "Version", SamplingPlanReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanReference.GetType().Name)));
            }
            if (SampleReference != null)
            {
                xEl.Add(new XElement(ns + "SampleReference", 
                    new XElement(ns + "URN", SampleReference.URN), 
                    new XElement(ns + "Agency", SampleReference.Agency), 
                    new XElement(ns + "ID", SampleReference.ID), 
                    new XElement(ns + "Version", SampleReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

