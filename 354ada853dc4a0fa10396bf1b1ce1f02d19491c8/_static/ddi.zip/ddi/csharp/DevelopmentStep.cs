using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A member of the ControlConstruct substitution group. Describes a Development Step implementing a Development Activity directed at a specific development object. Defines prerequisites, condition for acceptance, and activity date and and agent performing the step. Use ExternalAid to identify external resources used by the DevelopmentStep
    /// <summary>
    public partial class DevelopmentStep : ControlConstruct
    {
        /// <summary>
        /// Describes the object of the development. May reference a specific object instrument, question, measurement, or control construct to.
        /// <summary>
        public List<DevelopmentObjectType> DevelopmentObject { get; set; } = new List<DevelopmentObjectType>();
        public bool ShouldSerializeDevelopmentObject() { return DevelopmentObject.Count > 0; }
        /// <summary>
        /// Reference to one or more Development Activities used by the Development Process Step. DevelopmentActivity is a substitution base for a number of types of activities described with appropriate content. TypeOfObject should be ContentReviewActivity, TranslationActivity, or PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivity> DevelopmentActivityReference { get; set; } = new List<DevelopmentActivity>();
        public bool ShouldSerializeDevelopmentActivityReference() { return DevelopmentActivityReference.Count > 0; }
        /// <summary>
        /// Reference to an Organization or Individual responsible for this step. TypeOfObject should be any sub-type of Agency.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ResponsibleAgencyReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeResponsibleAgencyReference() { return ResponsibleAgencyReference.Count > 0; }
        /// <summary>
        /// A description of the overall prerequisites for completing this Development Processing Step. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> Prerequisite { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializePrerequisite() { return Prerequisite.Count > 0; }
        /// <summary>
        /// The conditions under which the output of the Development Process Step is accepted.
        /// <summary>
        public List<StructuredStringType> ConditionForAcceptance { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeConditionForAcceptance() { return ConditionForAcceptance.Count > 0; }
        /// <summary>
        /// The date or date range of activity in this step.
        /// <summary>
        public DateType ActivityDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "DevelopmentStep");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (DevelopmentObject != null && DevelopmentObject.Count > 0)
            {
                foreach (var item in DevelopmentObject)
                {
                    xEl.Add(item.ToXml("DevelopmentObject"));
                }
            }
            if (DevelopmentActivityReference != null && DevelopmentActivityReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResponsibleAgencyReference != null && ResponsibleAgencyReference.Count > 0)
            {
                foreach (var item in ResponsibleAgencyReference)
                {
                    xEl.Add(new XElement(ns + "ResponsibleAgencyReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Prerequisite != null && Prerequisite.Count > 0)
            {
                foreach (var item in Prerequisite)
                {
                    xEl.Add(item.ToXml("Prerequisite"));
                }
            }
            if (ConditionForAcceptance != null && ConditionForAcceptance.Count > 0)
            {
                foreach (var item in ConditionForAcceptance)
                {
                    xEl.Add(item.ToXml("ConditionForAcceptance"));
                }
            }
            if (ActivityDate != null) { xEl.Add(ActivityDate.ToXml("ActivityDate")); }
            return xEl;
        }
    }
}

