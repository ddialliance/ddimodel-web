using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Storage format for random order item variables. Each ItemValue references it's defining variable, it's record identifier, and the it's value.
    /// <summary>
    public partial class ItemSetType
    {
        /// <summary>
        /// Each value in the data set linked to it's variable and record identification.
        /// <summary>
        public List<ItemValueType> ItemValue { get; set; } = new List<ItemValueType>();
        public bool ShouldSerializeItemValue() { return ItemValue.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ItemValue != null && ItemValue.Count > 0)
            {
                foreach (var item in ItemValue)
                {
                    xEl.Add(item.ToXml("ItemValue"));
                }
            }
            return xEl;
        }
    }
}

