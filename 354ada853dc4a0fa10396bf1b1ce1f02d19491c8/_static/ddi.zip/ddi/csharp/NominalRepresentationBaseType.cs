using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A means of capturing the features of a nominal (marked/unmarked) response domain. Note that this is not the same as a code or category list with a yes/no set of responses. This representation is generally used in QuestionGrids when defining the response domain of a grid cell. In addition to the basic objects of a representation, the structure defines the allowed content of the mark using a regular expression.
    /// <summary>
    public partial class NominalRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// The regular expression allows for further description of the allowable content of the data.
        /// <summary>
        public string RegExp { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            return xEl;
        }
    }
}

