using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An inline description of a sample frame (the source material from which a sample is drawn), i.e. phone book, data base, etc. A sample frame is intended to be versioned over time and can be reused by multiple studies.
    /// <summary>
    public partial class SampleFrame : Versionable
    {
        /// <summary>
        /// A name for a sample frame which may be repeated to express differing names for different systems. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SampleFrameName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSampleFrameName() { return SampleFrameName.Count > 0; }
        /// <summary>
        /// A full display label for the sample frame, repeatable for different context or applications. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Full description of the sample frame. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Period for which the current version is valid.
        /// <summary>
        public DateType ValidPeriod { get; set; }
        /// <summary>
        /// Organization or individual holding the rights to the frame
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent CustodianReference { get; set; }
        /// <summary>
        /// Provides full description of access, forms for access, contact, etc.
        /// <summary>
        public AccessType SampleFrameAccess { get; set; }
        /// <summary>
        /// A reference to the Universe of this sample frame
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// A sample frame may identify multiple units. One unit should be identified as the primary unit. Additional units are listed as secondary.
        /// <summary>
        public PopulationSizeType UnitsOfFrame { get; set; }
        /// <summary>
        /// Description of general limitations of the frame, including  over/under-coverage and update schedules and procedures.
        /// <summary>
        public StructuredStringType FrameLimitations { get; set; }
        /// <summary>
        /// Description of information within the frame that could support stratification, including listing of available fields.
        /// <summary>
        public StructuredStringType AuxiliaryInformation { get; set; }
        /// <summary>
        /// The date/period of reference for this frame
        /// <summary>
        public DateType ReferencePeriod { get; set; }
        /// <summary>
        /// Describes how this frame gets updated.
        /// <summary>
        public StructuredStringType UpdateProcedure { get; set; }
        /// <summary>
        /// A reference to a frame that this frame was derived from.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<SampleFrame> SourceFrameReference { get; set; } = new List<SampleFrame>();
        public bool ShouldSerializeSourceFrameReference() { return SourceFrameReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SampleFrame");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (SampleFrameName != null && SampleFrameName.Count > 0)
            {
                foreach (var item in SampleFrameName)
                {
                    xEl.Add(item.ToXml("SampleFrameName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ValidPeriod != null) { xEl.Add(ValidPeriod.ToXml("ValidPeriod")); }
            if (CustodianReference != null)
            {
                xEl.Add(new XElement(ns + "CustodianReference", 
                    new XElement(ns + "URN", CustodianReference.URN), 
                    new XElement(ns + "Agency", CustodianReference.Agency), 
                    new XElement(ns + "ID", CustodianReference.ID), 
                    new XElement(ns + "Version", CustodianReference.Version), 
                    new XElement(ns + "TypeOfObject", CustodianReference.GetType().Name)));
            }
            if (SampleFrameAccess != null) { xEl.Add(SampleFrameAccess.ToXml("SampleFrameAccess")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (UnitsOfFrame != null) { xEl.Add(UnitsOfFrame.ToXml("UnitsOfFrame")); }
            if (FrameLimitations != null) { xEl.Add(FrameLimitations.ToXml("FrameLimitations")); }
            if (AuxiliaryInformation != null) { xEl.Add(AuxiliaryInformation.ToXml("AuxiliaryInformation")); }
            if (ReferencePeriod != null) { xEl.Add(ReferencePeriod.ToXml("ReferencePeriod")); }
            if (UpdateProcedure != null) { xEl.Add(UpdateProcedure.ToXml("UpdateProcedure")); }
            if (SourceFrameReference != null && SourceFrameReference.Count > 0)
            {
                foreach (var item in SourceFrameReference)
                {
                    xEl.Add(new XElement(ns + "SourceFrameReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

