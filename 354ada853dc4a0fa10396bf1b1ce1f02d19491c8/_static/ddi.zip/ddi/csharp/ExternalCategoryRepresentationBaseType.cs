using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures a response domain based on categorization that is described in an external non-DDI structure. Includes a UsageDescription that should provide information on how the external source is to be used.
    /// <summary>
    public partial class ExternalCategoryRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// References an external, non DDI category. This is the element to use if the Code Scheme being used is not in DDI and cannot be used directly. It provides for both the reference and an explanation of how to use the information accurately within a DDI context.
        /// <summary>
        public Uri ExternalCategoryReference { get; set; }
        /// <summary>
        /// A description of the use of the external category file. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType UsageDescription { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (ExternalCategoryReference != null)
            {
                xEl.Add(new XElement(ns + "ExternalCategoryReference", ExternalCategoryReference));
            }
            if (UsageDescription != null) { xEl.Add(UsageDescription.ToXml("UsageDescription")); }
            return xEl;
        }
    }
}

