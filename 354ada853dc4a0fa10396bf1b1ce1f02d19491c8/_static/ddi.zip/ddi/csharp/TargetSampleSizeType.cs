using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The desired sample size for this particular sample plan express in relation to its strata number if relevant. Provides means of expressing the formula used for determining the sample size.
    /// <summary>
    public partial class TargetSampleSizeType
    {
        /// <summary>
        /// Indicate specific strata if the sample frame has been stratified prior to sampling within the specified stage.
        /// <summary>
        public int StrataNumber { get; set; }
        /// <summary>
        /// The number and type of sample units.
        /// <summary>
        public SizeType DesiredSampleSize { get; set; }
        /// <summary>
        /// Reference to the General or GenerationInstruction containing the formula or instruction used to determine sample size. The basic Reference structure is extended to allow for the use of Binding to link specific source parameters to the InParameter of the instruction at the point of use. If there is a conflict between a Binding in the instruction of a specific source to an InParameter and the Binding information provided in the ProcessingInstructionReference, the Binding information in the reference overrides that found in the instruction. TypeOfObject should be set to GeneralInstruction or GenerationInstruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstruction SampleSizeFormulaReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "StrataNumber", StrataNumber));
            if (DesiredSampleSize != null) { xEl.Add(DesiredSampleSize.ToXml("DesiredSampleSize")); }
            if (SampleSizeFormulaReference != null)
            {
                xEl.Add(new XElement(ns + "SampleSizeFormulaReference", 
                    new XElement(ns + "URN", SampleSizeFormulaReference.URN), 
                    new XElement(ns + "Agency", SampleSizeFormulaReference.Agency), 
                    new XElement(ns + "ID", SampleSizeFormulaReference.ID), 
                    new XElement(ns + "Version", SampleSizeFormulaReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleSizeFormulaReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

