using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A stack of LocationValueReferences to each of the locations bundled together for a specific purpose Includes a GeographicTime to allow for repetition for change over time.
    /// <summary>
    public partial class LocationValueBundleType
    {
        /// <summary>
        /// Reference to the LocationValue of an included area.
        /// <summary>
        public List<LocationValueType> LocationValueReference { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializeLocationValueReference() { return LocationValueReference.Count > 0; }
        /// <summary>
        /// The time period for which the LocationValues listed are a valid set.
        /// <summary>
        public DateType GeographicTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (LocationValueReference != null && LocationValueReference.Count > 0)
            {
                foreach (var item in LocationValueReference)
                {
                    xEl.Add(item.ToXml("LocationValueReference"));
                }
            }
            if (GeographicTime != null) { xEl.Add(GeographicTime.ToXml("GeographicTime")); }
            return xEl;
        }
    }
}

