using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A grouping of SampleFrames for administrative purposes. Contains a group of sample frames and/or sample frame groups, which may be hierarchical.
    /// <summary>
    public partial class SampleFrameGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a sample frame group. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfSampleFrameGroup { get; set; }
        /// <summary>
        /// A name for the sample frame group. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SampleFrameGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSampleFrameGroupName() { return SampleFrameGroupName.Count > 0; }
        /// <summary>
        /// A display label for the sample frame group. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Additional textual description of the sample frame group. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other elements that the sample frames refer to, and to which any analytic results refer.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept measured by the sample frames in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to constituent SampleFrame.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SampleFrame SampleFrameReference { get; set; }
        /// <summary>
        /// Reference to constituent sample frame group. This allows for nesting of sample frame groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SampleFrameGroup SampleFrameGroupReference { get; set; }
        /// <summary>
        /// Indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SampleFrameGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSampleFrameGroup != null) { xEl.Add(TypeOfSampleFrameGroup.ToXml("TypeOfSampleFrameGroup")); }
            if (SampleFrameGroupName != null && SampleFrameGroupName.Count > 0)
            {
                foreach (var item in SampleFrameGroupName)
                {
                    xEl.Add(item.ToXml("SampleFrameGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (SampleFrameReference != null)
            {
                xEl.Add(new XElement(ns + "SampleFrameReference", 
                    new XElement(ns + "URN", SampleFrameReference.URN), 
                    new XElement(ns + "Agency", SampleFrameReference.Agency), 
                    new XElement(ns + "ID", SampleFrameReference.ID), 
                    new XElement(ns + "Version", SampleFrameReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleFrameReference.GetType().Name)));
            }
            if (SampleFrameGroupReference != null)
            {
                xEl.Add(new XElement(ns + "SampleFrameGroupReference", 
                    new XElement(ns + "URN", SampleFrameGroupReference.URN), 
                    new XElement(ns + "Agency", SampleFrameGroupReference.Agency), 
                    new XElement(ns + "ID", SampleFrameGroupReference.ID), 
                    new XElement(ns + "Version", SampleFrameGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleFrameGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

