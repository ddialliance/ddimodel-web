using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Map is an expression of the relation between a Classification Item in a source Statistical Classification and a corresponding Classification Item in the target Statistical Classification. The Map should specify whether the relationship between the two Classification Items is partial or complete. Depending on the relationship type of the Correspondence Table, there may be several Maps for a single source or target Classification Item. 
    /// <summary>
    public partial class ClassificationMapType
    {
        /// <summary>
        /// The source item refers to the Classification Item in the source Statistical Classification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationItem SourceClassificationItem { get; set; }
        /// <summary>
        /// The target item refers to the Classification Item in the target Statistical Classification.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ClassificationItem TargetClassificationItem { get; set; }
        /// <summary>
        /// Specifies whether the relationship between the two Classification Items is partial or complete.
        /// <summary>
        public bool IsComplete { get; set; }
        /// <summary>
        /// Date from which the Map became valid. The date must be defined if the Map belongs to a floating Correspondence Table.
        /// <summary>
        public CogsDate ValidFrom { get; set; }
        /// <summary>
        /// Date at which the Map became invalid. The date must be defined if the Map belongs to a floating Correspondence Table and is no longer valid.
        /// <summary>
        public CogsDate ValidTo { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (SourceClassificationItem != null)
            {
                xEl.Add(new XElement(ns + "SourceClassificationItem", 
                    new XElement(ns + "URN", SourceClassificationItem.URN), 
                    new XElement(ns + "Agency", SourceClassificationItem.Agency), 
                    new XElement(ns + "ID", SourceClassificationItem.ID), 
                    new XElement(ns + "Version", SourceClassificationItem.Version), 
                    new XElement(ns + "TypeOfObject", SourceClassificationItem.GetType().Name)));
            }
            if (TargetClassificationItem != null)
            {
                xEl.Add(new XElement(ns + "TargetClassificationItem", 
                    new XElement(ns + "URN", TargetClassificationItem.URN), 
                    new XElement(ns + "Agency", TargetClassificationItem.Agency), 
                    new XElement(ns + "ID", TargetClassificationItem.ID), 
                    new XElement(ns + "Version", TargetClassificationItem.Version), 
                    new XElement(ns + "TypeOfObject", TargetClassificationItem.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsComplete", IsComplete));
            if (ValidFrom != null && ValidFrom.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidFrom", ValidFrom.ToString()));
            }
            if (ValidTo != null && ValidTo.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ValidTo", ValidTo.ToString()));
            }
            return xEl;
        }
    }
}

