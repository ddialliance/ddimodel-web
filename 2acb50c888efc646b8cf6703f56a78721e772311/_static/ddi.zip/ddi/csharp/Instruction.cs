using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the content and description of a single instruction. In addition to the standard name, label, and description, an InParameter can be designated to specify information needed to process the dynamic content of the instruction, an image can be associated with the instruction, and the instruction text provided using DynamicText. Note that when using Dynamic Text, the full InstructionText must be repeated for multi-language versions of the content. Different languages may handle the dynamic portions in different locations and/or with different content. Therefore languages cannot be mixed within a dynamic text except when the full text itself has multiple language sections, for example, a foreign language term in a text. The InstructionText may also be repeated to provide a dynamic and plain text version of the instruction. This allows for accurate rendering of the instruction in a non-dynamic environment like print.
    /// <summary>
    public partial class Instruction : Versionable
    {
        /// <summary>
        /// A name for the Instruction. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> InstructionName { get; set; } = new List<NameType>();
        public bool ShouldSerializeInstructionName() { return InstructionName.Count > 0; }
        /// <summary>
        /// A display label for the Instruction. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Instruction. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A parameter that may accept content from outside the Instruction. In addition to standard parameter content may provide the instructions for limiting the allowable array index.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// An image associated with the Instruction, located at the provided URN or URL.
        /// <summary>
        public List<ImageType> AssociatedImage { get; set; } = new List<ImageType>();
        public bool ShouldSerializeAssociatedImage() { return AssociatedImage.Count > 0; }
        /// <summary>
        /// The content of the Instruction text provided using DynamicText. Note that when using Dynamic Text, the full InstructionText must be repeated for multi-language versions of the content. The InstructionText may also be repeated to provide a dynamic and plain text version of the instruction. This allows for accurate rendering of the instruction in a non-dynamic environment like print.
        /// <summary>
        public List<DynamicTextType> InstructionText { get; set; } = new List<DynamicTextType>();
        public bool ShouldSerializeInstructionText() { return InstructionText.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Instruction");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (InstructionName != null && InstructionName.Count > 0)
            {
                foreach (var item in InstructionName)
                {
                    xEl.Add(item.ToXml("InstructionName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (AssociatedImage != null && AssociatedImage.Count > 0)
            {
                foreach (var item in AssociatedImage)
                {
                    xEl.Add(item.ToXml("AssociatedImage"));
                }
            }
            if (InstructionText != null && InstructionText.Count > 0)
            {
                foreach (var item in InstructionText)
                {
                    xEl.Add(item.ToXml("InstructionText"));
                }
            }
            return xEl;
        }
    }
}

