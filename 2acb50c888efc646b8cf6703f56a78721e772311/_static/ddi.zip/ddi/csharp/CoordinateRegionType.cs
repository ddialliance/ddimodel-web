using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the area of attachment for an NCube attribute. It may be defined as the NCube as a whole or as certain dimensions or values of dimensions.
    /// <summary>
    public partial class CoordinateRegionType : IdentifiableType
    {
        /// <summary>
        /// A display label for the CoordinateRegion. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Reference to the universe statement containing a description of the persons or other elements that this CoordinateRegion refers to, and to which any analytic results refer. If more than one universe is referenced the universe of the CoordinateRegion is the intersect of the referenced universes. Use when the CoordinateRegion describes a subset of the NCube universe.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// A description of the content of the CoordinateRegion. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Defines the included set of values needed to describe the coordinate region of the NCube on a Dimension by Dimension basis.
        /// <summary>
        public List<CohortType> DimensionValue { get; set; } = new List<CohortType>();
        public bool ShouldSerializeDimensionValue() { return DimensionValue.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DimensionValue != null && DimensionValue.Count > 0)
            {
                foreach (var item in DimensionValue)
                {
                    xEl.Add(item.ToXml("DimensionValue"));
                }
            }
            return xEl;
        }
    }
}

