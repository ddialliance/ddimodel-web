using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Classification Index is an ordered list (alphabetical, in code order etc) of Classification Index Entries. A Classification Index can relate to one particular or to several Statistical Classifications.
    /// A Classification Index shows the relationship between text found in statistical data sources (responses to survey questionnaires, administrative records) and one or more Statistical Classifications. A Classification Index may be used to assign the codes for Classification Items to observations in statistical collections. 
    /// <summary>
    public partial class ClassificationIndex : Describable
    {
        /// <summary>
        /// Date when the current version of the Classification Index was released.
        /// <summary>
        public CogsDate ReleaseDate { get; set; }
        /// <summary>
        /// The unit or group of persons within the organization  responsible for the Classification Index, i.e. for adding, changing or deleting Classification Index Entries.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> MaintenanceUnit { get; set; } = new List<Agent>();
        public bool ShouldSerializeMaintenanceUnit() { return MaintenanceUnit.Count > 0; }
        /// <summary>
        ///  Person(s) who may be contacted for additional information about the Classification Index.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ContactPerson { get; set; } = new List<Agent>();
        public bool ShouldSerializeContactPerson() { return ContactPerson.Count > 0; }
        /// <summary>
        /// A list of the publications in which the Classification Index has been published.
        /// <summary>
        public List<PublicationType> Publication { get; set; } = new List<PublicationType>();
        public bool ShouldSerializePublication() { return Publication.Count > 0; }
        /// <summary>
        /// A Classification Index can exist in several languages. Indicates the languages available. If a Classification Index exists in several languages, the number of entries in each language may be different, as the number of terms describing the same phenomenon can change from one language to another. However, the same phenomena should be described in each language.
        /// <summary>
        public List<string> Languages { get; set; } = new List<string>();
        public bool ShouldSerializeLanguages() { return Languages.Count > 0; }
        /// <summary>
        /// Summary description of corrections, which have occurred within the Classification Index. Corrections include changing the item code associated with a Classification Index Entry.
        /// <summary>
        public StructuredStringType Corrections { get; set; }
        /// <summary>
        /// Additional information which drives the coding process for all entries in a Classification Index.
        /// <summary>
        public StructuredStringType CodingInstructions { get; set; }
        /// <summary>
        /// An ordered list (alphabetical, in code order etc.) of Classification Index Entries.
        /// <summary>
        public List<ClassificationIndexEntryType> ClassificationIndexEntry { get; set; } = new List<ClassificationIndexEntryType>();
        public bool ShouldSerializeClassificationIndexEntry() { return ClassificationIndexEntry.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationIndex");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ReleaseDate != null && ReleaseDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "ReleaseDate", ReleaseDate.ToString()));
            }
            if (MaintenanceUnit != null && MaintenanceUnit.Count > 0)
            {
                foreach (var item in MaintenanceUnit)
                {
                    xEl.Add(new XElement(ns + "MaintenanceUnit", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ContactPerson != null && ContactPerson.Count > 0)
            {
                foreach (var item in ContactPerson)
                {
                    xEl.Add(new XElement(ns + "ContactPerson", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Publication != null && Publication.Count > 0)
            {
                foreach (var item in Publication)
                {
                    xEl.Add(item.ToXml("Publication"));
                }
            }
            if (Languages != null && Languages.Count > 0)
            {
                foreach (var item in Languages)
                {
                    xEl.Add(new XElement(ns + "Languages", item));
                }
            }
            if (Corrections != null) { xEl.Add(Corrections.ToXml("Corrections")); }
            if (CodingInstructions != null) { xEl.Add(CodingInstructions.ToXml("CodingInstructions")); }
            if (ClassificationIndexEntry != null && ClassificationIndexEntry.Count > 0)
            {
                foreach (var item in ClassificationIndexEntry)
                {
                    xEl.Add(item.ToXml("ClassificationIndexEntry"));
                }
            }
            return xEl;
        }
    }
}

