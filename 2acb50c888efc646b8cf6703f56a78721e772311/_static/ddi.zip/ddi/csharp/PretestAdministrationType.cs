using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of the method and mode of data collection in administering the pretest. Notes any additional data collected in the administration of the pretest.
    /// <summary>
    public partial class PretestAdministrationType
    {
        /// <summary>
        /// Describes the method of pretest administration using a controlled vocabulary and description.
        /// <summary>
        public MethodOfAdministrationType MethodOfAdministration { get; set; }
        /// <summary>
        /// Describes the mode of collection used in the pretest. Repeat of multiple modes of collection were used. Indicate the primary mode using isPrimary attribute if applicable.
        /// <summary>
        public List<ModeOfPretestCollectionType> ModeOfPretestCollection { get; set; } = new List<ModeOfPretestCollectionType>();
        public bool ShouldSerializeModeOfPretestCollection() { return ModeOfPretestCollection.Count > 0; }
        /// <summary>
        /// Description of the method and mode of data collection in administering the pretest. Notes any additional data collected in the administration of the pretest.
        /// <summary>
        public List<AdditionalDataCollectionType> AdditionalDataCollection { get; set; } = new List<AdditionalDataCollectionType>();
        public bool ShouldSerializeAdditionalDataCollection() { return AdditionalDataCollection.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MethodOfAdministration != null) { xEl.Add(MethodOfAdministration.ToXml("MethodOfAdministration")); }
            if (ModeOfPretestCollection != null && ModeOfPretestCollection.Count > 0)
            {
                foreach (var item in ModeOfPretestCollection)
                {
                    xEl.Add(item.ToXml("ModeOfPretestCollection"));
                }
            }
            if (AdditionalDataCollection != null && AdditionalDataCollection.Count > 0)
            {
                foreach (var item in AdditionalDataCollection)
                {
                    xEl.Add(item.ToXml("AdditionalDataCollection"));
                }
            }
            return xEl;
        }
    }
}

