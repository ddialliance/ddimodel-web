using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Adds the attribute identifying this as a maintainable object. All content of Maintainable is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. All content of Maintainable with the exception of 'Note' is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. See DDI 3.2 Technical Documentation: Part I for further details.
    /// <summary>
    public partial class Maintainable : Versionable
    {
        /// <summary>
        /// Allows for the specification of identifiers other than the specified DDI identification of the object. This may be a legacy ID from DDI-C, a system specific ID such as for a database or registry, or a non-DDI unique identifier. As the identifier is specific to a system the system must be identified with the UserID structure.
        /// <summary>
        public List<UserIDType> UserID { get; set; } = new List<UserIDType>();
        public bool ShouldSerializeUserID() { return UserID.Count > 0; }
        /// <summary>
        /// A system specific user defined property of the object expressed as a key/value pair. As this is specific to an individual system the use of controlled vocabularies for the key is strongly recommended.
        /// <summary>
        public List<StandardKeyValuePairType> UserAttributePair { get; set; } = new List<StandardKeyValuePairType>();
        public bool ShouldSerializeUserAttributePair() { return UserAttributePair.Count > 0; }
        /// <summary>
        /// Person or organization within the MaintenanceAgency responsible for the version change. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, it may be included in this notation. This is primarily intended for internal use.
        /// <summary>
        public string VersionResponsibility { get; set; }
        /// <summary>
        /// Reference person or organization within the MaintenanceAgency responsible for the version change, as described in an OrganizationScheme. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, a Relation should be created between the individual referenced here and his/her organization. This is primarily intended for internal use.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent VersionResponsibilityReference { get; set; }
        /// <summary>
        /// Textual description of the rationale/purpose for the version change and a coded value to provide an internal processing flag within and organization or system. Note that versioning can only take place on objects owned by the specified DDI Agency. If you are creating a local instance of an object from another agency for current or future modification use BasedOnObject. If the changes being made result in what you determine to be new object rather than a version of a previous object, i.e. the change is too extensive to consider it a version of the existing object, create a new object and use BasedOnObject to provide a link to the object or objects that were a basis for the new object.
        /// <summary>
        public VersionRationaleType VersionRationale { get; set; }
        /// <summary>
        /// Use when creating an object that is based on an existing object or objects that are managed by a different agency or when the new object is NOT simply a version change but you wish to maintain a reference to the object that served as a basis for the new object. BasedOnObject may contain references to any number of objects which serve as a basis for this object, a BasedOnRationalDescription of how the content of the referenced object was incorporated or altered, and a BasedOnRationalCode to allow for specific typing of the BasedOnReference according to an external controlled vocabulary.
        /// <summary>
        public BasedOnObjectType BasedOnObject { get; set; }
        /// <summary>
        /// The inclusion of an existing OtherMaterial by reference. Use for any type of OtherMaterial not specifically addressed by an inline description for such as ExternalAid in QuestionItem.
        /// <summary>
        public List<ReferenceType> RelatedOtherMaterialReference { get; set; } = new List<ReferenceType>();
        public bool ShouldSerializeRelatedOtherMaterialReference() { return RelatedOtherMaterialReference.Count > 0; }
        /// <summary>
        /// Date of version using the union set BaseDateType. Duration should not be used in this field, even though allowed by the ISO format enforced by the parser.
        /// <summary>
        public CogsDate VersionDate { get; set; }
        /// <summary>
        /// Indicates that the maintainable will not be changed without versioning, and is a stable target for referencing.
        /// <summary>
        public bool IsPublished { get; set; }
        /// <summary>
        /// Note allows for the attachment of a piece of additional information to any object with an ID. Note facilitates capturing temporary processing notes such as "Review and approval required". A single note can be attached to multiple objects by reference to the objects. Note may also contain content for a needed object that has been reported for addition in a later version of the schema. Ideally this should be handled by a local extension, but Note can accommodate run-time extensions when required. The Note should be housed within the Maintainable object that contains the referenced objects. In this way the user is ensured of receiving all known Note attachments when the maintainable content is delivered. This means that if a Note references objects within multiple Maintainable objects, the Note should be repeated in each Maintainable and reference only those objects with that Maintainable.
        /// <summary>
        public List<NoteType> Note { get; set; } = new List<NoteType>();
        public bool ShouldSerializeNote() { return Note.Count > 0; }
        /// <summary>
        /// Indicate the software used to create and/or manage the metadata. This is repeatable to allow for multiple softwares or multiple functions. If this information is important it is advisable to provide it in each maintainable so that it does not become separated from the internal content if the metadata is re-factored.
        /// <summary>
        public List<SoftwareType> Software { get; set; } = new List<SoftwareType>();
        public bool ShouldSerializeSoftware() { return Software.Count > 0; }
        /// <summary>
        /// An assessment of the quality of the metadata within the Maintainable object, e.g. the quality of the transcription, completeness, editing status, etc.
        /// <summary>
        public List<MetadataQualityType> MetadataQuality { get; set; } = new List<MetadataQualityType>();
        public bool ShouldSerializeMetadataQuality() { return MetadataQuality.Count > 0; }
        /// <summary>
        /// Use to provide a default value for the URI of external references. Use of a URI in a reference within this maintainable overrides the value entered here. Nested maintainables should redeclare the contents of this attribute for clarity.
        /// <summary>
        public Uri ExternalReferenceDefaultURI { get; set; }
        /// <summary>
        /// This is used to designate the language of the metadata content of the maintainable. If a lower level xml:lang attribute conflicts with the content at the maintainable level, the object level value takes precedence.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Maintainable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (UserID != null && UserID.Count > 0)
            {
                foreach (var item in UserID)
                {
                    xEl.Add(item.ToXml("UserID"));
                }
            }
            if (UserAttributePair != null && UserAttributePair.Count > 0)
            {
                foreach (var item in UserAttributePair)
                {
                    xEl.Add(item.ToXml("UserAttributePair"));
                }
            }
            if (VersionResponsibility != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibility", VersionResponsibility));
            }
            if (VersionResponsibilityReference != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibilityReference", 
                    new XElement(ns + "URN", VersionResponsibilityReference.URN), 
                    new XElement(ns + "Agency", VersionResponsibilityReference.Agency), 
                    new XElement(ns + "ID", VersionResponsibilityReference.ID), 
                    new XElement(ns + "Version", VersionResponsibilityReference.Version), 
                    new XElement(ns + "TypeOfObject", VersionResponsibilityReference.GetType().Name)));
            }
            if (VersionRationale != null) { xEl.Add(VersionRationale.ToXml("VersionRationale")); }
            if (BasedOnObject != null) { xEl.Add(BasedOnObject.ToXml("BasedOnObject")); }
            if (RelatedOtherMaterialReference != null && RelatedOtherMaterialReference.Count > 0)
            {
                foreach (var item in RelatedOtherMaterialReference)
                {
                    xEl.Add(item.ToXml("RelatedOtherMaterialReference"));
                }
            }
            if (VersionDate != null && VersionDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "VersionDate", VersionDate.ToString()));
            }
            xEl.Add(new XElement(ns + "IsPublished", IsPublished));
            if (Note != null && Note.Count > 0)
            {
                foreach (var item in Note)
                {
                    xEl.Add(item.ToXml("Note"));
                }
            }
            if (Software != null && Software.Count > 0)
            {
                foreach (var item in Software)
                {
                    xEl.Add(item.ToXml("Software"));
                }
            }
            if (MetadataQuality != null && MetadataQuality.Count > 0)
            {
                foreach (var item in MetadataQuality)
                {
                    xEl.Add(item.ToXml("MetadataQuality"));
                }
            }
            if (ExternalReferenceDefaultURI != null)
            {
                xEl.Add(new XElement(ns + "ExternalReferenceDefaultURI", ExternalReferenceDefaultURI));
            }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

