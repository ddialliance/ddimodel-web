using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a name, label and description for the Development Process and lists the individual development activities which should take place.
    /// <summary>
    public partial class DevelopmentProcessStepType : IdentifiableType
    {
        /// <summary>
        /// Reference to the DevelopmentProcessStep that appears before this step. TypeOfObject should be DevelopmentProcessStep.
        /// <summary>
        public List<DevelopmentProcessStepType> PredecessorStepReference { get; set; } = new List<DevelopmentProcessStepType>();
        public bool ShouldSerializePredecessorStepReference() { return PredecessorStepReference.Count > 0; }
        /// <summary>
        /// Reference to the DevelopmentProcessStep that appears after this step. TypeOfObject should be DevelopmentProcessStep.
        /// <summary>
        public List<DevelopmentProcessStepType> SuccessorStepReference { get; set; } = new List<DevelopmentProcessStepType>();
        public bool ShouldSerializeSuccessorStepReference() { return SuccessorStepReference.Count > 0; }
        /// <summary>
        /// Reference to the development object that is the target of this development step. If it is an external object create a description as OtherMaterial and reference the OtherMaterial. Use the attribute "objectLanguage" to specify any language preference. Repeat for multiple development objects. TypeOfObject should relate to the object referenced.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Versionable> DevelopmentObjectReference_Versionable { get; set; } = new List<Versionable>();
        public bool ShouldSerializeDevelopmentObjectReference_Versionable() { return DevelopmentObjectReference_Versionable.Count > 0; }
        /// <summary>
        /// Reference to the development object that is the target of this development step. If it is an external object create a description as OtherMaterial and reference the OtherMaterial. Use the attribute "objectLanguage" to specify any language preference. Repeat for multiple development objects. TypeOfObject should relate to the object referenced.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Maintainable> DevelopmentObjectReference_Maintainable { get; set; } = new List<Maintainable>();
        public bool ShouldSerializeDevelopmentObjectReference_Maintainable() { return DevelopmentObjectReference_Maintainable.Count > 0; }
        /// <summary>
        /// Existing resources used in the process step.
        /// <summary>
        public List<ResourceUsedType> ResourceUsed { get; set; } = new List<ResourceUsedType>();
        public bool ShouldSerializeResourceUsed() { return ResourceUsed.Count > 0; }
        /// <summary>
        /// A description of the overall Development Process. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to one or more Development Activities used by the Development Process Step. DevelopmentActivity is a substitution base for a number of types of activities described with appropriate content. TypeOfObject should be ContentReviewActivity, TranslationActivity, or PretestActivity.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DevelopmentActivity> DevelopmentActivityReference { get; set; } = new List<DevelopmentActivity>();
        public bool ShouldSerializeDevelopmentActivityReference() { return DevelopmentActivityReference.Count > 0; }
        /// <summary>
        /// Reference to an Organization or Individual responsible for this step. TypeOfObject should be Organization or Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Agent> ResponsibleAgencyReference { get; set; } = new List<Agent>();
        public bool ShouldSerializeResponsibleAgencyReference() { return ResponsibleAgencyReference.Count > 0; }
        /// <summary>
        /// A description of the overall prerequisites for completing this Development Processing Step. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<StructuredStringType> Prerequisite { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializePrerequisite() { return Prerequisite.Count > 0; }
        /// <summary>
        /// The conditions under which the output of the Development Process Step is accepted.
        /// <summary>
        public List<StructuredStringType> ConditionForAcceptance { get; set; } = new List<StructuredStringType>();
        public bool ShouldSerializeConditionForAcceptance() { return ConditionForAcceptance.Count > 0; }
        /// <summary>
        /// The date or date range of activity in this step.
        /// <summary>
        public DateType ActivityDate { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (PredecessorStepReference != null && PredecessorStepReference.Count > 0)
            {
                foreach (var item in PredecessorStepReference)
                {
                    xEl.Add(item.ToXml("PredecessorStepReference"));
                }
            }
            if (SuccessorStepReference != null && SuccessorStepReference.Count > 0)
            {
                foreach (var item in SuccessorStepReference)
                {
                    xEl.Add(item.ToXml("SuccessorStepReference"));
                }
            }
            if (DevelopmentObjectReference_Versionable != null && DevelopmentObjectReference_Versionable.Count > 0)
            {
                foreach (var item in DevelopmentObjectReference_Versionable)
                {
                    xEl.Add(new XElement(ns + "DevelopmentObjectReference_Versionable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DevelopmentObjectReference_Maintainable != null && DevelopmentObjectReference_Maintainable.Count > 0)
            {
                foreach (var item in DevelopmentObjectReference_Maintainable)
                {
                    xEl.Add(new XElement(ns + "DevelopmentObjectReference_Maintainable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResourceUsed != null && ResourceUsed.Count > 0)
            {
                foreach (var item in ResourceUsed)
                {
                    xEl.Add(item.ToXml("ResourceUsed"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (DevelopmentActivityReference != null && DevelopmentActivityReference.Count > 0)
            {
                foreach (var item in DevelopmentActivityReference)
                {
                    xEl.Add(new XElement(ns + "DevelopmentActivityReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ResponsibleAgencyReference != null && ResponsibleAgencyReference.Count > 0)
            {
                foreach (var item in ResponsibleAgencyReference)
                {
                    xEl.Add(new XElement(ns + "ResponsibleAgencyReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Prerequisite != null && Prerequisite.Count > 0)
            {
                foreach (var item in Prerequisite)
                {
                    xEl.Add(item.ToXml("Prerequisite"));
                }
            }
            if (ConditionForAcceptance != null && ConditionForAcceptance.Count > 0)
            {
                foreach (var item in ConditionForAcceptance)
                {
                    xEl.Add(item.ToXml("ConditionForAcceptance"));
                }
            }
            if (ActivityDate != null) { xEl.Add(ActivityDate.ToXml("ActivityDate")); }
            return xEl;
        }
    }
}

