using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows a listing of events in the life cycle of a data set or collection. Identification, date, agency, and descriptive information are provided for each event. Note that the agency that documents a lifecycle event is not necessarily the same agency as the one that performed the operation being documented as a lifecycle event.
    /// <summary>
    public class LifecycleInformationType
    {
        /// <summary>
        /// Documents an event in the life cycle of a study or group of studies. A life cycle event can be any event which is judged to be significant enough to document by the agency maintaining the documentation for a particular set of data.
        /// <summary>
        public List<LifecycleEventType> LifecycleEvent { get; set; } = new List<LifecycleEventType>();
        public bool ShouldSerializeLifecycleEvent() { return LifecycleEvent.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (LifecycleEvent != null && LifecycleEvent.Count > 0)
            {
                foreach (var item in LifecycleEvent)
                {
                    xEl.Add(item.ToXml("LifecycleEvent"));
                }
            }
            return xEl;
        }
    }
}

