using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a representation based on categorization. The CategorySchemeReference allows for the exclusion of selected items from the use of the CategoryScheme as a representation.
    /// <summary>
    public class CategoryRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// A reference to a CategoryScheme containing the required categories using the SchemeReference structure. Use Exclude in the SchemeReference to designate any categories NOT to include in this representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

