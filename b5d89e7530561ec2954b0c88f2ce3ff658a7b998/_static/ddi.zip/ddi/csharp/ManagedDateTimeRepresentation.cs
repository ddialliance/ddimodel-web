using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing DateTime so that they can be reused by multiple variables or questions/question constructs. Regardless of the format of the data the content may be treated as a date and or time and converted to ISO standard structure if sufficient information is supplied. In addition to the name, label, and description of the representation, the structure provides the DateField Format, a DateTypeCode and a regular expression for further defining allowed content.
    /// <summary>
    public class ManagedDateTimeRepresentation : Versionable
    {
        /// <summary>
        /// A name for the representation. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedDateTimeRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedDateTimeRepresentationName() { return ManagedDateTimeRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the representation. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the representation. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Describes the format of the date field, in formats such as YYYY/MM or MM-DD-YY, etc. If this element is omitted, then the format is assumed to be the XML Schema format corresponding to the type attribute value.
        /// <summary>
        public CodeValueType DateFieldFormat { get; set; }
        /// <summary>
        /// This is a standard XML date type code and supports the use of an external controlled vocabulary. Examples are date, dateTime, gYearMonth, gYear, and duration
        /// <summary>
        public CodeValueType DateTypeCode { get; set; }
        /// <summary>
        /// The regular expression allows for further description of the allowable content of the data.
        /// <summary>
        public string RegExp { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ManagedDateTimeRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedDateTimeRepresentationName != null && ManagedDateTimeRepresentationName.Count > 0)
            {
                foreach (var item in ManagedDateTimeRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedDateTimeRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (DateFieldFormat != null) { xEl.Add(DateFieldFormat.ToXml("DateFieldFormat")); }
            if (DateTypeCode != null) { xEl.Add(DateTypeCode.ToXml("DateTypeCode")); }
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

