using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the weighting used in the process. In addition to a description of the weighting process it may be designated as a specific type of weighting. If the data uses a standard weight (each record has an equal weight) it may be expressed here with StandardWeight.
    /// <summary>
    public class Weighting : Versionable
    {
        /// <summary>
        /// Allows brief identification of Time Method used with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfWeighting { get; set; }
        /// <summary>
        /// Full description of the data collection methodology. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A standard weighting factor used by all or a group of variables within the data set.
        /// <summary>
        public List<StandardWeightType> StandardWeight { get; set; } = new List<StandardWeightType>();
        public bool ShouldSerializeStandardWeight() { return StandardWeight.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Weighting");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfWeighting != null) { xEl.Add(TypeOfWeighting.ToXml("TypeOfWeighting")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (StandardWeight != null && StandardWeight.Count > 0)
            {
                foreach (var item in StandardWeight)
                {
                    xEl.Add(item.ToXml("StandardWeight"));
                }
            }
            return xEl;
        }
    }
}

