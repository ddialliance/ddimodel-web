using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A citation or URI for the source of the data. Note that this is an external reference, and should not be used to point to DDI descriptions of the data, or to DDI-encoded data.
    /// <summary>
    public class OriginType
    {
        /// <summary>
        /// Citation for the data source.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// A URN or URL for the data source.
        /// <summary>
        public Uri OriginLocation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (OriginLocation != null)
            {
                xEl.Add(new XElement(ns + "OriginLocation", OriginLocation));
            }
            return xEl;
        }
    }
}

