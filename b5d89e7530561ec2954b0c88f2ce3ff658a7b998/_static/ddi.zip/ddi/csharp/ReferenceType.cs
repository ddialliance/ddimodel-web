using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Used for referencing an identified entity expressed in DDI XML, either by a URN and/or an identification sequence. If both are supplied, the URN takes precedence. At a minimum, one or the other is required. If the identification sequence is used the content of MaintainableObject may be required to be able to assemble the canonical or deprecated DDI URN. To fully support interoperability both the DDI URN and the full identification sequence should be used. Note that to support interoperability of the canonical and deprecated URN, at minimum the MaintainableIdentifier and TypeOfMaintainableObject should be supplied if the canonical URN is being used for the reference. The lateBound attribute has a boolean value, which - if set to true - indicates that the latest version should be used. Use the attribute lateBoundRestriction to indicate when a portion, such as the major version number, should be restricted to a specific value and then late bound within that restriction. Element descriptions will contain a list of applicable TypeOfObject values.
    /// <summary>
    public class ReferenceType
    {
        /// <summary>
        /// The URN of the entity being referenced. The URN should follow the pattern associated with the value of the attribute typeOfIdentifier (Canonical or Deprecated).
        /// <summary>
        public URNType URN { get; set; }
        /// <summary>
        /// This is the registered agency code with optional sub-agencies separated by dots.
        /// <summary>
        [StringLength(253, MinimumLength = 1)]
        [StringValidation(null, "[a-zA-Z0-9\-]{1,63}(\.[a-zA-Z0-9\-]{1,63})*")]
        public string Agency { get; set; }
        /// <summary>
        /// ID of the object being referenced.This must conform to the allowed structure of the DDI Identifier and must be unique within the declared scope of uniqueness (Agency or Maintainable).
        /// <summary>
        public IDType ID { get; set; }
        /// <summary>
        /// The version of the object at the time of reference. Late binding is handled separately and does not effect the content of this object.
        /// <summary>
        [StringValidation(null, "[0-9]+(\.[0-9]+)*")]
        public string Version { get; set; }
        /// <summary>
        /// States the type of object being referenced based on a persistent list of valid DDI object types.
        /// <summary>
        [StringValidation(new string[] {
            "Access"
,             "ActionToMinimizeLosses"
,             "AggregationVariables"
,             "Attribute"
,             "AuthorizedSource"
,             "BudgetDocument"
,             "Code"
,             "CollectionEvent"
,             "CollectionSituation"
,             "CoordinateRegion"
,             "DataCollectionMethodology"
,             "DefaultAccess"
,             "DeviationFromSampleDesign"
,             "Embargo"
,             "ExternalAid"
,             "ExternalInformation"
,             "ExternalInterviewerInstruction"
,             "GeographicLevel"
,             "GrossFileStructure"
,             "GrossRecordStructure"
,             "InParameter"
,             "ItemMap"
,             "LifecycleEvent"
,             "LocationValue"
,             "LogicalRecord"
,             "MeasureDefinition"
,             "ModeOfCollection"
,             "OtherMaterial"
,             "OutParameter"
,             "PhysicalRecordSegment"
,             "RecordRelationship"
,             "SamplingProcedure"
,             "SpatialCoverage"
,             "StandardUsed"
,             "StandardWeight"
,             "StimulusMaterial"
,             "TemporalCoverage"
,             "TimeMethod"
,             "TopicalCoverage"
,             "Category"
,             "CategoryGroup"
,             "CategoryMap"
,             "CodeListGroup"
,             "ComputationItem"
,             "Concept"
,             "ConceptGroup"
,             "ConceptMap"
,             "ConceptualVariable"
,             "ConceptualVariableGroup"
,             "ControlConstructGroup"
,             "DataRelationship"
,             "DataSet"
,             "GeneralInstruction"
,             "GenerationInstruction"
,             "GeographicLocation"
,             "GeographicLocationGroup"
,             "GeographicStructure"
,             "GeographicStructureGroup"
,             "IfThenElse"
,             "Individual"
,             "Instruction"
,             "InstructionGroup"
,             "Instrument"
,             "InstrumentGroup"
,             "Loop"
,             "ManagedDateTimeRepresentation"
,             "ManagedMissingValuesRepresentation"
,             "ManagedNumericRepresentation"
,             "ManagedRepresentationGroup"
,             "ManagedScaleRepresentation"
,             "ManagedTextRepresentation"
,             "Methodology"
,             "NCube"
,             "NCubeGroup"
,             "NCubeInstance"
,             "Organization"
,             "OrganizationGroup"
,             "PhysicalStructure"
,             "PhysicalStructureGroup"
,             "ProcessingEvent"
,             "ProcessingEventGroup"
,             "ProcessingInstructionGroup"
,             "QualityStatement"
,             "QualityStatementGroup"
,             "QuestionBlock"
,             "QuestionConstruct"
,             "QuestionGrid"
,             "QuestionGroup"
,             "QuestionItem"
,             "QuestionMap"
,             "RecordLayout"
,             "RecordLayoutGroup"
,             "Relation"
,             "RepeatUntil"
,             "RepeatWhile"
,             "RepresentationMap"
,             "RepresentedVariable"
,             "RepresentedVariableGroup"
,             "Sequence"
,             "StatementItem"
,             "SubGroup"
,             "SubUniverseClass"
,             "Universe"
,             "UniverseGroup"
,             "UniverseMap"
,             "Variable"
,             "VariableGroup"
,             "VariableMap"
,             "VariableStatistics"
,             "Weighting"
,             "Archive"
,             "CategoryScheme"
,             "CodeList"
,             "CodeListScheme"
,             "Comparison"
,             "ConceptScheme"
,             "ConceptualComponent"
,             "ConceptualVariableScheme"
,             "ControlConstructScheme"
,             "DataCollection"
,             "DDIInstance"
,             "DDIProfile"
,             "GeographicLocationScheme"
,             "GeographicStructureScheme"
,             "Group"
,             "InstrumentScheme"
,             "InterviewerInstructionScheme"
,             "LocalGroupContent"
,             "LocalHoldingPackage"
,             "LocalResourcePackageContent"
,             "LocalStudyUnitContent"
,             "LogicalProduct"
,             "ManagedRepresentationScheme"
,             "NCubeScheme"
,             "OrganizationScheme"
,             "PhysicalDataProduct"
,             "PhysicalInstance"
,             "PhysicalStructureScheme"
,             "ProcessingEventScheme"
,             "ProcessingInstructionScheme"
,             "QualityStatementScheme"
,             "QuestionScheme"
,             "RecordLayoutScheme"
,             "RepresentedVariableScheme"
,             "ResourcePackage"
,             "StudyUnit"
,             "UniverseScheme"
,             "VariableScheme"
        })]
        public string TypeOfObject { get; set; }
        /// <summary>
        /// Do not use if the referenced object is Maintainable. For references to Identifiable and Versionable objects this provides contextual information on the Maintainable Parent of this object at point of origin. Note that if the ID, Agency, Version sequence is used, and the scope of uniqueness of the referenced object is the Maintainable, then the ID of the Maintainable is needed to create the structured ID portion of the canonical URN. If the system uses the deprecated URN, both the Maintainable ID and TypeOfMaintainableObject are required to create the deprecated URN structure.
        /// <summary>
        public MaintainableObjectType MaintainableObject { get; set; }
        /// <summary>
        /// Indicates that the reference is made to an external source. If the value is true, then a URI must be provided.
        /// <summary>
        public bool IsExternal { get; set; }
        /// <summary>
        /// URI identifying the location of an external reference as provided in the maintainable object of the referenced item. For example the content of the externalReferenceDefaultURI of the parent VariableScheme for a referenced Variable. If there is a conflict where the content of the URI does not match the requested object, the DDI URN becomes the preferred value.
        /// <summary>
        public Uri ExternalReferenceDefaultURI { get; set; }
        /// <summary>
        /// A fixed attribute value identifying which elements are references.
        /// <summary>
        public bool IsReference { get; set; }
        /// <summary>
        /// The default value is set to false indicating that the reference is to a specific version of the object. If the most recent version or most recent minor version within a major version is required, set this flag to "true". Indicating lateBound and not providing information for lateBoundRestriction indicates the request is for the latest version available without restriction.
        /// <summary>
        public bool LateBound { get; set; }
        /// <summary>
        /// Use when lateBound is changed to "true". The specifies the point to begin late binding the version number. For example if an object had a two part version number such as X.Y where X is a major version and Y a minor version and the request is for the latest minor version of major version number 4, the content of this field would be 4. Indicating lateBound and not providing information for this field indicates the request is for the latest version available without restriction.
        /// <summary>
        [StringValidation(null, "[0-9]+(\.[0-9]+)*")]
        public string LateBoundRestriction { get; set; }
        /// <summary>
        /// Specifies the language (or language-locale pair) to use for display in references to objects which have multiple languages available.
        /// <summary>
        public List<string> ObjectLanguage { get; set; } = new List<string>();
        public bool ShouldSerializeObjectLanguage() { return ObjectLanguage.Count > 0; }
        /// <summary>
        /// Provide a DDI URN for the version of the parent maintainable that shows the full context for the referenced object. This is used only when the context of the object within the current version of a maintainable is important to the user and this version is later than the one containing the object itself. For example a occupation classification may be unchanged since version 1.0 of its maintainable but at the point of reference the current version of the maintainable containing the original structure is at version 2.0 etc..
        /// <summary>
        public Uri SourceContext { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (URN != null) { xEl.Add(URN.ToXml("URN")); }
            if (Agency != null)
            {
                xEl.Add(new XElement(ns + "Agency", Agency));
            }
            if (ID != null) { xEl.Add(ID.ToXml("ID")); }
            if (Version != null)
            {
                xEl.Add(new XElement(ns + "Version", Version));
            }
            if (TypeOfObject != null)
            {
                xEl.Add(new XElement(ns + "TypeOfObject", TypeOfObject));
            }
            if (MaintainableObject != null) { xEl.Add(MaintainableObject.ToXml("MaintainableObject")); }
            xEl.Add(new XElement(ns + "IsExternal", IsExternal));
            if (ExternalReferenceDefaultURI != null)
            {
                xEl.Add(new XElement(ns + "ExternalReferenceDefaultURI", ExternalReferenceDefaultURI));
            }
            xEl.Add(new XElement(ns + "IsReference", IsReference));
            xEl.Add(new XElement(ns + "LateBound", LateBound));
            if (LateBoundRestriction != null)
            {
                xEl.Add(new XElement(ns + "LateBoundRestriction", LateBoundRestriction));
            }
            if (ObjectLanguage != null && ObjectLanguage.Count > 0)
            {
                foreach (var item in ObjectLanguage)
                {
                    xEl.Add(new XElement(ns + "ObjectLanguage", item));
                }
            }
            if (SourceContext != null)
            {
                xEl.Add(new XElement(ns + "SourceContext", SourceContext));
            }
            return xEl;
        }
    }
}

