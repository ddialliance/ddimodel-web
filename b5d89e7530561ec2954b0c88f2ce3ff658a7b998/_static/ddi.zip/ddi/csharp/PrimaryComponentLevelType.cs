using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides references to the base level elements that are used as building blocks for composed geographies. For example, Metropolitan areas that are composed of counties except in the New England States where they are composed of county subdivisions, or School Attendance Boundaries (SABINS) built from Census Blocks. This structure allows for specifying the basic building block for composed areas and any restrictions (coverage limitations).
    /// <summary>
    public class PrimaryComponentLevelType
    {
        /// <summary>
        /// Reference to the Geographic Level used as the basic building block to a composite area. Use the largest level that is consistently used in full (i.e. Use a State rather than the sub-level County if a State is always a member of the composed unit in its entirety.
        /// <summary>
        public GeographicLevelType GeographicLevelReference { get; set; }
        /// <summary>
        /// Describes a limitation of the coverage such as all Metropolitan Areas EXCEPT those in New England States.
        /// <summary>
        public InternationalStringType CoverageLimitation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (GeographicLevelReference != null) { xEl.Add(GeographicLevelReference.ToXml("GeographicLevelReference")); }
            if (CoverageLimitation != null) { xEl.Add(CoverageLimitation.ToXml("CoverageLimitation")); }
            return xEl;
        }
    }
}

