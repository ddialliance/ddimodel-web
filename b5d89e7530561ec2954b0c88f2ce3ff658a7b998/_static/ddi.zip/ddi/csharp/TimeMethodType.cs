using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the time method or time dimension of the data collection. This may cover specific timing issues such as when a data collection instrument is fielded (time of year, month, week, day), intended repetition, length of data collection period etc. In addition to the descriptive narrative supports the use of a brief term or external controlled vocabulary to classify the methodology used.
    /// <summary>
    public class TimeMethodType : IdentifiableType
    {
        /// <summary>
        /// Allows brief identification of time method used with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfTimeMethod { get; set; }
        /// <summary>
        /// Full description of the data time method used. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfTimeMethod != null) { xEl.Add(TypeOfTimeMethod.ToXml("TypeOfTimeMethod")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

