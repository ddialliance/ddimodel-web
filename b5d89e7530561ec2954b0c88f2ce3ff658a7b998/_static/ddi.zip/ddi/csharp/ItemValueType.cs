using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Each value in the data set linked to it's variable and record identification.
    /// <summary>
    public class ItemValueType
    {
        /// <summary>
        /// Reference to the variable describing the item.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }
        /// <summary>
        /// The value of the record identifier or key. This is the value found in the item linked to the variable identified by the DataSet in the IdentifyingVariableReference.
        /// <summary>
        public string RecordReference { get; set; }
        /// <summary>
        /// The value of the item for the specified variable and record.
        /// <summary>
        public List<ValueType> Value { get; set; } = new List<ValueType>();
        public bool ShouldSerializeValue() { return Value.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            if (RecordReference != null)
            {
                xEl.Add(new XElement(ns + "RecordReference", RecordReference));
            }
            if (Value != null && Value.Count > 0)
            {
                foreach (var item in Value)
                {
                    xEl.Add(item.ToXml("Value"));
                }
            }
            return xEl;
        }
    }
}

