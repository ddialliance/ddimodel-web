using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Details of an individual including name, contact information, a definition, keywords to support searching, their regional affiliation, language ability and any additional information. The individual and specific pieces of information regarding the individual may be tagged for information privacy.
    /// <summary>
    public class Individual : Versionable
    {
        /// <summary>
        /// Identifying information about the individual.
        /// <summary>
        public IndividualIdentificationType IndividualIdentification { get; set; }
        /// <summary>
        /// A description of the individual. Supports multiple languages and optional structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Keywords used to classify an individual or their activities. May be used to support searching.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// The regional coverage of the individual. The geographic regions within which the individual is active.
        /// <summary>
        public List<CodeValueType> RegionalCoverage { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeRegionalCoverage() { return RegionalCoverage.Count > 0; }
        /// <summary>
        /// Any additional information you which to note about the individual. Supports multiple languages and optional structured content. A privacy tag may be used.
        /// <summary>
        public List<AdditionalInformationType> AdditionalInformation { get; set; } = new List<AdditionalInformationType>();
        public bool ShouldSerializeAdditionalInformation() { return AdditionalInformation.Count > 0; }
        /// <summary>
        /// Use to specify the languages known by the individual in terms of their ability to  speak, read, and write the language. May be repeated to cover multiple languages.
        /// <summary>
        public List<IndividualLanguageType> LanguageAbility { get; set; } = new List<IndividualLanguageType>();
        public bool ShouldSerializeLanguageAbility() { return LanguageAbility.Count > 0; }
        /// <summary>
        /// Contact information for the individual including location specification, address, URL, phone numbers, and other means of communication access. Address, location, telephone, and other means of communication can be repeated to express multiple means of a single type or change over time. Each major piece of contact information (with exception of URL contains the element EffectiveDates in order to date stamp the period for which the information is valid.
        /// <summary>
        public List<ContactInformationType> ContactInformation { get; set; } = new List<ContactInformationType>();
        public bool ShouldSerializeContactInformation() { return ContactInformation.Count > 0; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Individual");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (IndividualIdentification != null) { xEl.Add(IndividualIdentification.ToXml("IndividualIdentification")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (RegionalCoverage != null && RegionalCoverage.Count > 0)
            {
                foreach (var item in RegionalCoverage)
                {
                    xEl.Add(item.ToXml("RegionalCoverage"));
                }
            }
            if (AdditionalInformation != null && AdditionalInformation.Count > 0)
            {
                foreach (var item in AdditionalInformation)
                {
                    xEl.Add(item.ToXml("AdditionalInformation"));
                }
            }
            if (LanguageAbility != null && LanguageAbility.Count > 0)
            {
                foreach (var item in LanguageAbility)
                {
                    xEl.Add(item.ToXml("LanguageAbility"));
                }
            }
            if (ContactInformation != null && ContactInformation.Count > 0)
            {
                foreach (var item in ContactInformation)
                {
                    xEl.Add(item.ToXml("ContactInformation"));
                }
            }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            return xEl;
        }
    }
}

