using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the situation in which the data collection event takes place.
    /// <summary>
    public class CollectionSituationType : IdentifiableType
    {
        /// <summary>
        /// Allows brief identification of collection situation with the option of using a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfCollectionSituation { get; set; }
        /// <summary>
        /// Full description of the collection situation. Supports structured content and multiple language content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfCollectionSituation != null) { xEl.Add(TypeOfCollectionSituation.ToXml("TypeOfCollectionSituation")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

