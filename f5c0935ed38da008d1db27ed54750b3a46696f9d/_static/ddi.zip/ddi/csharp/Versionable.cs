using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Adds the attribute identifying this as a versionable object as well as the MaintainableObject. All versionable objects should provide their contextual information, the identity of their maintainable parent. The deprecated form of the URN contains all the information to identify and object and its context. A Canonical URN scoped to the Maintainable contains the ID of the Maintainable as part of its structure. To provide full contextual information use the MaintainableObject structure. The use of the Canonical URN scoped to the agency or the identification sequence alone requires the content of the MaintainableObject to provide full contextual information. All content of Versionable is considered to be administrative metadata. Note that changes to the administrative metadata does not drive a change in the version of the parent objects. See DDI 3.2 Technical Documentation: Part I for further details.
    /// <summary>
    public partial class Versionable : IIdentifiable
    {
        [JsonIgnore]
        public string ReferenceId { get { return $"{URN}:{Agency}:{ID}:{Version}"; } }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[Uu][Rr][Nn]:[Dd][Dd][Ii]:[a-zA-Z0-9\-]{1,63}(\.[a-zA-Z0-9\-]{1,63})*:[A-Za-z0-9\*@$\-_]+(\.[A-Za-z0-9\*@$\-_]+)?:[0-9]+(\.[0-9]+)*")]
        public string URN { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringLength(253, MinimumLength = 1)]
        [StringValidation(null, @"[a-zA-Z0-9\-]{1,63}(\.[a-zA-Z0-9\-]{1,63})*")]
        public string Agency { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[A-Za-z0-9\*@$\-_]+(\.[A-Za-z0-9\*@$\-_]+)?")]
        public string ID { get; set; }
        /// <summary>
        /// 
        /// <summary>
        [StringValidation(null, @"[0-9]+(\.[0-9]+)*")]
        public string Version { get; set; }
        /// <summary>
        /// Allows for the specification of identifiers other than the specified DDI identification of the object. This may be a legacy ID from DDI-C, a system specific ID such as for a database or registry, or a non-DDI unique identifier. As the identifier is specific to a system the system must be identified with the UserID structure.
        /// <summary>
        public List<UserIDType> UserID { get; set; } = new List<UserIDType>();
        public bool ShouldSerializeUserID() { return UserID.Count > 0; }
        /// <summary>
        /// A system specific user defined property of the object expressed as a key/value pair. As this is specific to an individual system the use of controlled vocabularies for the key is strongly recommended.
        /// <summary>
        public List<StandardKeyValuePairType> UserAttributePair { get; set; } = new List<StandardKeyValuePairType>();
        public bool ShouldSerializeUserAttributePair() { return UserAttributePair.Count > 0; }
        /// <summary>
        /// Person or organization within the MaintenanceAgency responsible for the version change. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, it may be included in this notation. This is primarily intended for internal use.
        /// <summary>
        public string VersionResponsibility { get; set; }
        /// <summary>
        /// Reference person or organization within the MaintenanceAgency responsible for the version change, as described in an OrganizationScheme. If it is important to retain the affiliation between and individual responsible for the version and his/her agency, a Relation should be created between the individual referenced here and his/her organization. This is primarily intended for internal use.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Agent VersionResponsibilityReference { get; set; }
        /// <summary>
        /// Textual description of the rationale/purpose for the version change and a coded value to provide an internal processing flag within and organization or system. Note that versioning can only take place on objects owned by the specified DDI Agency. If you are creating a local instance of an object from another agency for current or future modification use BasedOnObject. If the changes being made result in what you determine to be new object rather than a version of a previous object, i.e. the change is too extensive to consider it a version of the existing object, create a new object and use BasedOnObject to provide a link to the object or objects that were a basis for the new object.
        /// <summary>
        public VersionRationaleType VersionRationale { get; set; }
        /// <summary>
        /// Use when creating an object that is based on an existing object or objects that are managed by a different agency or when the new object is NOT simply a version change but you wish to maintain a reference to the object that served as a basis for the new object. BasedOnObject may contain references to any number of objects which serve as a basis for this object, a BasedOnRationalDescription of how the content of the referenced object was incorporated or altered, and a BasedOnRationalCode to allow for specific typing of the BasedOnReference according to an external controlled vocabulary.
        /// <summary>
        public BasedOnObjectType BasedOnObject { get; set; }
        /// <summary>
        /// The inclusion of an existing OtherMaterial by reference. Use for any type of OtherMaterial not specifically addressed by an inline description for such as ExternalAid in QuestionItem.
        /// <summary>
        public List<ReferenceType> RelatedOtherMaterialReference { get; set; } = new List<ReferenceType>();
        public bool ShouldSerializeRelatedOtherMaterialReference() { return RelatedOtherMaterialReference.Count > 0; }
        /// <summary>
        /// Date of version using the union set BaseDateType. Duration should not be used in this field, even though allowed by the ISO format enforced by the parser.
        /// <summary>
        public CogsDate VersionDate { get; set; }
        /// <summary>
        /// Indicates that the maintainable will not be changed without versioning, and is a stable target for referencing.
        /// <summary>
        public bool IsPublished { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "Versionable");
            xEl.Add(new XElement(ns + "URN", URN));
            xEl.Add(new XElement(ns + "Agency", Agency));
            xEl.Add(new XElement(ns + "ID", ID));
            xEl.Add(new XElement(ns + "Version", Version));
            if (UserID != null && UserID.Count > 0)
            {
                foreach (var item in UserID)
                {
                    xEl.Add(item.ToXml("UserID"));
                }
            }
            if (UserAttributePair != null && UserAttributePair.Count > 0)
            {
                foreach (var item in UserAttributePair)
                {
                    xEl.Add(item.ToXml("UserAttributePair"));
                }
            }
            if (VersionResponsibility != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibility", VersionResponsibility));
            }
            if (VersionResponsibilityReference != null)
            {
                xEl.Add(new XElement(ns + "VersionResponsibilityReference", 
                    new XElement(ns + "URN", VersionResponsibilityReference.URN), 
                    new XElement(ns + "Agency", VersionResponsibilityReference.Agency), 
                    new XElement(ns + "ID", VersionResponsibilityReference.ID), 
                    new XElement(ns + "Version", VersionResponsibilityReference.Version), 
                    new XElement(ns + "TypeOfObject", VersionResponsibilityReference.GetType().Name)));
            }
            if (VersionRationale != null) { xEl.Add(VersionRationale.ToXml("VersionRationale")); }
            if (BasedOnObject != null) { xEl.Add(BasedOnObject.ToXml("BasedOnObject")); }
            if (RelatedOtherMaterialReference != null && RelatedOtherMaterialReference.Count > 0)
            {
                foreach (var item in RelatedOtherMaterialReference)
                {
                    xEl.Add(item.ToXml("RelatedOtherMaterialReference"));
                }
            }
            if (VersionDate != null && VersionDate.UsedType != CogsDateType.None)
            {
                xEl.Add(new XElement(ns + "VersionDate", VersionDate.ToString()));
            }
            xEl.Add(new XElement(ns + "IsPublished", IsPublished));
            return xEl;
        }
    }
}

