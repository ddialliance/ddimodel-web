using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The name of an individual broken out into its component parts of prefix, first/given name, middle name, last/family/surname, and suffix. The preferred compilation of the name parts may also be provided. The legal or formal name of the individual should have the isFormal attribute set to true. The preferred name should be noted with the isPreferred attribute. The attribute sex provides information to assist in the appropriate use of pronouns.
    /// <summary>
    public partial class IndividualNameType
    {
        /// <summary>
        /// Title that precedes the name of the individual, such as Ms., or Dr.
        /// <summary>
        public string Prefix { get; set; }
        /// <summary>
        /// First (given) name of the individual
        /// <summary>
        public string FirstGiven { get; set; }
        /// <summary>
        /// Middle name or initial of the individual
        /// <summary>
        public List<string> Middle { get; set; } = new List<string>();
        public bool ShouldSerializeMiddle() { return Middle.Count > 0; }
        /// <summary>
        /// Last (family) name /surname of the individual
        /// <summary>
        public string LastFamily { get; set; }
        /// <summary>
        /// Title that follows the name of the individual, such as Esq.
        /// <summary>
        public string Suffix { get; set; }
        /// <summary>
        /// The type of individual name provided. the use of a controlled vocabulary is strongly recommended. At minimum his should include, e.g. PreviousFormalName, Nickname (or CommonName), Other.
        /// <summary>
        public CodeValueType TypeOfIndividualName { get; set; }
        /// <summary>
        /// This provides a means of providing a full name as a single object for display or print such as identification badges etc. For example a person with the name of William Grace for official use may prefer a display name of Bill Grace on a name tag or other informal publication.
        /// <summary>
        public InternationalStringType FullName { get; set; }
        /// <summary>
        /// Clarifies when the name information is accurate.
        /// <summary>
        public DateType EffectivePeriod { get; set; }
        /// <summary>
        /// An abbreviation or acronym for the name. This may be expressed in multiple languages. It is assumed that if only a single language is provided that it may be used in any of the other languages within which the name itself is expressed.
        /// <summary>
        public InternationalStringType Abbreviation { get; set; }
        /// <summary>
        /// Sex allows for the specification of male, female or neutral. The purpose of providing this information is to assist others in the appropriate use of pronouns when addressing the individual. Note that many countries/languages may offer a neutral pronoun form.
        /// <summary>
        [StringValidation(new string[] {
            "M"
,             "F"
,             "N"
        })]
        public string Sex { get; set; }
        /// <summary>
        /// If more than one name for the object is provided, use the isPreferred attribute to indicate which is the preferred name content. All other names should be set to isPreferred="false".
        /// <summary>
        public bool IsPreferred { get; set; }
        /// <summary>
        /// A name may be specific to a particular context, i.e. common usage, business, social, etc.. Identify the context related to the specified name.
        /// <summary>
        public string Context { get; set; }
        /// <summary>
        /// The legal or formal name of the individual should have the isFormal attribute set to true. To avoid confusion only one individual name should have the isFormal attribute set to true. Use the TypeOfIndividualName to further differentiate the type and applied usage when multiple names are provided.
        /// <summary>
        public bool IsFormal { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Prefix != null)
            {
                xEl.Add(new XElement(ns + "Prefix", Prefix));
            }
            if (FirstGiven != null)
            {
                xEl.Add(new XElement(ns + "FirstGiven", FirstGiven));
            }
            if (Middle != null && Middle.Count > 0)
            {
                xEl.Add(
                    from item in Middle
                    select new XElement(ns + "Middle", item.ToString()));
            }
            if (LastFamily != null)
            {
                xEl.Add(new XElement(ns + "LastFamily", LastFamily));
            }
            if (Suffix != null)
            {
                xEl.Add(new XElement(ns + "Suffix", Suffix));
            }
            if (TypeOfIndividualName != null) { xEl.Add(TypeOfIndividualName.ToXml("TypeOfIndividualName")); }
            if (FullName != null) { xEl.Add(FullName.ToXml("FullName")); }
            if (EffectivePeriod != null) { xEl.Add(EffectivePeriod.ToXml("EffectivePeriod")); }
            if (Abbreviation != null) { xEl.Add(Abbreviation.ToXml("Abbreviation")); }
            if (Sex != null)
            {
                xEl.Add(new XElement(ns + "Sex", Sex));
            }
            xEl.Add(new XElement(ns + "IsPreferred", IsPreferred));
            if (Context != null)
            {
                xEl.Add(new XElement(ns + "Context", Context));
            }
            xEl.Add(new XElement(ns + "IsFormal", IsFormal));
            return xEl;
        }
    }
}

