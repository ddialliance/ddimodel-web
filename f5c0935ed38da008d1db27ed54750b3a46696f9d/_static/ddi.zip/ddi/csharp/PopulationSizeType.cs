using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The target value of the sample size for the primary and any secondary or sub-population.
    /// <summary>
    public partial class PopulationSizeType
    {
        /// <summary>
        /// The sample size of the primary or full population included in this sample. Consists of an integer value and specification of the sample unit.
        /// <summary>
        public SizeType PrimaryPopulation { get; set; }
        /// <summary>
        /// The sample size of any secondary or sub-populations included in this sample. Consists of an integer value and specification of the sample unit.
        /// <summary>
        public List<SizeType> SecondaryPopulation { get; set; } = new List<SizeType>();
        public bool ShouldSerializeSecondaryPopulation() { return SecondaryPopulation.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (PrimaryPopulation != null) { xEl.Add(PrimaryPopulation.ToXml("PrimaryPopulation")); }
            if (SecondaryPopulation != null && SecondaryPopulation.Count > 0)
            {
                foreach (var item in SecondaryPopulation)
                {
                    xEl.Add(item.ToXml("SecondaryPopulation"));
                }
            }
            return xEl;
        }
    }
}

