using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Maps a Source and one or more Target items of the same type within the Source and Target Schemes identified.
    /// <summary>
    public partial class ItemMapType : IdentifiableType
    {
        /// <summary>
        /// A reference to the source object in the source scheme already identified. TypeOfObject dependent on object of comparison.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Versionable SourceItemReference_Versionable { get; set; }
        /// <summary>
        /// A reference to the source object in the source scheme already identified. TypeOfObject dependent on object of comparison.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Maintainable SourceItemReference_Maintainable { get; set; }
        /// <summary>
        /// A reference the target object or objects in the target scheme already identified. TypeOfObject dependent on object of comparison. Note that if multiple target items are identified the correspondence between the source and ALL target items must be identical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Versionable> TargetItemReference_Versionable { get; set; } = new List<Versionable>();
        public bool ShouldSerializeTargetItemReference_Versionable() { return TargetItemReference_Versionable.Count > 0; }
        /// <summary>
        /// A reference the target object or objects in the target scheme already identified. TypeOfObject dependent on object of comparison. Note that if multiple target items are identified the correspondence between the source and ALL target items must be identical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Maintainable> TargetItemReference_Maintainable { get; set; } = new List<Maintainable>();
        public bool ShouldSerializeTargetItemReference_Maintainable() { return TargetItemReference_Maintainable.Count > 0; }
        /// <summary>
        /// Describe the level of similarity and difference between the Source and the Target objects.
        /// <summary>
        public CorrespondenceType Correspondence { get; set; }
        /// <summary>
        /// Identifies related maps for example an ItemMap of two questions may point to the CodeMap defining the comparison of the two response domains.
        /// <summary>
        public List<ReferenceType> RelatedMapReference { get; set; } = new List<ReferenceType>();
        public bool ShouldSerializeRelatedMapReference() { return RelatedMapReference.Count > 0; }
        /// <summary>
        /// Allows for an alias to be assigned to the correspondence between two items, so that it can be referred to with a single name, that would include both related items.
        /// <summary>
        public string Alias { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("IdentifiableType").Descendants())
            {
                xEl.Add(el);
            }
            if (SourceItemReference_Versionable != null)
            {
                xEl.Add(new XElement(ns + "SourceItemReference_Versionable", 
                    new XElement(ns + "URN", SourceItemReference_Versionable.URN), 
                    new XElement(ns + "Agency", SourceItemReference_Versionable.Agency), 
                    new XElement(ns + "ID", SourceItemReference_Versionable.ID), 
                    new XElement(ns + "Version", SourceItemReference_Versionable.Version), 
                    new XElement(ns + "TypeOfObject", SourceItemReference_Versionable.GetType().Name)));
            }
            if (SourceItemReference_Maintainable != null)
            {
                xEl.Add(new XElement(ns + "SourceItemReference_Maintainable", 
                    new XElement(ns + "URN", SourceItemReference_Maintainable.URN), 
                    new XElement(ns + "Agency", SourceItemReference_Maintainable.Agency), 
                    new XElement(ns + "ID", SourceItemReference_Maintainable.ID), 
                    new XElement(ns + "Version", SourceItemReference_Maintainable.Version), 
                    new XElement(ns + "TypeOfObject", SourceItemReference_Maintainable.GetType().Name)));
            }
            if (TargetItemReference_Versionable != null && TargetItemReference_Versionable.Count > 0)
            {
                foreach (var item in TargetItemReference_Versionable)
                {
                    xEl.Add(new XElement(ns + "TargetItemReference_Versionable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (TargetItemReference_Maintainable != null && TargetItemReference_Maintainable.Count > 0)
            {
                foreach (var item in TargetItemReference_Maintainable)
                {
                    xEl.Add(new XElement(ns + "TargetItemReference_Maintainable", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (Correspondence != null) { xEl.Add(Correspondence.ToXml("Correspondence")); }
            if (RelatedMapReference != null && RelatedMapReference.Count > 0)
            {
                foreach (var item in RelatedMapReference)
                {
                    xEl.Add(item.ToXml("RelatedMapReference"));
                }
            }
            if (Alias != null)
            {
                xEl.Add(new XElement(ns + "Alias", Alias));
            }
            return xEl;
        }
    }
}

