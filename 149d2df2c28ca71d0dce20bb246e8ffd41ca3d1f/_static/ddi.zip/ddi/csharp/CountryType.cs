using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An unspecified identification of a Country. When using ISO 3166 code (2-letter, 3-letter, or numeric) use the specific CountryCode substitution element. Allows for an optional specification of language and effective date.
    /// <summary>
    public class CountryType : CountryCodeType
    {
        /// <summary>
        /// Indicates the language of content. Note that xml:lang allows for a simple 2 or 3 character language code or a language code extended by a country code , for example en-au for English as used in Australia.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

