using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A maintainable module containing information related to the archiving (longer term access and/or preservation) of the data and metadata. Note that in DDI Archive refers to a set of processes rather than a location. Archive contents are split into archive specific information (information that is related to the organization or individual performing archival activities) and information that reflects the processes that the metadata or data have undergone which should be maintained along with other content if the metadata changes locations. Two key pieces of information held within the Archive are the Organization Scheme (containing records of Organizations, Individuals, and the Relationships between them) and the Lifecycle. The Lifecycle can be used to document any significant event in the life of the data and metadata. It is a series of Lifecycle Events which note the date of the event, what took place, and who was involved. The module is described by a name, label, and description, archive specific information, an Organization Scheme (in-line or by reference), Lifecycle Information, and Other Materials related to the objects within the Archive Module. Archive Specific information covers details regarding individual items and collections within the archive as well as access conditions, funding and budget information, and quality statements. The reference to the Organization or individual acting as the archive as well as a coverage statement regarding the archive collection is found here.
    /// <summary>
    public class Archive : Maintainable
    {
        /// <summary>
        /// A name for the Archive module. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ArchiveModuleName { get; set; } = new List<NameType>();
        public bool ShouldSerializeArchiveModuleName() { return ArchiveModuleName.Count > 0; }
        /// <summary>
        /// A display label for the Archive module. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Archive module. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Contains metadata specific to a particular archive's holding.
        /// <summary>
        public List<ArchiveSpecificType> ArchiveSpecific { get; set; } = new List<ArchiveSpecificType>();
        public bool ShouldSerializeArchiveSpecific() { return ArchiveSpecific.Count > 0; }
        /// <summary>
        /// A list of the organizations related to the DDI instance. This includes information on the archives responsible for creating and maintaining the instance. All agencies must be defined as an Organization in an Archive schema (which can be defined inline or resolved externally).
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OrganizationScheme> OrganizationSchemeReference { get; set; } = new List<OrganizationScheme>();
        public bool ShouldSerializeOrganizationSchemeReference() { return OrganizationSchemeReference.Count > 0; }
        /// <summary>
        /// LifecycleInformation contains the description of a set of events in the life cycle of the data. It may be extended by specific users.
        /// <summary>
        public LifecycleInformationType LifecycleInformation { get; set; }
        /// <summary>
        /// Material related to this item from the archive's perspective.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Archive");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ArchiveModuleName != null && ArchiveModuleName.Count > 0)
            {
                foreach (var item in ArchiveModuleName)
                {
                    xEl.Add(item.ToXml("ArchiveModuleName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ArchiveSpecific != null && ArchiveSpecific.Count > 0)
            {
                foreach (var item in ArchiveSpecific)
                {
                    xEl.Add(item.ToXml("ArchiveSpecific"));
                }
            }
            if (OrganizationSchemeReference != null && OrganizationSchemeReference.Count > 0)
            {
                foreach (var item in OrganizationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OrganizationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (LifecycleInformation != null) { xEl.Add(LifecycleInformation.ToXml("LifecycleInformation")); }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            return xEl;
        }
    }
}

