using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures a textual representation. MinLength and maxlength attributes are inclusive integers describing the number of permitted characters. The regExp attribute holds a regular expression describing the valid contents of the string.
    /// <summary>
    public class TextRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// The maximum number of characters allowed.
        /// <summary>
        public int MaxLength { get; set; }
        /// <summary>
        /// The minimum number of characters allowed.
        /// <summary>
        public int MinLength { get; set; }
        /// <summary>
        /// A regular expression limiting the allowed characters or character order of the content.
        /// <summary>
        public string RegExp { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "MaxLength", MaxLength));
            xEl.Add(new XElement(ns + "MinLength", MinLength));
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            return xEl;
        }
    }
}

