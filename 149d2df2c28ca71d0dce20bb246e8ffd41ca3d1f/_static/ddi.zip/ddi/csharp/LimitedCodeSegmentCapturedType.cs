using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// When the code is a concatenation this structure allows you to limit the portion of the concatenated code that this object captures. Provides an description of the segment, declares the array base used, the start position of the segment and its length.
    /// <summary>
    public class LimitedCodeSegmentCapturedType
    {
        /// <summary>
        /// A description of the content and purpose of the segment used. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// The array base is the value of the designation for the first item in an array and is set to either 0 or 1. Unix based systems and most current programming systems use an array base of 0. Traditional codebooks normally set the array base at 1, for example the first data item in a fixed format ASCII file record begins at character 1.
        /// <summary>
        [StringValidation(new string[] {
            "0"
,             "1"
        })]
        public string ArrayBase_string { get; set; }
        /// <summary>
        /// The start position of the first character expressed as an integer.
        /// <summary>
        public int StartPosition { get; set; }
        /// <summary>
        /// The length of the segment expressed as an integer.
        /// <summary>
        public int Length { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ArrayBase_string != null)
            {
                xEl.Add(new XElement(ns + "ArrayBase_string", ArrayBase_string));
            }
            xEl.Add(new XElement(ns + "StartPosition", StartPosition));
            xEl.Add(new XElement(ns + "Length", Length));
            return xEl;
        }
    }
}

