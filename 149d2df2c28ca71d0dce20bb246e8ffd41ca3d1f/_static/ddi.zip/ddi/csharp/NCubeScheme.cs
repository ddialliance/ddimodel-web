using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of NCubes maintained by an agency and used to structure data items into relational structures. In addition to the standard name, label, and description of the scheme, contains descriptions of individual NCubes and NCubeGroups as well as allowing the inclusion of another NCubeScheme by reference.
    /// <summary>
    public class NCubeScheme : Maintainable
    {
        /// <summary>
        /// A name for the NCubeScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> NCubeSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeNCubeSchemeName() { return NCubeSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the NCubeScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the NCubeScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Describes the logical structure of an NCube which is a 1..n dimension structure which relates a set of individual value to each other by defining them within a matrix.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCube> NCubeReference { get; set; } = new List<NCube>();
        public bool ShouldSerializeNCubeReference() { return NCubeReference.Count > 0; }
        /// <summary>
        /// Describes a group of NCubes for conceptual or administrative purposes, which may be ordered or hierarchical.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeGroup> NCubeGroupReference { get; set; } = new List<NCubeGroup>();
        public bool ShouldSerializeNCubeGroupReference() { return NCubeGroupReference.Count > 0; }
        /// <summary>
        /// Allows for inclusion of other NCube schemes by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeScheme> NCubeSchemeReference { get; set; } = new List<NCubeScheme>();
        public bool ShouldSerializeNCubeSchemeReference() { return NCubeSchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "NCubeScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (NCubeSchemeName != null && NCubeSchemeName.Count > 0)
            {
                foreach (var item in NCubeSchemeName)
                {
                    xEl.Add(item.ToXml("NCubeSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (NCubeReference != null && NCubeReference.Count > 0)
            {
                foreach (var item in NCubeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (NCubeGroupReference != null && NCubeGroupReference.Count > 0)
            {
                foreach (var item in NCubeGroupReference)
                {
                    xEl.Add(new XElement(ns + "NCubeGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (NCubeSchemeReference != null && NCubeSchemeReference.Count > 0)
            {
                foreach (var item in NCubeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

