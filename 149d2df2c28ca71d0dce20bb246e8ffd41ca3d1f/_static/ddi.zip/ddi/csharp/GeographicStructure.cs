using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Contains information on the hierarchy of the geographic structure. In addition to the standard name, label, and description identifies one or more AuthorizedSources for the level codes/descriptions provided and a set of GeographicLevels in-line or by reference.
    /// <summary>
    public class GeographicStructure : Versionable
    {
        /// <summary>
        /// A name for the GeographicStructure. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> GeographicStructureName { get; set; } = new List<NameType>();
        public bool ShouldSerializeGeographicStructureName() { return GeographicStructureName.Count > 0; }
        /// <summary>
        /// A display label for the GeographicStructure. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the GeographicStructure. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// An identifiable authorization source repeated for each identifying code type. This allows the codes to be used as representations for response domains and value representations by designating a specific set of locations and the code of an authorization source. An authorization source should differentiate between codes derived for different purposes within the same agency.
        /// <summary>
        public List<AuthorizedSourceType> AuthorizedSource { get; set; } = new List<AuthorizedSourceType>();
        public bool ShouldSerializeAuthorizedSource() { return AuthorizedSource.Count > 0; }
        /// <summary>
        /// Used to describe any level of geography, including overall coverage and each of the lower levels.
        /// <summary>
        public GeographicLevelType GeographicLevel { get; set; }
        /// <summary>
        /// Inclusion of an existing GeographicLevel description by reference.
        /// <summary>
        public GeographicLevelType GeographicLevelReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "GeographicStructure");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (GeographicStructureName != null && GeographicStructureName.Count > 0)
            {
                foreach (var item in GeographicStructureName)
                {
                    xEl.Add(item.ToXml("GeographicStructureName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (AuthorizedSource != null && AuthorizedSource.Count > 0)
            {
                foreach (var item in AuthorizedSource)
                {
                    xEl.Add(item.ToXml("AuthorizedSource"));
                }
            }
            if (GeographicLevel != null) { xEl.Add(GeographicLevel.ToXml("GeographicLevel")); }
            if (GeographicLevelReference != null) { xEl.Add(GeographicLevelReference.ToXml("GeographicLevelReference")); }
            return xEl;
        }
    }
}

