using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A URN or URL for a file with a flag to indicate if it is a public copy.
    /// <summary>
    public class URIType : anyURI
    {
        /// <summary>
        /// Set to "true" (default value) if this file is publicly available. This does not imply that there are not restrictions to access. Set to "false" if this is not publicly available, such as a backup copy, an internal processing data file, etc.
        /// <summary>
        public bool IsPublic { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsPublic", IsPublic));
            return xEl;
        }
    }
}

