using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// For each record, contains the values for the items in order by the specified variable sequence.
    /// <summary>
    public class RecordType
    {
        /// <summary>
        /// An individual item value.
        /// <summary>
        public List<ValueType> Value { get; set; } = new List<ValueType>();
        public bool ShouldSerializeValue() { return Value.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Value != null && Value.Count > 0)
            {
                foreach (var item in Value)
                {
                    xEl.Add(item.ToXml("Value"));
                }
            }
            return xEl;
        }
    }
}

