using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// 
    /// <summary>
    public class OrganizationScheme : Maintainable
    {
        /// <summary>
        /// A name for the scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> OrganizationSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeOrganizationSchemeName() { return OrganizationSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the scheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing OrganizationScheme for inclusion by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OrganizationScheme> OrganizationSchemeReference { get; set; } = new List<OrganizationScheme>();
        public bool ShouldSerializeOrganizationSchemeReference() { return OrganizationSchemeReference.Count > 0; }
        /// <summary>
        /// In-line description of an Organization. These may be referenced by many elements in DDI and provide fuller detail regarding the Organization.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Organization> OrganizationReference { get; set; } = new List<Organization>();
        public bool ShouldSerializeOrganizationReference() { return OrganizationReference.Count > 0; }
        /// <summary>
        /// In-line description of an Individual. These may be referenced by many elements in DDI and provide fuller detail regarding the Individual.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Individual> IndividualReference { get; set; } = new List<Individual>();
        public bool ShouldSerializeIndividualReference() { return IndividualReference.Count > 0; }
        /// <summary>
        /// In-line description of a Relationship between two organizations or individual or between an individual and an organization. Relation is generally and on-going association not associated with a specific role in relationship to a study.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Relation> RelationReference { get; set; } = new List<Relation>();
        public bool ShouldSerializeRelationReference() { return RelationReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of Organizations, Individuals, and/or Relations.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<OrganizationGroup> OrganizationGroupReference { get; set; } = new List<OrganizationGroup>();
        public bool ShouldSerializeOrganizationGroupReference() { return OrganizationGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "OrganizationScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (OrganizationSchemeName != null && OrganizationSchemeName.Count > 0)
            {
                foreach (var item in OrganizationSchemeName)
                {
                    xEl.Add(item.ToXml("OrganizationSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (OrganizationSchemeReference != null && OrganizationSchemeReference.Count > 0)
            {
                foreach (var item in OrganizationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "OrganizationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OrganizationReference != null && OrganizationReference.Count > 0)
            {
                foreach (var item in OrganizationReference)
                {
                    xEl.Add(new XElement(ns + "OrganizationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (IndividualReference != null && IndividualReference.Count > 0)
            {
                foreach (var item in IndividualReference)
                {
                    xEl.Add(new XElement(ns + "IndividualReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RelationReference != null && RelationReference.Count > 0)
            {
                foreach (var item in RelationReference)
                {
                    xEl.Add(new XElement(ns + "RelationReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (OrganizationGroupReference != null && OrganizationGroupReference.Count > 0)
            {
                foreach (var item in OrganizationGroupReference)
                {
                    xEl.Add(new XElement(ns + "OrganizationGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

