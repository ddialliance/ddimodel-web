using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Lists the variables whose values when concatenated result in the value for this variable.
    /// <summary>
    public class ConcatenatedValueType
    {
        /// <summary>
        /// Identifies the variables whose values are concatenated to form the concatenated variable. Note that the order of these variables determines the order of concatenation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> VariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeVariableReference() { return VariableReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (VariableReference != null && VariableReference.Count > 0)
            {
                foreach (var item in VariableReference)
                {
                    xEl.Add(new XElement(ns + "VariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

