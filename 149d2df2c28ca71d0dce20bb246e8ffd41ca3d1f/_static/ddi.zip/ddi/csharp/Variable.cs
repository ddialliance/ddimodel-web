using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the structure of a Variable. This is the applied expression of a data item within a data set and maps to the GSIM ImplementedVariable. In addition to the standard name, label, and description, includes a reference to a source parameter, represented variable, conceptual variable, universe, concept, question, source variable, and embargo information. It identifies the normal source of the data in the variable, the unit of analysis, whether the variable provides temporal or geographic information, or serves as a weight for other variables in the data, and provides a full description of its representation.
    /// <summary>
    public class Variable : Versionable
    {
        /// <summary>
        /// A name for the Variable. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> VariableName { get; set; } = new List<NameType>();
        public bool ShouldSerializeVariableName() { return VariableName.Count > 0; }
        /// <summary>
        /// A display label for the Variable. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the Variable. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Assigns a parameter that contains output from the Variable so that it can be bound to an InParameter of an instruction or act as the SourceParameter of another Variable.
        /// <summary>
        public ParameterType OutParameter { get; set; }
        /// <summary>
        /// Reference to an OutParameter that serves as the source for the content of this variable.
        /// <summary>
        public ParameterType SourceParameterReference { get; set; }
        /// <summary>
        /// Reference to variable(s) used as a basis for recoding, derivation, or other means of calculating the data for this variable. This reference is intended to provide basic information on the source variable structure including value representation, measurement unit, etc. Note that if a variable is used by reference within multiple VariableSchemes you can identify its role within a specific VariableScheme by including that VariableScheme in the sourceContext attribute of the reference. Use ProcessingInstructionReference to provide additional information on the transformation of the source variable(s) into the data for this variable. If additional processing detail is required use the InParameter, OutParameter, and ParameterLinkage options in the GenerationInstruction and ProcessingInstructionReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> SourceVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeSourceVariableReference() { return SourceVariableReference.Count > 0; }
        /// <summary>
        /// Reference to the RepresentedVariable that describes the core of this variable (the RepresentedVariable that the variable is the implementation of). The RepresentedVariable contains the broad reusable specification of the Variable, i.e., concept, universe, and value representation. These may be constrained by specifications within the Variable description. TypeOfObject should be set to RepresentedVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public RepresentedVariable RepresentedVariableReference { get; set; }
        /// <summary>
        /// Reference to the ConceptualVariable that describes the core of this variable. The ConceptualVariable provides linked Concept and Universe specifications. These may be constrained by specifications within the Variable description. TypeOfObject should be set to ConceptualVariable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ConceptualVariable ConceptualVariableReference { get; set; }
        /// <summary>
        /// Reference to the universe statement containing a description of the persons or other elements that this variable refers to, and to which any analytic results refer. If more than one universe is referenced the universe of the variable is the intersect of the referenced universes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept measured by this variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// Reference to question(s) used to collect data for this variable. This references the wording and response domain of the question, not the question flow (if the same question was asked in reference to multiple objects (i.e., Age of each child). Use SourceParameterReference and/or VariableRepresentation/ProcessingInstructionReference to differentiate sources associated with flow patterns or data processing instructions.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QuestionItem> QuestionReference { get; set; } = new List<QuestionItem>();
        public bool ShouldSerializeQuestionReference() { return QuestionReference.Count > 0; }
        /// <summary>
        /// Reference to any embargoes placed on the contents of this variable. Embargoes may limit access to the data and/or metadata to specific groups and/or for specified periods of time.
        /// <summary>
        public EmbargoType EmbargoReference { get; set; }
        /// <summary>
        /// The normal source of the information contained in the variable. In the case of a survey this may be a respondent, proxy, interviewer, or other source. In the case of administrative data the position of a field on a form e.g., "top of page", "item 3", "generated by data processor", etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType SourceUnit { get; set; }
        /// <summary>
        /// The entity to which the data refer, for example, individuals, families or households, groups, institutions/organizations, administrative units, etc. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType AnalysisUnit { get; set; }
        /// <summary>
        /// Describes the representation of the variable in the data set, including allowed content, data typing, and computation information.
        /// <summary>
        public VariableRepresentationType VariableRepresentation { get; set; }
        /// <summary>
        /// Set to "true" if the variable relays time-related information (date, time, season, relative time, etc.).
        /// <summary>
        public bool IsTemporal { get; set; }
        /// <summary>
        /// Set to "true" if the variable relays geographic information, i.e., geographic code, area name, relative location, etc.
        /// <summary>
        public bool IsGeographic { get; set; }
        /// <summary>
        /// Set to "true" if the variable is used a weight when analyzing data within the data set.
        /// <summary>
        public bool IsWeight { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "Variable");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (VariableName != null && VariableName.Count > 0)
            {
                foreach (var item in VariableName)
                {
                    xEl.Add(item.ToXml("VariableName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (OutParameter != null) { xEl.Add(OutParameter.ToXml("OutParameter")); }
            if (SourceParameterReference != null) { xEl.Add(SourceParameterReference.ToXml("SourceParameterReference")); }
            if (SourceVariableReference != null && SourceVariableReference.Count > 0)
            {
                foreach (var item in SourceVariableReference)
                {
                    xEl.Add(new XElement(ns + "SourceVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentedVariableReference != null)
            {
                xEl.Add(new XElement(ns + "RepresentedVariableReference", 
                    new XElement(ns + "URN", RepresentedVariableReference.URN), 
                    new XElement(ns + "Agency", RepresentedVariableReference.Agency), 
                    new XElement(ns + "ID", RepresentedVariableReference.ID), 
                    new XElement(ns + "Version", RepresentedVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", RepresentedVariableReference.GetType().Name)));
            }
            if (ConceptualVariableReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptualVariableReference", 
                    new XElement(ns + "URN", ConceptualVariableReference.URN), 
                    new XElement(ns + "Agency", ConceptualVariableReference.Agency), 
                    new XElement(ns + "ID", ConceptualVariableReference.ID), 
                    new XElement(ns + "Version", ConceptualVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptualVariableReference.GetType().Name)));
            }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (QuestionReference != null && QuestionReference.Count > 0)
            {
                foreach (var item in QuestionReference)
                {
                    xEl.Add(new XElement(ns + "QuestionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (EmbargoReference != null) { xEl.Add(EmbargoReference.ToXml("EmbargoReference")); }
            if (SourceUnit != null) { xEl.Add(SourceUnit.ToXml("SourceUnit")); }
            if (AnalysisUnit != null) { xEl.Add(AnalysisUnit.ToXml("AnalysisUnit")); }
            if (VariableRepresentation != null) { xEl.Add(VariableRepresentation.ToXml("VariableRepresentation")); }
            xEl.Add(new XElement(ns + "IsTemporal", IsTemporal));
            xEl.Add(new XElement(ns + "IsGeographic", IsGeographic));
            xEl.Add(new XElement(ns + "IsWeight", IsWeight));
            return xEl;
        }
    }
}

