using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// References the managed representation of the variables' values. Allows for the listing of values to be treated as missing in order to support 3.1 structures. The prefered method is the use of a reference to MissingValues description using MissingValuesReference. If both are used and there is a conflict in the content, MissingValuesReference will override the content provided in the ValueRepresentationReference. TypeOfObject should be set to ManagedDateTimeRepresentation, ManagedNumericRepresentation, ManagedScaleRepresentation, or ManagedTextRepresentation.
    /// <summary>
    public class RepresentationReferenceType : ReferenceType
    {
        /// <summary>
        /// List the values used to represent missing data in a space delimited array. Use of MissingValuesReference is preferred. If this content does not match the values provided in the MissingValuesReference, the content of the MissingValuesReference overrides the content of this attribute.
        /// <summary>
        [StringValidation(null, "\c+")]
        public string MissingValue { get; set; }
        /// <summary>
        /// When value is true a blank or empty variable content should be treated as a missing value.  Use of MissingValuesReference is preferred.
        /// <summary>
        public bool BlankIsMissingValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (MissingValue != null)
            {
                xEl.Add(new XElement(ns + "MissingValue", MissingValue));
            }
            xEl.Add(new XElement(ns + "BlankIsMissingValue", BlankIsMissingValue));
            return xEl;
        }
    }
}

