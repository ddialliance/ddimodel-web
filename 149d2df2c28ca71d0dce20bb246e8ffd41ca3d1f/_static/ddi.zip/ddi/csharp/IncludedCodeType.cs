using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Specifies the codes to include in the representation by providing the references to the included Codes or a range of Values from the Code.
    /// <summary>
    public class IncludedCodeType
    {
        /// <summary>
        /// Reference to the Code within the CodeList used by the representation. Repeat for including multiple values.
        /// <summary>
        public List<string> CodeReference_string { get; set; } = new List<string>();
        public bool ShouldSerializeCodeReference_string() { return CodeReference_string.Count > 0; }
        /// <summary>
        /// Use when multiple values are included. This uses the unique Value provided for the Code as a means of identification. Provides the range of Values used by the representation. Repeat for non-contiguous values.
        /// <summary>
        public List<RangeType> Range { get; set; } = new List<RangeType>();
        public bool ShouldSerializeRange() { return Range.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CodeReference_string != null && CodeReference_string.Count > 0)
            {
                xEl.Add(
                    from item in CodeReference_string
                    select new XElement(ns + "CodeReference_string", item.ToString()));
            }
            if (Range != null && Range.Count > 0)
            {
                foreach (var item in Range)
                {
                    xEl.Add(item.ToXml("Range"));
                }
            }
            return xEl;
        }
    }
}

