using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description of the physical location of the value of the object in the data file. Includes information about the data item location and its data type/format if other than the default.
    /// <summary>
    public class PhysicalLocationType
    {
        /// <summary>
        /// An explicit definition of the data storage format. This field is necessary in the case of some numeric data formats where the format definition would allow real values, but the values are integer values. Supports the use of an external controlled vocabulary. Use of a controlled vocabulary is strongly recommended.
        /// <summary>
        public CodeValueType StorageFormat { get; set; }
        /// <summary>
        /// Defines the delimiter used to separate variables in a delimited record. The attribute treatConsecutiveDelimiterAsOne indicates how consecutive delimiters should be handed by the software.
        /// <summary>
        public DelimiterType Delimiter { get; set; }
        /// <summary>
        /// Position of the first character of the data item in fixed format file.
        /// <summary>
        public int StartPosition { get; set; }
        /// <summary>
        /// Array number of the data item for delimited files.
        /// <summary>
        public int ArrayPosition { get; set; }
        /// <summary>
        /// Position of the last character of the data item in fixed format. Must be specified if a value for Width is not provided.
        /// <summary>
        public int EndPosition { get; set; }
        /// <summary>
        /// Data item width for fixed format file, maximum width for delimited file. Must be specified if a value for EndPosition is not provided.
        /// <summary>
        public int Width { get; set; }
        /// <summary>
        /// Number of decimal places for data with an implied decimal separator. Another expression is the decimal scaling factor (SAS). Default: 0.
        /// <summary>
        public int DecimalPositions { get; set; }
        /// <summary>
        /// The character used to separate the integer and the fraction part of a number (if an explicit separator is used in the data). Allowed values are: None (default), Dot, Comma, Other. On the basis of the data definition in DDI documents, data processing tools could compute the necessary precision width on the basis of the format width and the existence of separators. Appropriate data types could be used, i.e. float or double, short or long. The decimal separator definition only makes sense with some XML Schema primitives.
        /// <summary>
        [StringLength(1)]
        public string DecimalSeparator { get; set; }
        /// <summary>
        /// The character used to separate groups of digits (if an explicit separator is used in the data). Allowed values are: None (default), Dot, Comma, Other. The decimal separator definition makes only sense with some XML Schema primitives.
        /// <summary>
        [StringLength(1)]
        public string DigitGroupSeparator { get; set; }
        /// <summary>
        /// Language of the data file expressed as a delimited list of language codes.
        /// <summary>
        public List<string> LanguageOfData { get; set; } = new List<string>();
        public bool ShouldSerializeLanguageOfData() { return LanguageOfData.Count > 0; }
        /// <summary>
        /// A two-character ISO country code, to supplement the LanguageOfData value.
        /// <summary>
        public string LocaleOfData { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (StorageFormat != null) { xEl.Add(StorageFormat.ToXml("StorageFormat")); }
            if (Delimiter != null) { xEl.Add(Delimiter.ToXml("Delimiter")); }
            xEl.Add(new XElement(ns + "StartPosition", StartPosition));
            xEl.Add(new XElement(ns + "ArrayPosition", ArrayPosition));
            xEl.Add(new XElement(ns + "EndPosition", EndPosition));
            xEl.Add(new XElement(ns + "Width", Width));
            xEl.Add(new XElement(ns + "DecimalPositions", DecimalPositions));
            if (DecimalSeparator != null)
            {
                xEl.Add(new XElement(ns + "DecimalSeparator", DecimalSeparator));
            }
            if (DigitGroupSeparator != null)
            {
                xEl.Add(new XElement(ns + "DigitGroupSeparator", DigitGroupSeparator));
            }
            if (LanguageOfData != null && LanguageOfData.Count > 0)
            {
                foreach (var item in LanguageOfData)
                {
                    xEl.Add(new XElement(ns + "LanguageOfData", item));
                }
            }
            if (LocaleOfData != null)
            {
                xEl.Add(new XElement(ns + "LocaleOfData", LocaleOfData));
            }
            return xEl;
        }
    }
}

