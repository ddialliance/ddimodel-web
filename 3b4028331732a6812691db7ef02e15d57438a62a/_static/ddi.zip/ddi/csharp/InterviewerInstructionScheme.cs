using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of interviewer instructions to be displayed within the instrument, such as definitions, and explanations of terminology and questions. Content may also be used to provide the contents of an instruction manual for questions or instruments. In addition to the standard name, label, and description, allows for the inclusion of another InterviewerInstructionScheme by reference an a set of in-line instructions.
    /// <summary>
    public partial class InterviewerInstructionScheme : Maintainable
    {
        /// <summary>
        /// A name for the InterviewerInstructionScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> InterviewerInstructionSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeInterviewerInstructionSchemeName() { return InterviewerInstructionSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the InterviewerInstructionScheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the InterviewerInstructionScheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Allows for the inclusion of an existing InterviewerInstructionScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InterviewerInstructionScheme> InterviewerInstructionSchemeReference { get; set; } = new List<InterviewerInstructionScheme>();
        public bool ShouldSerializeInterviewerInstructionSchemeReference() { return InterviewerInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// Content of an individual instruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Instruction> InstructionReference { get; set; } = new List<Instruction>();
        public bool ShouldSerializeInstructionReference() { return InstructionReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of Instructions.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<InstructionGroup> InstructionGroupReference { get; set; } = new List<InstructionGroup>();
        public bool ShouldSerializeInstructionGroupReference() { return InstructionGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "InterviewerInstructionScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (InterviewerInstructionSchemeName != null && InterviewerInstructionSchemeName.Count > 0)
            {
                foreach (var item in InterviewerInstructionSchemeName)
                {
                    xEl.Add(item.ToXml("InterviewerInstructionSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (InterviewerInstructionSchemeReference != null && InterviewerInstructionSchemeReference.Count > 0)
            {
                foreach (var item in InterviewerInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "InterviewerInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstructionReference != null && InstructionReference.Count > 0)
            {
                foreach (var item in InstructionReference)
                {
                    xEl.Add(new XElement(ns + "InstructionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (InstructionGroupReference != null && InstructionGroupReference.Count > 0)
            {
                foreach (var item in InstructionGroupReference)
                {
                    xEl.Add(new XElement(ns + "InstructionGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

