using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to the Unique key variable for segment identification and the value it contains for the specific segment. TypeOfObject should be set to Variable.
    /// <summary>
    public partial class KeyVariableReferenceType : ReferenceType
    {
        /// <summary>
        /// Value of the variable for this segment.
        /// <summary>
        public ValueType Value { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (Value != null) { xEl.Add(Value.ToXml("Value")); }
            return xEl;
        }
    }
}

