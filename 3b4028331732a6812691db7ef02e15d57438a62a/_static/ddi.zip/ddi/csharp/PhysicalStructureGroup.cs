using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A group of PhysicalStructure descriptions for administrative or conceptual purposes. May be hierarchical. In addition to the standard name, label, and description, allows for a brief classification of the group type, reference to an applicable Universe and Concept, inclusion of PhysicalStructures and PhysicalStructureGroups by reference and an indicator which can be set to "true" if the group is ordered.
    /// <summary>
    public partial class PhysicalStructureGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a PhysicalStructureGroup. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfPhysicalStructureGroup { get; set; }
        /// <summary>
        /// A name for the PhysicalStructureGroup. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> PhysicalStructureGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializePhysicalStructureGroupName() { return PhysicalStructureGroupName.Count > 0; }
        /// <summary>
        /// A display label for the PhysicalStructureGroup. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the PhysicalStructureGroup. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other objects to which the contents of this group pertain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept expressed by the objects in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// If subjects are listed for this group, it is strongly recommended that the subjects listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of subject at the group level allows for associating objects as a type of subject based group or to identify subject characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Subject { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeSubject() { return Subject.Count > 0; }
        /// <summary>
        /// If keywords are listed for this group, it is strongly recommended that the keywords listed also be found in the TopicalCoverage element for the parent packaging element when this group is included directly or by reference in a module containing a coverage element. Use of keyword at the group level allows for associating objects as a type of keyword based group or to identify keyword characteristics of a reusable group of objects.
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Reference to constituent PhysicalStructure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public PhysicalStructure PhysicalStructureReference { get; set; }
        /// <summary>
        /// Reference to constituent PhysicalStructureGroup. This allows for nesting of PhysicalStructureGroups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public PhysicalStructureGroup PhysicalStructureGroupReference { get; set; }
        /// <summary>
        /// If set to "true" indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "PhysicalStructureGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfPhysicalStructureGroup != null) { xEl.Add(TypeOfPhysicalStructureGroup.ToXml("TypeOfPhysicalStructureGroup")); }
            if (PhysicalStructureGroupName != null && PhysicalStructureGroupName.Count > 0)
            {
                foreach (var item in PhysicalStructureGroupName)
                {
                    xEl.Add(item.ToXml("PhysicalStructureGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (Subject != null && Subject.Count > 0)
            {
                foreach (var item in Subject)
                {
                    xEl.Add(item.ToXml("Subject"));
                }
            }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (PhysicalStructureReference != null)
            {
                xEl.Add(new XElement(ns + "PhysicalStructureReference", 
                    new XElement(ns + "URN", PhysicalStructureReference.URN), 
                    new XElement(ns + "Agency", PhysicalStructureReference.Agency), 
                    new XElement(ns + "ID", PhysicalStructureReference.ID), 
                    new XElement(ns + "Version", PhysicalStructureReference.Version), 
                    new XElement(ns + "TypeOfObject", PhysicalStructureReference.GetType().Name)));
            }
            if (PhysicalStructureGroupReference != null)
            {
                xEl.Add(new XElement(ns + "PhysicalStructureGroupReference", 
                    new XElement(ns + "URN", PhysicalStructureGroupReference.URN), 
                    new XElement(ns + "Agency", PhysicalStructureGroupReference.Agency), 
                    new XElement(ns + "ID", PhysicalStructureGroupReference.ID), 
                    new XElement(ns + "Version", PhysicalStructureGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", PhysicalStructureGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

