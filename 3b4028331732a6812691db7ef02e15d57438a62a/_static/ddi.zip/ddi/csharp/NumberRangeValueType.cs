using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes a bounding value for a number range expressed as an xs:demical.
    /// <summary>
    public partial class NumberRangeValueType : decimal
    {
        /// <summary>
        /// Indicates that the value is included in the range. Set to false if the range includes numbers up to but no including the designated value.
        /// <summary>
        public bool IsInclusive { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("decimal").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "IsInclusive", IsInclusive));
            return xEl;
        }
    }
}

