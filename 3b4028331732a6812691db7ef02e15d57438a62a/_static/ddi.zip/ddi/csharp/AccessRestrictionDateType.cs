using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The date or date range of the access restriction for all or portions of the data. Includes a reason for the access restriction as well as the user group to which the restriction applies.
    /// <summary>
    public partial class AccessRestrictionDateType : DateType
    {
        /// <summary>
        /// The reason for the access restriction.
        /// <summary>
        public StructuredStringType Reason { get; set; }
        /// <summary>
        /// The user group to whom the restriction applies
        /// <summary>
        public StructuredStringType User { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("DateType").Descendants())
            {
                xEl.Add(el);
            }
            if (Reason != null) { xEl.Add(Reason.ToXml("Reason")); }
            if (User != null) { xEl.Add(User.ToXml("User")); }
            return xEl;
        }
    }
}

