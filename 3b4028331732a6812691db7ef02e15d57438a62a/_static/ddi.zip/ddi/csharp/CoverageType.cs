using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the temporal, spatial and topical coverage. At the instance level these descriptions should be inclusive of the coverage of all modules in the instance. The element is available within individual modules and can be used to refine the coverage to that of the individual module.
    /// <summary>
    public partial class CoverageType
    {
        /// <summary>
        /// Reference to a previously defined topical coverage.
        /// <summary>
        public TopicalCoverageType TopicalCoverageReference { get; set; }
        /// <summary>
        /// Description of the topical coverage of the data described in a particular DDI module.
        /// <summary>
        public TopicalCoverageType TopicalCoverage { get; set; }
        /// <summary>
        /// Reference to a previously defined spatial coverage.
        /// <summary>
        public GeographicCoverageType SpatialCoverageReference { get; set; }
        /// <summary>
        /// Description of the geographic coverage of the data described in a particular DDI module.
        /// <summary>
        public GeographicCoverageType SpatialCoverage { get; set; }
        /// <summary>
        /// Reference to a previously defined temporal coverage.
        /// <summary>
        public TemporalCoverageType TemporalCoverageReference { get; set; }
        /// <summary>
        /// Description of the temporal coverage of the data described in a particular DDI module.
        /// <summary>
        public TemporalCoverageType TemporalCoverage { get; set; }
        /// <summary>
        /// Allows for a specific machine actionable description of the restriction process using a GenerationInstructionReference, if one currently exists, or through a CommandCode. In the case of a physical instance, the RestrictionProcess would be the same as a case, record or variable selection process.
        /// <summary>
        public RestrictionProcessType RestrictionProcess { get; set; }
        /// <summary>
        /// If the coverage described within this object is a restriction of the coverage of its parent study or group set this attribute to "true". If the coverage of a specific type (spatial, topical, or temporal) is not a restriction, include this coverage type by reference to that described in parent. Create a new coverage for the type being restricted.
        /// <summary>
        public bool IsRestrictionOfParentCoverage { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (TopicalCoverageReference != null) { xEl.Add(TopicalCoverageReference.ToXml("TopicalCoverageReference")); }
            if (TopicalCoverage != null) { xEl.Add(TopicalCoverage.ToXml("TopicalCoverage")); }
            if (SpatialCoverageReference != null) { xEl.Add(SpatialCoverageReference.ToXml("SpatialCoverageReference")); }
            if (SpatialCoverage != null) { xEl.Add(SpatialCoverage.ToXml("SpatialCoverage")); }
            if (TemporalCoverageReference != null) { xEl.Add(TemporalCoverageReference.ToXml("TemporalCoverageReference")); }
            if (TemporalCoverage != null) { xEl.Add(TemporalCoverage.ToXml("TemporalCoverage")); }
            if (RestrictionProcess != null) { xEl.Add(RestrictionProcess.ToXml("RestrictionProcess")); }
            xEl.Add(new XElement(ns + "IsRestrictionOfParentCoverage", IsRestrictionOfParentCoverage));
            return xEl;
        }
    }
}

