using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Holds the name of the publisher with their role and/or a reference to the publisher as described within a DDI Organization scheme. Repeat this element for multiple publishers.
    /// <summary>
    public partial class PublisherType
    {
        /// <summary>
        /// Full name of the publisher. Language equivalents should be expressed within the International String structure.
        /// <summary>
        public BibliographicNameType PublisherName { get; set; }
        /// <summary>
        /// The role of the publisher as publisher, distributor, etc.
        /// <summary>
        public List<CodeValueType> PublisherRole { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializePublisherRole() { return PublisherRole.Count > 0; }
        /// <summary>
        /// Reference to a publisher as described within a DDI Organization Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization PublisherReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (PublisherName != null) { xEl.Add(PublisherName.ToXml("PublisherName")); }
            if (PublisherRole != null && PublisherRole.Count > 0)
            {
                foreach (var item in PublisherRole)
                {
                    xEl.Add(item.ToXml("PublisherRole"));
                }
            }
            if (PublisherReference != null)
            {
                xEl.Add(new XElement(ns + "PublisherReference", 
                    new XElement(ns + "URN", PublisherReference.URN), 
                    new XElement(ns + "Agency", PublisherReference.Agency), 
                    new XElement(ns + "ID", PublisherReference.ID), 
                    new XElement(ns + "Version", PublisherReference.Version), 
                    new XElement(ns + "TypeOfObject", PublisherReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

