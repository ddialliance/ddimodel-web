using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides bibliographic citation information for a DDI instance, a group of studies, a study unit, or a physical instance. Note that a native DDI citation is required - the citation information may be repeated using DCElements if desired, but a citation must not consist only of DCElements.
    /// <summary>
    public partial class CitationType
    {
        /// <summary>
        /// Full authoritative title. List any additional titles for this item as AlternativeTitle.
        /// <summary>
        public InternationalStringType Title { get; set; }
        /// <summary>
        /// Secondary or explanatory title.
        /// <summary>
        public List<InternationalStringType> SubTitle { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeSubTitle() { return SubTitle.Count > 0; }
        /// <summary>
        /// An alternative title by which a data collection is commonly referred, or an abbreviation  for the title.
        /// <summary>
        public List<InternationalStringType> AlternateTitle { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeAlternateTitle() { return AlternateTitle.Count > 0; }
        /// <summary>
        /// Person, corporate body, or agency responsible for the substantive and intellectual content of the described object.
        /// <summary>
        public List<CreatorType> Creator { get; set; } = new List<CreatorType>();
        public bool ShouldSerializeCreator() { return Creator.Count > 0; }
        /// <summary>
        /// Person or organization responsible for making the resource available in its present form.
        /// <summary>
        public List<PublisherType> Publisher { get; set; } = new List<PublisherType>();
        public bool ShouldSerializePublisher() { return Publisher.Count > 0; }
        /// <summary>
        /// The name of a contributing author or creator, who worked in support of the primary creator given above.
        /// <summary>
        public List<ContributorType> Contributor { get; set; } = new List<ContributorType>();
        public bool ShouldSerializeContributor() { return Contributor.Count > 0; }
        /// <summary>
        /// The date of publication.
        /// <summary>
        public DateType PublicationDate { get; set; }
        /// <summary>
        /// Language of the intellectual content of the described object. Strongly recommend the use of language codes supported by xs:language which include the 2 and 3 character and extended structures defined by RFC4646 or its successors.
        /// <summary>
        public List<CodeValueType> Language { get; set; } = new List<CodeValueType>();
        public bool ShouldSerializeLanguage() { return Language.Count > 0; }
        /// <summary>
        /// An identifier whose scope of uniqueness is broader than the local archive. Common forms of an international identifier are ISBN, ISSN, DOI or similar designator.
        /// <summary>
        public List<InternationalIdentifierType> InternationalIdentifier { get; set; } = new List<InternationalIdentifierType>();
        public bool ShouldSerializeInternationalIdentifier() { return InternationalIdentifier.Count > 0; }
        /// <summary>
        /// The copyright statement.
        /// <summary>
        public List<InternationalStringType> Copyright { get; set; } = new List<InternationalStringType>();
        public bool ShouldSerializeCopyright() { return Copyright.Count > 0; }
        /// <summary>
        /// Element including a sequence of Dublin Core fields that may be used to supplement - but not replace - the DDI citation.
        /// <summary>
        public List<dcTerms> DcTerms { get; set; } = new List<dcTerms>();
        public bool ShouldSerializeDcTerms() { return DcTerms.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Title != null) { xEl.Add(Title.ToXml("Title")); }
            if (SubTitle != null && SubTitle.Count > 0)
            {
                foreach (var item in SubTitle)
                {
                    xEl.Add(item.ToXml("SubTitle"));
                }
            }
            if (AlternateTitle != null && AlternateTitle.Count > 0)
            {
                foreach (var item in AlternateTitle)
                {
                    xEl.Add(item.ToXml("AlternateTitle"));
                }
            }
            if (Creator != null && Creator.Count > 0)
            {
                foreach (var item in Creator)
                {
                    xEl.Add(item.ToXml("Creator"));
                }
            }
            if (Publisher != null && Publisher.Count > 0)
            {
                foreach (var item in Publisher)
                {
                    xEl.Add(item.ToXml("Publisher"));
                }
            }
            if (Contributor != null && Contributor.Count > 0)
            {
                foreach (var item in Contributor)
                {
                    xEl.Add(item.ToXml("Contributor"));
                }
            }
            if (PublicationDate != null) { xEl.Add(PublicationDate.ToXml("PublicationDate")); }
            if (Language != null && Language.Count > 0)
            {
                foreach (var item in Language)
                {
                    xEl.Add(item.ToXml("Language"));
                }
            }
            if (InternationalIdentifier != null && InternationalIdentifier.Count > 0)
            {
                foreach (var item in InternationalIdentifier)
                {
                    xEl.Add(item.ToXml("InternationalIdentifier"));
                }
            }
            if (Copyright != null && Copyright.Count > 0)
            {
                foreach (var item in Copyright)
                {
                    xEl.Add(item.ToXml("Copyright"));
                }
            }
            if (DcTerms != null && DcTerms.Count > 0)
            {
                xEl.Add(
                    from item in DcTerms
                    select new XElement(ns + "DcTerms", item.ToString()));
            }
            return xEl;
        }
    }
}

