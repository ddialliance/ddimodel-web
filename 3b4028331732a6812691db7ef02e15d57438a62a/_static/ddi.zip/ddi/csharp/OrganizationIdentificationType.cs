using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of identifying an organization. The structure contains a repeatable OrganizationName. At minimum enter the current legal or formal name setting the attribute isFormal to "true". Additional OrganizationNames may be provided that have a) a specific contextual usage, or b) are of specific types (e.g. PreviousFormalName). The DDI Maintenance Agency ID and and organization images, such as a building picture or logo are found in OrganizationIdentification. Images and names can be individually date stamped.
    /// <summary>
    public partial class OrganizationIdentificationType
    {
        /// <summary>
        /// Names by which the organization is known. Use the attribute isFormal="true" to designate the legal or formal name of the Organization. The preferred name should be noted with the isPreferred attribute. Names may be typed with TypeOfOrganizationName to indicate their appropriate usage.
        /// <summary>
        public List<OrganizationNameType> OrganizationName { get; set; } = new List<OrganizationNameType>();
        public bool ShouldSerializeOrganizationName() { return OrganizationName.Count > 0; }
        /// <summary>
        /// Contains the official DDI ID of the maintenance agency as registered with the DDI registry by the parent organization or individual. A single organization or individual may have one or more DDI Maintenance Agency IDs registered within the DDI registry (i.e., an organization may have a DDI Maintenance Agency ID for each project managed by the organization) The structure of this string is described by Part I of the Technical Documentation and the content is registered within the DDI registry as a unique identifier.
        /// <summary>
        public List<DDIMaintenanceAgencyIDType> DDIMaintenanceAgencyID { get; set; } = new List<DDIMaintenanceAgencyIDType>();
        public bool ShouldSerializeDDIMaintenanceAgencyID() { return DDIMaintenanceAgencyID.Count > 0; }
        /// <summary>
        /// Provides an external link to images associated with the individual.
        /// <summary>
        public List<PrivateImageType> OrganizationImage { get; set; } = new List<PrivateImageType>();
        public bool ShouldSerializeOrganizationImage() { return OrganizationImage.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (OrganizationName != null && OrganizationName.Count > 0)
            {
                foreach (var item in OrganizationName)
                {
                    xEl.Add(item.ToXml("OrganizationName"));
                }
            }
            if (DDIMaintenanceAgencyID != null && DDIMaintenanceAgencyID.Count > 0)
            {
                foreach (var item in DDIMaintenanceAgencyID)
                {
                    xEl.Add(item.ToXml("DDIMaintenanceAgencyID"));
                }
            }
            if (OrganizationImage != null && OrganizationImage.Count > 0)
            {
                foreach (var item in OrganizationImage)
                {
                    xEl.Add(item.ToXml("OrganizationImage"));
                }
            }
            return xEl;
        }
    }
}

