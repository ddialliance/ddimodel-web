using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A choice of a BoundingBox and/or a set of BoundingPolygons and ExcludingPolygons that describe an area for a specific time period.
    /// <summary>
    public partial class GeographicBoundaryType
    {
        /// <summary>
        /// Use to specify the area of land, water, total or other area coverage in terms of square miles/kilometers or other measures.
        /// <summary>
        public List<AreaCoverageType> AreaCoverage { get; set; } = new List<AreaCoverageType>();
        public bool ShouldSerializeAreaCoverage() { return AreaCoverage.Count > 0; }
        /// <summary>
        /// A BoundingBox (North, South Latitude and East, West Longitude) of the LocationValue for the time period specified with the GeographicBoundary.
        /// <summary>
        public BoundingBoxType BoundingBox { get; set; }
        /// <summary>
        /// A description of the boundaries of the polygon either in-line or by a reference to an external file containing the boundaries. Repeatable to describe non-contiguous areas such as islands or Native American Reservations in some parts of the United States.
        /// <summary>
        public List<PolygonType> BoundingPolygon { get; set; } = new List<PolygonType>();
        public bool ShouldSerializeBoundingPolygon() { return BoundingPolygon.Count > 0; }
        /// <summary>
        /// A description of a the boundaries of a polygon internal to the bounding polygon which should be excluded. For example, for the bounding polygon describing the State of Brandenburg in Germany, the Excluding Polygon would describe the boundary of Berlin, creating hole within Brandenburg which is occupied by Berlin.
        /// <summary>
        public List<PolygonType> ExcludingPolygon { get; set; } = new List<PolygonType>();
        public bool ShouldSerializeExcludingPolygon() { return ExcludingPolygon.Count > 0; }
        /// <summary>
        /// A time for which the polygon is an accurate description of the area. This may be a range (without an end date if currently still valid) or a single date when the shape was know to be valid if a range is not available.
        /// <summary>
        public DateType GeographicTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (AreaCoverage != null && AreaCoverage.Count > 0)
            {
                foreach (var item in AreaCoverage)
                {
                    xEl.Add(item.ToXml("AreaCoverage"));
                }
            }
            if (BoundingBox != null) { xEl.Add(BoundingBox.ToXml("BoundingBox")); }
            if (BoundingPolygon != null && BoundingPolygon.Count > 0)
            {
                foreach (var item in BoundingPolygon)
                {
                    xEl.Add(item.ToXml("BoundingPolygon"));
                }
            }
            if (ExcludingPolygon != null && ExcludingPolygon.Count > 0)
            {
                foreach (var item in ExcludingPolygon)
                {
                    xEl.Add(item.ToXml("ExcludingPolygon"));
                }
            }
            if (GeographicTime != null) { xEl.Add(GeographicTime.ToXml("GeographicTime")); }
            return xEl;
        }
    }
}

