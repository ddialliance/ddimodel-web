using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to an existing GeographicLocation using the Reference structure plus the ability to exclude any number of contained location values as specified by reference. TypeOfObject should be set to GeographicLocation.
    /// <summary>
    public partial class GeographicLocationReferenceType : ReferenceType
    {
        /// <summary>
        /// Reference to a LocationValue within the referenced GeographicLocation which should be excluded. Each excluded location value should be specified by reference.
        /// <summary>
        public List<LocationValueType> ExcludedLocationValueReference { get; set; } = new List<LocationValueType>();
        public bool ShouldSerializeExcludedLocationValueReference() { return ExcludedLocationValueReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (ExcludedLocationValueReference != null && ExcludedLocationValueReference.Count > 0)
            {
                foreach (var item in ExcludedLocationValueReference)
                {
                    xEl.Add(item.ToXml("ExcludedLocationValueReference"));
                }
            }
            return xEl;
        }
    }
}

