using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A means of capturing a managed representation of a numbers (item that are analyzed as numbers) which can be referenced by a variable or question and used as a value representation or response domain. In addition to the name, label, and description of the managed numeric representation, the structure defines the number range of valid values, plus information on the format, scale, number of decimals, and intervals between valid responses within the range.
    /// <summary>
    public partial class ManagedNumericRepresentation : Versionable
    {
        /// <summary>
        /// A name for the ManagedNumericRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ManagedNumericRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedNumericRepresentationName() { return ManagedNumericRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the representation. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the representation. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Defines the valid number range or number values for the representation.
        /// <summary>
        public List<NumberRangeType> NumberRange { get; set; } = new List<NumberRangeType>();
        public bool ShouldSerializeNumberRange() { return NumberRange.Count > 0; }
        /// <summary>
        /// Identification of the numeric type such as integer, decimal, etc. supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType NumericTypeCode { get; set; }
        /// <summary>
        /// A format for number expressed as a string.
        /// <summary>
        public string Format { get; set; }
        /// <summary>
        /// The scale of the number expressed as an integer (for example a number expressed in 100's, 5 = 500 would have a scale of 100).
        /// <summary>
        public int Scale { get; set; }
        /// <summary>
        /// The number of decimal positions expressed as an integer (precision of the number).
        /// <summary>
        public int DecimalPositions { get; set; }
        /// <summary>
        /// The interval between valid responses expressed as an integer.
        /// <summary>
        public int Interval { get; set; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "ManagedNumericRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedNumericRepresentationName != null && ManagedNumericRepresentationName.Count > 0)
            {
                foreach (var item in ManagedNumericRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedNumericRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (NumberRange != null && NumberRange.Count > 0)
            {
                foreach (var item in NumberRange)
                {
                    xEl.Add(item.ToXml("NumberRange"));
                }
            }
            if (NumericTypeCode != null) { xEl.Add(NumericTypeCode.ToXml("NumericTypeCode")); }
            if (Format != null)
            {
                xEl.Add(new XElement(ns + "Format", Format));
            }
            xEl.Add(new XElement(ns + "Scale", Scale));
            xEl.Add(new XElement(ns + "DecimalPositions", DecimalPositions));
            xEl.Add(new XElement(ns + "Interval", Interval));
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

