using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Category statistics filtered by the value of a second variable. Essentially a cross tabulation of one variable by another. For example variable may be crossed with country as is done in the Eurobarometer when reporting category statistics. For example, the Eurobarometer may filter its category statistics by country as represented in a variable "CountryCode".
    /// <summary>
    public partial class FilteredCategoryStatisticsType
    {
        /// <summary>
        /// Reference to the variable used to filter the category level statistics. 
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable FilterVariableReference { get; set; }
        /// <summary>
        /// Provides filtered category statistics for the specified filter variable category.
        /// <summary>
        public List<FilterVariableCategoryType> FilterVariableCategory { get; set; } = new List<FilterVariableCategoryType>();
        public bool ShouldSerializeFilterVariableCategory() { return FilterVariableCategory.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (FilterVariableReference != null)
            {
                xEl.Add(new XElement(ns + "FilterVariableReference", 
                    new XElement(ns + "URN", FilterVariableReference.URN), 
                    new XElement(ns + "Agency", FilterVariableReference.Agency), 
                    new XElement(ns + "ID", FilterVariableReference.ID), 
                    new XElement(ns + "Version", FilterVariableReference.Version), 
                    new XElement(ns + "TypeOfObject", FilterVariableReference.GetType().Name)));
            }
            if (FilterVariableCategory != null && FilterVariableCategory.Count > 0)
            {
                foreach (var item in FilterVariableCategory)
                {
                    xEl.Add(item.ToXml("FilterVariableCategory"));
                }
            }
            return xEl;
        }
    }
}

