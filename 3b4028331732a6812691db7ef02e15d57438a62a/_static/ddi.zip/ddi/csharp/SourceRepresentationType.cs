using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a reference to the managed content of a representation which may be a ManagedRepresentation or a specific CodeList, GeographicRepresentation, or GeographicLocation. Allows for the optional reference to a Concept when context is important. For example, a ManagedNumericRepresentation within the context of Age.
    /// <summary>
    public partial class SourceRepresentationType
    {
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ManagedRepresentationReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ManagedRepresentationReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ManagedRepresentationReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ManagedRepresentationReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ManagedRepresentationReference_ManagedTextRepresentation { get; set; }
        /// <summary>
        /// A reference to a CategoryScheme as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }
        /// <summary>
        /// A reference to a CodeList as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CodeList CodeListReference { get; set; }
        /// <summary>
        /// A reference to a GeographicStructure as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicStructure GeographicStructureReference { get; set; }
        /// <summary>
        /// A reference to a GeographicLocation as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public GeographicLocation GeographicLocationReference { get; set; }
        /// <summary>
        /// Reference to a Concept which provides a context for the representation, e.g. Age for a numeric representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ManagedRepresentationReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedTextRepresentation.GetType().Name)));
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            if (CodeListReference != null)
            {
                xEl.Add(new XElement(ns + "CodeListReference", 
                    new XElement(ns + "URN", CodeListReference.URN), 
                    new XElement(ns + "Agency", CodeListReference.Agency), 
                    new XElement(ns + "ID", CodeListReference.ID), 
                    new XElement(ns + "Version", CodeListReference.Version), 
                    new XElement(ns + "TypeOfObject", CodeListReference.GetType().Name)));
            }
            if (GeographicStructureReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicStructureReference", 
                    new XElement(ns + "URN", GeographicStructureReference.URN), 
                    new XElement(ns + "Agency", GeographicStructureReference.Agency), 
                    new XElement(ns + "ID", GeographicStructureReference.ID), 
                    new XElement(ns + "Version", GeographicStructureReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicStructureReference.GetType().Name)));
            }
            if (GeographicLocationReference != null)
            {
                xEl.Add(new XElement(ns + "GeographicLocationReference", 
                    new XElement(ns + "URN", GeographicLocationReference.URN), 
                    new XElement(ns + "Agency", GeographicLocationReference.Agency), 
                    new XElement(ns + "ID", GeographicLocationReference.ID), 
                    new XElement(ns + "Version", GeographicLocationReference.Version), 
                    new XElement(ns + "TypeOfObject", GeographicLocationReference.GetType().Name)));
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

