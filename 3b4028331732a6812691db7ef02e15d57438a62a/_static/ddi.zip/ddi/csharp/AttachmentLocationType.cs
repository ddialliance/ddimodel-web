using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows attachment of a response domain to a specific item in a code or category scheme. For example, attach a TextDomain to the value "Other".
    /// <summary>
    public partial class AttachmentLocationType
    {
        /// <summary>
        /// Identifies the value to which the new response domain is attached by a references a specific Code within the CodeDomain.
        /// <summary>
        public CodeType CodeReference { get; set; }
        /// <summary>
        /// Identifies the value to which the new response domain is attached by a references a specific Category within the CategoryDomain.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Category CategoryReference { get; set; }
        /// <summary>
        /// Identifies the value to which the new response domain is attached by a reference to a specific value used by the response domain and the specific value.
        /// <summary>
        public DomainSpecificValueType DomainSpecificValue { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (CodeReference != null) { xEl.Add(CodeReference.ToXml("CodeReference")); }
            if (CategoryReference != null)
            {
                xEl.Add(new XElement(ns + "CategoryReference", 
                    new XElement(ns + "URN", CategoryReference.URN), 
                    new XElement(ns + "Agency", CategoryReference.Agency), 
                    new XElement(ns + "ID", CategoryReference.ID), 
                    new XElement(ns + "Version", CategoryReference.Version), 
                    new XElement(ns + "TypeOfObject", CategoryReference.GetType().Name)));
            }
            if (DomainSpecificValue != null) { xEl.Add(DomainSpecificValue.ToXml("DomainSpecificValue")); }
            return xEl;
        }
    }
}

