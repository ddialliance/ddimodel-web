using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Reference to an interviewer instruction expressed as DDI XML plus a flag to designate whether the instruction should always be displayed. TypeOfObject should be set to InterviewerInstruction.
    /// <summary>
    public partial class InterviewerInstructionReferenceType : ReferenceType
    {
        /// <summary>
        /// Allows attachment of an instruction to a specific item in a question structure. For example, to a Label, QuestionText, ResponseDomain, Response domain value, or grid cell.
        /// <summary>
        public List<InstructionAttachmentLocationType> InstructionAttachmentLocation { get; set; } = new List<InstructionAttachmentLocationType>();
        public bool ShouldSerializeInstructionAttachmentLocation() { return InstructionAttachmentLocation.Count > 0; }
        /// <summary>
        /// If set to "true" the content of the instruction is intended to be displayed. If set to "false" the preference is for the instruction to be displayed upon request if this is supported by the mode of presentation.
        /// <summary>
        public bool IsDisplayed { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("ReferenceType").Descendants())
            {
                xEl.Add(el);
            }
            if (InstructionAttachmentLocation != null && InstructionAttachmentLocation.Count > 0)
            {
                foreach (var item in InstructionAttachmentLocation)
                {
                    xEl.Add(item.ToXml("InstructionAttachmentLocation"));
                }
            }
            xEl.Add(new XElement(ns + "IsDisplayed", IsDisplayed));
            return xEl;
        }
    }
}

