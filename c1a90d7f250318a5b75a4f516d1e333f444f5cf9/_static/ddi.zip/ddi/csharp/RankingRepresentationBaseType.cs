using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A means of capturing the representation of Ranking to be used as a response domain used by a question. In addition to the basic objects of the representation, the structure defines the range used for ranking including the number of times an individual value may be repeated.
    /// <summary>
    public class RankingRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// The allowed values expressed using Range (allows for non-numeric values). In addition, defines the number of times a value may be used in expressing a ranking.
        /// <summary>
        public RankingRangeType RankingRange { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RankingRange != null) { xEl.Add(RankingRange.ToXml("RankingRange")); }
            return xEl;
        }
    }
}

