using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the official DDI ID of a maintenance agency as a value taken from the registry cited in @registryID.
    /// <summary>
    public class DDIMaintenanceAgencyIDType : string
    {
        /// <summary>
        /// Currently there is only a single DDI Agency Registry. Use "DDIAgencyRegistry".
        /// <summary>
        public string RegistryID { get; set; }
        /// <summary>
        /// The date when this agency ID was registered or become active.
        /// <summary>
        [JsonConverter(typeof(DateTimeConverter))]
        public DateTimeOffset StartDate_dateTime { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (RegistryID != null)
            {
                xEl.Add(new XElement(ns + "RegistryID", RegistryID));
            }
            if (StartDate_dateTime != default(DateTimeOffset))
            {
                xEl.Add(new XElement(ns + "StartDate_dateTime", StartDate_dateTime.ToString("yyyy-MM-dd\\THH:mm:ss.FFFFFFFK")));
            }
            return xEl;
        }
    }
}

