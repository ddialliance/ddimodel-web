using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Defines the shape and area of an image used as part of a location representation. The shape is defined as a Rectangle, Circle, or Polygon and Coordinates provides the information required to define it.
    /// <summary>
    public class ImageAreaType
    {
        /// <summary>
        /// A fixed set of valid responses includes Rectangle, Circle, and Polygon.
        /// <summary>
        [StringValidation(new string[] {
            "Rectangle"
,             "Circle"
,             "Polygon"
        })]
        public string Shape { get; set; }
        /// <summary>
        /// A comma-delimited list of x,y coordinates, listed as a set of adjacent points for rectangles and polygons, and as a center-point and a radius for circles (x,y,r).
        /// <summary>
        public string Coordinates { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Shape != null)
            {
                xEl.Add(new XElement(ns + "Shape", Shape));
            }
            if (Coordinates != null)
            {
                xEl.Add(new XElement(ns + "Coordinates", Coordinates));
            }
            return xEl;
        }
    }
}

