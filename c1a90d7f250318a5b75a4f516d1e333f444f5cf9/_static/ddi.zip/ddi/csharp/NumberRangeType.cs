using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Structures a numeric range. Low and High values are designated. The structure identifies Low values that should be treated as bottom coded (Stated value and bellow, High values that should be treated as top coded (stated value and higher), and provides a regular expression to further define the valid content of the range.
    /// <summary>
    public class NumberRangeType
    {
        /// <summary>
        /// A display label for the number range. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// The lower bound of the range expressed in the datatype xs:decimal. If not present, then there is no lower bound.
        /// <summary>
        public NumberRangeValueType Low { get; set; }
        /// <summary>
        /// The lower bound of the range expressed in the datatype xs:double. If not present, then there is no lower bound.
        /// <summary>
        public DoubleNumberRangeValueType LowDouble { get; set; }
        /// <summary>
        /// The upper bound of the range in the datatype xs:decimal. If not present, then there is no upper bound.
        /// <summary>
        public NumberRangeValueType High { get; set; }
        /// <summary>
        /// The upper bound of the range in the datatype xs:double. If not present, then there is no upper bound.
        /// <summary>
        public DoubleNumberRangeValueType HighDouble { get; set; }
        /// <summary>
        /// Indicates that any response equal to or greater than this value has been coded as the top-code value. Expressed in the datatype xs:decimal.
        /// <summary>
        public decimal TopCode { get; set; }
        /// <summary>
        /// Indicates that any response equal to or greater than this value has been coded as the top-code value. Expressed in the datatype xs:decimal.
        /// <summary>
        public double TopCodeDouble { get; set; }
        /// <summary>
        /// Indicates that any response equal to or less than this value has been coded as the bottom-code value. Expressed in the datatype xs:double.
        /// <summary>
        public decimal BottomCode { get; set; }
        /// <summary>
        /// Indicates that any response equal to or less than this value has been coded as the bottom-code value. Expressed in the datatype xs:double.
        /// <summary>
        public double BottomCodeDouble { get; set; }
        /// <summary>
        /// Regular expression defining the allowed syntax of the number.
        /// <summary>
        public string RegExp { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Low != null) { xEl.Add(Low.ToXml("Low")); }
            if (LowDouble != null) { xEl.Add(LowDouble.ToXml("LowDouble")); }
            if (High != null) { xEl.Add(High.ToXml("High")); }
            if (HighDouble != null) { xEl.Add(HighDouble.ToXml("HighDouble")); }
            if (TopCode != null)
            {
                xEl.Add(new XElement(ns + "TopCode", TopCode));
            }
            xEl.Add(new XElement(ns + "TopCodeDouble", TopCodeDouble));
            if (BottomCode != null)
            {
                xEl.Add(new XElement(ns + "BottomCode", BottomCode));
            }
            xEl.Add(new XElement(ns + "BottomCodeDouble", BottomCodeDouble));
            if (RegExp != null)
            {
                xEl.Add(new XElement(ns + "RegExp", RegExp));
            }
            return xEl;
        }
    }
}

