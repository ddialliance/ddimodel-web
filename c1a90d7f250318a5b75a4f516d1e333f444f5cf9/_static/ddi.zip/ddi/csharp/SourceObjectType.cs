using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the Source organization or individual in the relationship. References either an Organization or an Individual and specifies their relationship in terms of parent, child, or sibling.
    /// <summary>
    public class SourceObjectType
    {
        /// <summary>
        /// A reference to an Organization described in DDI.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Organization OrganizationReference { get; set; }
        /// <summary>
        /// A reference to an Individual described in DDI.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Individual IndividualReference { get; set; }
        /// <summary>
        /// A specification of the relationship of the Source to the Target in terms of Parent (superior), Child (subordinate), or Sibling (on par).
        /// <summary>
        [StringValidation(new string[] {
            "Parent"
,             "Child"
,             "Sibling"
        })]
        public string RelationshipCode { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (OrganizationReference != null)
            {
                xEl.Add(new XElement(ns + "OrganizationReference", 
                    new XElement(ns + "URN", OrganizationReference.URN), 
                    new XElement(ns + "Agency", OrganizationReference.Agency), 
                    new XElement(ns + "ID", OrganizationReference.ID), 
                    new XElement(ns + "Version", OrganizationReference.Version), 
                    new XElement(ns + "TypeOfObject", OrganizationReference.GetType().Name)));
            }
            if (IndividualReference != null)
            {
                xEl.Add(new XElement(ns + "IndividualReference", 
                    new XElement(ns + "URN", IndividualReference.URN), 
                    new XElement(ns + "Agency", IndividualReference.Agency), 
                    new XElement(ns + "ID", IndividualReference.ID), 
                    new XElement(ns + "Version", IndividualReference.Version), 
                    new XElement(ns + "TypeOfObject", IndividualReference.GetType().Name)));
            }
            if (RelationshipCode != null)
            {
                xEl.Add(new XElement(ns + "RelationshipCode", RelationshipCode));
            }
            return xEl;
        }
    }
}

