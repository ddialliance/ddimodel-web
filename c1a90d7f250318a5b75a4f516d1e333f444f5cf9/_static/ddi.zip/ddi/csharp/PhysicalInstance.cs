using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Includes information about the physical instance of a data product (an actual data file). It completes the documentation contained in the Physical Data Product module that is specific to the individual file and serves as a descriptive record of the external data file. Physical Instance provides a citation for the data file, a link to the RecordLayout(s) used by the files records, a description of it coverage (as a constraint if different from the study), check figures for quality control (e.g. digital fingerprint, record count, etc.), and a statistical summary of the data in the file at both the variable and category level.
    /// <summary>
    public class PhysicalInstance : Maintainable
    {
        /// <summary>
        /// A citation for the physical instance of a data set. Note that a DOI or similar unique identifier for the data file should be placed in InternationalIdentifier. It is strongly recommended that use of a Citation in this location includes the use of the optional sub-element Title.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// Allows for assigning a hash value (digital fingerprint) to the data or data file. Set the attribute flag to "data" when the hash value provides a digital fingerprint to the data contained in the file regardless of the storage format (ASCII, SAS, binary, etc.). One approach to compute a data fingerprint is the Universal Numerical Fingerprint (UNF). Set the attribute flag to "dataFile" if the digital fingerprint is only for the data file in its current storage format.
        /// <summary>
        public List<DataFingerprintType> DataFingerprint { get; set; } = new List<DataFingerprintType>();
        public bool ShouldSerializeDataFingerprint() { return DataFingerprint.Count > 0; }
        /// <summary>
        /// Includes information about the topical, spatial, and temporal coverage of the physical instance. May be expressed as a restriction of the parent study coverage.
        /// <summary>
        public CoverageType Coverage { get; set; }
        /// <summary>
        /// Provides information about other resources related to the physical instance.
        /// <summary>
        public List<OtherMaterialType> OtherMaterial { get; set; } = new List<OtherMaterialType>();
        public bool ShouldSerializeOtherMaterial() { return OtherMaterial.Count > 0; }
        /// <summary>
        /// Reference to the DataRelationship containing the LogicalRecord to which the RecordLayout refers. Repeat for cases where LogicalRecords are described in multiple DataRelationship structures. Note that this does not imply that all of the LogicalRecords described in the DataRelationship are contained, wholly or in part in the PhysicalInstance. This reference allows for a direct path between the PhysicalInstance and the related content found in a LogicalProduct.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<DataRelationship> DataRelationshipReference { get; set; } = new List<DataRelationship>();
        public bool ShouldSerializeDataRelationshipReference() { return DataRelationshipReference.Count > 0; }
        /// <summary>
        /// References the record layout of the data documented in the physical instance.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RecordLayout> RecordLayoutReference { get; set; } = new List<RecordLayout>();
        public bool ShouldSerializeRecordLayoutReference() { return RecordLayoutReference.Count > 0; }
        /// <summary>
        /// References the content of the default missing values used in the file. The content of this file overrides default missing value information provided in the LogicalRecord. Allows for the specification that is a Systems Missing Value.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation DefaultMissingValuesReference { get; set; }
        /// <summary>
        /// Identifies the data file documented in the physical instance and provides information about its location.
        /// <summary>
        public List<DataFileIdentificationType> DataFileIdentification { get; set; } = new List<DataFileIdentificationType>();
        public bool ShouldSerializeDataFileIdentification() { return DataFileIdentification.Count > 0; }
        /// <summary>
        /// Provides the version information for the data file related to this physical instance. Note that while Physical Instance allows for multiple copies of the same data file (such as backup copies) the assumption is that they are identical in terms of content, layout, format and version.
        /// <summary>
        public DataFileVersionType DataFileVersion { get; set; }
        /// <summary>
        /// A reference to a Quality Statement pertaining to the quality of the study methodology, metadata, or data to which it is associated. Quality statements may be related to external quality standards.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// Includes information about the file structure, as well as other characteristics that are specific to the physical instance.
        /// <summary>
        public GrossFileStructureType GrossFileStructure { get; set; }
        /// <summary>
        /// Contains information proprietary to the software package which produced the data file. This is expressed as a set of name-value pairs. The value may be taken from a controlled vocabulary.
        /// <summary>
        public ProprietaryInfoType ProprietaryInfo { get; set; }
        /// <summary>
        /// Includes variable and category statistics data documented in the physical instance, or a reference to a physical instance where the statistics are described or located in line.
        /// <summary>
        public StatisticalSummaryType StatisticalSummary { get; set; }
        /// <summary>
        /// Contains a term from a controlled vocabulary indicating the byte ordering.
        /// <summary>
        public CodeValueType ByteOrder { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "PhysicalInstance");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (DataFingerprint != null && DataFingerprint.Count > 0)
            {
                foreach (var item in DataFingerprint)
                {
                    xEl.Add(item.ToXml("DataFingerprint"));
                }
            }
            if (Coverage != null) { xEl.Add(Coverage.ToXml("Coverage")); }
            if (OtherMaterial != null && OtherMaterial.Count > 0)
            {
                foreach (var item in OtherMaterial)
                {
                    xEl.Add(item.ToXml("OtherMaterial"));
                }
            }
            if (DataRelationshipReference != null && DataRelationshipReference.Count > 0)
            {
                foreach (var item in DataRelationshipReference)
                {
                    xEl.Add(new XElement(ns + "DataRelationshipReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RecordLayoutReference != null && RecordLayoutReference.Count > 0)
            {
                foreach (var item in RecordLayoutReference)
                {
                    xEl.Add(new XElement(ns + "RecordLayoutReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (DefaultMissingValuesReference != null)
            {
                xEl.Add(new XElement(ns + "DefaultMissingValuesReference", 
                    new XElement(ns + "URN", DefaultMissingValuesReference.URN), 
                    new XElement(ns + "Agency", DefaultMissingValuesReference.Agency), 
                    new XElement(ns + "ID", DefaultMissingValuesReference.ID), 
                    new XElement(ns + "Version", DefaultMissingValuesReference.Version), 
                    new XElement(ns + "TypeOfObject", DefaultMissingValuesReference.GetType().Name)));
            }
            if (DataFileIdentification != null && DataFileIdentification.Count > 0)
            {
                foreach (var item in DataFileIdentification)
                {
                    xEl.Add(item.ToXml("DataFileIdentification"));
                }
            }
            if (DataFileVersion != null) { xEl.Add(DataFileVersion.ToXml("DataFileVersion")); }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GrossFileStructure != null) { xEl.Add(GrossFileStructure.ToXml("GrossFileStructure")); }
            if (ProprietaryInfo != null) { xEl.Add(ProprietaryInfo.ToXml("ProprietaryInfo")); }
            if (StatisticalSummary != null) { xEl.Add(StatisticalSummary.ToXml("StatisticalSummary")); }
            if (ByteOrder != null) { xEl.Add(ByteOrder.ToXml("ByteOrder")); }
            return xEl;
        }
    }
}

