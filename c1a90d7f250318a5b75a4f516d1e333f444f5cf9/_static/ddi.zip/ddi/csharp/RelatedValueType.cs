using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The characteristic value expressed as a string with an indicator of the specific relationship of the variable value to the characteristic value. The default is "Equal". The value may be defined as containing no content (blank) by setting the attribute valueIsBlank to "true".
    /// <summary>
    public class RelatedValueType : ValueType
    {
        /// <summary>
        /// Indicates value type as "GreaterThan", LessThan", "Equal", "GreaterThanOrEqual", "LessThanOrEqual", or "NotEqual".
        /// <summary>
        [StringValidation(new string[] {
            "GreaterThan"
,             "LessThan"
,             "Equal"
,             "GreaterThanOrEqual"
,             "LessThanOrEqual"
,             "NotEqual"
        })]
        public string Type { get; set; }
        /// <summary>
        /// Set to "true" if the value of the conditional variable is blank.
        /// <summary>
        public bool ValueIsBlank { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (Type != null)
            {
                xEl.Add(new XElement(ns + "Type", Type));
            }
            xEl.Add(new XElement(ns + "ValueIsBlank", ValueIsBlank));
            return xEl;
        }
    }
}

