using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// This scheme contains a set of quality statements referenced by the metadata at different points in the lifecycle. In addition to the name, label, and description of the scheme, the structure supports the inclusion of another QualityStatementScheme by reference and a set of QualityStatement descriptions either in-line or by reference.
    /// <summary>
    public class QualityStatementScheme : Maintainable
    {
        /// <summary>
        /// A name for the scheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> QualityStatementSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeQualityStatementSchemeName() { return QualityStatementSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the scheme. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the scheme. May be expressed in multiple languages and supports the use of structured content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Inclusion of an existing QualityStatementScheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatementScheme> QualityStatementSchemeReference { get; set; } = new List<QualityStatementScheme>();
        public bool ShouldSerializeQualityStatementSchemeReference() { return QualityStatementSchemeReference.Count > 0; }
        /// <summary>
        /// In-line description of a QualityStatement. These are used by reference at various points in the lifecycle.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatement> QualityStatementReference { get; set; } = new List<QualityStatement>();
        public bool ShouldSerializeQualityStatementReference() { return QualityStatementReference.Count > 0; }
        /// <summary>
        /// In-line description of a group of QualityStatements.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<QualityStatementGroup> QualityStatementGroupReference { get; set; } = new List<QualityStatementGroup>();
        public bool ShouldSerializeQualityStatementGroupReference() { return QualityStatementGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + "QualityStatementScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (QualityStatementSchemeName != null && QualityStatementSchemeName.Count > 0)
            {
                foreach (var item in QualityStatementSchemeName)
                {
                    xEl.Add(item.ToXml("QualityStatementSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (QualityStatementSchemeReference != null && QualityStatementSchemeReference.Count > 0)
            {
                foreach (var item in QualityStatementSchemeReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementReference != null && QualityStatementReference.Count > 0)
            {
                foreach (var item in QualityStatementReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (QualityStatementGroupReference != null && QualityStatementGroupReference.Count > 0)
            {
                foreach (var item in QualityStatementGroupReference)
                {
                    xEl.Add(new XElement(ns + "QualityStatementGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

