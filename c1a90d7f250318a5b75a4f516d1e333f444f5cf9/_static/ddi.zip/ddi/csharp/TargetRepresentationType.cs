using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a reference to a codified representation. Supports the ability to limit code coverage as appropriate for the coding structure referenced.
    /// <summary>
    public class TargetRepresentationType
    {
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation ManagedRepresentationReference_ManagedMissingValuesRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedScaleRepresentation ManagedRepresentationReference_ManagedScaleRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedNumericRepresentation ManagedRepresentationReference_ManagedNumericRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedDateTimeRepresentation ManagedRepresentationReference_ManagedDateTimeRepresentation { get; set; }
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedTextRepresentation ManagedRepresentationReference_ManagedTextRepresentation { get; set; }
        /// <summary>
        /// A reference to a CategoryScheme as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }
        /// <summary>
        /// A reference to a CodeList as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CodeList CodeListReference { get; set; }
        /// <summary>
        /// Allows further specification of the codes to use from the CodeList.
        /// <summary>
        public CodeSubsetInformationType CodeSubsetInformation { get; set; }
        /// <summary>
        /// Identifies the Geographic Structure codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicStructureCodesType IncludedGeographicStructureCodes { get; set; }
        /// <summary>
        /// Identifies the Geographic Location codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicLocationCodesType IncludedGeographicLocationCodes { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "http://ddialliance.org/ddi";
            XElement xEl = new XElement(ns + name);
            if (ManagedRepresentationReference_ManagedMissingValuesRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedMissingValuesRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedMissingValuesRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedMissingValuesRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedMissingValuesRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedMissingValuesRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedMissingValuesRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedScaleRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedScaleRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedScaleRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedScaleRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedScaleRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedScaleRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedScaleRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedNumericRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedNumericRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedNumericRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedNumericRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedNumericRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedNumericRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedNumericRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedDateTimeRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedDateTimeRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedDateTimeRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedDateTimeRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedDateTimeRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedDateTimeRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedDateTimeRepresentation.GetType().Name)));
            }
            if (ManagedRepresentationReference_ManagedTextRepresentation != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference_ManagedTextRepresentation", 
                    new XElement(ns + "URN", ManagedRepresentationReference_ManagedTextRepresentation.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference_ManagedTextRepresentation.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference_ManagedTextRepresentation.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference_ManagedTextRepresentation.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference_ManagedTextRepresentation.GetType().Name)));
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            if (CodeListReference != null)
            {
                xEl.Add(new XElement(ns + "CodeListReference", 
                    new XElement(ns + "URN", CodeListReference.URN), 
                    new XElement(ns + "Agency", CodeListReference.Agency), 
                    new XElement(ns + "ID", CodeListReference.ID), 
                    new XElement(ns + "Version", CodeListReference.Version), 
                    new XElement(ns + "TypeOfObject", CodeListReference.GetType().Name)));
            }
            if (CodeSubsetInformation != null) { xEl.Add(CodeSubsetInformation.ToXml("CodeSubsetInformation")); }
            if (IncludedGeographicStructureCodes != null) { xEl.Add(IncludedGeographicStructureCodes.ToXml("IncludedGeographicStructureCodes")); }
            if (IncludedGeographicLocationCodes != null) { xEl.Add(IncludedGeographicLocationCodes.ToXml("IncludedGeographicLocationCodes")); }
            return xEl;
        }
    }
}

