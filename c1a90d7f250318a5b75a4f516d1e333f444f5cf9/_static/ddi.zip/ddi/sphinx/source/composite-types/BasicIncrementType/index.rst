BasicIncrementType
------------------

Describes the start, end, and increment value for an incremental string (numeric, character, or length).

.. contents::

Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/BasicIncrementType.svg

Properties
~~~~~~~~~~



