DefaultMissingValuesReferenceType
---------------------------------

Identifies the default missing value parameter for the this physical instance by referencing a ManagedMissingValuesRepresentation. Note that this MissingValues declaration overrides the value found in the LogicalRecord if it conflicts. The assumption is that this is a System Missing Value declaration, specific to the storage format of the file. If not, change the value of isSystemMissingValue to "false". TypeOfObject should be set to ManagedMissingValuesRepresentation.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/reusable-types/ReferenceType/index`
    * **DefaultMissingValuesReferenceType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/DefaultMissingValuesReferenceType.svg

Properties
~~~~~~~~~~

IsSystemMissingValue
********************

Type
    boolean
Cardinality
    0..1

The assumption is that this is a System Missing Value declaration, specific to the storage format of the file (default value of "true"). If not, change the value to "false".



