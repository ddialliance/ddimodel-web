CoordinateRegionType
--------------------

Defines the area of attachment for an NCube attribute. It may be defined as the NCube as a whole or as certain dimensions or values of dimensions.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* AbstractIdentifiableType
    * :doc:`/reusable-types/IdentifiableType/index`
        * **CoordinateRegionType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/CoordinateRegionType.svg

Properties
~~~~~~~~~~

Label
*****

Type
    :doc:`/reusable-types/LabelType/index`
Cardinality
    0..n

A display label for the CoordinateRegion. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.

UniverseReference
*****************

Type
    :doc:`/item-types/Universe/index`
Cardinality
    0..n

Reference to the universe statement containing a description of the persons or other elements that this CoordinateRegion refers to, and to which any analytic results refer. If more than one universe is referenced the universe of the CoordinateRegion is the intersect of the referenced universes. Use when the CoordinateRegion describes a subset of the NCube universe.

Description
***********

Type
    :doc:`/reusable-types/StructuredStringType/index`
Cardinality
    0..1

A description of the content of the CoordinateRegion. May be expressed in multiple languages and supports the use of structured content.

DimensionValue
**************

Type
    :doc:`/reusable-types/CohortType/index`
Cardinality
    0..n

Defines the included set of values needed to describe the coordinate region of the NCube on a Dimension by Dimension basis.



