DateTimeRepresentationBaseType
------------------------------

Structures the representation for any type of time format (including dates, etc.). Regardless of the format of the data the content may be treated as a date and or time and converted to ISO standard structure if sufficient information is supplied.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/reusable-types/RepresentationType/index`
    * **DateTimeRepresentationBaseType**
        * :doc:`/reusable-types/DateTimeDomainType/index`


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/DateTimeRepresentationBaseType.svg

Properties
~~~~~~~~~~

DateFieldFormat
***************

Type
    :doc:`/reusable-types/CodeValueType/index`
Cardinality
    0..1

Describes the format of the date field, in formats such as YYYY/MM or MM-DD-YY, etc. If this element is omitted, then the format is assumed to be the XML Schema format corresponding to the type attribute value.

DateTypeCode
************

Type
    :doc:`/reusable-types/CodeValueType/index`
Cardinality
    0..1

This is a standard XML date type code and supports the use of an external controlled vocabulary. Examples are date, dateTime, gYearMonth, gYear, and duration

RegExp
******

Type
    string
Cardinality
    0..1

The regular expression allows for further description of the allowable content of the data.



