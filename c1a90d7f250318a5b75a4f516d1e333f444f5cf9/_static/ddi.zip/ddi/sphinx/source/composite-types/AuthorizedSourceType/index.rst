AuthorizedSourceType
--------------------

A stack of LocationValueReferences to each of the locations of the specified PrimaryComponentLevel type that make up the Component Area. Includes a GeographicTime to allow for repetition for change over time.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* AbstractIdentifiableType
    * :doc:`/reusable-types/IdentifiableType/index`
        * :doc:`/reusable-types/OtherMaterialType/index`
            * **AuthorizedSourceType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/AuthorizedSourceType.svg

Properties
~~~~~~~~~~

IdentifierParsingInformation
****************************

Type
    :doc:`/reusable-types/IdentifierParsingInformationType/index`
Cardinality
    0..1

Provides structural information for parsing the identification code structure of the Authorized Source into its separate parts.



