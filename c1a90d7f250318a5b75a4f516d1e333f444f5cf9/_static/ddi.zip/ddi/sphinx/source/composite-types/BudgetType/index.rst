BudgetType
----------

A description of the budget for any of the main publication types that can contain a reference to an external budget document.

.. contents::

Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/BudgetType.svg

Properties
~~~~~~~~~~

Description
***********

Type
    :doc:`/reusable-types/StructuredStringType/index`
Cardinality
    0..1

A description of the overall budget of the project. Supports structured content including tables.

BudgetDocument
**************

Type
    :doc:`/reusable-types/OtherMaterialType/index`
Cardinality
    0..n

References to one or more external budget documents.



