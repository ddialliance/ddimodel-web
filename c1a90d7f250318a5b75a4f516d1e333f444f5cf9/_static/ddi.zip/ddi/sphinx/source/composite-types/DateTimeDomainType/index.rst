DateTimeDomainType
------------------

A response domain capturing a date or time response for a question item. Contains the equivalent content of a DateTimeRepresentation including the format of the date field, a DateTypeCode, and restriction of content using a regular expression. Adds a set of elements available to all Response Domains; Label, Description, OutParameter, designation of response cardinality, and a declaration of an offset date for the data content. Has an equivalent DateTimeDomainReference which references a ManagedTextRepresentation.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/reusable-types/RepresentationType/index`
    * :doc:`/reusable-types/DateTimeRepresentationBaseType/index`
        * **DateTimeDomainType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/DateTimeDomainType.svg

Properties
~~~~~~~~~~

Label
*****

Type
    :doc:`/reusable-types/LabelType/index`
Cardinality
    0..n

A display label for the domain. May be expressed in multiple languages. Repeat for labels with different content, for example, labels with differing length limitations.

Description
***********

Type
    :doc:`/reusable-types/StructuredStringType/index`
Cardinality
    0..1

A description of the content and purpose of the domain. May be expressed in multiple languages and supports the use of structured content.

OutParameter
************

Type
    :doc:`/reusable-types/ParameterType/index`
Cardinality
    0..1

Allows for the response to be bound to one of the QuestionItem's OutParameters, so the collected information can be used elsewhere, for example as inputs to subsequent questions in an Instrument or to a GenerationInstruction. If multiple responses are possible, this would represent and ordered array of the responses.

ResponseCardinality
*******************

Type
    :doc:`/reusable-types/ResponseCardinalityType/index`
Cardinality
    0..1

Allows the designation of the minimum and maximum number of responses allowed for this response domain.

ContentDateOffset
*****************

Type
    :doc:`/reusable-types/ContentDateOffsetType/index`
Cardinality
    0..1

Identifies the difference between the date applied to the data as a whole and this specific item such as previous year's income or residence 5 years ago.



