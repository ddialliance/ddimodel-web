AttributeType
-------------

An attribute may be any object which should be attached to all or part of the NCube. It may be defined as a Variable or contain textual content (such as a footnote).

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* AbstractIdentifiableType
    * :doc:`/reusable-types/IdentifiableType/index`
        * **AttributeType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/AttributeType.svg

Properties
~~~~~~~~~~

VariableReference
*****************

Type
    :doc:`/item-types/Variable/index`
Cardinality
    0..1

A reference to a variable that describes the attribute.

AttachmentValue
***************

Type
    string
Cardinality
    0..1

The value of the attachment expressed as a string, if not a variable.

AttachmentRegionReference
*************************

Type
    :doc:`/reusable-types/CoordinateRegionType/index`
Cardinality
    0..1

Reference to the CoordinateRegion that defines the attachment point for the attribute.

MeasureDefinitionReference
**************************

Type
    :doc:`/reusable-types/MeasureDefinitionType/index`
Cardinality
    0..n

Reference to the MeasureDefinition that the attribute is attached to.

Value
*****

Type
    :doc:`/reusable-types/ValueType/index`
Cardinality
    0..n

Reference to the specified Value of the MeasureDefinition that the attribute is attached to.

AttachmentLevel
***************

Type
    string
Cardinality
    0..1

Describes the attachment level of the attribute as Cube, CoordinateRegion, Dimension, Measurement, or MeasurementValue.



