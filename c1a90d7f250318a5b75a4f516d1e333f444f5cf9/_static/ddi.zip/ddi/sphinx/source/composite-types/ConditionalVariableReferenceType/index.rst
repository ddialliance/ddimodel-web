ConditionalVariableReferenceType
--------------------------------

Value of variable indicating this record type, multiple entries allow for multiple valid values or ranges. Includes a reference to the variable an the specified related value. TypeOfObject should be set to Variabele.

.. contents::

Item Type Hierarchy
~~~~~~~~~~~~~~~~~~~

* :doc:`/reusable-types/ReferenceType/index`
    * **ConditionalVariableReferenceType**


Relationships
~~~~~~~~~~~~~
.. container:: image

   |stub|

.. |stub| image:: ../../images/ConditionalVariableReferenceType.svg

Properties
~~~~~~~~~~

RelatedValue
************

Type
    :doc:`/reusable-types/RelatedValueType/index`
Cardinality
    0..1

Use to specify the value of variable for which this is a case specification (i.e., GeoLevel in the example for Case Specification).



