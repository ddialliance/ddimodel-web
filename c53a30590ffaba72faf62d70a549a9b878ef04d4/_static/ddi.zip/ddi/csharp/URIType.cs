using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A URN or URL for a file with a flag to indicate if it is a public copy.
    /// <summary>
    public partial class URIType
    {
        /// <summary>
        /// 
        /// <summary>
        public Uri AnyURIValue { get; set; }
        /// <summary>
        /// Set to "true" (default value) if this file is publicly available. This does not imply that there are not restrictions to access. Set to "false" if this is not publicly available, such as a backup copy, an internal processing data file, etc.
        /// <summary>
        public bool IsPublic { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (AnyURIValue != null)
            {
                xEl.Add(new XElement(ns + "AnyURIValue", AnyURIValue));
            }
            xEl.Add(new XElement(ns + "IsPublic", IsPublic));
            return xEl;
        }
    }
}

