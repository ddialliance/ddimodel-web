using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes an if-then-else decision type for conditional text. IF the stated condition is met, the THEN clause is trigged, otherwise the ELSE clause is triggered. Contains an IfCondition (the condition that must be met to trigger the Then clause), a ThenResult (indicating the ConditionalResult to invoke if the condition is met), an ElseResult (indicating the construct to invoke if the condition is not met), and an ElseIfText structure allowing the expression of multiple conditions to invoke multiple branching.
    /// <summary>
    public partial class IfThenElseTextType
    {
        /// <summary>
        /// The condition which must be met to trigger the Then clause, expressed as a CommandCode. The condition is an expression in the programming language used in the instrument.
        /// <summary>
        public CommandCodeType IfCondition { get; set; }
        /// <summary>
        /// The conditional response which should be triggered if the associated condition is met.
        /// <summary>
        public ConditionalResultType ThenResult { get; set; }
        /// <summary>
        /// Use for multiple branching from a single point in the flow logic represented by the flow logic If, Then, ElseIf, Then, etc.
        /// <summary>
        public List<ElseIfTextType> ElseIfText { get; set; } = new List<ElseIfTextType>();
        public bool ShouldSerializeElseIfText() { return ElseIfText.Count > 0; }
        /// <summary>
        /// The conditional response which should be triggered if the associated condition is not met.
        /// <summary>
        public ConditionalResultType ElseResult { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (IfCondition != null) { xEl.Add(IfCondition.ToXml("IfCondition")); }
            if (ThenResult != null) { xEl.Add(ThenResult.ToXml("ThenResult")); }
            if (ElseIfText != null && ElseIfText.Count > 0)
            {
                foreach (var item in ElseIfText)
                {
                    xEl.Add(item.ToXml("ElseIfText"));
                }
            }
            if (ElseResult != null) { xEl.Add(ElseResult.ToXml("ElseResult")); }
            return xEl;
        }
    }
}

