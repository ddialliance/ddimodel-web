using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Description and link to the Publication using the DDI Other Material structure.
    /// <summary>
    public partial class PublicationType
    {
        /// <summary>
        /// Description and link to the Publication using the DDI Other Material structure.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public OtherMaterial OtherMaterialReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (OtherMaterialReference != null)
            {
                xEl.Add(new XElement(ns + "OtherMaterialReference", 
                    new XElement(ns + "URN", OtherMaterialReference.URN), 
                    new XElement(ns + "Agency", OtherMaterialReference.Agency), 
                    new XElement(ns + "ID", OtherMaterialReference.ID), 
                    new XElement(ns + "Version", OtherMaterialReference.Version), 
                    new XElement(ns + "TypeOfObject", OtherMaterialReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

