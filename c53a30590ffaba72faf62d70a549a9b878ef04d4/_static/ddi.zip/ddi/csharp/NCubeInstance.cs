using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A container for defining an instance of an NCube, indicating the matrix address of each cell and where the data for each measure within a cell of the NCube is stored. Allows specifying the values of the attributes attached to a NCube.
    /// <summary>
    public partial class NCubeInstance : Versionable
    {
        /// <summary>
        /// Reference to the logical NCube description.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public NCube NCubeReference { get; set; }
        /// <summary>
        /// This element defines the structure of a measure dimension for the NCube Instance. A value along the MeasureDimension is defined by a stack of references to one or more MeasureDefinitions found in the logical description of the NCube with each containing an attribute of orderValue which provides its value for use in the cell address (similar to the use of a CodeRepresentation of a Variable used as a conceptual dimension. This allows measures (whether one or several) to be handled in the same way as the conceptual dimension of the NCube in declaring a cell address. It is assumed that the value of the MeasureDimension is the last value in the address array. For example, for an NCube with 3 conceptual dimensions of rank 1 = Sex, rank 2 = Age, and rank 3 = Educational Attainment, plus a MeasureDimension. The cell address of 1,4,2,2 would indicate Code value of 1 for Sex, 4 for Age, 2 for Educational Attainment, and 2 for MeasureDimension. For systems translating to SDMX or an OLap structure DDI assumes that the MeasureDefinitionReference with the orderValue="1" is the equivalent of the PrimaryMeasure.
        /// <summary>
        public MeasureDimensionType MeasureDimension { get; set; }
        /// <summary>
        /// This is an attribute attached to the NCube as a whole or a region of the NCube as defined in the logical description as a CoordinateRegion. The content of the attribute can be provided as a single value or reference a location in the data store where the attribute value will be found. This may be in addition to attribute information described in the logical structure.
        /// <summary>
        public List<AttachedAttributeType> AttachedAttribute { get; set; } = new List<AttachedAttributeType>();
        public bool ShouldSerializeAttachedAttribute() { return AttachedAttribute.Count > 0; }
        /// <summary>
        /// Describes a single data item or cell within an NCube Instance. It defines its location within the NCube by its coordinate (matrix) address which is its intersect point on each dimension. Allows for the specification of data item specific attributes, and identifies the physical location of each measure for the data item. May optionally indicate the language of the data contents.
        /// <summary>
        public List<DataItemNType> DataItemN { get; set; } = new List<DataItemNType>();
        public bool ShouldSerializeDataItemN() { return DataItemN.Count > 0; }
        /// <summary>
        /// An explicit definition of the data type that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. This field is necessary in the case of some numeric data formats where the format definition would allow real values, but the values are integer values. Allowed values are: integer (default), real, string.
        /// <summary>
        public CodeValueType DefaultDataType { get; set; }
        /// <summary>
        /// Delimiter definition for delimited (free field) data that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: Empty (default), Tab, Blank, AnyString. If a delimiter is used, free field (delimited data) is assumed; binary formats are not allowed.
        /// <summary>
        public DelimiterType DefaultDelimiter { get; set; }
        /// <summary>
        /// Number of decimal places for data with an implied decimal separator that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Another expression is the decimal scaling factor (SAS). Default: 0.
        /// <summary>
        public int DefaultDecimalPositions { get; set; }
        /// <summary>
        /// The character used to separate the integer and the fraction part of a number (if an explicit separator is used in the data) that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: None (default), Dot, Comma, Other. On the basis of the data definition in DDI documents, data processing tools could compute the necessary precision width on the basis of the format width and the existence of separators. Appropriate data types could be used, i.e. float or double, short or long. The decimal separator definition only makes sense with some XML Schema primitives. This is a default which may be overridden in specific cases.
        /// <summary>
        [StringLength(1)]
        public string DefaultDecimalSeparator { get; set; }
        /// <summary>
        /// The character used to separate groups of digits (if an explicit separator is used in the data) that is applied to the majority of the data items reducing the amount of repetitive markup required. It can be overridden at the data item level. Allowed values are: None (default), Dot, Comma, Other. The decimal separator definition makes only sense with some XML Schema primitives. This is a default which may be overridden in specific cases.
        /// <summary>
        [StringLength(1)]
        public string DefaultDigitGroupSeparator { get; set; }
        /// <summary>
        /// Total number of cases represented by the contents of the NCube. This is normally the sum of the cell contents when the NCube contains counts and sub-totals are not included.
        /// <summary>
        public int NumberOfCases { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "NCubeInstance");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (NCubeReference != null)
            {
                xEl.Add(new XElement(ns + "NCubeReference", 
                    new XElement(ns + "URN", NCubeReference.URN), 
                    new XElement(ns + "Agency", NCubeReference.Agency), 
                    new XElement(ns + "ID", NCubeReference.ID), 
                    new XElement(ns + "Version", NCubeReference.Version), 
                    new XElement(ns + "TypeOfObject", NCubeReference.GetType().Name)));
            }
            if (MeasureDimension != null) { xEl.Add(MeasureDimension.ToXml("MeasureDimension")); }
            if (AttachedAttribute != null && AttachedAttribute.Count > 0)
            {
                foreach (var item in AttachedAttribute)
                {
                    xEl.Add(item.ToXml("AttachedAttribute"));
                }
            }
            if (DataItemN != null && DataItemN.Count > 0)
            {
                foreach (var item in DataItemN)
                {
                    xEl.Add(item.ToXml("DataItemN"));
                }
            }
            if (DefaultDataType != null) { xEl.Add(DefaultDataType.ToXml("DefaultDataType")); }
            if (DefaultDelimiter != null) { xEl.Add(DefaultDelimiter.ToXml("DefaultDelimiter")); }
            xEl.Add(new XElement(ns + "DefaultDecimalPositions", DefaultDecimalPositions));
            if (DefaultDecimalSeparator != null)
            {
                xEl.Add(new XElement(ns + "DefaultDecimalSeparator", DefaultDecimalSeparator));
            }
            if (DefaultDigitGroupSeparator != null)
            {
                xEl.Add(new XElement(ns + "DefaultDigitGroupSeparator", DefaultDigitGroupSeparator));
            }
            xEl.Add(new XElement(ns + "NumberOfCases", NumberOfCases));
            return xEl;
        }
    }
}

