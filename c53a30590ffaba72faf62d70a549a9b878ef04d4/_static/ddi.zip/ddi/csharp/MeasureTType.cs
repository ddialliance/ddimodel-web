using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the specific measure of the cell designating the order value of the Measure within the MeasureDimension and provides information on the storage location of the value for the measure. When individual measures are stored in separately identifiable locations repeat Measure to define each measure and storage location. When multiple measures are stored as an ordered array in a single location list each  in the array as a MeasureDimensionValue with its specified arrayOrder within a single Measure definition.
    /// <summary>
    public partial class MeasureTType
    {
        /// <summary>
        /// Specifies the orderValue of the Measure in the MeasureDimension described in the NCubeInstance along with its arrayOrder if multiple measures are provided as an array in a single storage location.
        /// <summary>
        public List<MeasureDimensionValueType> MeasureDimensionValue { get; set; } = new List<MeasureDimensionValueType>();
        public bool ShouldSerializeMeasureDimensionValue() { return MeasureDimensionValue.Count > 0; }
        /// <summary>
        /// Description of the physical location of the measure value(s) in the data file.
        /// <summary>
        public PhysicalTableLocationType PhysicalTableLocation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MeasureDimensionValue != null && MeasureDimensionValue.Count > 0)
            {
                foreach (var item in MeasureDimensionValue)
                {
                    xEl.Add(item.ToXml("MeasureDimensionValue"));
                }
            }
            if (PhysicalTableLocation != null) { xEl.Add(PhysicalTableLocation.ToXml("PhysicalTableLocation")); }
            return xEl;
        }
    }
}

