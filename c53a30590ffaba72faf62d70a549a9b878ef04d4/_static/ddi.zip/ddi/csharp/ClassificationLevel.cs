using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A Statistical Classification has a structure which is composed of one or several Levels. A Level often is associated with a concept, which defines it. In a hierarchical Statistical Classification the Classification Items of each Level but the highest are aggregated to the nearest higher Level. A linear Statistical Classification has only one Level. 
    /// <summary>
    public partial class ClassificationLevel : Describable
    {
        /// <summary>
        /// Indicates whether the code at the Level is alphabetical, numerical or alphanumerical. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType LevelCodeType { get; set; }
        /// <summary>
        /// Indicates how the code at the Level is constructed of numbers, letters and separators. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType LevelCodeStructure { get; set; }
        /// <summary>
        /// Rule for the construction of dummy codes from the codes of the next higher Level (used when one or several categories are the same in two consecutive Levels). Supports the use of multiple languages and structured content.
        /// <summary>
        public StructuredStringType DummyCode { get; set; }
        /// <summary>
        /// A concept which describes the level. TypeOfObject should be set to Concept.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Concept> DefiningConceptReference { get; set; } = new List<Concept>();
        public bool ShouldSerializeDefiningConceptReference() { return DefiningConceptReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ClassificationLevel");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (LevelCodeType != null) { xEl.Add(LevelCodeType.ToXml("LevelCodeType")); }
            if (LevelCodeStructure != null) { xEl.Add(LevelCodeStructure.ToXml("LevelCodeStructure")); }
            if (DummyCode != null) { xEl.Add(DummyCode.ToXml("DummyCode")); }
            if (DefiningConceptReference != null && DefiningConceptReference.Count > 0)
            {
                foreach (var item in DefiningConceptReference)
                {
                    xEl.Add(new XElement(ns + "DefiningConceptReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

