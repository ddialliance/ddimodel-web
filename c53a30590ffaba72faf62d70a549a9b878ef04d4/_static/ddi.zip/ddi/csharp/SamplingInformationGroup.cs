using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A grouping of Sampling Information objects for administrative purposes. Contains a group of sampling information objects and/or sampling information groups, which may be hierarchical.
    /// <summary>
    public partial class SamplingInformationGroup : Versionable
    {
        /// <summary>
        /// A generic element for specifying a reason for a sampling information group. Note that this element can contain either a term from a controlled vocabulary list or a textual description.
        /// <summary>
        public CodeValueType TypeOfSamplingInformationGroup { get; set; }
        /// <summary>
        /// A name for the sampling information group. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> SamplingInformationGroupName { get; set; } = new List<NameType>();
        public bool ShouldSerializeSamplingInformationGroupName() { return SamplingInformationGroupName.Count > 0; }
        /// <summary>
        /// A display label for the sampling information group. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// Additional textual description of the sampling information group. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to the universe statement describing the persons or other elements that the sampling information objects refer to, and to which any analytic results refer.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }
        /// <summary>
        /// Reference to the concept measured by the sampling information objects in this group.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Concept ConceptReference { get; set; }
        /// <summary>
        /// A sample frame item included in the scheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SampleFrame SampleFrameReference { get; set; }
        /// <summary>
        /// A sampling plan item included in the scheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingPlan SamplingPlanReference { get; set; }
        /// <summary>
        /// A sample included in the scheme by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Sample SampleReference { get; set; }
        /// <summary>
        /// Inclusion of a SamplingInformationGroup by reference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public SamplingInformationGroup SamplingInformationGroupReference { get; set; }
        /// <summary>
        /// Indicates that the content of the group is ordered as it appears within the XML structure.
        /// <summary>
        public bool IsOrdered { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "SamplingInformationGroup");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfSamplingInformationGroup != null) { xEl.Add(TypeOfSamplingInformationGroup.ToXml("TypeOfSamplingInformationGroup")); }
            if (SamplingInformationGroupName != null && SamplingInformationGroupName.Count > 0)
            {
                foreach (var item in SamplingInformationGroupName)
                {
                    xEl.Add(item.ToXml("SamplingInformationGroupName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ConceptReference != null)
            {
                xEl.Add(new XElement(ns + "ConceptReference", 
                    new XElement(ns + "URN", ConceptReference.URN), 
                    new XElement(ns + "Agency", ConceptReference.Agency), 
                    new XElement(ns + "ID", ConceptReference.ID), 
                    new XElement(ns + "Version", ConceptReference.Version), 
                    new XElement(ns + "TypeOfObject", ConceptReference.GetType().Name)));
            }
            if (SampleFrameReference != null)
            {
                xEl.Add(new XElement(ns + "SampleFrameReference", 
                    new XElement(ns + "URN", SampleFrameReference.URN), 
                    new XElement(ns + "Agency", SampleFrameReference.Agency), 
                    new XElement(ns + "ID", SampleFrameReference.ID), 
                    new XElement(ns + "Version", SampleFrameReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleFrameReference.GetType().Name)));
            }
            if (SamplingPlanReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingPlanReference", 
                    new XElement(ns + "URN", SamplingPlanReference.URN), 
                    new XElement(ns + "Agency", SamplingPlanReference.Agency), 
                    new XElement(ns + "ID", SamplingPlanReference.ID), 
                    new XElement(ns + "Version", SamplingPlanReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingPlanReference.GetType().Name)));
            }
            if (SampleReference != null)
            {
                xEl.Add(new XElement(ns + "SampleReference", 
                    new XElement(ns + "URN", SampleReference.URN), 
                    new XElement(ns + "Agency", SampleReference.Agency), 
                    new XElement(ns + "ID", SampleReference.ID), 
                    new XElement(ns + "Version", SampleReference.Version), 
                    new XElement(ns + "TypeOfObject", SampleReference.GetType().Name)));
            }
            if (SamplingInformationGroupReference != null)
            {
                xEl.Add(new XElement(ns + "SamplingInformationGroupReference", 
                    new XElement(ns + "URN", SamplingInformationGroupReference.URN), 
                    new XElement(ns + "Agency", SamplingInformationGroupReference.Agency), 
                    new XElement(ns + "ID", SamplingInformationGroupReference.ID), 
                    new XElement(ns + "Version", SamplingInformationGroupReference.Version), 
                    new XElement(ns + "TypeOfObject", SamplingInformationGroupReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "IsOrdered", IsOrdered));
            return xEl;
        }
    }
}

