using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describe the population through a combination of textual description and reference to a structured Universe. If multiple universes are referenced, the overall universe is the intersect of the set of universes referenced.
    /// <summary>
    public partial class PopulationType
    {
        /// <summary>
        /// A textual description of the population. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// A reference to a structured Universe description.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Universe> UniverseReference { get; set; } = new List<Universe>();
        public bool ShouldSerializeUniverseReference() { return UniverseReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (UniverseReference != null && UniverseReference.Count > 0)
            {
                foreach (var item in UniverseReference)
                {
                    xEl.Add(new XElement(ns + "UniverseReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

