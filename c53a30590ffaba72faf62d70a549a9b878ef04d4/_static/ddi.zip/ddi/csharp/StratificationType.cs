using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describe all stratifications here. Note that each stratified group will be sampled using the same sampling plan. For example stratifying a state by ZIP Code areas in each of 5 mean income quintiles and then doing a random sample of the households in set of ZIP Codes. Allows for oversampling of identified subpopulations. Example: urban/rural, gender, state, marital status. Might be defined at the SamplngScheme level.
    /// <summary>
    public partial class StratificationType
    {
        /// <summary>
        /// Describe the purpose for stratifying your sample frame prior to sampling.
        /// <summary>
        public StratificationRationaleType StratificationRationale { get; set; }
        /// <summary>
        /// Method to determine how the sample should be allocated/distributed (Source: US Census Metadata Standard document)
        /// <summary>
        public StructuredStringType AllocationMethod { get; set; }
        /// <summary>
        /// Assign a number to the strata being described
        /// <summary>
        public int StrataNumber { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (StratificationRationale != null) { xEl.Add(StratificationRationale.ToXml("StratificationRationale")); }
            if (AllocationMethod != null) { xEl.Add(AllocationMethod.ToXml("AllocationMethod")); }
            xEl.Add(new XElement(ns + "StrataNumber", StrataNumber));
            return xEl;
        }
    }
}

