using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A set of Processing Instructions (General and Generation Instructions) maintained by an agency. In addition to the standard name, label, and description allows for the inclusion of an existing ProcessingInstructionScheme by reference, and GeneralInstruction, GenerationInstruction, and ProcessingInstructionGroup descriptions either in-line or by reference.
    /// <summary>
    public partial class ProcessingInstructionScheme : Maintainable
    {
        /// <summary>
        /// A name for the ProcessingInstructionScheme. May be expressed in multiple languages. Repeat the element to express names with different content, for example different names for different systems.
        /// <summary>
        public List<NameType> ProcessingInstructionSchemeName { get; set; } = new List<NameType>();
        public bool ShouldSerializeProcessingInstructionSchemeName() { return ProcessingInstructionSchemeName.Count > 0; }
        /// <summary>
        /// A display label for the ProcessingInstructionScheme. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the ProcessingInstructionScheme. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Reference to an existing ProcessingInstructionScheme for inclusion.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingInstructionScheme> ProcessingInstructionSchemeReference { get; set; } = new List<ProcessingInstructionScheme>();
        public bool ShouldSerializeProcessingInstructionSchemeReference() { return ProcessingInstructionSchemeReference.Count > 0; }
        /// <summary>
        /// A General Instruction described in the Processing Instruction Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GeneralInstruction> GeneralInstructionReference { get; set; } = new List<GeneralInstruction>();
        public bool ShouldSerializeGeneralInstructionReference() { return GeneralInstructionReference.Count > 0; }
        /// <summary>
        /// A Generation Instruction described in the Processing Instruction Scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<GenerationInstruction> GenerationInstructionReference { get; set; } = new List<GenerationInstruction>();
        public bool ShouldSerializeGenerationInstructionReference() { return GenerationInstructionReference.Count > 0; }
        /// <summary>
        /// A description of a group of ProcessingInstructions for administrative or conceptual purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ProcessingInstructionGroup> ProcessingInstructionGroupReference { get; set; } = new List<ProcessingInstructionGroup>();
        public bool ShouldSerializeProcessingInstructionGroupReference() { return ProcessingInstructionGroupReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ProcessingInstructionScheme");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ProcessingInstructionSchemeName != null && ProcessingInstructionSchemeName.Count > 0)
            {
                foreach (var item in ProcessingInstructionSchemeName)
                {
                    xEl.Add(item.ToXml("ProcessingInstructionSchemeName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (ProcessingInstructionSchemeReference != null && ProcessingInstructionSchemeReference.Count > 0)
            {
                foreach (var item in ProcessingInstructionSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GeneralInstructionReference != null && GeneralInstructionReference.Count > 0)
            {
                foreach (var item in GeneralInstructionReference)
                {
                    xEl.Add(new XElement(ns + "GeneralInstructionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (GenerationInstructionReference != null && GenerationInstructionReference.Count > 0)
            {
                foreach (var item in GenerationInstructionReference)
                {
                    xEl.Add(new XElement(ns + "GenerationInstructionReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ProcessingInstructionGroupReference != null && ProcessingInstructionGroupReference.Count > 0)
            {
                foreach (var item in ProcessingInstructionGroupReference)
                {
                    xEl.Add(new XElement(ns + "ProcessingInstructionGroupReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

