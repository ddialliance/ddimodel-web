using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// The location of the data item within a two-dimensional (spreadsheet) storage format.
    /// <summary>
    public partial class PhysicalTableLocationType : PhysicalLocationType
    {
        /// <summary>
        /// Column in which data item is found. This is an integer defined in relationship to a specified "first" column NOT the column identifier found in the spreadsheet. Begin numbering columns from the upper left corner of the table as defined in TopLeftTableAnchor attribute "column".
        /// <summary>
        public int ColumnNumber { get; set; }
        /// <summary>
        /// A single case may be represented on a single row or a series of rows, particularly when multiple measures are used. This element designates the row, with the assumption that there is a single row per case unless otherwise stated.
        /// <summary>
        public int RowSequence { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("PhysicalLocationType").Descendants())
            {
                xEl.Add(el);
            }
            xEl.Add(new XElement(ns + "ColumnNumber", ColumnNumber));
            xEl.Add(new XElement(ns + "RowSequence", RowSequence));
            return xEl;
        }
    }
}

