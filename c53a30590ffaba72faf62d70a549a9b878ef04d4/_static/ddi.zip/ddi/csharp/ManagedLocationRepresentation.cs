using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Means of describing the Location of an action and the action itself within a repesentation so that they can be used by questions as a response domain. In addition to the basic objects of the representation, the structure briefly describes the object type upon which the action is to take place and the action to take (where an how to mark the object).
    /// <summary>
    public partial class ManagedLocationRepresentation : ManagedRepresentation
    {
        /// <summary>
        /// A name for the ManagedLocationRepresentation. May be expressed in multiple languages. Repeat the element to express names with different content, for example, different names for different systems.
        /// <summary>
        public List<NameType> ManagedLocationRepresentationName { get; set; } = new List<NameType>();
        public bool ShouldSerializeManagedLocationRepresentationName() { return ManagedLocationRepresentationName.Count > 0; }
        /// <summary>
        /// A display label for the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content. Repeat for labels with different content, for example, labels with differing length limitations.
        /// <summary>
        public List<LabelType> Label { get; set; } = new List<LabelType>();
        public bool ShouldSerializeLabel() { return Label.Count > 0; }
        /// <summary>
        /// A description of the content and purpose of the ManagedTextRepresentation. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// This field provides the recommended treatment of the data within an application. The value should come from a controlled vocabulary - recommended values include the set found in W3C XML Schema Part 2, but excluding string sub-types, QNAME, and NOTATION. The DDI Alliance has provided a controlled vocabulary (DataType) to support this element at http://www.ddialliance.org/controlled-vocabularies.
        /// <summary>
        public CodeValueType RecommendedDataType { get; set; }
        /// <summary>
        /// This field provides a recommended generic treatment of the data for display by an application. The value should come from a controlled vocabulary.
        /// <summary>
        public CodeValueType GenericOutputFormat { get; set; }
        /// <summary>
        /// Records the measurement unit, for example, 'km', 'miles', etc. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MeasurementUnit { get; set; }
        /// <summary>
        /// The type of object on which the action takes place such as an image, audio tape, etc. Allows for the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType Object { get; set; }
        /// <summary>
        /// Describes the region of an image, recording, or text where an action where a specified action is performed and the type of action taken (i.e., Mark an "X" where the actor should be standing on the picture of the stage.).
        /// <summary>
        public List<ActionType> Action { get; set; } = new List<ActionType>();
        public bool ShouldSerializeAction() { return Action.Count > 0; }
        /// <summary>
        /// Indicates the type of relationship, nominal, ordinal, interval, ratio, or continuous. Use where appropriate for the representation type.
        /// <summary>
        [StringValidation(new string[] {
            "Nominal"
,             "Ordinal"
,             "Interval"
,             "Ratio"
,             "Continuous"
        })]
        public string ClassificationLevel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "ManagedLocationRepresentation");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (ManagedLocationRepresentationName != null && ManagedLocationRepresentationName.Count > 0)
            {
                foreach (var item in ManagedLocationRepresentationName)
                {
                    xEl.Add(item.ToXml("ManagedLocationRepresentationName"));
                }
            }
            if (Label != null && Label.Count > 0)
            {
                foreach (var item in Label)
                {
                    xEl.Add(item.ToXml("Label"));
                }
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (RecommendedDataType != null) { xEl.Add(RecommendedDataType.ToXml("RecommendedDataType")); }
            if (GenericOutputFormat != null) { xEl.Add(GenericOutputFormat.ToXml("GenericOutputFormat")); }
            if (MeasurementUnit != null) { xEl.Add(MeasurementUnit.ToXml("MeasurementUnit")); }
            if (Object != null) { xEl.Add(Object.ToXml("Object")); }
            if (Action != null && Action.Count > 0)
            {
                foreach (var item in Action)
                {
                    xEl.Add(item.ToXml("Action"));
                }
            }
            if (ClassificationLevel != null)
            {
                xEl.Add(new XElement(ns + "ClassificationLevel", ClassificationLevel));
            }
            return xEl;
        }
    }
}

