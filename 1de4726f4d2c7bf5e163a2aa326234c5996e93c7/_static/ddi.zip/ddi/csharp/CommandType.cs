using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides the following information on the command: The content of the command, the programming language used, the pieces of information (InParameters) used by the command, the pieces of information created by the command (OutParameters) and the source of the information used by the InParameters (Binding).
    /// <summary>
    public partial class CommandType
    {
        /// <summary>
        /// Designates the programming language used for the command. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType ProgramLanguage { get; set; }
        /// <summary>
        /// Describes the information used by the command as it is identified within the command structure.
        /// <summary>
        public List<InParameterType> InParameter { get; set; } = new List<InParameterType>();
        public bool ShouldSerializeInParameter() { return InParameter.Count > 0; }
        /// <summary>
        /// Describes the information that results from the command that may be used as input by another object.
        /// <summary>
        public List<ParameterType> OutParameter { get; set; } = new List<ParameterType>();
        public bool ShouldSerializeOutParameter() { return OutParameter.Count > 0; }
        /// <summary>
        /// Defines the link between the output of an external object to an InParameter described above.
        /// <summary>
        public List<BindingType> Binding { get; set; } = new List<BindingType>();
        public bool ShouldSerializeBinding() { return Binding.Count > 0; }
        /// <summary>
        /// Content of the command itself expressed in the language designated in Programming Language.
        /// <summary>
        public string CommandContent { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ProgramLanguage != null) { xEl.Add(ProgramLanguage.ToXml("ProgramLanguage")); }
            if (InParameter != null && InParameter.Count > 0)
            {
                foreach (var item in InParameter)
                {
                    xEl.Add(item.ToXml("InParameter"));
                }
            }
            if (OutParameter != null && OutParameter.Count > 0)
            {
                foreach (var item in OutParameter)
                {
                    xEl.Add(item.ToXml("OutParameter"));
                }
            }
            if (Binding != null && Binding.Count > 0)
            {
                foreach (var item in Binding)
                {
                    xEl.Add(item.ToXml("Binding"));
                }
            }
            if (CommandContent != null)
            {
                xEl.Add(new XElement(ns + "CommandContent", CommandContent));
            }
            return xEl;
        }
    }
}

