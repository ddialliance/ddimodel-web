using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the role of Target Individual or Organization in relation to the Source Object. Provides a description and classification of the role, the period for which the role was valid, and any additional information relevent to the role.
    /// <summary>
    public partial class RoleType
    {
        /// <summary>
        /// Description of the role played by the Target Object in relationship to the Source Object.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Keyword used to classify the role of the organization or individual in relationship to the Source Object
        /// <summary>
        public List<InternationalCodeValueType> Keyword { get; set; } = new List<InternationalCodeValueType>();
        public bool ShouldSerializeKeyword() { return Keyword.Count > 0; }
        /// <summary>
        /// Time period when this role is/was valid.
        /// <summary>
        public List<DateType> EffectivePeriod { get; set; } = new List<DateType>();
        public bool ShouldSerializeEffectivePeriod() { return EffectivePeriod.Count > 0; }
        /// <summary>
        /// Any information not captured by the other descriptive objects. The privacy code may be set to indicate access restriction to this information. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public List<AdditionalInformationType> AdditionalInformation { get; set; } = new List<AdditionalInformationType>();
        public bool ShouldSerializeAdditionalInformation() { return AdditionalInformation.Count > 0; }
        /// <summary>
        /// A basic set of privacy codes for the parent element. These may be stricter than the general access restrictions for the overall metadata. If available codes are insufficient this may also contain any string.
        /// <summary>
        [StringValidation(new string[] {
            "public"
,             "restricted"
,             "private"
        })]
        public string Privacy { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Keyword != null && Keyword.Count > 0)
            {
                foreach (var item in Keyword)
                {
                    xEl.Add(item.ToXml("Keyword"));
                }
            }
            if (EffectivePeriod != null && EffectivePeriod.Count > 0)
            {
                foreach (var item in EffectivePeriod)
                {
                    xEl.Add(item.ToXml("EffectivePeriod"));
                }
            }
            if (AdditionalInformation != null && AdditionalInformation.Count > 0)
            {
                foreach (var item in AdditionalInformation)
                {
                    xEl.Add(item.ToXml("AdditionalInformation"));
                }
            }
            if (Privacy != null)
            {
                xEl.Add(new XElement(ns + "Privacy", Privacy));
            }
            return xEl;
        }
    }
}

