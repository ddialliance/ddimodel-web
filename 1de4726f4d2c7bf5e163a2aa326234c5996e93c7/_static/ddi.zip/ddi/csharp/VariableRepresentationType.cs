using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes the representation of the variable in the data set. Describes the function of the variable, variables or standard weights that may be used to weight this variable during analysis, imputation and processing information, other variables used to create the value of this variable through concatenation, valid value representations (valid for analysis of respondents), missing value representations, aggregation methods used to generate the content of the variable, and additivity information.
    /// <summary>
    public partial class VariableRepresentationType
    {
        /// <summary>
        /// Describes a specific function of the variable, such as identity, weight, geographic variable, time, date, currency, etc. This is a more extensive means of identifying the function of the variable than the Boolean indicators on the variable. Allows for agency specific designations. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType VariableRole { get; set; }
        /// <summary>
        /// Reference to one or more weight variables that may be used in analyzing this variable.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<Variable> WeightVariableReference { get; set; } = new List<Variable>();
        public bool ShouldSerializeWeightVariableReference() { return WeightVariableReference.Count > 0; }
        /// <summary>
        /// Reference to the StandardWeight found in the Weighting description, which is relevant for analyzing this variable. A standard weight is a single weight used for all variables of a specific type or for a specified sub-universe.
        /// <summary>
        public StandardWeightType StandardWeightReference { get; set; }
        /// <summary>
        /// An attribute may be any object which should be attached to or coupled with a Variable such as a related suppression flag, source flag, footnote, etc. It may be defined as a Variable or contain textual content (such as a footnote).
        /// <summary>
        public List<VariableAttributeType> VariableAttribute { get; set; } = new List<VariableAttributeType>();
        public bool ShouldSerializeVariableAttribute() { return VariableAttribute.Count > 0; }
        /// <summary>
        /// Reference to the imputation process described as a General Instruction in a ProcessingInstructionScheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstruction ImputationReference { get; set; }
        /// <summary>
        /// Provides a reference to other variables and describes the method for deriving the value of this variable by concatenating a collection of other variables. This is useful in creating concatenated keys.
        /// <summary>
        public ConcatenatedValueType ConcatenatedValue { get; set; }
        /// <summary>
        /// A reference to either a general or generation instruction that was provided to those who converted information from one form to another to create a particular variable. This might include the reordering of numeric information into another form or the conversion of textual information into numeric information. TypeOfObject should be set to GeneralInstruction or GenerationInstruction.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ProcessingInstruction ProcessingInstructionReference { get; set; }
        /// <summary>
        /// Describes the actual representation of the variables' values. Allows for the listing of values to be treated as missing in order to support 3.1 structures. The preferred method is the use of a reference to ManagedMissingValues description using MissingValuesReference. If both are used and there is a conflict in the content, MissingValuesReference will override the content provided in the ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(SubstitutionConverter))]
        public RepresentationType ValueRepresentation { get; set; }
        /// <summary>
        /// Allows for the use of a ManagedRepresentation by reference. ValueRepresentationReference is the abstract head of a substitution group and may be replaced with any valid substitution for ValueRepresentationReference.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ValueRepresentationReference { get; set; }
        /// <summary>
        /// Reference to an existing MissingValuesRepresentation using the Reference structure. If this content conflicts with content provided in the ValueRepresentation regarding Missing Values. The content of the MissingValuesRepresentation overrides. TypeOfObject will be MissingValuesRepresentation
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation MissingValuesReference { get; set; }
        /// <summary>
        /// Identifies the difference between the date applied to the data as a whole and this specific item such as previous year's income or residence 5 years ago.
        /// <summary>
        public ContentDateOffsetType ContentDateOffset { get; set; }
        /// <summary>
        /// Indicates the type of aggregation method used. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType AggregationMethod { get; set; }
        /// <summary>
        /// Records type of additivity, such as 'stock', 'flow', 'non-additive'.
        /// <summary>
        [StringValidation(new string[] {
            "Stock"
,             "Flow"
,             "NonAdditive"
        })]
        public string Additivity { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (VariableRole != null) { xEl.Add(VariableRole.ToXml("VariableRole")); }
            if (WeightVariableReference != null && WeightVariableReference.Count > 0)
            {
                foreach (var item in WeightVariableReference)
                {
                    xEl.Add(new XElement(ns + "WeightVariableReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (StandardWeightReference != null) { xEl.Add(StandardWeightReference.ToXml("StandardWeightReference")); }
            if (VariableAttribute != null && VariableAttribute.Count > 0)
            {
                foreach (var item in VariableAttribute)
                {
                    xEl.Add(item.ToXml("VariableAttribute"));
                }
            }
            if (ImputationReference != null)
            {
                xEl.Add(new XElement(ns + "ImputationReference", 
                    new XElement(ns + "URN", ImputationReference.URN), 
                    new XElement(ns + "Agency", ImputationReference.Agency), 
                    new XElement(ns + "ID", ImputationReference.ID), 
                    new XElement(ns + "Version", ImputationReference.Version), 
                    new XElement(ns + "TypeOfObject", ImputationReference.GetType().Name)));
            }
            if (ConcatenatedValue != null) { xEl.Add(ConcatenatedValue.ToXml("ConcatenatedValue")); }
            if (ProcessingInstructionReference != null)
            {
                xEl.Add(new XElement(ns + "ProcessingInstructionReference", 
                    new XElement(ns + "URN", ProcessingInstructionReference.URN), 
                    new XElement(ns + "Agency", ProcessingInstructionReference.Agency), 
                    new XElement(ns + "ID", ProcessingInstructionReference.ID), 
                    new XElement(ns + "Version", ProcessingInstructionReference.Version), 
                    new XElement(ns + "TypeOfObject", ProcessingInstructionReference.GetType().Name)));
            }
            if (ValueRepresentation != null) { xEl.Add(ValueRepresentation.ToXml("ValueRepresentation")); }
            if (ValueRepresentationReference != null)
            {
                xEl.Add(new XElement(ns + "ValueRepresentationReference", 
                    new XElement(ns + "URN", ValueRepresentationReference.URN), 
                    new XElement(ns + "Agency", ValueRepresentationReference.Agency), 
                    new XElement(ns + "ID", ValueRepresentationReference.ID), 
                    new XElement(ns + "Version", ValueRepresentationReference.Version), 
                    new XElement(ns + "TypeOfObject", ValueRepresentationReference.GetType().Name)));
            }
            if (MissingValuesReference != null)
            {
                xEl.Add(new XElement(ns + "MissingValuesReference", 
                    new XElement(ns + "URN", MissingValuesReference.URN), 
                    new XElement(ns + "Agency", MissingValuesReference.Agency), 
                    new XElement(ns + "ID", MissingValuesReference.ID), 
                    new XElement(ns + "Version", MissingValuesReference.Version), 
                    new XElement(ns + "TypeOfObject", MissingValuesReference.GetType().Name)));
            }
            if (ContentDateOffset != null) { xEl.Add(ContentDateOffset.ToXml("ContentDateOffset")); }
            if (AggregationMethod != null) { xEl.Add(AggregationMethod.ToXml("AggregationMethod")); }
            if (Additivity != null)
            {
                xEl.Add(new XElement(ns + "Additivity", Additivity));
            }
            return xEl;
        }
    }
}

