using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Identifies the default missing value parameter for the this logical record by referencing a ManagedMissingValuesRepresentation or by stating that there is a default missing values parameter used but it is undocumented. Note that a conflicting DefaultMissingValues definition in a PhysicalInstance will override that found in the LogicalRecord.
    /// <summary>
    public partial class DefaultMissingValuesType
    {
        /// <summary>
        /// Reference to the appropriate ManagedMissingValuesRepresentation describing the default values.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedMissingValuesRepresentation MissingValuesReference { get; set; }
        /// <summary>
        /// Use when it is known that a default missing values definition was use but there is NO documentation describing its content.
        /// <summary>
        public bool DefaultUsedNoDocumentation { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (MissingValuesReference != null)
            {
                xEl.Add(new XElement(ns + "MissingValuesReference", 
                    new XElement(ns + "URN", MissingValuesReference.URN), 
                    new XElement(ns + "Agency", MissingValuesReference.Agency), 
                    new XElement(ns + "ID", MissingValuesReference.ID), 
                    new XElement(ns + "Version", MissingValuesReference.Version), 
                    new XElement(ns + "TypeOfObject", MissingValuesReference.GetType().Name)));
            }
            xEl.Add(new XElement(ns + "DefaultUsedNoDocumentation", DefaultUsedNoDocumentation));
            return xEl;
        }
    }
}

