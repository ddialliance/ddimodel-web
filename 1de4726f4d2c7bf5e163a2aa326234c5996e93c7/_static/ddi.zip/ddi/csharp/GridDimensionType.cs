using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes each dimension of the grid including dimension rank (for the purpose of identifying a cell address), a text for the dimension, and optional labels and codes used as column and row stubs. May also describe a roster (a set of unlabeled rows or columns depending upon display situation).
    /// <summary>
    public partial class GridDimensionType
    {
        /// <summary>
        /// This includes a reference to a CodeList that is used for the labels contained in the dimension. CodeLists are used even when the code is not being displayed in order to use this information for creating the cell coordinate address.
        /// <summary>
        public CodeDomainType CodeDomain { get; set; }
        /// <summary>
        /// A roster is an unlabeled list of numbered rows or columns depending upon orientation. The numbers may or may not be displayed but will be used as information for creating the cell coordinate address.
        /// <summary>
        public RosterType Roster { get; set; }
        /// <summary>
        /// The rank order of this dimension (the order in which the value for this dimension will appear in the cell address)denoted with a 1-based indexing. Provides coordinate order (1,2,n) for the intersect point of this dimension within the cell address. For example, if the rank of this dimension is 2, the intersect point on this dimension will be the second value listed in the cell address.
        /// <summary>
        public int Rank { get; set; }
        /// <summary>
        /// If set to "true" (default value) the code value associated with the category label will be displayed. Set to "false" if only the category label should not be displayed.
        /// <summary>
        public bool DisplayCode { get; set; }
        /// <summary>
        /// If set to "true" (default value) the label of the CodeList will be displayed. Set to "false" to suppress this display.
        /// <summary>
        public bool DisplayLabel { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (CodeDomain != null) { xEl.Add(CodeDomain.ToXml("CodeDomain")); }
            if (Roster != null) { xEl.Add(Roster.ToXml("Roster")); }
            xEl.Add(new XElement(ns + "Rank", Rank));
            xEl.Add(new XElement(ns + "DisplayCode", DisplayCode));
            xEl.Add(new XElement(ns + "DisplayLabel", DisplayLabel));
            return xEl;
        }
    }
}

