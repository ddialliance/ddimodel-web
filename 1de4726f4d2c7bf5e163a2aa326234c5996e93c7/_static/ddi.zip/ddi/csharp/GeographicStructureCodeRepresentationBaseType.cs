using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Allows for the use of all or part of a GeographicStructure description to be used as a response domain or value representation by a question or variable. In addition to the basic objects of a representation it describes the Geographic Structure values available for use by the question or variable.
    /// <summary>
    public partial class GeographicStructureCodeRepresentationBaseType : RepresentationType
    {
        /// <summary>
        /// Identifies the Geographic Structure codes included by the Authorized source of the code, the Geographic Structure being used and the Structures to exclude.
        /// <summary>
        public IncludedGeographicStructureCodesType IncludedGeographicStructureCodes { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("RepresentationType").Descendants())
            {
                xEl.Add(el);
            }
            if (IncludedGeographicStructureCodes != null) { xEl.Add(IncludedGeographicStructureCodes.ToXml("IncludedGeographicStructureCodes")); }
            return xEl;
        }
    }
}

