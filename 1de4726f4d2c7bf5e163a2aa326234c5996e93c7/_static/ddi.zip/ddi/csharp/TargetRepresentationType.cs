using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Provides a reference to a codified representation. Supports the ability to limit code coverage as appropriate for the coding structure referenced.
    /// <summary>
    public partial class TargetRepresentationType
    {
        /// <summary>
        /// Substitution group head for referencing Managed Representations. For example, ManagedTextRepresentationReference, ManagedNumericRepresentationReference, etc.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public ManagedRepresentation ManagedRepresentationReference { get; set; }
        /// <summary>
        /// A reference to a CategoryScheme as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CategoryScheme CategorySchemeReference { get; set; }
        /// <summary>
        /// A reference to a CodeList as the managed component of a representation.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public CodeList CodeListReference { get; set; }
        /// <summary>
        /// Allows further specification of the codes to use from the CodeList.
        /// <summary>
        public CodeSubsetInformationType CodeSubsetInformation { get; set; }
        /// <summary>
        /// Identifies the Geographic Structure codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicStructureCodesType IncludedGeographicStructureCodes { get; set; }
        /// <summary>
        /// Identifies the Geographic Location codes included by the Authorized source of the code, the geographic location being used and the locations to exclude.
        /// <summary>
        public IncludedGeographicLocationCodesType IncludedGeographicLocationCodes { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (ManagedRepresentationReference != null)
            {
                xEl.Add(new XElement(ns + "ManagedRepresentationReference", 
                    new XElement(ns + "URN", ManagedRepresentationReference.URN), 
                    new XElement(ns + "Agency", ManagedRepresentationReference.Agency), 
                    new XElement(ns + "ID", ManagedRepresentationReference.ID), 
                    new XElement(ns + "Version", ManagedRepresentationReference.Version), 
                    new XElement(ns + "TypeOfObject", ManagedRepresentationReference.GetType().Name)));
            }
            if (CategorySchemeReference != null)
            {
                xEl.Add(new XElement(ns + "CategorySchemeReference", 
                    new XElement(ns + "URN", CategorySchemeReference.URN), 
                    new XElement(ns + "Agency", CategorySchemeReference.Agency), 
                    new XElement(ns + "ID", CategorySchemeReference.ID), 
                    new XElement(ns + "Version", CategorySchemeReference.Version), 
                    new XElement(ns + "TypeOfObject", CategorySchemeReference.GetType().Name)));
            }
            if (CodeListReference != null)
            {
                xEl.Add(new XElement(ns + "CodeListReference", 
                    new XElement(ns + "URN", CodeListReference.URN), 
                    new XElement(ns + "Agency", CodeListReference.Agency), 
                    new XElement(ns + "ID", CodeListReference.ID), 
                    new XElement(ns + "Version", CodeListReference.Version), 
                    new XElement(ns + "TypeOfObject", CodeListReference.GetType().Name)));
            }
            if (CodeSubsetInformation != null) { xEl.Add(CodeSubsetInformation.ToXml("CodeSubsetInformation")); }
            if (IncludedGeographicStructureCodes != null) { xEl.Add(IncludedGeographicStructureCodes.ToXml("IncludedGeographicStructureCodes")); }
            if (IncludedGeographicLocationCodes != null) { xEl.Add(IncludedGeographicLocationCodes.ToXml("IncludedGeographicLocationCodes")); }
            return xEl;
        }
    }
}

