using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// OtherMaterialType describes the structure of the OtherMaterial element, used to reference external resources. It includes citations to materials related to the content of the DDI Instance. This includes citations to such material, an external reference to a URL (or other URI), and a statement about the relationship between the cited OtherMaterial the contents of the DDI instance.
    /// <summary>
    public partial class OtherMaterial : Versionable
    {
        /// <summary>
        /// Designation of the type of material being described. Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfMaterial { get; set; }
        /// <summary>
        /// A description of the referenced material. This field can map to a Dublin Core abstract. Note that Dublin Core does not support structure within the abstract element. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Bibliographic citation for the external resource.
        /// <summary>
        public CitationType Citation { get; set; }
        /// <summary>
        /// Contains a URL which indicates the location of the cited external resource.
        /// <summary>
        public List<Uri> ExternalURLReference { get; set; } = new List<Uri>();
        public bool ShouldSerializeExternalURLReference() { return ExternalURLReference.Count > 0; }
        /// <summary>
        /// Contains a URN which identifies the cited external resource.
        /// <summary>
        public Uri ExternalURNReference { get; set; }
        /// <summary>
        /// Reference to the item within the DDI Instance to which the external resource is related.
        /// <summary>
        public List<RelationshipType> Relationship { get; set; } = new List<RelationshipType>();
        public bool ShouldSerializeRelationship() { return Relationship.Count > 0; }
        /// <summary>
        /// Provides a standard Internet MIME type for use by processing applications.
        /// <summary>
        public CodeValueType MIMEType { get; set; }
        /// <summary>
        /// Can describe a segment within a larger object such as a text or video segment.
        /// <summary>
        public List<SegmentType> Segment { get; set; } = new List<SegmentType>();
        public bool ShouldSerializeSegment() { return Segment.Count > 0; }
        /// <summary>
        /// Specifies the size of the file in bytes.
        /// <summary>
        public int SizeInBytes { get; set; }
        /// <summary>
        /// Language of the metadata describing the other material.
        /// <summary>
        public string Lang { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "OtherMaterial");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (TypeOfMaterial != null) { xEl.Add(TypeOfMaterial.ToXml("TypeOfMaterial")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (Citation != null) { xEl.Add(Citation.ToXml("Citation")); }
            if (ExternalURLReference != null && ExternalURLReference.Count > 0)
            {
                foreach (var item in ExternalURLReference)
                {
                    xEl.Add(new XElement(ns + "ExternalURLReference", item));
                }
            }
            if (ExternalURNReference != null)
            {
                xEl.Add(new XElement(ns + "ExternalURNReference", ExternalURNReference));
            }
            if (Relationship != null && Relationship.Count > 0)
            {
                foreach (var item in Relationship)
                {
                    xEl.Add(item.ToXml("Relationship"));
                }
            }
            if (MIMEType != null) { xEl.Add(MIMEType.ToXml("MIMEType")); }
            if (Segment != null && Segment.Count > 0)
            {
                foreach (var item in Segment)
                {
                    xEl.Add(item.ToXml("Segment"));
                }
            }
            xEl.Add(new XElement(ns + "SizeInBytes", SizeInBytes));
            if (Lang != null)
            {
                xEl.Add(new XElement(ns + "Lang", Lang));
            }
            return xEl;
        }
    }
}

