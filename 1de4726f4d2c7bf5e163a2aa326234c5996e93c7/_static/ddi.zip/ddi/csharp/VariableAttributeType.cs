using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// An attribute may be any other Variable which should be attached to or coupled with a Variable such as a weight, filter, or other related variable. The VariableAttribute may be typed using a Controlled Vocabulary structure.
    /// <summary>
    public partial class VariableAttributeType
    {
        /// <summary>
        /// A brief textual identification of the variable attribute type. Supports the use of an external controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfVariableAttribute { get; set; }
        /// <summary>
        /// A reference to a variable that describes the attribute.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public Variable VariableReference { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfVariableAttribute != null) { xEl.Add(TypeOfVariableAttribute.ToXml("TypeOfVariableAttribute")); }
            if (VariableReference != null)
            {
                xEl.Add(new XElement(ns + "VariableReference", 
                    new XElement(ns + "URN", VariableReference.URN), 
                    new XElement(ns + "Agency", VariableReference.Agency), 
                    new XElement(ns + "ID", VariableReference.ID), 
                    new XElement(ns + "Version", VariableReference.Version), 
                    new XElement(ns + "TypeOfObject", VariableReference.GetType().Name)));
            }
            return xEl;
        }
    }
}

