using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Describes available aids for translation typed by a controlled vocabulary and a description.
    /// <summary>
    public partial class ModeOfPretestCollectionType
    {
        /// <summary>
        /// Specifies the type of data collection mode used (i.e. interview, self-completed form, observation). Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType TypeOfPretestCollectionMode { get; set; }
        /// <summary>
        /// Description of mode of data collection for the pretest. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }
        /// <summary>
        /// Method of delivery for the pretest mode (i.e., mail, hand-delivery, etc.). Supports the use of a controlled vocabulary.
        /// <summary>
        public CodeValueType MethodOfDelivery { get; set; }
        /// <summary>
        /// A value of true indicates that this is the primary mode of data collection.
        /// <summary>
        public bool IsPrimary { get; set; }
        /// <summary>
        /// A value of true indicates that an audio format of the question text is available.
        /// <summary>
        public bool IsAudioFormatAvailable { get; set; }
        /// <summary>
        /// A value of true indicates that the interview is recorded.
        /// <summary>
        public bool IsRecordedInterview { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            if (TypeOfPretestCollectionMode != null) { xEl.Add(TypeOfPretestCollectionMode.ToXml("TypeOfPretestCollectionMode")); }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            if (MethodOfDelivery != null) { xEl.Add(MethodOfDelivery.ToXml("MethodOfDelivery")); }
            xEl.Add(new XElement(ns + "IsPrimary", IsPrimary));
            xEl.Add(new XElement(ns + "IsAudioFormatAvailable", IsAudioFormatAvailable));
            xEl.Add(new XElement(ns + "IsRecordedInterview", IsRecordedInterview));
            return xEl;
        }
    }
}

