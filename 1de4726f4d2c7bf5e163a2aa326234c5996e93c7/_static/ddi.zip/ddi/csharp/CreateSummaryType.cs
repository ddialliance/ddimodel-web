using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// Note that this is generally usable only with single valid response domain in grid. More complex uses should be carefully documented using details in CommandCode and Input/output Parameters.
    /// <summary>
    public partial class CreateSummaryType : CommandCodeType
    {
        /// <summary>
        /// Label for the summary type used.
        /// <summary>
        public LabelType Label { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            foreach (var el in base.ToXml("CommandCodeType").Descendants())
            {
                xEl.Add(el);
            }
            if (Label != null) { xEl.Add(Label.ToXml("Label")); }
            return xEl;
        }
    }
}

