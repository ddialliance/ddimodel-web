using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A module describing the logical (intellectual) contents of the quantitative data. It is a member of the substitution group BaseLogicalProduct and contains all of the common features of the BaseLogicalProduct as well as content specific to quantitative data. This is a member of the BaseLogicalProduct substitution group and in addition to the content inherited from the BaseLogicalProduct, contains CategorySchemes, CodeListSchemes, ManagedRepresentationSchemes, RepresentedVariableSchemes, VariableSchemes an NCubeSchemes both in-line an by reference.
    /// <summary>
    public partial class LogicalProduct : BaseLogicalProduct
    {
        /// <summary>
        /// Contains descriptions of particular categories used as question responses and in the logical product. Their relationships and code values are described in the code scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CategoryScheme> CategorySchemeReference { get; set; } = new List<CategoryScheme>();
        public bool ShouldSerializeCategorySchemeReference() { return CategorySchemeReference.Count > 0; }
        /// <summary>
        /// Lists the code values used to represent categories for a variable or question. Also describes hierarchical relationships between categories used in the code scheme.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<CodeListScheme> CodeListSchemeReference { get; set; } = new List<CodeListScheme>();
        public bool ShouldSerializeCodeListSchemeReference() { return CodeListSchemeReference.Count > 0; }
        /// <summary>
        /// A scheme containing representations that are being managed as reusable sources for response domains and value representations.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<ManagedRepresentationScheme> ManagedRepresentationSchemeReference { get; set; } = new List<ManagedRepresentationScheme>();
        public bool ShouldSerializeManagedRepresentationSchemeReference() { return ManagedRepresentationSchemeReference.Count > 0; }
        /// <summary>
        /// A set of RepresentedVariables managed by an agency. RepresentedVariables are the core reusable parts of a Variable. RepresentedVariable maps to the GSIM Represented Variable. In addition to the standard name, label, and description, allows for the inclusion of an existing RepresentedVariableScheme by reference and RepresentedVariables either in-line or by reference. RepresentedVariables may be grouped for management purposes.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<RepresentedVariableScheme> RepresentedVariableSchemeReference { get; set; } = new List<RepresentedVariableScheme>();
        public bool ShouldSerializeRepresentedVariableSchemeReference() { return RepresentedVariableSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a collection of variables and variable groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<VariableScheme> VariableSchemeReference { get; set; } = new List<VariableScheme>();
        public bool ShouldSerializeVariableSchemeReference() { return VariableSchemeReference.Count > 0; }
        /// <summary>
        /// Contains a collection of NCubes and NCube groups.
        /// <summary>
        [JsonConverter(typeof(IIdentifiableConverter))]
        public List<NCubeScheme> NCubeSchemeReference { get; set; } = new List<NCubeScheme>();
        public bool ShouldSerializeNCubeSchemeReference() { return NCubeSchemeReference.Count > 0; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public override XElement ToXml()
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + "LogicalProduct");
            foreach (var el in base.ToXml().Descendants())
            {
                xEl.Add(el);
            }
            if (CategorySchemeReference != null && CategorySchemeReference.Count > 0)
            {
                foreach (var item in CategorySchemeReference)
                {
                    xEl.Add(new XElement(ns + "CategorySchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (CodeListSchemeReference != null && CodeListSchemeReference.Count > 0)
            {
                foreach (var item in CodeListSchemeReference)
                {
                    xEl.Add(new XElement(ns + "CodeListSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (ManagedRepresentationSchemeReference != null && ManagedRepresentationSchemeReference.Count > 0)
            {
                foreach (var item in ManagedRepresentationSchemeReference)
                {
                    xEl.Add(new XElement(ns + "ManagedRepresentationSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (RepresentedVariableSchemeReference != null && RepresentedVariableSchemeReference.Count > 0)
            {
                foreach (var item in RepresentedVariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "RepresentedVariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (VariableSchemeReference != null && VariableSchemeReference.Count > 0)
            {
                foreach (var item in VariableSchemeReference)
                {
                    xEl.Add(new XElement(ns + "VariableSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            if (NCubeSchemeReference != null && NCubeSchemeReference.Count > 0)
            {
                foreach (var item in NCubeSchemeReference)
                {
                    xEl.Add(new XElement(ns + "NCubeSchemeReference", 
                        new XElement(ns + "URN", item.URN), 
                        new XElement(ns + "Agency", item.Agency), 
                        new XElement(ns + "ID", item.ID), 
                        new XElement(ns + "Version", item.Version), 
                        new XElement(ns + "TypeOfObject", item.GetType().Name)));
                }
            }
            return xEl;
        }
    }
}

