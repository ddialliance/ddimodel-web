using System;
using System.Linq;
using Newtonsoft.Json;
using System.Xml.Linq;
using Cogs.SimpleTypes;
using System.Reflection;
using System.Collections;
using Newtonsoft.Json.Linq;
using Cogs.DataAnnotations;
using Cogs.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ddi
{
    /// <summary>
    /// A specific rate of response and/or a description of the rate of response for a specific processing event that includes data appraisal.
    /// <summary>
    public partial class ResponseRateType
    {
        /// <summary>
        /// The size of the sample from whom data was requested.
        /// <summary>
        public int SampleSize { get; set; }
        /// <summary>
        /// The number of responses within the specified sample.
        /// <summary>
        public int NumberOfResponses { get; set; }
        /// <summary>
        /// The specific rate of response expressed as a percent.
        /// <summary>
        public decimal SpecificResponseRate { get; set; }
        /// <summary>
        /// A description of the rate of response including any information pertinent to understanding the specified rate of response. Supports multiple language versions of the same content as well as optional formatting of the content.
        /// <summary>
        public StructuredStringType Description { get; set; }

        /// <summary>
        /// Used to Serialize this object to XML
        /// <summary>
        public virtual XElement ToXml(string name)
        {
            XNamespace ns = "Ddi.Model";
            XElement xEl = new XElement(ns + name);
            xEl.Add(new XElement(ns + "SampleSize", SampleSize));
            xEl.Add(new XElement(ns + "NumberOfResponses", NumberOfResponses));
            if (SpecificResponseRate != null)
            {
                xEl.Add(new XElement(ns + "SpecificResponseRate", SpecificResponseRate));
            }
            if (Description != null) { xEl.Add(Description.ToXml("Description")); }
            return xEl;
        }
    }
}

